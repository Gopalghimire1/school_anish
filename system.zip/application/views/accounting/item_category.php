<section class="panel">
	<div class="tabs-custom">
		<ul class="nav nav-tabs">
			<li class="active">
				<a href="#list" data-toggle="tab"><i class="fas fa-list-ul"></i> <?php echo translate('item') . " " . translate('category'); ?></a>
			</li>
		</ul>
		<div class="tab-content">
			<div id="list" class="tab-pane active">
			    <div class="row">
			        <div class="col-md-5">
            		<section class="panel">
			        <header class="panel-heading">
				        <h4 class="panel-title"><i class="far fa-edit"></i> <?php echo translate('add') . " " . translate('item') . " " . translate('category'); ?></h4>
			        </header>
        				<?php echo form_open('accounting/item_category', array('class' => 'form-horizontal form-bordered frm-submit')); ?>
        				<div class="panel-body">
    					<?php if (is_superadmin_loggedin()): ?>
	    				<div class="form-group">
		    				<label class="col-md-3 control-label"><?=translate('branch')?> <span class="required">*</span></label>
			    			<div class="col-md-6">
				    			<?php
					    			$arrayBranch = $this->app_lib->getSelectList('branch');
						    		echo form_dropdown("branch_id", $arrayBranch, "", "class='form-control' id='branch_id'
							    	id='branch_id' data-plugin-selectTwo data-width='100%' data-minimum-results-for-search='Infinity'");
    							?>
	    						<span class="error"></span>
		    				</div>
			    		</div>
				    	<?php endif; ?>
					    <div class="form-group">
						    <label class="col-md-4 control-label"><?=translate('category') . " " . translate('name')?> <span class="required">*</span></label>
    						<div class="col-md-6">
	    						<input type="text" class="form-control" name="category" value="<?php echo set_value('category'); ?>" placeholder="Category.." required/>
		    					<span class="error"></span>
			    			</div>
				    	</div>
				    	<footer class="panel-footer mt-lg">
    						<div class="row">
	    						<div class="col-md-12">
		    						<button type="submit" class="btn btn-default pull-right" data-loading-text="<i class='fas fa-spinner fa-spin'></i> Processing">
			    						<i class="fas fa-plus-circle"></i> <?php echo translate('save'); ?>
				    				</button>
					    		</div>
						    </div>	
				        </footer>
				        </div>
				    	<?php echo form_close(); ?>
				    	</section>
	                </div>
		            <div class="col-md-7">
		                <div class="mb-md">
					        <div class="export_title"><?php echo translate('item') . " " . translate('category'); ?></div>
					        <table class="table table-bordered table-hover table-condensed table-export">
					    	    <thead>
					    		    <tr>
					    			    <th width="50"><?php echo translate('sl'); ?></th>
				    		            <?php if (is_superadmin_loggedin()): ?>
					    			    <th><?=translate('branch')?></th>
					    		        <?php endif; ?>
					    			    <th><?php echo translate('category'); ?></th>
				    			        <th><?php echo translate('action'); ?></th>
					    		    </tr>
					    	    </thead>
					    	    <tbody>
					    		    <?php 
					    		    $count = 1; foreach ($categorylist as $row):
					    		    ?>
					    		    <tr>
					    			    <td><?php echo $count++; ?></td>
					    	        <?php if (is_superadmin_loggedin()): ?>
					    			    <td><?php echo $row['branch_name']; ?></td>
					    	        <?php endif; ?>
					    			    <td><?php echo $row['category']; ?></td>
					    			    <td>
					    				    <?php if (get_permission('account', 'is_delete')): ?>
				    					    <?php echo btn_delete('accounting/item_category_delete/' . $row['id']); ?>
					    				    <?php endif; ?>
					    			    </td>
					    		    </tr>
					    		    <?php endforeach; ?>
					    	    </tbody>
					        </table>
				        </div>
		            </div>
			    </div>
			</div>
		</div>
	</div>
</section>