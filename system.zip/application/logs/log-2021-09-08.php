<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-09-08 07:44:09 --> Config Class Initialized
INFO - 2021-09-08 07:44:09 --> Hooks Class Initialized
DEBUG - 2021-09-08 07:44:10 --> UTF-8 Support Enabled
INFO - 2021-09-08 07:44:10 --> Utf8 Class Initialized
INFO - 2021-09-08 07:44:10 --> URI Class Initialized
INFO - 2021-09-08 07:44:10 --> Router Class Initialized
INFO - 2021-09-08 07:44:10 --> Output Class Initialized
INFO - 2021-09-08 07:44:10 --> Security Class Initialized
DEBUG - 2021-09-08 07:44:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-08 07:44:10 --> CSRF cookie sent
INFO - 2021-09-08 07:44:10 --> Input Class Initialized
INFO - 2021-09-08 07:44:10 --> Language Class Initialized
INFO - 2021-09-08 07:44:10 --> Loader Class Initialized
INFO - 2021-09-08 07:44:10 --> Helper loaded: url_helper
INFO - 2021-09-08 07:44:10 --> Helper loaded: file_helper
INFO - 2021-09-08 07:44:10 --> Helper loaded: form_helper
INFO - 2021-09-08 07:44:10 --> Helper loaded: security_helper
INFO - 2021-09-08 07:44:11 --> Helper loaded: directory_helper
INFO - 2021-09-08 07:44:11 --> Helper loaded: general_helper
INFO - 2021-09-08 07:44:11 --> Database Driver Class Initialized
INFO - 2021-09-08 07:44:11 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-08 07:44:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-08 07:44:11 --> Pagination Class Initialized
INFO - 2021-09-08 07:44:12 --> XML-RPC Class Initialized
INFO - 2021-09-08 07:44:12 --> Form Validation Class Initialized
INFO - 2021-09-08 07:44:12 --> Upload Class Initialized
INFO - 2021-09-08 07:44:12 --> MY_Model class loaded
INFO - 2021-09-08 07:44:12 --> Model "Application_model" initialized
INFO - 2021-09-08 07:44:12 --> Controller Class Initialized
DEBUG - 2021-09-08 07:44:12 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-08 07:44:12 --> Helper loaded: inflector_helper
INFO - 2021-09-08 07:44:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-08 07:44:12 --> Database Driver Class Initialized
ERROR - 2021-09-08 07:44:12 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-08 07:44:12 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-08 07:44:12 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-08 07:44:12 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-08 07:44:12 --> Final output sent to browser
DEBUG - 2021-09-08 07:44:12 --> Total execution time: 3.2379
INFO - 2021-09-08 07:45:04 --> Config Class Initialized
INFO - 2021-09-08 07:45:04 --> Hooks Class Initialized
DEBUG - 2021-09-08 07:45:04 --> UTF-8 Support Enabled
INFO - 2021-09-08 07:45:04 --> Utf8 Class Initialized
INFO - 2021-09-08 07:45:04 --> URI Class Initialized
INFO - 2021-09-08 07:45:04 --> Router Class Initialized
INFO - 2021-09-08 07:45:04 --> Output Class Initialized
INFO - 2021-09-08 07:45:04 --> Security Class Initialized
DEBUG - 2021-09-08 07:45:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-08 07:45:04 --> CSRF cookie sent
INFO - 2021-09-08 07:45:04 --> Input Class Initialized
INFO - 2021-09-08 07:45:04 --> Language Class Initialized
INFO - 2021-09-08 07:45:04 --> Loader Class Initialized
INFO - 2021-09-08 07:45:04 --> Helper loaded: url_helper
INFO - 2021-09-08 07:45:04 --> Helper loaded: file_helper
INFO - 2021-09-08 07:45:04 --> Helper loaded: form_helper
INFO - 2021-09-08 07:45:04 --> Helper loaded: security_helper
INFO - 2021-09-08 07:45:04 --> Helper loaded: directory_helper
INFO - 2021-09-08 07:45:04 --> Helper loaded: general_helper
INFO - 2021-09-08 07:45:04 --> Database Driver Class Initialized
INFO - 2021-09-08 07:45:04 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-08 07:45:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-08 07:45:04 --> Pagination Class Initialized
INFO - 2021-09-08 07:45:04 --> XML-RPC Class Initialized
INFO - 2021-09-08 07:45:04 --> Form Validation Class Initialized
INFO - 2021-09-08 07:45:04 --> Upload Class Initialized
INFO - 2021-09-08 07:45:04 --> MY_Model class loaded
INFO - 2021-09-08 07:45:04 --> Model "Application_model" initialized
INFO - 2021-09-08 07:45:04 --> Controller Class Initialized
DEBUG - 2021-09-08 07:45:04 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-08 07:45:04 --> Helper loaded: inflector_helper
INFO - 2021-09-08 07:45:04 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-08 07:45:04 --> Database Driver Class Initialized
ERROR - 2021-09-08 07:45:04 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-08 07:45:04 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-08 07:45:04 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-08 07:45:04 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-08 07:45:04 --> Final output sent to browser
DEBUG - 2021-09-08 07:45:04 --> Total execution time: 0.1229
INFO - 2021-09-08 08:06:23 --> Config Class Initialized
INFO - 2021-09-08 08:06:23 --> Hooks Class Initialized
DEBUG - 2021-09-08 08:06:23 --> UTF-8 Support Enabled
INFO - 2021-09-08 08:06:23 --> Utf8 Class Initialized
INFO - 2021-09-08 08:06:24 --> URI Class Initialized
INFO - 2021-09-08 08:06:24 --> Router Class Initialized
INFO - 2021-09-08 08:06:24 --> Output Class Initialized
INFO - 2021-09-08 08:06:24 --> Security Class Initialized
DEBUG - 2021-09-08 08:06:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-08 08:06:24 --> CSRF cookie sent
INFO - 2021-09-08 08:06:24 --> Input Class Initialized
INFO - 2021-09-08 08:06:24 --> Language Class Initialized
INFO - 2021-09-08 08:06:24 --> Loader Class Initialized
INFO - 2021-09-08 08:06:24 --> Helper loaded: url_helper
INFO - 2021-09-08 08:06:24 --> Helper loaded: file_helper
INFO - 2021-09-08 08:06:24 --> Helper loaded: form_helper
INFO - 2021-09-08 08:06:24 --> Helper loaded: security_helper
INFO - 2021-09-08 08:06:25 --> Helper loaded: directory_helper
INFO - 2021-09-08 08:06:25 --> Helper loaded: general_helper
INFO - 2021-09-08 08:06:25 --> Database Driver Class Initialized
INFO - 2021-09-08 08:06:25 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-08 08:06:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-08 08:06:25 --> Pagination Class Initialized
INFO - 2021-09-08 08:06:25 --> XML-RPC Class Initialized
INFO - 2021-09-08 08:06:25 --> Form Validation Class Initialized
INFO - 2021-09-08 08:06:25 --> Upload Class Initialized
INFO - 2021-09-08 08:06:25 --> MY_Model class loaded
INFO - 2021-09-08 08:06:25 --> Model "Application_model" initialized
INFO - 2021-09-08 08:06:25 --> Controller Class Initialized
INFO - 2021-09-08 08:06:26 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\errors/error_404_message.php
INFO - 2021-09-08 08:06:26 --> Final output sent to browser
DEBUG - 2021-09-08 08:06:26 --> Total execution time: 2.8372
INFO - 2021-09-08 08:06:41 --> Config Class Initialized
INFO - 2021-09-08 08:06:41 --> Hooks Class Initialized
DEBUG - 2021-09-08 08:06:41 --> UTF-8 Support Enabled
INFO - 2021-09-08 08:06:41 --> Utf8 Class Initialized
INFO - 2021-09-08 08:06:41 --> URI Class Initialized
INFO - 2021-09-08 08:06:41 --> Router Class Initialized
INFO - 2021-09-08 08:06:41 --> Output Class Initialized
INFO - 2021-09-08 08:06:41 --> Security Class Initialized
DEBUG - 2021-09-08 08:06:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-08 08:06:41 --> CSRF cookie sent
INFO - 2021-09-08 08:06:41 --> Input Class Initialized
INFO - 2021-09-08 08:06:41 --> Language Class Initialized
INFO - 2021-09-08 08:06:41 --> Loader Class Initialized
INFO - 2021-09-08 08:06:41 --> Helper loaded: url_helper
INFO - 2021-09-08 08:06:41 --> Helper loaded: file_helper
INFO - 2021-09-08 08:06:41 --> Helper loaded: form_helper
INFO - 2021-09-08 08:06:41 --> Helper loaded: security_helper
INFO - 2021-09-08 08:06:41 --> Helper loaded: directory_helper
INFO - 2021-09-08 08:06:41 --> Helper loaded: general_helper
INFO - 2021-09-08 08:06:41 --> Database Driver Class Initialized
INFO - 2021-09-08 08:06:41 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-08 08:06:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-08 08:06:41 --> Pagination Class Initialized
INFO - 2021-09-08 08:06:41 --> XML-RPC Class Initialized
INFO - 2021-09-08 08:06:41 --> Form Validation Class Initialized
INFO - 2021-09-08 08:06:41 --> Upload Class Initialized
INFO - 2021-09-08 08:06:41 --> MY_Model class loaded
INFO - 2021-09-08 08:06:41 --> Model "Application_model" initialized
INFO - 2021-09-08 08:06:41 --> Controller Class Initialized
DEBUG - 2021-09-08 08:06:41 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-08 08:06:41 --> Helper loaded: inflector_helper
INFO - 2021-09-08 08:06:41 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-08 08:06:41 --> Database Driver Class Initialized
ERROR - 2021-09-08 08:06:41 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-08 08:06:41 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-08 08:06:41 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-08 08:06:41 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-08 08:06:41 --> Severity: Warning --> call_user_func_array() expects parameter 1 to be a valid callback, class 'Parents' does not have a method 'index_get' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 742
INFO - 2021-09-08 08:06:41 --> Final output sent to browser
DEBUG - 2021-09-08 08:06:41 --> Total execution time: 0.4591
INFO - 2021-09-08 08:06:52 --> Config Class Initialized
INFO - 2021-09-08 08:06:52 --> Hooks Class Initialized
DEBUG - 2021-09-08 08:06:53 --> UTF-8 Support Enabled
INFO - 2021-09-08 08:06:53 --> Utf8 Class Initialized
INFO - 2021-09-08 08:06:53 --> URI Class Initialized
INFO - 2021-09-08 08:06:53 --> Router Class Initialized
INFO - 2021-09-08 08:06:53 --> Output Class Initialized
INFO - 2021-09-08 08:06:53 --> Security Class Initialized
DEBUG - 2021-09-08 08:06:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-08 08:06:53 --> CSRF cookie sent
INFO - 2021-09-08 08:06:53 --> Input Class Initialized
INFO - 2021-09-08 08:06:53 --> Language Class Initialized
INFO - 2021-09-08 08:06:53 --> Loader Class Initialized
INFO - 2021-09-08 08:06:53 --> Helper loaded: url_helper
INFO - 2021-09-08 08:06:53 --> Helper loaded: file_helper
INFO - 2021-09-08 08:06:53 --> Helper loaded: form_helper
INFO - 2021-09-08 08:06:53 --> Helper loaded: security_helper
INFO - 2021-09-08 08:06:53 --> Helper loaded: directory_helper
INFO - 2021-09-08 08:06:53 --> Helper loaded: general_helper
INFO - 2021-09-08 08:06:53 --> Database Driver Class Initialized
INFO - 2021-09-08 08:06:53 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-08 08:06:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-08 08:06:53 --> Pagination Class Initialized
INFO - 2021-09-08 08:06:53 --> XML-RPC Class Initialized
INFO - 2021-09-08 08:06:53 --> Form Validation Class Initialized
INFO - 2021-09-08 08:06:53 --> Upload Class Initialized
INFO - 2021-09-08 08:06:53 --> MY_Model class loaded
INFO - 2021-09-08 08:06:53 --> Model "Application_model" initialized
INFO - 2021-09-08 08:06:53 --> Controller Class Initialized
DEBUG - 2021-09-08 08:06:53 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-08 08:06:53 --> Helper loaded: inflector_helper
INFO - 2021-09-08 08:06:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-08 08:06:53 --> Database Driver Class Initialized
ERROR - 2021-09-08 08:06:53 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-08 08:06:53 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-08 08:06:53 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-08 08:06:53 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-08 08:06:53 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\Users\Gopal Ghimire\Desktop\New folder\school\application\controllers\api\Parents.php 20
INFO - 2021-09-08 08:07:54 --> Config Class Initialized
INFO - 2021-09-08 08:07:54 --> Hooks Class Initialized
DEBUG - 2021-09-08 08:07:54 --> UTF-8 Support Enabled
INFO - 2021-09-08 08:07:54 --> Utf8 Class Initialized
INFO - 2021-09-08 08:07:54 --> URI Class Initialized
INFO - 2021-09-08 08:07:54 --> Router Class Initialized
INFO - 2021-09-08 08:07:54 --> Output Class Initialized
INFO - 2021-09-08 08:07:54 --> Security Class Initialized
DEBUG - 2021-09-08 08:07:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-08 08:07:54 --> CSRF cookie sent
INFO - 2021-09-08 08:07:54 --> Input Class Initialized
INFO - 2021-09-08 08:07:54 --> Language Class Initialized
INFO - 2021-09-08 08:07:54 --> Loader Class Initialized
INFO - 2021-09-08 08:07:54 --> Helper loaded: url_helper
INFO - 2021-09-08 08:07:54 --> Helper loaded: file_helper
INFO - 2021-09-08 08:07:54 --> Helper loaded: form_helper
INFO - 2021-09-08 08:07:54 --> Helper loaded: security_helper
INFO - 2021-09-08 08:07:54 --> Helper loaded: directory_helper
INFO - 2021-09-08 08:07:54 --> Helper loaded: general_helper
INFO - 2021-09-08 08:07:54 --> Database Driver Class Initialized
INFO - 2021-09-08 08:07:54 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-08 08:07:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-08 08:07:54 --> Pagination Class Initialized
INFO - 2021-09-08 08:07:54 --> XML-RPC Class Initialized
INFO - 2021-09-08 08:07:54 --> Form Validation Class Initialized
INFO - 2021-09-08 08:07:54 --> Upload Class Initialized
INFO - 2021-09-08 08:07:54 --> MY_Model class loaded
INFO - 2021-09-08 08:07:54 --> Model "Application_model" initialized
INFO - 2021-09-08 08:07:54 --> Controller Class Initialized
DEBUG - 2021-09-08 08:07:54 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-08 08:07:54 --> Helper loaded: inflector_helper
INFO - 2021-09-08 08:07:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-08 08:07:54 --> Database Driver Class Initialized
ERROR - 2021-09-08 08:07:54 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-08 08:07:54 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-08 08:07:54 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-08 08:07:54 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-08 08:07:54 --> Final output sent to browser
DEBUG - 2021-09-08 08:07:54 --> Total execution time: 0.1421
INFO - 2021-09-08 08:09:36 --> Config Class Initialized
INFO - 2021-09-08 08:09:36 --> Hooks Class Initialized
DEBUG - 2021-09-08 08:09:36 --> UTF-8 Support Enabled
INFO - 2021-09-08 08:09:36 --> Utf8 Class Initialized
INFO - 2021-09-08 08:09:36 --> URI Class Initialized
INFO - 2021-09-08 08:09:36 --> Router Class Initialized
INFO - 2021-09-08 08:09:36 --> Output Class Initialized
INFO - 2021-09-08 08:09:36 --> Security Class Initialized
DEBUG - 2021-09-08 08:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-08 08:09:36 --> CSRF cookie sent
INFO - 2021-09-08 08:09:36 --> Input Class Initialized
INFO - 2021-09-08 08:09:36 --> Language Class Initialized
INFO - 2021-09-08 08:09:36 --> Loader Class Initialized
INFO - 2021-09-08 08:09:36 --> Helper loaded: url_helper
INFO - 2021-09-08 08:09:36 --> Helper loaded: file_helper
INFO - 2021-09-08 08:09:36 --> Helper loaded: form_helper
INFO - 2021-09-08 08:09:36 --> Helper loaded: security_helper
INFO - 2021-09-08 08:09:36 --> Helper loaded: directory_helper
INFO - 2021-09-08 08:09:36 --> Helper loaded: general_helper
INFO - 2021-09-08 08:09:36 --> Database Driver Class Initialized
INFO - 2021-09-08 08:09:36 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-08 08:09:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-08 08:09:36 --> Pagination Class Initialized
INFO - 2021-09-08 08:09:36 --> XML-RPC Class Initialized
INFO - 2021-09-08 08:09:36 --> Form Validation Class Initialized
INFO - 2021-09-08 08:09:36 --> Upload Class Initialized
INFO - 2021-09-08 08:09:36 --> MY_Model class loaded
INFO - 2021-09-08 08:09:36 --> Model "Application_model" initialized
INFO - 2021-09-08 08:09:36 --> Controller Class Initialized
DEBUG - 2021-09-08 08:09:36 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-08 08:09:36 --> Helper loaded: inflector_helper
INFO - 2021-09-08 08:09:36 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-08 08:09:36 --> Database Driver Class Initialized
ERROR - 2021-09-08 08:09:36 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-08 08:09:36 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-08 08:09:36 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-08 08:09:36 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-08 08:09:36 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\Users\Gopal Ghimire\Desktop\New folder\school\application\controllers\api\Parents.php 21
INFO - 2021-09-08 08:17:45 --> Config Class Initialized
INFO - 2021-09-08 08:17:45 --> Hooks Class Initialized
DEBUG - 2021-09-08 08:17:45 --> UTF-8 Support Enabled
INFO - 2021-09-08 08:17:45 --> Utf8 Class Initialized
INFO - 2021-09-08 08:17:45 --> URI Class Initialized
INFO - 2021-09-08 08:17:45 --> Router Class Initialized
INFO - 2021-09-08 08:17:45 --> Output Class Initialized
INFO - 2021-09-08 08:17:45 --> Security Class Initialized
DEBUG - 2021-09-08 08:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-08 08:17:45 --> CSRF cookie sent
INFO - 2021-09-08 08:17:45 --> Input Class Initialized
INFO - 2021-09-08 08:17:45 --> Language Class Initialized
INFO - 2021-09-08 08:17:45 --> Loader Class Initialized
INFO - 2021-09-08 08:17:45 --> Helper loaded: url_helper
INFO - 2021-09-08 08:17:45 --> Helper loaded: file_helper
INFO - 2021-09-08 08:17:45 --> Helper loaded: form_helper
INFO - 2021-09-08 08:17:45 --> Helper loaded: security_helper
INFO - 2021-09-08 08:17:46 --> Helper loaded: directory_helper
INFO - 2021-09-08 08:17:46 --> Helper loaded: general_helper
INFO - 2021-09-08 08:17:46 --> Database Driver Class Initialized
INFO - 2021-09-08 08:17:46 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-08 08:17:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-08 08:17:46 --> Pagination Class Initialized
INFO - 2021-09-08 08:17:46 --> XML-RPC Class Initialized
INFO - 2021-09-08 08:17:46 --> Form Validation Class Initialized
INFO - 2021-09-08 08:17:47 --> Upload Class Initialized
INFO - 2021-09-08 08:17:47 --> MY_Model class loaded
INFO - 2021-09-08 08:17:47 --> Model "Application_model" initialized
INFO - 2021-09-08 08:17:47 --> Controller Class Initialized
DEBUG - 2021-09-08 08:17:47 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-08 08:17:47 --> Helper loaded: inflector_helper
INFO - 2021-09-08 08:17:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-08 08:17:47 --> Database Driver Class Initialized
ERROR - 2021-09-08 08:17:47 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-08 08:17:47 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-08 08:17:47 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-08 08:17:47 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-08 08:17:47 --> Model "Branch_model" initialized
INFO - 2021-09-08 08:17:47 --> Final output sent to browser
DEBUG - 2021-09-08 08:17:47 --> Total execution time: 2.0839
INFO - 2021-09-08 08:18:31 --> Config Class Initialized
INFO - 2021-09-08 08:18:31 --> Hooks Class Initialized
DEBUG - 2021-09-08 08:18:31 --> UTF-8 Support Enabled
INFO - 2021-09-08 08:18:31 --> Utf8 Class Initialized
INFO - 2021-09-08 08:18:31 --> URI Class Initialized
INFO - 2021-09-08 08:18:31 --> Router Class Initialized
INFO - 2021-09-08 08:18:31 --> Output Class Initialized
INFO - 2021-09-08 08:18:31 --> Security Class Initialized
DEBUG - 2021-09-08 08:18:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-08 08:18:31 --> CSRF cookie sent
INFO - 2021-09-08 08:18:31 --> Input Class Initialized
INFO - 2021-09-08 08:18:31 --> Language Class Initialized
INFO - 2021-09-08 08:18:31 --> Loader Class Initialized
INFO - 2021-09-08 08:18:31 --> Helper loaded: url_helper
INFO - 2021-09-08 08:18:31 --> Helper loaded: file_helper
INFO - 2021-09-08 08:18:31 --> Helper loaded: form_helper
INFO - 2021-09-08 08:18:31 --> Helper loaded: security_helper
INFO - 2021-09-08 08:18:31 --> Helper loaded: directory_helper
INFO - 2021-09-08 08:18:31 --> Helper loaded: general_helper
INFO - 2021-09-08 08:18:31 --> Database Driver Class Initialized
INFO - 2021-09-08 08:18:31 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-08 08:18:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-08 08:18:31 --> Pagination Class Initialized
INFO - 2021-09-08 08:18:31 --> XML-RPC Class Initialized
INFO - 2021-09-08 08:18:31 --> Form Validation Class Initialized
INFO - 2021-09-08 08:18:31 --> Upload Class Initialized
INFO - 2021-09-08 08:18:31 --> MY_Model class loaded
INFO - 2021-09-08 08:18:31 --> Model "Application_model" initialized
INFO - 2021-09-08 08:18:31 --> Controller Class Initialized
DEBUG - 2021-09-08 08:18:31 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-08 08:18:31 --> Helper loaded: inflector_helper
INFO - 2021-09-08 08:18:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-08 08:18:31 --> Database Driver Class Initialized
ERROR - 2021-09-08 08:18:31 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-08 08:18:31 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-08 08:18:31 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-08 08:18:31 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-08 08:18:31 --> Model "Branch_model" initialized
INFO - 2021-09-08 08:18:31 --> Final output sent to browser
DEBUG - 2021-09-08 08:18:31 --> Total execution time: 0.2276
INFO - 2021-09-08 08:20:23 --> Config Class Initialized
INFO - 2021-09-08 08:20:23 --> Hooks Class Initialized
DEBUG - 2021-09-08 08:20:23 --> UTF-8 Support Enabled
INFO - 2021-09-08 08:20:23 --> Utf8 Class Initialized
INFO - 2021-09-08 08:20:23 --> URI Class Initialized
INFO - 2021-09-08 08:20:23 --> Router Class Initialized
INFO - 2021-09-08 08:20:23 --> Output Class Initialized
INFO - 2021-09-08 08:20:23 --> Security Class Initialized
DEBUG - 2021-09-08 08:20:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-08 08:20:23 --> CSRF cookie sent
INFO - 2021-09-08 08:20:23 --> Input Class Initialized
INFO - 2021-09-08 08:20:23 --> Language Class Initialized
INFO - 2021-09-08 08:20:23 --> Loader Class Initialized
INFO - 2021-09-08 08:20:23 --> Helper loaded: url_helper
INFO - 2021-09-08 08:20:23 --> Helper loaded: file_helper
INFO - 2021-09-08 08:20:23 --> Helper loaded: form_helper
INFO - 2021-09-08 08:20:23 --> Helper loaded: security_helper
INFO - 2021-09-08 08:20:23 --> Helper loaded: directory_helper
INFO - 2021-09-08 08:20:23 --> Helper loaded: general_helper
INFO - 2021-09-08 08:20:23 --> Database Driver Class Initialized
INFO - 2021-09-08 08:20:23 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-08 08:20:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-08 08:20:23 --> Pagination Class Initialized
INFO - 2021-09-08 08:20:23 --> XML-RPC Class Initialized
INFO - 2021-09-08 08:20:23 --> Form Validation Class Initialized
INFO - 2021-09-08 08:20:23 --> Upload Class Initialized
INFO - 2021-09-08 08:20:23 --> MY_Model class loaded
INFO - 2021-09-08 08:20:23 --> Model "Application_model" initialized
INFO - 2021-09-08 08:20:23 --> Controller Class Initialized
DEBUG - 2021-09-08 08:20:23 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-08 08:20:23 --> Helper loaded: inflector_helper
INFO - 2021-09-08 08:20:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-08 08:20:23 --> Database Driver Class Initialized
ERROR - 2021-09-08 08:20:23 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-08 08:20:23 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-08 08:20:23 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-08 08:20:23 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-08 08:20:23 --> Model "Branch_model" initialized
INFO - 2021-09-08 08:20:23 --> Final output sent to browser
DEBUG - 2021-09-08 08:20:23 --> Total execution time: 0.1450
INFO - 2021-09-08 08:21:17 --> Config Class Initialized
INFO - 2021-09-08 08:21:17 --> Hooks Class Initialized
DEBUG - 2021-09-08 08:21:17 --> UTF-8 Support Enabled
INFO - 2021-09-08 08:21:17 --> Utf8 Class Initialized
INFO - 2021-09-08 08:21:17 --> URI Class Initialized
INFO - 2021-09-08 08:21:17 --> Router Class Initialized
INFO - 2021-09-08 08:21:17 --> Output Class Initialized
INFO - 2021-09-08 08:21:17 --> Security Class Initialized
DEBUG - 2021-09-08 08:21:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-08 08:21:17 --> CSRF cookie sent
INFO - 2021-09-08 08:21:17 --> Input Class Initialized
INFO - 2021-09-08 08:21:17 --> Language Class Initialized
INFO - 2021-09-08 08:21:17 --> Loader Class Initialized
INFO - 2021-09-08 08:21:17 --> Helper loaded: url_helper
INFO - 2021-09-08 08:21:17 --> Helper loaded: file_helper
INFO - 2021-09-08 08:21:17 --> Helper loaded: form_helper
INFO - 2021-09-08 08:21:17 --> Helper loaded: security_helper
INFO - 2021-09-08 08:21:17 --> Helper loaded: directory_helper
INFO - 2021-09-08 08:21:17 --> Helper loaded: general_helper
INFO - 2021-09-08 08:21:17 --> Database Driver Class Initialized
INFO - 2021-09-08 08:21:17 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-08 08:21:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-08 08:21:17 --> Pagination Class Initialized
INFO - 2021-09-08 08:21:17 --> XML-RPC Class Initialized
INFO - 2021-09-08 08:21:17 --> Form Validation Class Initialized
INFO - 2021-09-08 08:21:17 --> Upload Class Initialized
INFO - 2021-09-08 08:21:17 --> MY_Model class loaded
INFO - 2021-09-08 08:21:17 --> Model "Application_model" initialized
INFO - 2021-09-08 08:21:17 --> Controller Class Initialized
DEBUG - 2021-09-08 08:21:17 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-08 08:21:17 --> Helper loaded: inflector_helper
INFO - 2021-09-08 08:21:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-08 08:21:17 --> Database Driver Class Initialized
ERROR - 2021-09-08 08:21:17 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-08 08:21:17 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-08 08:21:17 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-08 08:21:17 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-08 08:21:17 --> Model "Branch_model" initialized
INFO - 2021-09-08 08:21:17 --> Final output sent to browser
DEBUG - 2021-09-08 08:21:17 --> Total execution time: 0.1121
INFO - 2021-09-08 08:23:27 --> Config Class Initialized
INFO - 2021-09-08 08:23:27 --> Hooks Class Initialized
DEBUG - 2021-09-08 08:23:27 --> UTF-8 Support Enabled
INFO - 2021-09-08 08:23:27 --> Utf8 Class Initialized
INFO - 2021-09-08 08:23:27 --> URI Class Initialized
INFO - 2021-09-08 08:23:27 --> Router Class Initialized
INFO - 2021-09-08 08:23:27 --> Output Class Initialized
INFO - 2021-09-08 08:23:27 --> Security Class Initialized
DEBUG - 2021-09-08 08:23:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-08 08:23:27 --> CSRF cookie sent
INFO - 2021-09-08 08:23:27 --> Input Class Initialized
INFO - 2021-09-08 08:23:27 --> Language Class Initialized
INFO - 2021-09-08 08:23:27 --> Loader Class Initialized
INFO - 2021-09-08 08:23:27 --> Helper loaded: url_helper
INFO - 2021-09-08 08:23:27 --> Helper loaded: file_helper
INFO - 2021-09-08 08:23:27 --> Helper loaded: form_helper
INFO - 2021-09-08 08:23:27 --> Helper loaded: security_helper
INFO - 2021-09-08 08:23:28 --> Helper loaded: directory_helper
INFO - 2021-09-08 08:23:28 --> Helper loaded: general_helper
INFO - 2021-09-08 08:23:28 --> Database Driver Class Initialized
INFO - 2021-09-08 08:23:28 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-08 08:23:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-08 08:23:28 --> Pagination Class Initialized
INFO - 2021-09-08 08:23:28 --> XML-RPC Class Initialized
INFO - 2021-09-08 08:23:28 --> Form Validation Class Initialized
INFO - 2021-09-08 08:23:28 --> Upload Class Initialized
INFO - 2021-09-08 08:23:28 --> MY_Model class loaded
INFO - 2021-09-08 08:23:28 --> Model "Application_model" initialized
INFO - 2021-09-08 08:23:28 --> Controller Class Initialized
DEBUG - 2021-09-08 08:23:28 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-08 08:23:28 --> Helper loaded: inflector_helper
INFO - 2021-09-08 08:23:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-08 08:23:28 --> Database Driver Class Initialized
ERROR - 2021-09-08 08:23:28 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-08 08:23:28 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-08 08:23:28 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-08 08:23:28 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-08 08:23:28 --> Model "Branch_model" initialized
INFO - 2021-09-08 08:23:28 --> Final output sent to browser
DEBUG - 2021-09-08 08:23:28 --> Total execution time: 0.3645
INFO - 2021-09-08 09:50:11 --> Config Class Initialized
INFO - 2021-09-08 09:50:11 --> Hooks Class Initialized
DEBUG - 2021-09-08 09:50:13 --> UTF-8 Support Enabled
INFO - 2021-09-08 09:50:13 --> Utf8 Class Initialized
INFO - 2021-09-08 09:50:13 --> URI Class Initialized
INFO - 2021-09-08 09:50:13 --> Router Class Initialized
INFO - 2021-09-08 09:50:13 --> Output Class Initialized
INFO - 2021-09-08 09:50:13 --> Security Class Initialized
DEBUG - 2021-09-08 09:50:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-08 09:50:13 --> CSRF cookie sent
INFO - 2021-09-08 09:50:13 --> Input Class Initialized
INFO - 2021-09-08 09:50:13 --> Language Class Initialized
INFO - 2021-09-08 09:50:14 --> Loader Class Initialized
INFO - 2021-09-08 09:50:14 --> Helper loaded: url_helper
INFO - 2021-09-08 09:50:14 --> Helper loaded: file_helper
INFO - 2021-09-08 09:50:14 --> Helper loaded: form_helper
INFO - 2021-09-08 09:50:14 --> Helper loaded: security_helper
INFO - 2021-09-08 09:50:14 --> Helper loaded: directory_helper
INFO - 2021-09-08 09:50:14 --> Helper loaded: general_helper
INFO - 2021-09-08 09:50:15 --> Database Driver Class Initialized
INFO - 2021-09-08 09:50:15 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-08 09:50:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-08 09:50:16 --> Pagination Class Initialized
INFO - 2021-09-08 09:50:16 --> XML-RPC Class Initialized
INFO - 2021-09-08 09:50:16 --> Form Validation Class Initialized
INFO - 2021-09-08 09:50:16 --> Upload Class Initialized
INFO - 2021-09-08 09:50:16 --> MY_Model class loaded
INFO - 2021-09-08 09:50:16 --> Model "Application_model" initialized
INFO - 2021-09-08 09:50:16 --> Controller Class Initialized
DEBUG - 2021-09-08 09:50:16 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-08 09:50:16 --> Helper loaded: inflector_helper
INFO - 2021-09-08 09:50:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-08 09:50:16 --> Database Driver Class Initialized
ERROR - 2021-09-08 09:50:16 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-08 09:50:16 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-08 09:50:16 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-08 09:50:16 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-08 09:50:17 --> Model "Branch_model" initialized
INFO - 2021-09-08 09:50:17 --> Final output sent to browser
DEBUG - 2021-09-08 09:50:17 --> Total execution time: 5.5953
INFO - 2021-09-08 09:51:50 --> Config Class Initialized
INFO - 2021-09-08 09:51:50 --> Hooks Class Initialized
DEBUG - 2021-09-08 09:51:50 --> UTF-8 Support Enabled
INFO - 2021-09-08 09:51:50 --> Utf8 Class Initialized
INFO - 2021-09-08 09:51:50 --> URI Class Initialized
INFO - 2021-09-08 09:51:50 --> Router Class Initialized
INFO - 2021-09-08 09:51:50 --> Output Class Initialized
INFO - 2021-09-08 09:51:50 --> Security Class Initialized
DEBUG - 2021-09-08 09:51:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-08 09:51:50 --> CSRF cookie sent
INFO - 2021-09-08 09:51:50 --> Input Class Initialized
INFO - 2021-09-08 09:51:50 --> Language Class Initialized
INFO - 2021-09-08 09:51:50 --> Loader Class Initialized
INFO - 2021-09-08 09:51:50 --> Helper loaded: url_helper
INFO - 2021-09-08 09:51:50 --> Helper loaded: file_helper
INFO - 2021-09-08 09:51:50 --> Helper loaded: form_helper
INFO - 2021-09-08 09:51:50 --> Helper loaded: security_helper
INFO - 2021-09-08 09:51:50 --> Helper loaded: directory_helper
INFO - 2021-09-08 09:51:50 --> Helper loaded: general_helper
INFO - 2021-09-08 09:51:50 --> Database Driver Class Initialized
INFO - 2021-09-08 09:51:50 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-08 09:51:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-08 09:51:50 --> Pagination Class Initialized
INFO - 2021-09-08 09:51:50 --> XML-RPC Class Initialized
INFO - 2021-09-08 09:51:50 --> Form Validation Class Initialized
INFO - 2021-09-08 09:51:50 --> Upload Class Initialized
INFO - 2021-09-08 09:51:50 --> MY_Model class loaded
INFO - 2021-09-08 09:51:50 --> Model "Application_model" initialized
INFO - 2021-09-08 09:51:50 --> Controller Class Initialized
DEBUG - 2021-09-08 09:51:50 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-08 09:51:50 --> Helper loaded: inflector_helper
INFO - 2021-09-08 09:51:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-08 09:51:50 --> Database Driver Class Initialized
ERROR - 2021-09-08 09:51:50 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-08 09:51:50 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-08 09:51:50 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-08 09:51:50 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-08 09:51:50 --> Model "Branch_model" initialized
INFO - 2021-09-08 09:51:50 --> Final output sent to browser
DEBUG - 2021-09-08 09:51:50 --> Total execution time: 0.2261
INFO - 2021-09-08 09:53:01 --> Config Class Initialized
INFO - 2021-09-08 09:53:01 --> Hooks Class Initialized
DEBUG - 2021-09-08 09:53:01 --> UTF-8 Support Enabled
INFO - 2021-09-08 09:53:01 --> Utf8 Class Initialized
INFO - 2021-09-08 09:53:01 --> URI Class Initialized
INFO - 2021-09-08 09:53:01 --> Router Class Initialized
INFO - 2021-09-08 09:53:01 --> Output Class Initialized
INFO - 2021-09-08 09:53:01 --> Security Class Initialized
DEBUG - 2021-09-08 09:53:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-08 09:53:01 --> CSRF cookie sent
INFO - 2021-09-08 09:53:01 --> Input Class Initialized
INFO - 2021-09-08 09:53:01 --> Language Class Initialized
INFO - 2021-09-08 09:53:01 --> Loader Class Initialized
INFO - 2021-09-08 09:53:01 --> Helper loaded: url_helper
INFO - 2021-09-08 09:53:01 --> Helper loaded: file_helper
INFO - 2021-09-08 09:53:01 --> Helper loaded: form_helper
INFO - 2021-09-08 09:53:01 --> Helper loaded: security_helper
INFO - 2021-09-08 09:53:01 --> Helper loaded: directory_helper
INFO - 2021-09-08 09:53:01 --> Helper loaded: general_helper
INFO - 2021-09-08 09:53:01 --> Database Driver Class Initialized
INFO - 2021-09-08 09:53:01 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-08 09:53:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-08 09:53:01 --> Pagination Class Initialized
INFO - 2021-09-08 09:53:01 --> XML-RPC Class Initialized
INFO - 2021-09-08 09:53:01 --> Form Validation Class Initialized
INFO - 2021-09-08 09:53:01 --> Upload Class Initialized
INFO - 2021-09-08 09:53:01 --> MY_Model class loaded
INFO - 2021-09-08 09:53:01 --> Model "Application_model" initialized
INFO - 2021-09-08 09:53:01 --> Controller Class Initialized
DEBUG - 2021-09-08 09:53:01 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-08 09:53:01 --> Helper loaded: inflector_helper
INFO - 2021-09-08 09:53:01 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-08 09:53:01 --> Database Driver Class Initialized
ERROR - 2021-09-08 09:53:01 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-08 09:53:01 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-08 09:53:01 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-08 09:53:01 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-08 09:53:01 --> Model "Branch_model" initialized
INFO - 2021-09-08 09:53:01 --> Final output sent to browser
DEBUG - 2021-09-08 09:53:01 --> Total execution time: 0.4015
INFO - 2021-09-08 09:54:06 --> Config Class Initialized
INFO - 2021-09-08 09:54:06 --> Hooks Class Initialized
DEBUG - 2021-09-08 09:54:06 --> UTF-8 Support Enabled
INFO - 2021-09-08 09:54:06 --> Utf8 Class Initialized
INFO - 2021-09-08 09:54:06 --> URI Class Initialized
INFO - 2021-09-08 09:54:06 --> Router Class Initialized
INFO - 2021-09-08 09:54:06 --> Output Class Initialized
INFO - 2021-09-08 09:54:06 --> Security Class Initialized
DEBUG - 2021-09-08 09:54:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-08 09:54:06 --> CSRF cookie sent
INFO - 2021-09-08 09:54:06 --> Input Class Initialized
INFO - 2021-09-08 09:54:06 --> Language Class Initialized
INFO - 2021-09-08 09:54:06 --> Loader Class Initialized
INFO - 2021-09-08 09:54:06 --> Helper loaded: url_helper
INFO - 2021-09-08 09:54:06 --> Helper loaded: file_helper
INFO - 2021-09-08 09:54:06 --> Helper loaded: form_helper
INFO - 2021-09-08 09:54:06 --> Helper loaded: security_helper
INFO - 2021-09-08 09:54:07 --> Helper loaded: directory_helper
INFO - 2021-09-08 09:54:07 --> Helper loaded: general_helper
INFO - 2021-09-08 09:54:07 --> Database Driver Class Initialized
INFO - 2021-09-08 09:54:07 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-08 09:54:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-08 09:54:07 --> Pagination Class Initialized
INFO - 2021-09-08 09:54:07 --> XML-RPC Class Initialized
INFO - 2021-09-08 09:54:07 --> Form Validation Class Initialized
INFO - 2021-09-08 09:54:07 --> Upload Class Initialized
INFO - 2021-09-08 09:54:07 --> MY_Model class loaded
INFO - 2021-09-08 09:54:07 --> Model "Application_model" initialized
INFO - 2021-09-08 09:54:07 --> Controller Class Initialized
DEBUG - 2021-09-08 09:54:07 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-08 09:54:07 --> Helper loaded: inflector_helper
INFO - 2021-09-08 09:54:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-08 09:54:07 --> Database Driver Class Initialized
ERROR - 2021-09-08 09:54:07 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-08 09:54:07 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-08 09:54:07 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-08 09:54:07 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-08 09:54:07 --> Model "Branch_model" initialized
INFO - 2021-09-08 09:54:07 --> Final output sent to browser
DEBUG - 2021-09-08 09:54:07 --> Total execution time: 0.2115
INFO - 2021-09-08 09:55:22 --> Config Class Initialized
INFO - 2021-09-08 09:55:22 --> Hooks Class Initialized
DEBUG - 2021-09-08 09:55:22 --> UTF-8 Support Enabled
INFO - 2021-09-08 09:55:22 --> Utf8 Class Initialized
INFO - 2021-09-08 09:55:22 --> URI Class Initialized
INFO - 2021-09-08 09:55:22 --> Router Class Initialized
INFO - 2021-09-08 09:55:22 --> Output Class Initialized
INFO - 2021-09-08 09:55:22 --> Security Class Initialized
DEBUG - 2021-09-08 09:55:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-08 09:55:22 --> CSRF cookie sent
INFO - 2021-09-08 09:55:22 --> Input Class Initialized
INFO - 2021-09-08 09:55:22 --> Language Class Initialized
INFO - 2021-09-08 09:55:22 --> Loader Class Initialized
INFO - 2021-09-08 09:55:22 --> Helper loaded: url_helper
INFO - 2021-09-08 09:55:22 --> Helper loaded: file_helper
INFO - 2021-09-08 09:55:22 --> Helper loaded: form_helper
INFO - 2021-09-08 09:55:22 --> Helper loaded: security_helper
INFO - 2021-09-08 09:55:22 --> Helper loaded: directory_helper
INFO - 2021-09-08 09:55:22 --> Helper loaded: general_helper
INFO - 2021-09-08 09:55:22 --> Database Driver Class Initialized
INFO - 2021-09-08 09:55:22 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-08 09:55:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-08 09:55:22 --> Pagination Class Initialized
INFO - 2021-09-08 09:55:22 --> XML-RPC Class Initialized
INFO - 2021-09-08 09:55:22 --> Form Validation Class Initialized
INFO - 2021-09-08 09:55:22 --> Upload Class Initialized
INFO - 2021-09-08 09:55:22 --> MY_Model class loaded
INFO - 2021-09-08 09:55:22 --> Model "Application_model" initialized
INFO - 2021-09-08 09:55:22 --> Controller Class Initialized
DEBUG - 2021-09-08 09:55:22 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-08 09:55:22 --> Helper loaded: inflector_helper
INFO - 2021-09-08 09:55:22 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-08 09:55:22 --> Database Driver Class Initialized
ERROR - 2021-09-08 09:55:22 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-08 09:55:22 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-08 09:55:22 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-08 09:55:22 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-08 09:55:22 --> Model "Branch_model" initialized
INFO - 2021-09-08 09:55:22 --> Final output sent to browser
DEBUG - 2021-09-08 09:55:22 --> Total execution time: 0.3377
INFO - 2021-09-08 10:02:14 --> Config Class Initialized
INFO - 2021-09-08 10:02:14 --> Hooks Class Initialized
DEBUG - 2021-09-08 10:02:14 --> UTF-8 Support Enabled
INFO - 2021-09-08 10:02:14 --> Utf8 Class Initialized
INFO - 2021-09-08 10:02:14 --> URI Class Initialized
INFO - 2021-09-08 10:02:14 --> Router Class Initialized
INFO - 2021-09-08 10:02:14 --> Output Class Initialized
INFO - 2021-09-08 10:02:14 --> Security Class Initialized
DEBUG - 2021-09-08 10:02:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-08 10:02:14 --> CSRF cookie sent
INFO - 2021-09-08 10:02:14 --> Input Class Initialized
INFO - 2021-09-08 10:02:14 --> Language Class Initialized
INFO - 2021-09-08 10:02:14 --> Loader Class Initialized
INFO - 2021-09-08 10:02:14 --> Helper loaded: url_helper
INFO - 2021-09-08 10:02:14 --> Helper loaded: file_helper
INFO - 2021-09-08 10:02:14 --> Helper loaded: form_helper
INFO - 2021-09-08 10:02:14 --> Helper loaded: security_helper
INFO - 2021-09-08 10:02:14 --> Helper loaded: directory_helper
INFO - 2021-09-08 10:02:14 --> Helper loaded: general_helper
INFO - 2021-09-08 10:02:14 --> Database Driver Class Initialized
INFO - 2021-09-08 10:02:14 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-08 10:02:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-08 10:02:14 --> Pagination Class Initialized
INFO - 2021-09-08 10:02:14 --> XML-RPC Class Initialized
INFO - 2021-09-08 10:02:14 --> Form Validation Class Initialized
INFO - 2021-09-08 10:02:14 --> Upload Class Initialized
INFO - 2021-09-08 10:02:14 --> MY_Model class loaded
INFO - 2021-09-08 10:02:14 --> Model "Application_model" initialized
INFO - 2021-09-08 10:02:14 --> Controller Class Initialized
DEBUG - 2021-09-08 10:02:14 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-08 10:02:14 --> Helper loaded: inflector_helper
INFO - 2021-09-08 10:02:14 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-08 10:02:14 --> Database Driver Class Initialized
ERROR - 2021-09-08 10:02:14 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-08 10:02:14 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-08 10:02:14 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-08 10:02:14 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-08 10:02:14 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\Users\Gopal Ghimire\Desktop\New folder\school\application\controllers\api\Parents.php 16
INFO - 2021-09-08 10:02:29 --> Config Class Initialized
INFO - 2021-09-08 10:02:29 --> Hooks Class Initialized
DEBUG - 2021-09-08 10:02:29 --> UTF-8 Support Enabled
INFO - 2021-09-08 10:02:29 --> Utf8 Class Initialized
INFO - 2021-09-08 10:02:29 --> URI Class Initialized
INFO - 2021-09-08 10:02:29 --> Router Class Initialized
INFO - 2021-09-08 10:02:29 --> Output Class Initialized
INFO - 2021-09-08 10:02:29 --> Security Class Initialized
DEBUG - 2021-09-08 10:02:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-08 10:02:29 --> CSRF cookie sent
INFO - 2021-09-08 10:02:29 --> Input Class Initialized
INFO - 2021-09-08 10:02:29 --> Language Class Initialized
INFO - 2021-09-08 10:02:29 --> Loader Class Initialized
INFO - 2021-09-08 10:02:29 --> Helper loaded: url_helper
INFO - 2021-09-08 10:02:29 --> Helper loaded: file_helper
INFO - 2021-09-08 10:02:29 --> Helper loaded: form_helper
INFO - 2021-09-08 10:02:29 --> Helper loaded: security_helper
INFO - 2021-09-08 10:02:29 --> Helper loaded: directory_helper
INFO - 2021-09-08 10:02:29 --> Helper loaded: general_helper
INFO - 2021-09-08 10:02:29 --> Database Driver Class Initialized
INFO - 2021-09-08 10:02:29 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-08 10:02:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-08 10:02:29 --> Pagination Class Initialized
INFO - 2021-09-08 10:02:29 --> XML-RPC Class Initialized
INFO - 2021-09-08 10:02:29 --> Form Validation Class Initialized
INFO - 2021-09-08 10:02:29 --> Upload Class Initialized
INFO - 2021-09-08 10:02:29 --> MY_Model class loaded
INFO - 2021-09-08 10:02:29 --> Model "Application_model" initialized
INFO - 2021-09-08 10:02:29 --> Controller Class Initialized
DEBUG - 2021-09-08 10:02:29 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-08 10:02:29 --> Helper loaded: inflector_helper
INFO - 2021-09-08 10:02:29 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-08 10:02:29 --> Database Driver Class Initialized
ERROR - 2021-09-08 10:02:29 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-08 10:02:29 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-08 10:02:29 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-08 10:02:29 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-08 10:02:29 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\Users\Gopal Ghimire\Desktop\New folder\school\application\controllers\api\Parents.php 16
INFO - 2021-09-08 10:03:33 --> Config Class Initialized
INFO - 2021-09-08 10:03:33 --> Hooks Class Initialized
DEBUG - 2021-09-08 10:03:33 --> UTF-8 Support Enabled
INFO - 2021-09-08 10:03:33 --> Utf8 Class Initialized
INFO - 2021-09-08 10:03:33 --> URI Class Initialized
INFO - 2021-09-08 10:03:33 --> Router Class Initialized
INFO - 2021-09-08 10:03:33 --> Output Class Initialized
INFO - 2021-09-08 10:03:33 --> Security Class Initialized
DEBUG - 2021-09-08 10:03:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-08 10:03:33 --> CSRF cookie sent
INFO - 2021-09-08 10:03:33 --> Input Class Initialized
INFO - 2021-09-08 10:03:33 --> Language Class Initialized
INFO - 2021-09-08 10:03:33 --> Loader Class Initialized
INFO - 2021-09-08 10:03:33 --> Helper loaded: url_helper
INFO - 2021-09-08 10:03:33 --> Helper loaded: file_helper
INFO - 2021-09-08 10:03:33 --> Helper loaded: form_helper
INFO - 2021-09-08 10:03:33 --> Helper loaded: security_helper
INFO - 2021-09-08 10:03:33 --> Helper loaded: directory_helper
INFO - 2021-09-08 10:03:33 --> Helper loaded: general_helper
INFO - 2021-09-08 10:03:33 --> Database Driver Class Initialized
INFO - 2021-09-08 10:03:33 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-08 10:03:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-08 10:03:33 --> Pagination Class Initialized
INFO - 2021-09-08 10:03:33 --> XML-RPC Class Initialized
INFO - 2021-09-08 10:03:33 --> Form Validation Class Initialized
INFO - 2021-09-08 10:03:33 --> Upload Class Initialized
INFO - 2021-09-08 10:03:33 --> MY_Model class loaded
INFO - 2021-09-08 10:03:33 --> Model "Application_model" initialized
INFO - 2021-09-08 10:03:33 --> Controller Class Initialized
DEBUG - 2021-09-08 10:03:33 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-08 10:03:33 --> Helper loaded: inflector_helper
INFO - 2021-09-08 10:03:33 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-08 10:03:33 --> Database Driver Class Initialized
ERROR - 2021-09-08 10:03:33 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-08 10:03:33 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-08 10:03:33 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-08 10:03:33 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-08 10:03:33 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\Users\Gopal Ghimire\Desktop\New folder\school\application\controllers\api\Parents.php 16
INFO - 2021-09-08 10:04:11 --> Config Class Initialized
INFO - 2021-09-08 10:04:11 --> Hooks Class Initialized
DEBUG - 2021-09-08 10:04:11 --> UTF-8 Support Enabled
INFO - 2021-09-08 10:04:11 --> Utf8 Class Initialized
INFO - 2021-09-08 10:04:11 --> URI Class Initialized
INFO - 2021-09-08 10:04:11 --> Router Class Initialized
INFO - 2021-09-08 10:04:11 --> Output Class Initialized
INFO - 2021-09-08 10:04:11 --> Security Class Initialized
DEBUG - 2021-09-08 10:04:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-08 10:04:11 --> CSRF cookie sent
INFO - 2021-09-08 10:04:11 --> Input Class Initialized
INFO - 2021-09-08 10:04:11 --> Language Class Initialized
INFO - 2021-09-08 10:04:11 --> Loader Class Initialized
INFO - 2021-09-08 10:04:11 --> Helper loaded: url_helper
INFO - 2021-09-08 10:04:11 --> Helper loaded: file_helper
INFO - 2021-09-08 10:04:11 --> Helper loaded: form_helper
INFO - 2021-09-08 10:04:11 --> Helper loaded: security_helper
INFO - 2021-09-08 10:04:11 --> Helper loaded: directory_helper
INFO - 2021-09-08 10:04:11 --> Helper loaded: general_helper
INFO - 2021-09-08 10:04:11 --> Database Driver Class Initialized
INFO - 2021-09-08 10:04:11 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-08 10:04:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-08 10:04:11 --> Pagination Class Initialized
INFO - 2021-09-08 10:04:11 --> XML-RPC Class Initialized
INFO - 2021-09-08 10:04:11 --> Form Validation Class Initialized
INFO - 2021-09-08 10:04:11 --> Upload Class Initialized
INFO - 2021-09-08 10:04:11 --> MY_Model class loaded
INFO - 2021-09-08 10:04:11 --> Model "Application_model" initialized
INFO - 2021-09-08 10:04:11 --> Controller Class Initialized
DEBUG - 2021-09-08 10:04:11 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-08 10:04:11 --> Helper loaded: inflector_helper
INFO - 2021-09-08 10:04:11 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-08 10:04:11 --> Database Driver Class Initialized
ERROR - 2021-09-08 10:04:11 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-08 10:04:11 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-08 10:04:11 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-08 10:04:11 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-08 10:04:11 --> Final output sent to browser
DEBUG - 2021-09-08 10:04:11 --> Total execution time: 0.1625
INFO - 2021-09-08 10:04:27 --> Config Class Initialized
INFO - 2021-09-08 10:04:27 --> Hooks Class Initialized
DEBUG - 2021-09-08 10:04:27 --> UTF-8 Support Enabled
INFO - 2021-09-08 10:04:27 --> Utf8 Class Initialized
INFO - 2021-09-08 10:04:27 --> URI Class Initialized
INFO - 2021-09-08 10:04:27 --> Router Class Initialized
INFO - 2021-09-08 10:04:27 --> Output Class Initialized
INFO - 2021-09-08 10:04:27 --> Security Class Initialized
DEBUG - 2021-09-08 10:04:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-08 10:04:27 --> CSRF cookie sent
INFO - 2021-09-08 10:04:27 --> Input Class Initialized
INFO - 2021-09-08 10:04:27 --> Language Class Initialized
INFO - 2021-09-08 10:04:27 --> Loader Class Initialized
INFO - 2021-09-08 10:04:27 --> Helper loaded: url_helper
INFO - 2021-09-08 10:04:27 --> Helper loaded: file_helper
INFO - 2021-09-08 10:04:27 --> Helper loaded: form_helper
INFO - 2021-09-08 10:04:27 --> Helper loaded: security_helper
INFO - 2021-09-08 10:04:27 --> Helper loaded: directory_helper
INFO - 2021-09-08 10:04:27 --> Helper loaded: general_helper
INFO - 2021-09-08 10:04:27 --> Database Driver Class Initialized
INFO - 2021-09-08 10:04:27 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-08 10:04:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-08 10:04:27 --> Pagination Class Initialized
INFO - 2021-09-08 10:04:27 --> XML-RPC Class Initialized
INFO - 2021-09-08 10:04:27 --> Form Validation Class Initialized
INFO - 2021-09-08 10:04:27 --> Upload Class Initialized
INFO - 2021-09-08 10:04:27 --> MY_Model class loaded
INFO - 2021-09-08 10:04:27 --> Model "Application_model" initialized
INFO - 2021-09-08 10:04:27 --> Controller Class Initialized
DEBUG - 2021-09-08 10:04:27 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-08 10:04:27 --> Helper loaded: inflector_helper
INFO - 2021-09-08 10:04:27 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-08 10:04:27 --> Database Driver Class Initialized
ERROR - 2021-09-08 10:04:27 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-08 10:04:27 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-08 10:04:27 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-08 10:04:27 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-08 10:04:27 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\Users\Gopal Ghimire\Desktop\New folder\school\application\controllers\api\Parents.php 15
INFO - 2021-09-08 10:04:43 --> Config Class Initialized
INFO - 2021-09-08 10:04:43 --> Hooks Class Initialized
DEBUG - 2021-09-08 10:04:43 --> UTF-8 Support Enabled
INFO - 2021-09-08 10:04:43 --> Utf8 Class Initialized
INFO - 2021-09-08 10:04:43 --> URI Class Initialized
INFO - 2021-09-08 10:04:43 --> Router Class Initialized
INFO - 2021-09-08 10:04:43 --> Output Class Initialized
INFO - 2021-09-08 10:04:43 --> Security Class Initialized
DEBUG - 2021-09-08 10:04:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-08 10:04:43 --> CSRF cookie sent
INFO - 2021-09-08 10:04:43 --> Input Class Initialized
INFO - 2021-09-08 10:04:43 --> Language Class Initialized
INFO - 2021-09-08 10:04:43 --> Loader Class Initialized
INFO - 2021-09-08 10:04:43 --> Helper loaded: url_helper
INFO - 2021-09-08 10:04:43 --> Helper loaded: file_helper
INFO - 2021-09-08 10:04:43 --> Helper loaded: form_helper
INFO - 2021-09-08 10:04:43 --> Helper loaded: security_helper
INFO - 2021-09-08 10:04:43 --> Helper loaded: directory_helper
INFO - 2021-09-08 10:04:43 --> Helper loaded: general_helper
INFO - 2021-09-08 10:04:43 --> Database Driver Class Initialized
INFO - 2021-09-08 10:04:43 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-08 10:04:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-08 10:04:43 --> Pagination Class Initialized
INFO - 2021-09-08 10:04:43 --> XML-RPC Class Initialized
INFO - 2021-09-08 10:04:43 --> Form Validation Class Initialized
INFO - 2021-09-08 10:04:43 --> Upload Class Initialized
INFO - 2021-09-08 10:04:43 --> MY_Model class loaded
INFO - 2021-09-08 10:04:43 --> Model "Application_model" initialized
INFO - 2021-09-08 10:04:43 --> Controller Class Initialized
DEBUG - 2021-09-08 10:04:43 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-08 10:04:43 --> Helper loaded: inflector_helper
INFO - 2021-09-08 10:04:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-08 10:04:43 --> Database Driver Class Initialized
ERROR - 2021-09-08 10:04:43 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-08 10:04:43 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-08 10:04:43 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-08 10:04:43 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-08 10:04:43 --> Final output sent to browser
DEBUG - 2021-09-08 10:04:43 --> Total execution time: 0.1798
INFO - 2021-09-08 10:05:07 --> Config Class Initialized
INFO - 2021-09-08 10:05:07 --> Hooks Class Initialized
DEBUG - 2021-09-08 10:05:07 --> UTF-8 Support Enabled
INFO - 2021-09-08 10:05:07 --> Utf8 Class Initialized
INFO - 2021-09-08 10:05:07 --> URI Class Initialized
INFO - 2021-09-08 10:05:07 --> Router Class Initialized
INFO - 2021-09-08 10:05:07 --> Output Class Initialized
INFO - 2021-09-08 10:05:07 --> Security Class Initialized
DEBUG - 2021-09-08 10:05:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-08 10:05:07 --> CSRF cookie sent
INFO - 2021-09-08 10:05:07 --> Input Class Initialized
INFO - 2021-09-08 10:05:07 --> Language Class Initialized
INFO - 2021-09-08 10:05:07 --> Loader Class Initialized
INFO - 2021-09-08 10:05:07 --> Helper loaded: url_helper
INFO - 2021-09-08 10:05:07 --> Helper loaded: file_helper
INFO - 2021-09-08 10:05:07 --> Helper loaded: form_helper
INFO - 2021-09-08 10:05:07 --> Helper loaded: security_helper
INFO - 2021-09-08 10:05:07 --> Helper loaded: directory_helper
INFO - 2021-09-08 10:05:07 --> Helper loaded: general_helper
INFO - 2021-09-08 10:05:07 --> Database Driver Class Initialized
INFO - 2021-09-08 10:05:07 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-08 10:05:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-08 10:05:07 --> Pagination Class Initialized
INFO - 2021-09-08 10:05:07 --> XML-RPC Class Initialized
INFO - 2021-09-08 10:05:07 --> Form Validation Class Initialized
INFO - 2021-09-08 10:05:07 --> Upload Class Initialized
INFO - 2021-09-08 10:05:07 --> MY_Model class loaded
INFO - 2021-09-08 10:05:07 --> Model "Application_model" initialized
INFO - 2021-09-08 10:05:07 --> Controller Class Initialized
DEBUG - 2021-09-08 10:05:07 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-08 10:05:07 --> Helper loaded: inflector_helper
INFO - 2021-09-08 10:05:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-08 10:05:07 --> Database Driver Class Initialized
ERROR - 2021-09-08 10:05:07 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-08 10:05:07 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-08 10:05:07 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-08 10:05:07 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-08 10:05:07 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\Users\Gopal Ghimire\Desktop\New folder\school\application\controllers\api\Parents.php 15
INFO - 2021-09-08 10:05:40 --> Config Class Initialized
INFO - 2021-09-08 10:05:40 --> Hooks Class Initialized
DEBUG - 2021-09-08 10:05:40 --> UTF-8 Support Enabled
INFO - 2021-09-08 10:05:40 --> Utf8 Class Initialized
INFO - 2021-09-08 10:05:40 --> URI Class Initialized
INFO - 2021-09-08 10:05:40 --> Router Class Initialized
INFO - 2021-09-08 10:05:40 --> Output Class Initialized
INFO - 2021-09-08 10:05:40 --> Security Class Initialized
DEBUG - 2021-09-08 10:05:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-08 10:05:40 --> CSRF cookie sent
INFO - 2021-09-08 10:05:40 --> Input Class Initialized
INFO - 2021-09-08 10:05:40 --> Language Class Initialized
INFO - 2021-09-08 10:05:40 --> Loader Class Initialized
INFO - 2021-09-08 10:05:40 --> Helper loaded: url_helper
INFO - 2021-09-08 10:05:40 --> Helper loaded: file_helper
INFO - 2021-09-08 10:05:40 --> Helper loaded: form_helper
INFO - 2021-09-08 10:05:40 --> Helper loaded: security_helper
INFO - 2021-09-08 10:05:40 --> Helper loaded: directory_helper
INFO - 2021-09-08 10:05:40 --> Helper loaded: general_helper
INFO - 2021-09-08 10:05:40 --> Database Driver Class Initialized
INFO - 2021-09-08 10:05:40 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-08 10:05:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-08 10:05:40 --> Pagination Class Initialized
INFO - 2021-09-08 10:05:40 --> XML-RPC Class Initialized
INFO - 2021-09-08 10:05:40 --> Form Validation Class Initialized
INFO - 2021-09-08 10:05:40 --> Upload Class Initialized
INFO - 2021-09-08 10:05:40 --> MY_Model class loaded
INFO - 2021-09-08 10:05:40 --> Model "Application_model" initialized
INFO - 2021-09-08 10:05:40 --> Controller Class Initialized
DEBUG - 2021-09-08 10:05:40 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-08 10:05:40 --> Helper loaded: inflector_helper
INFO - 2021-09-08 10:05:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-08 10:05:40 --> Database Driver Class Initialized
ERROR - 2021-09-08 10:05:40 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-08 10:05:40 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-08 10:05:40 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-08 10:05:40 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-08 10:05:40 --> Final output sent to browser
DEBUG - 2021-09-08 10:05:40 --> Total execution time: 0.3186
INFO - 2021-09-08 10:06:15 --> Config Class Initialized
INFO - 2021-09-08 10:06:15 --> Hooks Class Initialized
DEBUG - 2021-09-08 10:06:15 --> UTF-8 Support Enabled
INFO - 2021-09-08 10:06:15 --> Utf8 Class Initialized
INFO - 2021-09-08 10:06:15 --> URI Class Initialized
INFO - 2021-09-08 10:06:15 --> Router Class Initialized
INFO - 2021-09-08 10:06:15 --> Output Class Initialized
INFO - 2021-09-08 10:06:15 --> Security Class Initialized
DEBUG - 2021-09-08 10:06:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-08 10:06:15 --> CSRF cookie sent
INFO - 2021-09-08 10:06:15 --> Input Class Initialized
INFO - 2021-09-08 10:06:15 --> Language Class Initialized
INFO - 2021-09-08 10:06:15 --> Loader Class Initialized
INFO - 2021-09-08 10:06:15 --> Helper loaded: url_helper
INFO - 2021-09-08 10:06:15 --> Helper loaded: file_helper
INFO - 2021-09-08 10:06:15 --> Helper loaded: form_helper
INFO - 2021-09-08 10:06:15 --> Helper loaded: security_helper
INFO - 2021-09-08 10:06:15 --> Helper loaded: directory_helper
INFO - 2021-09-08 10:06:15 --> Helper loaded: general_helper
INFO - 2021-09-08 10:06:15 --> Database Driver Class Initialized
INFO - 2021-09-08 10:06:15 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-08 10:06:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-08 10:06:15 --> Pagination Class Initialized
INFO - 2021-09-08 10:06:15 --> XML-RPC Class Initialized
INFO - 2021-09-08 10:06:15 --> Form Validation Class Initialized
INFO - 2021-09-08 10:06:15 --> Upload Class Initialized
INFO - 2021-09-08 10:06:15 --> MY_Model class loaded
INFO - 2021-09-08 10:06:15 --> Model "Application_model" initialized
INFO - 2021-09-08 10:06:15 --> Controller Class Initialized
DEBUG - 2021-09-08 10:06:15 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-08 10:06:15 --> Helper loaded: inflector_helper
INFO - 2021-09-08 10:06:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-08 10:06:15 --> Database Driver Class Initialized
ERROR - 2021-09-08 10:06:15 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-08 10:06:15 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-08 10:06:15 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-08 10:06:15 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-08 10:06:15 --> Final output sent to browser
DEBUG - 2021-09-08 10:06:15 --> Total execution time: 0.2008
INFO - 2021-09-08 10:23:40 --> Config Class Initialized
INFO - 2021-09-08 10:23:40 --> Hooks Class Initialized
DEBUG - 2021-09-08 10:23:40 --> UTF-8 Support Enabled
INFO - 2021-09-08 10:23:40 --> Utf8 Class Initialized
INFO - 2021-09-08 10:23:40 --> URI Class Initialized
INFO - 2021-09-08 10:23:41 --> Router Class Initialized
INFO - 2021-09-08 10:23:41 --> Output Class Initialized
INFO - 2021-09-08 10:23:41 --> Security Class Initialized
DEBUG - 2021-09-08 10:23:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-08 10:23:41 --> CSRF cookie sent
INFO - 2021-09-08 10:23:41 --> Input Class Initialized
INFO - 2021-09-08 10:23:41 --> Language Class Initialized
INFO - 2021-09-08 10:23:41 --> Loader Class Initialized
INFO - 2021-09-08 10:23:41 --> Helper loaded: url_helper
INFO - 2021-09-08 10:23:41 --> Helper loaded: file_helper
INFO - 2021-09-08 10:23:41 --> Helper loaded: form_helper
INFO - 2021-09-08 10:23:41 --> Helper loaded: security_helper
INFO - 2021-09-08 10:23:41 --> Helper loaded: directory_helper
INFO - 2021-09-08 10:23:41 --> Helper loaded: general_helper
INFO - 2021-09-08 10:23:41 --> Database Driver Class Initialized
INFO - 2021-09-08 10:23:41 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-08 10:23:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-08 10:23:41 --> Pagination Class Initialized
INFO - 2021-09-08 10:23:41 --> XML-RPC Class Initialized
INFO - 2021-09-08 10:23:41 --> Form Validation Class Initialized
INFO - 2021-09-08 10:23:42 --> Upload Class Initialized
INFO - 2021-09-08 10:23:42 --> MY_Model class loaded
INFO - 2021-09-08 10:23:42 --> Model "Application_model" initialized
INFO - 2021-09-08 10:23:42 --> Controller Class Initialized
DEBUG - 2021-09-08 10:23:42 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-08 10:23:42 --> Helper loaded: inflector_helper
INFO - 2021-09-08 10:23:42 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-08 10:23:42 --> Database Driver Class Initialized
ERROR - 2021-09-08 10:23:42 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-08 10:23:42 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-08 10:23:42 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-08 10:23:42 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-08 10:23:42 --> Final output sent to browser
DEBUG - 2021-09-08 10:23:42 --> Total execution time: 1.7994
INFO - 2021-09-08 10:37:08 --> Config Class Initialized
INFO - 2021-09-08 10:37:08 --> Hooks Class Initialized
DEBUG - 2021-09-08 10:37:08 --> UTF-8 Support Enabled
INFO - 2021-09-08 10:37:08 --> Utf8 Class Initialized
INFO - 2021-09-08 10:37:08 --> URI Class Initialized
DEBUG - 2021-09-08 10:37:08 --> No URI present. Default controller set.
INFO - 2021-09-08 10:37:08 --> Router Class Initialized
INFO - 2021-09-08 10:37:08 --> Output Class Initialized
INFO - 2021-09-08 10:37:08 --> Security Class Initialized
DEBUG - 2021-09-08 10:37:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-08 10:37:08 --> CSRF cookie sent
INFO - 2021-09-08 10:37:08 --> Input Class Initialized
INFO - 2021-09-08 10:37:08 --> Language Class Initialized
INFO - 2021-09-08 10:37:09 --> Loader Class Initialized
INFO - 2021-09-08 10:37:09 --> Helper loaded: url_helper
INFO - 2021-09-08 10:37:09 --> Helper loaded: file_helper
INFO - 2021-09-08 10:37:09 --> Helper loaded: form_helper
INFO - 2021-09-08 10:37:09 --> Helper loaded: security_helper
INFO - 2021-09-08 10:37:09 --> Helper loaded: directory_helper
INFO - 2021-09-08 10:37:09 --> Helper loaded: general_helper
INFO - 2021-09-08 10:37:09 --> Database Driver Class Initialized
INFO - 2021-09-08 10:37:10 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-08 10:37:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-08 10:37:10 --> Pagination Class Initialized
INFO - 2021-09-08 10:37:10 --> XML-RPC Class Initialized
INFO - 2021-09-08 10:37:10 --> Form Validation Class Initialized
INFO - 2021-09-08 10:37:10 --> Upload Class Initialized
INFO - 2021-09-08 10:37:10 --> MY_Model class loaded
INFO - 2021-09-08 10:37:10 --> Model "Application_model" initialized
INFO - 2021-09-08 10:37:10 --> Controller Class Initialized
INFO - 2021-09-08 14:22:12 --> Model "Home_model" initialized
INFO - 2021-09-08 10:37:14 --> Config Class Initialized
INFO - 2021-09-08 10:37:14 --> Hooks Class Initialized
DEBUG - 2021-09-08 10:37:14 --> UTF-8 Support Enabled
INFO - 2021-09-08 10:37:14 --> Utf8 Class Initialized
INFO - 2021-09-08 10:37:14 --> URI Class Initialized
INFO - 2021-09-08 10:37:14 --> Router Class Initialized
INFO - 2021-09-08 10:37:14 --> Output Class Initialized
INFO - 2021-09-08 10:37:14 --> Security Class Initialized
DEBUG - 2021-09-08 10:37:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-08 10:37:14 --> CSRF cookie sent
INFO - 2021-09-08 10:37:14 --> Input Class Initialized
INFO - 2021-09-08 10:37:14 --> Language Class Initialized
INFO - 2021-09-08 10:37:15 --> Loader Class Initialized
INFO - 2021-09-08 10:37:15 --> Helper loaded: url_helper
INFO - 2021-09-08 10:37:15 --> Helper loaded: file_helper
INFO - 2021-09-08 10:37:15 --> Helper loaded: form_helper
INFO - 2021-09-08 10:37:15 --> Helper loaded: security_helper
INFO - 2021-09-08 10:37:15 --> Helper loaded: directory_helper
INFO - 2021-09-08 10:37:15 --> Helper loaded: general_helper
INFO - 2021-09-08 10:37:15 --> Database Driver Class Initialized
INFO - 2021-09-08 10:37:15 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-08 10:37:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-08 10:37:15 --> Pagination Class Initialized
INFO - 2021-09-08 10:37:15 --> XML-RPC Class Initialized
INFO - 2021-09-08 10:37:15 --> Form Validation Class Initialized
INFO - 2021-09-08 10:37:15 --> Upload Class Initialized
INFO - 2021-09-08 10:37:15 --> MY_Model class loaded
INFO - 2021-09-08 10:37:15 --> Model "Application_model" initialized
INFO - 2021-09-08 10:37:15 --> Controller Class Initialized
INFO - 2021-09-08 14:22:15 --> Model "Authentication_model" initialized
INFO - 2021-09-08 14:22:18 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\authentication/login.php
INFO - 2021-09-08 14:22:18 --> Final output sent to browser
DEBUG - 2021-09-08 14:22:18 --> Total execution time: 4.4468
INFO - 2021-09-08 11:40:07 --> Config Class Initialized
INFO - 2021-09-08 11:40:08 --> Hooks Class Initialized
DEBUG - 2021-09-08 11:40:08 --> UTF-8 Support Enabled
INFO - 2021-09-08 11:40:08 --> Utf8 Class Initialized
INFO - 2021-09-08 11:40:09 --> URI Class Initialized
INFO - 2021-09-08 11:40:10 --> Router Class Initialized
INFO - 2021-09-08 11:40:10 --> Output Class Initialized
INFO - 2021-09-08 11:40:10 --> Security Class Initialized
DEBUG - 2021-09-08 11:40:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-08 11:40:11 --> CSRF cookie sent
INFO - 2021-09-08 11:40:11 --> CSRF token verified
INFO - 2021-09-08 11:40:11 --> Input Class Initialized
INFO - 2021-09-08 11:40:11 --> Language Class Initialized
INFO - 2021-09-08 11:40:11 --> Loader Class Initialized
INFO - 2021-09-08 11:40:12 --> Helper loaded: url_helper
INFO - 2021-09-08 11:40:12 --> Helper loaded: file_helper
INFO - 2021-09-08 11:40:13 --> Helper loaded: form_helper
INFO - 2021-09-08 11:40:13 --> Helper loaded: security_helper
INFO - 2021-09-08 11:40:13 --> Helper loaded: directory_helper
INFO - 2021-09-08 11:40:13 --> Helper loaded: general_helper
INFO - 2021-09-08 11:40:15 --> Database Driver Class Initialized
INFO - 2021-09-08 11:40:21 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-08 11:40:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-08 11:40:22 --> Pagination Class Initialized
INFO - 2021-09-08 11:40:23 --> XML-RPC Class Initialized
INFO - 2021-09-08 11:40:23 --> Form Validation Class Initialized
INFO - 2021-09-08 11:40:24 --> Upload Class Initialized
INFO - 2021-09-08 11:40:24 --> MY_Model class loaded
INFO - 2021-09-08 11:40:25 --> Model "Application_model" initialized
INFO - 2021-09-08 11:40:25 --> Controller Class Initialized
INFO - 2021-09-08 15:25:25 --> Model "Authentication_model" initialized
INFO - 2021-09-08 15:25:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-09-08 11:40:30 --> Config Class Initialized
INFO - 2021-09-08 11:40:30 --> Hooks Class Initialized
DEBUG - 2021-09-08 11:40:30 --> UTF-8 Support Enabled
INFO - 2021-09-08 11:40:30 --> Utf8 Class Initialized
INFO - 2021-09-08 11:40:30 --> URI Class Initialized
INFO - 2021-09-08 11:40:30 --> Router Class Initialized
INFO - 2021-09-08 11:40:30 --> Output Class Initialized
INFO - 2021-09-08 11:40:30 --> Security Class Initialized
DEBUG - 2021-09-08 11:40:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-08 11:40:30 --> CSRF cookie sent
INFO - 2021-09-08 11:40:30 --> Input Class Initialized
INFO - 2021-09-08 11:40:30 --> Language Class Initialized
INFO - 2021-09-08 11:40:30 --> Loader Class Initialized
INFO - 2021-09-08 11:40:30 --> Helper loaded: url_helper
INFO - 2021-09-08 11:40:30 --> Helper loaded: file_helper
INFO - 2021-09-08 11:40:30 --> Helper loaded: form_helper
INFO - 2021-09-08 11:40:30 --> Helper loaded: security_helper
INFO - 2021-09-08 11:40:30 --> Helper loaded: directory_helper
INFO - 2021-09-08 11:40:30 --> Helper loaded: general_helper
INFO - 2021-09-08 11:40:31 --> Database Driver Class Initialized
INFO - 2021-09-08 11:40:31 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-08 11:40:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-08 11:40:31 --> Pagination Class Initialized
INFO - 2021-09-08 11:40:31 --> XML-RPC Class Initialized
INFO - 2021-09-08 11:40:31 --> Form Validation Class Initialized
INFO - 2021-09-08 11:40:31 --> Upload Class Initialized
INFO - 2021-09-08 11:40:31 --> MY_Model class loaded
INFO - 2021-09-08 11:40:31 --> Model "Application_model" initialized
INFO - 2021-09-08 11:40:31 --> Controller Class Initialized
INFO - 2021-09-08 15:25:31 --> Model "Dashboard_model" initialized
INFO - 2021-09-08 15:25:40 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/header.php
INFO - 2021-09-08 15:25:45 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/topbar.php
INFO - 2021-09-08 15:25:46 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/sidebar.php
INFO - 2021-09-08 15:25:48 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\dashboard/index.php
INFO - 2021-09-08 15:25:49 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/script.php
INFO - 2021-09-08 15:25:49 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/index.php
INFO - 2021-09-08 15:25:49 --> Final output sent to browser
DEBUG - 2021-09-08 15:25:49 --> Total execution time: 18.8564
INFO - 2021-09-08 11:52:13 --> Config Class Initialized
INFO - 2021-09-08 11:52:13 --> Hooks Class Initialized
DEBUG - 2021-09-08 11:52:14 --> UTF-8 Support Enabled
INFO - 2021-09-08 11:52:14 --> Utf8 Class Initialized
INFO - 2021-09-08 11:52:14 --> URI Class Initialized
DEBUG - 2021-09-08 11:52:14 --> No URI present. Default controller set.
INFO - 2021-09-08 11:52:14 --> Router Class Initialized
INFO - 2021-09-08 11:52:15 --> Output Class Initialized
INFO - 2021-09-08 11:52:15 --> Security Class Initialized
DEBUG - 2021-09-08 11:52:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-08 11:52:16 --> CSRF cookie sent
INFO - 2021-09-08 11:52:16 --> Input Class Initialized
INFO - 2021-09-08 11:52:16 --> Language Class Initialized
INFO - 2021-09-08 11:52:16 --> Loader Class Initialized
INFO - 2021-09-08 11:52:16 --> Helper loaded: url_helper
INFO - 2021-09-08 11:52:16 --> Helper loaded: file_helper
INFO - 2021-09-08 11:52:16 --> Helper loaded: form_helper
INFO - 2021-09-08 11:52:16 --> Helper loaded: security_helper
INFO - 2021-09-08 11:52:16 --> Helper loaded: directory_helper
INFO - 2021-09-08 11:52:17 --> Helper loaded: general_helper
INFO - 2021-09-08 11:52:18 --> Database Driver Class Initialized
INFO - 2021-09-08 11:52:23 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-08 11:52:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-08 11:52:24 --> Pagination Class Initialized
INFO - 2021-09-08 11:52:24 --> XML-RPC Class Initialized
INFO - 2021-09-08 11:52:24 --> Form Validation Class Initialized
INFO - 2021-09-08 11:52:24 --> Upload Class Initialized
INFO - 2021-09-08 11:52:25 --> MY_Model class loaded
INFO - 2021-09-08 11:52:25 --> Model "Application_model" initialized
INFO - 2021-09-08 11:52:25 --> Controller Class Initialized
INFO - 2021-09-08 15:37:25 --> Model "Home_model" initialized
INFO - 2021-09-08 11:52:26 --> Config Class Initialized
INFO - 2021-09-08 11:52:26 --> Hooks Class Initialized
DEBUG - 2021-09-08 11:52:26 --> UTF-8 Support Enabled
INFO - 2021-09-08 11:52:26 --> Utf8 Class Initialized
INFO - 2021-09-08 11:52:26 --> URI Class Initialized
INFO - 2021-09-08 11:52:26 --> Router Class Initialized
INFO - 2021-09-08 11:52:26 --> Output Class Initialized
INFO - 2021-09-08 11:52:26 --> Security Class Initialized
DEBUG - 2021-09-08 11:52:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-08 11:52:26 --> CSRF cookie sent
INFO - 2021-09-08 11:52:26 --> Input Class Initialized
INFO - 2021-09-08 11:52:26 --> Language Class Initialized
INFO - 2021-09-08 11:52:26 --> Loader Class Initialized
INFO - 2021-09-08 11:52:26 --> Helper loaded: url_helper
INFO - 2021-09-08 11:52:26 --> Helper loaded: file_helper
INFO - 2021-09-08 11:52:26 --> Helper loaded: form_helper
INFO - 2021-09-08 11:52:26 --> Helper loaded: security_helper
INFO - 2021-09-08 11:52:26 --> Helper loaded: directory_helper
INFO - 2021-09-08 11:52:26 --> Helper loaded: general_helper
INFO - 2021-09-08 11:52:26 --> Database Driver Class Initialized
INFO - 2021-09-08 11:52:27 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-08 11:52:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-08 11:52:27 --> Pagination Class Initialized
INFO - 2021-09-08 11:52:27 --> XML-RPC Class Initialized
INFO - 2021-09-08 11:52:27 --> Form Validation Class Initialized
INFO - 2021-09-08 11:52:27 --> Upload Class Initialized
INFO - 2021-09-08 11:52:27 --> MY_Model class loaded
INFO - 2021-09-08 11:52:27 --> Model "Application_model" initialized
INFO - 2021-09-08 11:52:27 --> Controller Class Initialized
INFO - 2021-09-08 15:37:27 --> Model "Authentication_model" initialized
INFO - 2021-09-08 11:52:27 --> Config Class Initialized
INFO - 2021-09-08 11:52:27 --> Hooks Class Initialized
DEBUG - 2021-09-08 11:52:27 --> UTF-8 Support Enabled
INFO - 2021-09-08 11:52:27 --> Utf8 Class Initialized
INFO - 2021-09-08 11:52:27 --> URI Class Initialized
INFO - 2021-09-08 11:52:27 --> Router Class Initialized
INFO - 2021-09-08 11:52:27 --> Output Class Initialized
INFO - 2021-09-08 11:52:27 --> Security Class Initialized
DEBUG - 2021-09-08 11:52:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-08 11:52:27 --> CSRF cookie sent
INFO - 2021-09-08 11:52:27 --> Input Class Initialized
INFO - 2021-09-08 11:52:27 --> Language Class Initialized
INFO - 2021-09-08 11:52:28 --> Loader Class Initialized
INFO - 2021-09-08 11:52:28 --> Helper loaded: url_helper
INFO - 2021-09-08 11:52:28 --> Helper loaded: file_helper
INFO - 2021-09-08 11:52:28 --> Helper loaded: form_helper
INFO - 2021-09-08 11:52:28 --> Helper loaded: security_helper
INFO - 2021-09-08 11:52:28 --> Helper loaded: directory_helper
INFO - 2021-09-08 11:52:28 --> Helper loaded: general_helper
INFO - 2021-09-08 11:52:28 --> Database Driver Class Initialized
INFO - 2021-09-08 11:52:28 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-08 11:52:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-08 11:52:28 --> Pagination Class Initialized
INFO - 2021-09-08 11:52:28 --> XML-RPC Class Initialized
INFO - 2021-09-08 11:52:28 --> Form Validation Class Initialized
INFO - 2021-09-08 11:52:28 --> Upload Class Initialized
INFO - 2021-09-08 11:52:28 --> MY_Model class loaded
INFO - 2021-09-08 11:52:28 --> Model "Application_model" initialized
INFO - 2021-09-08 11:52:28 --> Controller Class Initialized
INFO - 2021-09-08 15:37:28 --> Model "Dashboard_model" initialized
INFO - 2021-09-08 15:37:31 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/header.php
INFO - 2021-09-08 15:37:32 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/topbar.php
INFO - 2021-09-08 15:37:32 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/sidebar.php
INFO - 2021-09-08 15:37:34 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\dashboard/index.php
INFO - 2021-09-08 15:37:34 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/script.php
INFO - 2021-09-08 15:37:34 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/index.php
INFO - 2021-09-08 15:37:34 --> Final output sent to browser
DEBUG - 2021-09-08 15:37:34 --> Total execution time: 7.0178
INFO - 2021-09-08 11:54:00 --> Config Class Initialized
INFO - 2021-09-08 11:54:00 --> Hooks Class Initialized
DEBUG - 2021-09-08 11:54:00 --> UTF-8 Support Enabled
INFO - 2021-09-08 11:54:00 --> Utf8 Class Initialized
INFO - 2021-09-08 11:54:00 --> URI Class Initialized
INFO - 2021-09-08 11:54:00 --> Router Class Initialized
INFO - 2021-09-08 11:54:00 --> Output Class Initialized
INFO - 2021-09-08 11:54:00 --> Security Class Initialized
DEBUG - 2021-09-08 11:54:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-08 11:54:01 --> CSRF cookie sent
INFO - 2021-09-08 11:54:01 --> Input Class Initialized
INFO - 2021-09-08 11:54:01 --> Language Class Initialized
INFO - 2021-09-08 11:54:01 --> Loader Class Initialized
INFO - 2021-09-08 11:54:02 --> Helper loaded: url_helper
INFO - 2021-09-08 11:54:02 --> Helper loaded: file_helper
INFO - 2021-09-08 11:54:02 --> Helper loaded: form_helper
INFO - 2021-09-08 11:54:02 --> Helper loaded: security_helper
INFO - 2021-09-08 11:54:02 --> Helper loaded: directory_helper
INFO - 2021-09-08 11:54:02 --> Helper loaded: general_helper
INFO - 2021-09-08 11:54:03 --> Database Driver Class Initialized
INFO - 2021-09-08 11:54:05 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-08 11:54:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-08 11:54:05 --> Pagination Class Initialized
INFO - 2021-09-08 11:54:05 --> XML-RPC Class Initialized
INFO - 2021-09-08 11:54:05 --> Form Validation Class Initialized
INFO - 2021-09-08 11:54:06 --> Upload Class Initialized
INFO - 2021-09-08 11:54:06 --> MY_Model class loaded
INFO - 2021-09-08 11:54:06 --> Model "Application_model" initialized
INFO - 2021-09-08 11:54:06 --> Controller Class Initialized
INFO - 2021-09-08 15:39:07 --> Helper loaded: custom_fields_helper
INFO - 2021-09-08 15:39:07 --> Model "Employee_model" initialized
INFO - 2021-09-08 15:39:09 --> Email Class Initialized
INFO - 2021-09-08 15:39:09 --> Model "Email_model" initialized
INFO - 2021-09-08 15:39:09 --> Model "Crud_model" initialized
INFO - 2021-09-08 15:39:19 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/header.php
INFO - 2021-09-08 15:39:19 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/topbar.php
INFO - 2021-09-08 15:39:19 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/sidebar.php
INFO - 2021-09-08 15:39:21 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\employee/view.php
INFO - 2021-09-08 15:39:21 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/script.php
INFO - 2021-09-08 15:39:21 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/index.php
INFO - 2021-09-08 15:39:21 --> Final output sent to browser
DEBUG - 2021-09-08 15:39:21 --> Total execution time: 21.0227
INFO - 2021-09-08 12:31:59 --> Config Class Initialized
INFO - 2021-09-08 12:31:59 --> Hooks Class Initialized
DEBUG - 2021-09-08 12:31:59 --> UTF-8 Support Enabled
INFO - 2021-09-08 12:31:59 --> Utf8 Class Initialized
INFO - 2021-09-08 12:31:59 --> URI Class Initialized
DEBUG - 2021-09-08 12:31:59 --> No URI present. Default controller set.
INFO - 2021-09-08 12:31:59 --> Router Class Initialized
INFO - 2021-09-08 12:31:59 --> Output Class Initialized
INFO - 2021-09-08 12:31:59 --> Security Class Initialized
DEBUG - 2021-09-08 12:31:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-08 12:31:59 --> CSRF cookie sent
INFO - 2021-09-08 12:31:59 --> Input Class Initialized
INFO - 2021-09-08 12:31:59 --> Language Class Initialized
INFO - 2021-09-08 12:31:59 --> Loader Class Initialized
INFO - 2021-09-08 12:31:59 --> Helper loaded: url_helper
INFO - 2021-09-08 12:31:59 --> Helper loaded: file_helper
INFO - 2021-09-08 12:31:59 --> Helper loaded: form_helper
INFO - 2021-09-08 12:31:59 --> Helper loaded: security_helper
INFO - 2021-09-08 12:31:59 --> Helper loaded: directory_helper
INFO - 2021-09-08 12:31:59 --> Helper loaded: general_helper
INFO - 2021-09-08 12:32:00 --> Database Driver Class Initialized
INFO - 2021-09-08 12:32:01 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-08 12:32:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-08 12:32:01 --> Pagination Class Initialized
INFO - 2021-09-08 12:32:01 --> XML-RPC Class Initialized
INFO - 2021-09-08 12:32:01 --> Form Validation Class Initialized
INFO - 2021-09-08 12:32:01 --> Upload Class Initialized
INFO - 2021-09-08 12:32:01 --> MY_Model class loaded
INFO - 2021-09-08 12:32:01 --> Model "Application_model" initialized
INFO - 2021-09-08 12:32:01 --> Controller Class Initialized
INFO - 2021-09-08 16:17:02 --> Model "Home_model" initialized
INFO - 2021-09-08 12:32:02 --> Config Class Initialized
INFO - 2021-09-08 12:32:02 --> Hooks Class Initialized
DEBUG - 2021-09-08 12:32:02 --> UTF-8 Support Enabled
INFO - 2021-09-08 12:32:02 --> Utf8 Class Initialized
INFO - 2021-09-08 12:32:02 --> URI Class Initialized
INFO - 2021-09-08 12:32:02 --> Router Class Initialized
INFO - 2021-09-08 12:32:02 --> Output Class Initialized
INFO - 2021-09-08 12:32:02 --> Security Class Initialized
DEBUG - 2021-09-08 12:32:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-08 12:32:02 --> CSRF cookie sent
INFO - 2021-09-08 12:32:02 --> Input Class Initialized
INFO - 2021-09-08 12:32:02 --> Language Class Initialized
INFO - 2021-09-08 12:32:02 --> Loader Class Initialized
INFO - 2021-09-08 12:32:02 --> Helper loaded: url_helper
INFO - 2021-09-08 12:32:02 --> Helper loaded: file_helper
INFO - 2021-09-08 12:32:02 --> Helper loaded: form_helper
INFO - 2021-09-08 12:32:03 --> Helper loaded: security_helper
INFO - 2021-09-08 12:32:03 --> Helper loaded: directory_helper
INFO - 2021-09-08 12:32:03 --> Helper loaded: general_helper
INFO - 2021-09-08 12:32:03 --> Database Driver Class Initialized
INFO - 2021-09-08 12:32:03 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-08 12:32:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-08 12:32:03 --> Pagination Class Initialized
INFO - 2021-09-08 12:32:03 --> XML-RPC Class Initialized
INFO - 2021-09-08 12:32:03 --> Form Validation Class Initialized
INFO - 2021-09-08 12:32:03 --> Upload Class Initialized
INFO - 2021-09-08 12:32:03 --> MY_Model class loaded
INFO - 2021-09-08 12:32:03 --> Model "Application_model" initialized
INFO - 2021-09-08 12:32:03 --> Controller Class Initialized
INFO - 2021-09-08 16:17:03 --> Model "Authentication_model" initialized
INFO - 2021-09-08 12:32:03 --> Config Class Initialized
INFO - 2021-09-08 12:32:03 --> Hooks Class Initialized
DEBUG - 2021-09-08 12:32:03 --> UTF-8 Support Enabled
INFO - 2021-09-08 12:32:03 --> Utf8 Class Initialized
INFO - 2021-09-08 12:32:03 --> URI Class Initialized
INFO - 2021-09-08 12:32:03 --> Router Class Initialized
INFO - 2021-09-08 12:32:03 --> Output Class Initialized
INFO - 2021-09-08 12:32:03 --> Security Class Initialized
DEBUG - 2021-09-08 12:32:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-08 12:32:03 --> CSRF cookie sent
INFO - 2021-09-08 12:32:03 --> Input Class Initialized
INFO - 2021-09-08 12:32:03 --> Language Class Initialized
INFO - 2021-09-08 12:32:03 --> Loader Class Initialized
INFO - 2021-09-08 12:32:03 --> Helper loaded: url_helper
INFO - 2021-09-08 12:32:03 --> Helper loaded: file_helper
INFO - 2021-09-08 12:32:03 --> Helper loaded: form_helper
INFO - 2021-09-08 12:32:03 --> Helper loaded: security_helper
INFO - 2021-09-08 12:32:03 --> Helper loaded: directory_helper
INFO - 2021-09-08 12:32:03 --> Helper loaded: general_helper
INFO - 2021-09-08 12:32:03 --> Database Driver Class Initialized
INFO - 2021-09-08 12:32:03 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-08 12:32:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-08 12:32:03 --> Pagination Class Initialized
INFO - 2021-09-08 12:32:03 --> XML-RPC Class Initialized
INFO - 2021-09-08 12:32:03 --> Form Validation Class Initialized
INFO - 2021-09-08 12:32:03 --> Upload Class Initialized
INFO - 2021-09-08 12:32:03 --> MY_Model class loaded
INFO - 2021-09-08 12:32:03 --> Model "Application_model" initialized
INFO - 2021-09-08 12:32:03 --> Controller Class Initialized
INFO - 2021-09-08 16:17:03 --> Model "Dashboard_model" initialized
INFO - 2021-09-08 16:17:06 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/header.php
INFO - 2021-09-08 16:17:06 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/topbar.php
INFO - 2021-09-08 16:17:08 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/sidebar.php
INFO - 2021-09-08 16:17:09 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\dashboard/index.php
INFO - 2021-09-08 16:17:09 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/script.php
INFO - 2021-09-08 16:17:09 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/index.php
INFO - 2021-09-08 16:17:09 --> Final output sent to browser
DEBUG - 2021-09-08 16:17:09 --> Total execution time: 6.3583
INFO - 2021-09-08 12:33:24 --> Config Class Initialized
INFO - 2021-09-08 12:33:24 --> Hooks Class Initialized
DEBUG - 2021-09-08 12:33:24 --> UTF-8 Support Enabled
INFO - 2021-09-08 12:33:24 --> Utf8 Class Initialized
INFO - 2021-09-08 12:33:24 --> URI Class Initialized
INFO - 2021-09-08 12:33:24 --> Router Class Initialized
INFO - 2021-09-08 12:33:24 --> Output Class Initialized
INFO - 2021-09-08 12:33:24 --> Security Class Initialized
DEBUG - 2021-09-08 12:33:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-08 12:33:24 --> CSRF cookie sent
INFO - 2021-09-08 12:33:24 --> Input Class Initialized
INFO - 2021-09-08 12:33:24 --> Language Class Initialized
INFO - 2021-09-08 12:33:24 --> Loader Class Initialized
INFO - 2021-09-08 12:33:24 --> Helper loaded: url_helper
INFO - 2021-09-08 12:33:24 --> Helper loaded: file_helper
INFO - 2021-09-08 12:33:24 --> Helper loaded: form_helper
INFO - 2021-09-08 12:33:24 --> Helper loaded: security_helper
INFO - 2021-09-08 12:33:24 --> Helper loaded: directory_helper
INFO - 2021-09-08 12:33:24 --> Helper loaded: general_helper
INFO - 2021-09-08 12:33:24 --> Database Driver Class Initialized
INFO - 2021-09-08 12:33:24 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-08 12:33:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-08 12:33:25 --> Pagination Class Initialized
INFO - 2021-09-08 12:33:25 --> XML-RPC Class Initialized
INFO - 2021-09-08 12:33:25 --> Form Validation Class Initialized
INFO - 2021-09-08 12:33:25 --> Upload Class Initialized
INFO - 2021-09-08 12:33:25 --> MY_Model class loaded
INFO - 2021-09-08 12:33:25 --> Model "Application_model" initialized
INFO - 2021-09-08 12:33:25 --> Controller Class Initialized
INFO - 2021-09-08 16:18:25 --> Helper loaded: custom_fields_helper
INFO - 2021-09-08 16:18:25 --> Model "Employee_model" initialized
INFO - 2021-09-08 16:18:25 --> Email Class Initialized
INFO - 2021-09-08 16:18:25 --> Model "Email_model" initialized
INFO - 2021-09-08 16:18:25 --> Model "Crud_model" initialized
INFO - 2021-09-08 16:18:25 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/header.php
INFO - 2021-09-08 16:18:25 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/topbar.php
INFO - 2021-09-08 16:18:26 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/sidebar.php
INFO - 2021-09-08 16:18:26 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\employee/view.php
INFO - 2021-09-08 16:18:26 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/script.php
INFO - 2021-09-08 16:18:26 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/index.php
INFO - 2021-09-08 16:18:26 --> Final output sent to browser
DEBUG - 2021-09-08 16:18:26 --> Total execution time: 2.2518
INFO - 2021-09-08 12:39:40 --> Config Class Initialized
INFO - 2021-09-08 12:39:40 --> Hooks Class Initialized
DEBUG - 2021-09-08 12:39:40 --> UTF-8 Support Enabled
INFO - 2021-09-08 12:39:40 --> Utf8 Class Initialized
INFO - 2021-09-08 12:39:40 --> URI Class Initialized
INFO - 2021-09-08 12:39:40 --> Router Class Initialized
INFO - 2021-09-08 12:39:40 --> Output Class Initialized
INFO - 2021-09-08 12:39:40 --> Security Class Initialized
DEBUG - 2021-09-08 12:39:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-08 12:39:40 --> CSRF cookie sent
INFO - 2021-09-08 12:39:40 --> Input Class Initialized
INFO - 2021-09-08 12:39:40 --> Language Class Initialized
INFO - 2021-09-08 12:39:40 --> Loader Class Initialized
INFO - 2021-09-08 12:39:40 --> Helper loaded: url_helper
INFO - 2021-09-08 12:39:40 --> Helper loaded: file_helper
INFO - 2021-09-08 12:39:40 --> Helper loaded: form_helper
INFO - 2021-09-08 12:39:40 --> Helper loaded: security_helper
INFO - 2021-09-08 12:39:40 --> Helper loaded: directory_helper
INFO - 2021-09-08 12:39:40 --> Helper loaded: general_helper
INFO - 2021-09-08 12:39:40 --> Database Driver Class Initialized
INFO - 2021-09-08 12:39:40 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-08 12:39:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-08 12:39:40 --> Pagination Class Initialized
INFO - 2021-09-08 12:39:40 --> XML-RPC Class Initialized
INFO - 2021-09-08 12:39:40 --> Form Validation Class Initialized
INFO - 2021-09-08 12:39:40 --> Upload Class Initialized
INFO - 2021-09-08 12:39:41 --> MY_Model class loaded
INFO - 2021-09-08 12:39:41 --> Model "Application_model" initialized
INFO - 2021-09-08 12:39:41 --> Controller Class Initialized
INFO - 2021-09-08 16:24:41 --> Helper loaded: custom_fields_helper
INFO - 2021-09-08 16:24:41 --> Model "Employee_model" initialized
INFO - 2021-09-08 16:24:41 --> Email Class Initialized
INFO - 2021-09-08 16:24:41 --> Model "Email_model" initialized
INFO - 2021-09-08 16:24:41 --> Model "Crud_model" initialized
INFO - 2021-09-08 16:24:41 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/header.php
INFO - 2021-09-08 16:24:41 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/topbar.php
INFO - 2021-09-08 16:24:42 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/sidebar.php
INFO - 2021-09-08 16:24:42 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\employee/profile.php
INFO - 2021-09-08 16:24:42 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/script.php
INFO - 2021-09-08 16:24:42 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/index.php
INFO - 2021-09-08 16:24:42 --> Final output sent to browser
DEBUG - 2021-09-08 16:24:42 --> Total execution time: 2.3593
INFO - 2021-09-08 12:40:57 --> Config Class Initialized
INFO - 2021-09-08 12:40:57 --> Hooks Class Initialized
DEBUG - 2021-09-08 12:40:57 --> UTF-8 Support Enabled
INFO - 2021-09-08 12:40:57 --> Utf8 Class Initialized
INFO - 2021-09-08 12:40:57 --> URI Class Initialized
INFO - 2021-09-08 12:40:57 --> Router Class Initialized
INFO - 2021-09-08 12:40:57 --> Output Class Initialized
INFO - 2021-09-08 12:40:58 --> Security Class Initialized
DEBUG - 2021-09-08 12:40:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-08 12:40:58 --> CSRF cookie sent
INFO - 2021-09-08 12:40:58 --> Input Class Initialized
INFO - 2021-09-08 12:40:58 --> Language Class Initialized
INFO - 2021-09-08 12:40:58 --> Loader Class Initialized
INFO - 2021-09-08 12:40:58 --> Helper loaded: url_helper
INFO - 2021-09-08 12:40:58 --> Helper loaded: file_helper
INFO - 2021-09-08 12:40:58 --> Helper loaded: form_helper
INFO - 2021-09-08 12:40:58 --> Helper loaded: security_helper
INFO - 2021-09-08 12:40:58 --> Helper loaded: directory_helper
INFO - 2021-09-08 12:40:58 --> Helper loaded: general_helper
INFO - 2021-09-08 12:40:58 --> Database Driver Class Initialized
INFO - 2021-09-08 12:40:58 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-08 12:40:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-08 12:40:58 --> Pagination Class Initialized
INFO - 2021-09-08 12:40:58 --> XML-RPC Class Initialized
INFO - 2021-09-08 12:40:58 --> Form Validation Class Initialized
INFO - 2021-09-08 12:40:58 --> Upload Class Initialized
INFO - 2021-09-08 12:40:58 --> MY_Model class loaded
INFO - 2021-09-08 12:40:58 --> Model "Application_model" initialized
INFO - 2021-09-08 12:40:58 --> Controller Class Initialized
INFO - 2021-09-08 16:25:58 --> Helper loaded: download_helper
INFO - 2021-09-08 16:25:58 --> Helper loaded: custom_fields_helper
INFO - 2021-09-08 16:25:58 --> Model "Student_model" initialized
INFO - 2021-09-08 16:25:58 --> Email Class Initialized
INFO - 2021-09-08 16:25:58 --> Model "Email_model" initialized
INFO - 2021-09-08 16:25:58 --> Model "Sms_model" initialized
INFO - 2021-09-08 16:25:58 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/header.php
INFO - 2021-09-08 16:25:58 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/topbar.php
INFO - 2021-09-08 16:25:59 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/sidebar.php
INFO - 2021-09-08 16:25:59 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\student/view.php
INFO - 2021-09-08 16:25:59 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/script.php
INFO - 2021-09-08 16:25:59 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/index.php
INFO - 2021-09-08 16:25:59 --> Final output sent to browser
DEBUG - 2021-09-08 16:25:59 --> Total execution time: 1.2569
INFO - 2021-09-08 14:50:14 --> Config Class Initialized
INFO - 2021-09-08 14:50:14 --> Hooks Class Initialized
DEBUG - 2021-09-08 14:50:14 --> UTF-8 Support Enabled
INFO - 2021-09-08 14:50:14 --> Utf8 Class Initialized
INFO - 2021-09-08 14:50:14 --> URI Class Initialized
INFO - 2021-09-08 14:50:14 --> Router Class Initialized
INFO - 2021-09-08 14:50:14 --> Output Class Initialized
INFO - 2021-09-08 14:50:14 --> Security Class Initialized
DEBUG - 2021-09-08 14:50:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-08 14:50:15 --> CSRF cookie sent
INFO - 2021-09-08 14:50:15 --> Input Class Initialized
INFO - 2021-09-08 14:50:15 --> Language Class Initialized
INFO - 2021-09-08 14:50:15 --> Loader Class Initialized
INFO - 2021-09-08 14:50:15 --> Helper loaded: url_helper
INFO - 2021-09-08 14:50:15 --> Helper loaded: file_helper
INFO - 2021-09-08 14:50:15 --> Helper loaded: form_helper
INFO - 2021-09-08 14:50:15 --> Helper loaded: security_helper
INFO - 2021-09-08 14:50:15 --> Helper loaded: directory_helper
INFO - 2021-09-08 14:50:15 --> Helper loaded: general_helper
INFO - 2021-09-08 14:50:15 --> Database Driver Class Initialized
INFO - 2021-09-08 14:50:16 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-08 14:50:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-08 14:50:16 --> Pagination Class Initialized
INFO - 2021-09-08 14:50:16 --> XML-RPC Class Initialized
INFO - 2021-09-08 14:50:16 --> Form Validation Class Initialized
INFO - 2021-09-08 14:50:16 --> Upload Class Initialized
INFO - 2021-09-08 14:50:16 --> MY_Model class loaded
INFO - 2021-09-08 14:50:16 --> Model "Application_model" initialized
INFO - 2021-09-08 14:50:16 --> Controller Class Initialized
INFO - 2021-09-08 14:50:17 --> Config Class Initialized
INFO - 2021-09-08 14:50:17 --> Hooks Class Initialized
DEBUG - 2021-09-08 14:50:17 --> UTF-8 Support Enabled
INFO - 2021-09-08 14:50:17 --> Utf8 Class Initialized
INFO - 2021-09-08 14:50:17 --> URI Class Initialized
INFO - 2021-09-08 14:50:17 --> Router Class Initialized
INFO - 2021-09-08 14:50:17 --> Output Class Initialized
INFO - 2021-09-08 14:50:17 --> Security Class Initialized
DEBUG - 2021-09-08 14:50:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-08 14:50:17 --> CSRF cookie sent
INFO - 2021-09-08 14:50:17 --> Input Class Initialized
INFO - 2021-09-08 14:50:17 --> Language Class Initialized
INFO - 2021-09-08 14:50:17 --> Loader Class Initialized
INFO - 2021-09-08 14:50:17 --> Helper loaded: url_helper
INFO - 2021-09-08 14:50:17 --> Helper loaded: file_helper
INFO - 2021-09-08 14:50:17 --> Helper loaded: form_helper
INFO - 2021-09-08 14:50:17 --> Helper loaded: security_helper
INFO - 2021-09-08 14:50:17 --> Helper loaded: directory_helper
INFO - 2021-09-08 14:50:17 --> Helper loaded: general_helper
INFO - 2021-09-08 14:50:17 --> Database Driver Class Initialized
INFO - 2021-09-08 14:50:17 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-08 14:50:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-08 14:50:17 --> Pagination Class Initialized
INFO - 2021-09-08 14:50:17 --> XML-RPC Class Initialized
INFO - 2021-09-08 14:50:17 --> Form Validation Class Initialized
INFO - 2021-09-08 14:50:17 --> Upload Class Initialized
INFO - 2021-09-08 14:50:17 --> MY_Model class loaded
INFO - 2021-09-08 14:50:17 --> Model "Application_model" initialized
INFO - 2021-09-08 14:50:17 --> Controller Class Initialized
INFO - 2021-09-08 18:35:17 --> Model "Authentication_model" initialized
INFO - 2021-09-08 18:35:17 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\authentication/login.php
INFO - 2021-09-08 18:35:17 --> Final output sent to browser
DEBUG - 2021-09-08 18:35:17 --> Total execution time: 0.7243
INFO - 2021-09-08 14:52:50 --> Config Class Initialized
INFO - 2021-09-08 14:52:50 --> Hooks Class Initialized
DEBUG - 2021-09-08 14:52:50 --> UTF-8 Support Enabled
INFO - 2021-09-08 14:52:50 --> Utf8 Class Initialized
INFO - 2021-09-08 14:52:50 --> URI Class Initialized
INFO - 2021-09-08 14:52:50 --> Router Class Initialized
INFO - 2021-09-08 14:52:50 --> Output Class Initialized
INFO - 2021-09-08 14:52:50 --> Security Class Initialized
DEBUG - 2021-09-08 14:52:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-08 14:52:51 --> CSRF cookie sent
INFO - 2021-09-08 14:52:51 --> CSRF token verified
INFO - 2021-09-08 14:52:51 --> Input Class Initialized
INFO - 2021-09-08 14:52:51 --> Language Class Initialized
INFO - 2021-09-08 14:52:51 --> Loader Class Initialized
INFO - 2021-09-08 14:52:51 --> Helper loaded: url_helper
INFO - 2021-09-08 14:52:51 --> Helper loaded: file_helper
INFO - 2021-09-08 14:52:51 --> Helper loaded: form_helper
INFO - 2021-09-08 14:52:51 --> Helper loaded: security_helper
INFO - 2021-09-08 14:52:51 --> Helper loaded: directory_helper
INFO - 2021-09-08 14:52:51 --> Helper loaded: general_helper
INFO - 2021-09-08 14:52:51 --> Database Driver Class Initialized
INFO - 2021-09-08 14:52:51 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-08 14:52:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-08 14:52:51 --> Pagination Class Initialized
INFO - 2021-09-08 14:52:51 --> XML-RPC Class Initialized
INFO - 2021-09-08 14:52:51 --> Form Validation Class Initialized
INFO - 2021-09-08 14:52:51 --> Upload Class Initialized
INFO - 2021-09-08 14:52:51 --> MY_Model class loaded
INFO - 2021-09-08 14:52:51 --> Model "Application_model" initialized
INFO - 2021-09-08 14:52:51 --> Controller Class Initialized
INFO - 2021-09-08 18:37:51 --> Model "Authentication_model" initialized
INFO - 2021-09-08 18:37:51 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-09-08 14:52:52 --> Config Class Initialized
INFO - 2021-09-08 14:52:52 --> Hooks Class Initialized
DEBUG - 2021-09-08 14:52:52 --> UTF-8 Support Enabled
INFO - 2021-09-08 14:52:52 --> Utf8 Class Initialized
INFO - 2021-09-08 14:52:52 --> URI Class Initialized
INFO - 2021-09-08 14:52:52 --> Router Class Initialized
INFO - 2021-09-08 14:52:52 --> Output Class Initialized
INFO - 2021-09-08 14:52:52 --> Security Class Initialized
DEBUG - 2021-09-08 14:52:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-08 14:52:52 --> CSRF cookie sent
INFO - 2021-09-08 14:52:52 --> Input Class Initialized
INFO - 2021-09-08 14:52:52 --> Language Class Initialized
INFO - 2021-09-08 14:52:52 --> Loader Class Initialized
INFO - 2021-09-08 14:52:52 --> Helper loaded: url_helper
INFO - 2021-09-08 14:52:52 --> Helper loaded: file_helper
INFO - 2021-09-08 14:52:52 --> Helper loaded: form_helper
INFO - 2021-09-08 14:52:52 --> Helper loaded: security_helper
INFO - 2021-09-08 14:52:52 --> Helper loaded: directory_helper
INFO - 2021-09-08 14:52:52 --> Helper loaded: general_helper
INFO - 2021-09-08 14:52:52 --> Database Driver Class Initialized
INFO - 2021-09-08 14:52:52 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-08 14:52:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-08 14:52:52 --> Pagination Class Initialized
INFO - 2021-09-08 14:52:52 --> XML-RPC Class Initialized
INFO - 2021-09-08 14:52:52 --> Form Validation Class Initialized
INFO - 2021-09-08 14:52:52 --> Upload Class Initialized
INFO - 2021-09-08 14:52:52 --> MY_Model class loaded
INFO - 2021-09-08 14:52:52 --> Model "Application_model" initialized
INFO - 2021-09-08 14:52:52 --> Controller Class Initialized
INFO - 2021-09-08 18:37:52 --> Helper loaded: download_helper
INFO - 2021-09-08 18:37:52 --> Helper loaded: custom_fields_helper
INFO - 2021-09-08 18:37:52 --> Model "Student_model" initialized
INFO - 2021-09-08 18:37:52 --> Email Class Initialized
INFO - 2021-09-08 18:37:52 --> Model "Email_model" initialized
INFO - 2021-09-08 18:37:52 --> Model "Sms_model" initialized
INFO - 2021-09-08 18:37:52 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/header.php
INFO - 2021-09-08 18:37:52 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/topbar.php
INFO - 2021-09-08 18:37:53 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/sidebar.php
INFO - 2021-09-08 18:37:53 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\student/view.php
INFO - 2021-09-08 18:37:53 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/script.php
INFO - 2021-09-08 18:37:53 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/index.php
INFO - 2021-09-08 18:37:53 --> Final output sent to browser
DEBUG - 2021-09-08 18:37:53 --> Total execution time: 1.3305
INFO - 2021-09-08 15:02:58 --> Config Class Initialized
INFO - 2021-09-08 15:02:58 --> Hooks Class Initialized
DEBUG - 2021-09-08 15:02:58 --> UTF-8 Support Enabled
INFO - 2021-09-08 15:02:58 --> Utf8 Class Initialized
INFO - 2021-09-08 15:02:58 --> URI Class Initialized
INFO - 2021-09-08 15:02:58 --> Router Class Initialized
INFO - 2021-09-08 15:02:58 --> Output Class Initialized
INFO - 2021-09-08 15:02:58 --> Security Class Initialized
DEBUG - 2021-09-08 15:02:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-08 15:02:58 --> CSRF cookie sent
INFO - 2021-09-08 15:02:58 --> Input Class Initialized
INFO - 2021-09-08 15:02:58 --> Language Class Initialized
INFO - 2021-09-08 15:02:59 --> Loader Class Initialized
INFO - 2021-09-08 15:02:59 --> Helper loaded: url_helper
INFO - 2021-09-08 15:02:59 --> Helper loaded: file_helper
INFO - 2021-09-08 15:02:59 --> Helper loaded: form_helper
INFO - 2021-09-08 15:02:59 --> Helper loaded: security_helper
INFO - 2021-09-08 15:02:59 --> Helper loaded: directory_helper
INFO - 2021-09-08 15:02:59 --> Helper loaded: general_helper
INFO - 2021-09-08 15:02:59 --> Database Driver Class Initialized
INFO - 2021-09-08 15:03:00 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-08 15:03:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-08 15:03:00 --> Pagination Class Initialized
INFO - 2021-09-08 15:03:00 --> XML-RPC Class Initialized
INFO - 2021-09-08 15:03:00 --> Form Validation Class Initialized
INFO - 2021-09-08 15:03:00 --> Upload Class Initialized
INFO - 2021-09-08 15:03:00 --> MY_Model class loaded
INFO - 2021-09-08 15:03:00 --> Model "Application_model" initialized
INFO - 2021-09-08 15:03:00 --> Controller Class Initialized
INFO - 2021-09-08 18:48:00 --> Model "Sms_model" initialized
INFO - 2021-09-08 18:48:00 --> Model "Fees_model" initialized
INFO - 2021-09-08 18:48:01 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/header.php
INFO - 2021-09-08 18:48:01 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/topbar.php
INFO - 2021-09-08 18:48:01 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/sidebar.php
INFO - 2021-09-08 18:48:01 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\fees/type.php
INFO - 2021-09-08 18:48:01 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/script.php
INFO - 2021-09-08 18:48:01 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/index.php
INFO - 2021-09-08 18:48:01 --> Final output sent to browser
DEBUG - 2021-09-08 18:48:01 --> Total execution time: 3.8244
INFO - 2021-09-08 15:03:08 --> Config Class Initialized
INFO - 2021-09-08 15:03:08 --> Hooks Class Initialized
DEBUG - 2021-09-08 15:03:08 --> UTF-8 Support Enabled
INFO - 2021-09-08 15:03:08 --> Utf8 Class Initialized
INFO - 2021-09-08 15:03:08 --> URI Class Initialized
INFO - 2021-09-08 15:03:08 --> Router Class Initialized
INFO - 2021-09-08 15:03:08 --> Output Class Initialized
INFO - 2021-09-08 15:03:08 --> Security Class Initialized
DEBUG - 2021-09-08 15:03:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-08 15:03:08 --> CSRF cookie sent
INFO - 2021-09-08 15:03:08 --> Input Class Initialized
INFO - 2021-09-08 15:03:08 --> Language Class Initialized
INFO - 2021-09-08 15:03:08 --> Loader Class Initialized
INFO - 2021-09-08 15:03:08 --> Helper loaded: url_helper
INFO - 2021-09-08 15:03:08 --> Helper loaded: file_helper
INFO - 2021-09-08 15:03:08 --> Helper loaded: form_helper
INFO - 2021-09-08 15:03:08 --> Helper loaded: security_helper
INFO - 2021-09-08 15:03:08 --> Helper loaded: directory_helper
INFO - 2021-09-08 15:03:08 --> Helper loaded: general_helper
INFO - 2021-09-08 15:03:08 --> Database Driver Class Initialized
INFO - 2021-09-08 15:03:08 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-08 15:03:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-08 15:03:08 --> Pagination Class Initialized
INFO - 2021-09-08 15:03:08 --> XML-RPC Class Initialized
INFO - 2021-09-08 15:03:08 --> Form Validation Class Initialized
INFO - 2021-09-08 15:03:08 --> Upload Class Initialized
INFO - 2021-09-08 15:03:08 --> MY_Model class loaded
INFO - 2021-09-08 15:03:08 --> Model "Application_model" initialized
INFO - 2021-09-08 15:03:08 --> Controller Class Initialized
INFO - 2021-09-08 18:48:08 --> Model "Sms_model" initialized
INFO - 2021-09-08 18:48:08 --> Model "Fees_model" initialized
INFO - 2021-09-08 18:48:08 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/header.php
INFO - 2021-09-08 18:48:08 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/topbar.php
INFO - 2021-09-08 18:48:09 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/sidebar.php
INFO - 2021-09-08 18:48:09 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\fees/allocation.php
INFO - 2021-09-08 18:48:09 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/script.php
INFO - 2021-09-08 18:48:09 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/index.php
INFO - 2021-09-08 18:48:09 --> Final output sent to browser
DEBUG - 2021-09-08 18:48:09 --> Total execution time: 0.8414
INFO - 2021-09-08 15:03:13 --> Config Class Initialized
INFO - 2021-09-08 15:03:13 --> Hooks Class Initialized
DEBUG - 2021-09-08 15:03:13 --> UTF-8 Support Enabled
INFO - 2021-09-08 15:03:13 --> Utf8 Class Initialized
INFO - 2021-09-08 15:03:13 --> URI Class Initialized
INFO - 2021-09-08 15:03:13 --> Router Class Initialized
INFO - 2021-09-08 15:03:13 --> Output Class Initialized
INFO - 2021-09-08 15:03:13 --> Security Class Initialized
DEBUG - 2021-09-08 15:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-08 15:03:13 --> CSRF cookie sent
INFO - 2021-09-08 15:03:13 --> CSRF token verified
INFO - 2021-09-08 15:03:13 --> Input Class Initialized
INFO - 2021-09-08 15:03:13 --> Language Class Initialized
INFO - 2021-09-08 15:03:13 --> Loader Class Initialized
INFO - 2021-09-08 15:03:13 --> Helper loaded: url_helper
INFO - 2021-09-08 15:03:13 --> Helper loaded: file_helper
INFO - 2021-09-08 15:03:13 --> Helper loaded: form_helper
INFO - 2021-09-08 15:03:13 --> Helper loaded: security_helper
INFO - 2021-09-08 15:03:13 --> Helper loaded: directory_helper
INFO - 2021-09-08 15:03:13 --> Helper loaded: general_helper
INFO - 2021-09-08 15:03:13 --> Database Driver Class Initialized
INFO - 2021-09-08 15:03:13 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-08 15:03:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-08 15:03:13 --> Pagination Class Initialized
INFO - 2021-09-08 15:03:13 --> XML-RPC Class Initialized
INFO - 2021-09-08 15:03:13 --> Form Validation Class Initialized
INFO - 2021-09-08 15:03:13 --> Upload Class Initialized
INFO - 2021-09-08 15:03:13 --> MY_Model class loaded
INFO - 2021-09-08 15:03:13 --> Model "Application_model" initialized
INFO - 2021-09-08 15:03:13 --> Controller Class Initialized
INFO - 2021-09-08 18:48:14 --> Model "Ajax_model" initialized
INFO - 2021-09-08 18:48:14 --> Final output sent to browser
DEBUG - 2021-09-08 18:48:14 --> Total execution time: 0.8081
INFO - 2021-09-08 15:03:25 --> Config Class Initialized
INFO - 2021-09-08 15:03:25 --> Hooks Class Initialized
DEBUG - 2021-09-08 15:03:25 --> UTF-8 Support Enabled
INFO - 2021-09-08 15:03:25 --> Utf8 Class Initialized
INFO - 2021-09-08 15:03:25 --> URI Class Initialized
INFO - 2021-09-08 15:03:25 --> Router Class Initialized
INFO - 2021-09-08 15:03:25 --> Output Class Initialized
INFO - 2021-09-08 15:03:25 --> Security Class Initialized
DEBUG - 2021-09-08 15:03:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-08 15:03:25 --> CSRF cookie sent
INFO - 2021-09-08 15:03:25 --> Input Class Initialized
INFO - 2021-09-08 15:03:25 --> Language Class Initialized
INFO - 2021-09-08 15:03:25 --> Loader Class Initialized
INFO - 2021-09-08 15:03:25 --> Helper loaded: url_helper
INFO - 2021-09-08 15:03:25 --> Helper loaded: file_helper
INFO - 2021-09-08 15:03:25 --> Helper loaded: form_helper
INFO - 2021-09-08 15:03:25 --> Helper loaded: security_helper
INFO - 2021-09-08 15:03:25 --> Helper loaded: directory_helper
INFO - 2021-09-08 15:03:25 --> Helper loaded: general_helper
INFO - 2021-09-08 15:03:25 --> Database Driver Class Initialized
INFO - 2021-09-08 15:03:25 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-08 15:03:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-08 15:03:25 --> Pagination Class Initialized
INFO - 2021-09-08 15:03:25 --> XML-RPC Class Initialized
INFO - 2021-09-08 15:03:25 --> Form Validation Class Initialized
INFO - 2021-09-08 15:03:25 --> Upload Class Initialized
INFO - 2021-09-08 15:03:25 --> MY_Model class loaded
INFO - 2021-09-08 15:03:25 --> Model "Application_model" initialized
INFO - 2021-09-08 15:03:25 --> Controller Class Initialized
INFO - 2021-09-08 18:48:25 --> Model "Sms_model" initialized
INFO - 2021-09-08 18:48:25 --> Model "Fees_model" initialized
INFO - 2021-09-08 18:48:25 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/header.php
INFO - 2021-09-08 18:48:25 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/topbar.php
INFO - 2021-09-08 18:48:26 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/sidebar.php
INFO - 2021-09-08 18:48:26 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\fees/group.php
INFO - 2021-09-08 18:48:26 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/script.php
INFO - 2021-09-08 18:48:26 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/index.php
INFO - 2021-09-08 18:48:26 --> Final output sent to browser
DEBUG - 2021-09-08 18:48:26 --> Total execution time: 1.0473
INFO - 2021-09-08 15:03:31 --> Config Class Initialized
INFO - 2021-09-08 15:03:31 --> Hooks Class Initialized
DEBUG - 2021-09-08 15:03:31 --> UTF-8 Support Enabled
INFO - 2021-09-08 15:03:31 --> Utf8 Class Initialized
INFO - 2021-09-08 15:03:31 --> URI Class Initialized
INFO - 2021-09-08 15:03:31 --> Router Class Initialized
INFO - 2021-09-08 15:03:31 --> Output Class Initialized
INFO - 2021-09-08 15:03:31 --> Security Class Initialized
DEBUG - 2021-09-08 15:03:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-08 15:03:31 --> CSRF cookie sent
INFO - 2021-09-08 15:03:31 --> Input Class Initialized
INFO - 2021-09-08 15:03:31 --> Language Class Initialized
INFO - 2021-09-08 15:03:31 --> Loader Class Initialized
INFO - 2021-09-08 15:03:31 --> Helper loaded: url_helper
INFO - 2021-09-08 15:03:31 --> Helper loaded: file_helper
INFO - 2021-09-08 15:03:31 --> Helper loaded: form_helper
INFO - 2021-09-08 15:03:31 --> Helper loaded: security_helper
INFO - 2021-09-08 15:03:31 --> Helper loaded: directory_helper
INFO - 2021-09-08 15:03:31 --> Helper loaded: general_helper
INFO - 2021-09-08 15:03:31 --> Database Driver Class Initialized
INFO - 2021-09-08 15:03:31 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-08 15:03:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-08 15:03:31 --> Pagination Class Initialized
INFO - 2021-09-08 15:03:31 --> XML-RPC Class Initialized
INFO - 2021-09-08 15:03:31 --> Form Validation Class Initialized
INFO - 2021-09-08 15:03:31 --> Upload Class Initialized
INFO - 2021-09-08 15:03:31 --> MY_Model class loaded
INFO - 2021-09-08 15:03:31 --> Model "Application_model" initialized
INFO - 2021-09-08 15:03:31 --> Controller Class Initialized
INFO - 2021-09-08 18:48:31 --> Model "Sms_model" initialized
INFO - 2021-09-08 18:48:31 --> Model "Fees_model" initialized
INFO - 2021-09-08 18:48:31 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/header.php
INFO - 2021-09-08 18:48:31 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/topbar.php
INFO - 2021-09-08 18:48:32 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/sidebar.php
INFO - 2021-09-08 18:48:32 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\fees/allocation.php
INFO - 2021-09-08 18:48:32 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/script.php
INFO - 2021-09-08 18:48:32 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/index.php
INFO - 2021-09-08 18:48:32 --> Final output sent to browser
DEBUG - 2021-09-08 18:48:32 --> Total execution time: 0.7820
INFO - 2021-09-08 15:03:36 --> Config Class Initialized
INFO - 2021-09-08 15:03:36 --> Hooks Class Initialized
DEBUG - 2021-09-08 15:03:36 --> UTF-8 Support Enabled
INFO - 2021-09-08 15:03:36 --> Utf8 Class Initialized
INFO - 2021-09-08 15:03:36 --> URI Class Initialized
INFO - 2021-09-08 15:03:36 --> Router Class Initialized
INFO - 2021-09-08 15:03:36 --> Output Class Initialized
INFO - 2021-09-08 15:03:36 --> Security Class Initialized
DEBUG - 2021-09-08 15:03:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-08 15:03:36 --> CSRF cookie sent
INFO - 2021-09-08 15:03:36 --> CSRF token verified
INFO - 2021-09-08 15:03:36 --> Input Class Initialized
INFO - 2021-09-08 15:03:36 --> Language Class Initialized
INFO - 2021-09-08 15:03:36 --> Loader Class Initialized
INFO - 2021-09-08 15:03:36 --> Helper loaded: url_helper
INFO - 2021-09-08 15:03:36 --> Helper loaded: file_helper
INFO - 2021-09-08 15:03:36 --> Helper loaded: form_helper
INFO - 2021-09-08 15:03:36 --> Helper loaded: security_helper
INFO - 2021-09-08 15:03:36 --> Helper loaded: directory_helper
INFO - 2021-09-08 15:03:36 --> Helper loaded: general_helper
INFO - 2021-09-08 15:03:36 --> Database Driver Class Initialized
INFO - 2021-09-08 15:03:36 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-08 15:03:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-08 15:03:36 --> Pagination Class Initialized
INFO - 2021-09-08 15:03:36 --> XML-RPC Class Initialized
INFO - 2021-09-08 15:03:36 --> Form Validation Class Initialized
INFO - 2021-09-08 15:03:36 --> Upload Class Initialized
INFO - 2021-09-08 15:03:36 --> MY_Model class loaded
INFO - 2021-09-08 15:03:36 --> Model "Application_model" initialized
INFO - 2021-09-08 15:03:36 --> Controller Class Initialized
INFO - 2021-09-08 18:48:36 --> Model "Ajax_model" initialized
INFO - 2021-09-08 18:48:36 --> Final output sent to browser
DEBUG - 2021-09-08 18:48:36 --> Total execution time: 0.1229
INFO - 2021-09-08 15:03:42 --> Config Class Initialized
INFO - 2021-09-08 15:03:42 --> Hooks Class Initialized
DEBUG - 2021-09-08 15:03:42 --> UTF-8 Support Enabled
INFO - 2021-09-08 15:03:42 --> Utf8 Class Initialized
INFO - 2021-09-08 15:03:42 --> URI Class Initialized
INFO - 2021-09-08 15:03:42 --> Router Class Initialized
INFO - 2021-09-08 15:03:42 --> Output Class Initialized
INFO - 2021-09-08 15:03:42 --> Security Class Initialized
DEBUG - 2021-09-08 15:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-08 15:03:42 --> CSRF cookie sent
INFO - 2021-09-08 15:03:42 --> CSRF token verified
INFO - 2021-09-08 15:03:42 --> Input Class Initialized
INFO - 2021-09-08 15:03:42 --> Language Class Initialized
INFO - 2021-09-08 15:03:42 --> Loader Class Initialized
INFO - 2021-09-08 15:03:42 --> Helper loaded: url_helper
INFO - 2021-09-08 15:03:42 --> Helper loaded: file_helper
INFO - 2021-09-08 15:03:42 --> Helper loaded: form_helper
INFO - 2021-09-08 15:03:42 --> Helper loaded: security_helper
INFO - 2021-09-08 15:03:42 --> Helper loaded: directory_helper
INFO - 2021-09-08 15:03:42 --> Helper loaded: general_helper
INFO - 2021-09-08 15:03:42 --> Database Driver Class Initialized
INFO - 2021-09-08 15:03:42 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-08 15:03:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-08 15:03:42 --> Pagination Class Initialized
INFO - 2021-09-08 15:03:42 --> XML-RPC Class Initialized
INFO - 2021-09-08 15:03:42 --> Form Validation Class Initialized
INFO - 2021-09-08 15:03:42 --> Upload Class Initialized
INFO - 2021-09-08 15:03:42 --> MY_Model class loaded
INFO - 2021-09-08 15:03:42 --> Model "Application_model" initialized
INFO - 2021-09-08 15:03:42 --> Controller Class Initialized
INFO - 2021-09-08 18:48:42 --> Model "Sms_model" initialized
INFO - 2021-09-08 18:48:42 --> Model "Fees_model" initialized
INFO - 2021-09-08 18:48:43 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/header.php
INFO - 2021-09-08 18:48:43 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/topbar.php
INFO - 2021-09-08 18:48:43 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/sidebar.php
INFO - 2021-09-08 18:48:43 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\fees/allocation.php
INFO - 2021-09-08 18:48:43 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/script.php
INFO - 2021-09-08 18:48:43 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/index.php
INFO - 2021-09-08 18:48:43 --> Final output sent to browser
DEBUG - 2021-09-08 18:48:43 --> Total execution time: 1.1873
INFO - 2021-09-08 15:04:04 --> Config Class Initialized
INFO - 2021-09-08 15:04:04 --> Hooks Class Initialized
DEBUG - 2021-09-08 15:04:04 --> UTF-8 Support Enabled
INFO - 2021-09-08 15:04:04 --> Utf8 Class Initialized
INFO - 2021-09-08 15:04:04 --> URI Class Initialized
INFO - 2021-09-08 15:04:04 --> Router Class Initialized
INFO - 2021-09-08 15:04:04 --> Output Class Initialized
INFO - 2021-09-08 15:04:04 --> Security Class Initialized
DEBUG - 2021-09-08 15:04:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-08 15:04:04 --> CSRF cookie sent
INFO - 2021-09-08 15:04:04 --> CSRF token verified
INFO - 2021-09-08 15:04:04 --> Input Class Initialized
INFO - 2021-09-08 15:04:04 --> Language Class Initialized
INFO - 2021-09-08 15:04:04 --> Loader Class Initialized
INFO - 2021-09-08 15:04:04 --> Helper loaded: url_helper
INFO - 2021-09-08 15:04:04 --> Helper loaded: file_helper
INFO - 2021-09-08 15:04:04 --> Helper loaded: form_helper
INFO - 2021-09-08 15:04:04 --> Helper loaded: security_helper
INFO - 2021-09-08 15:04:04 --> Helper loaded: directory_helper
INFO - 2021-09-08 15:04:04 --> Helper loaded: general_helper
INFO - 2021-09-08 15:04:04 --> Database Driver Class Initialized
INFO - 2021-09-08 15:04:04 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-08 15:04:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-08 15:04:04 --> Pagination Class Initialized
INFO - 2021-09-08 15:04:04 --> XML-RPC Class Initialized
INFO - 2021-09-08 15:04:04 --> Form Validation Class Initialized
INFO - 2021-09-08 15:04:04 --> Upload Class Initialized
INFO - 2021-09-08 15:04:04 --> MY_Model class loaded
INFO - 2021-09-08 15:04:04 --> Model "Application_model" initialized
INFO - 2021-09-08 15:04:04 --> Controller Class Initialized
INFO - 2021-09-08 18:49:04 --> Model "Sms_model" initialized
INFO - 2021-09-08 18:49:04 --> Model "Fees_model" initialized
INFO - 2021-09-08 18:49:04 --> Final output sent to browser
DEBUG - 2021-09-08 18:49:04 --> Total execution time: 0.2294
INFO - 2021-09-08 15:04:09 --> Config Class Initialized
INFO - 2021-09-08 15:04:09 --> Hooks Class Initialized
DEBUG - 2021-09-08 15:04:09 --> UTF-8 Support Enabled
INFO - 2021-09-08 15:04:09 --> Utf8 Class Initialized
INFO - 2021-09-08 15:04:09 --> URI Class Initialized
INFO - 2021-09-08 15:04:09 --> Router Class Initialized
INFO - 2021-09-08 15:04:09 --> Output Class Initialized
INFO - 2021-09-08 15:04:09 --> Security Class Initialized
DEBUG - 2021-09-08 15:04:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-08 15:04:09 --> CSRF cookie sent
INFO - 2021-09-08 15:04:09 --> Input Class Initialized
INFO - 2021-09-08 15:04:09 --> Language Class Initialized
INFO - 2021-09-08 15:04:09 --> Loader Class Initialized
INFO - 2021-09-08 15:04:09 --> Helper loaded: url_helper
INFO - 2021-09-08 15:04:09 --> Helper loaded: file_helper
INFO - 2021-09-08 15:04:09 --> Helper loaded: form_helper
INFO - 2021-09-08 15:04:09 --> Helper loaded: security_helper
INFO - 2021-09-08 15:04:09 --> Helper loaded: directory_helper
INFO - 2021-09-08 15:04:09 --> Helper loaded: general_helper
INFO - 2021-09-08 15:04:09 --> Database Driver Class Initialized
INFO - 2021-09-08 15:04:09 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-08 15:04:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-08 15:04:09 --> Pagination Class Initialized
INFO - 2021-09-08 15:04:09 --> XML-RPC Class Initialized
INFO - 2021-09-08 15:04:09 --> Form Validation Class Initialized
INFO - 2021-09-08 15:04:09 --> Upload Class Initialized
INFO - 2021-09-08 15:04:09 --> MY_Model class loaded
INFO - 2021-09-08 15:04:09 --> Model "Application_model" initialized
INFO - 2021-09-08 15:04:09 --> Controller Class Initialized
INFO - 2021-09-08 18:49:09 --> Model "Sms_model" initialized
INFO - 2021-09-08 18:49:09 --> Model "Fees_model" initialized
INFO - 2021-09-08 18:49:09 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/header.php
INFO - 2021-09-08 18:49:09 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/topbar.php
INFO - 2021-09-08 18:49:09 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/sidebar.php
INFO - 2021-09-08 18:49:09 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\fees/invoice_list.php
INFO - 2021-09-08 18:49:09 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/script.php
INFO - 2021-09-08 18:49:09 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/index.php
INFO - 2021-09-08 18:49:09 --> Final output sent to browser
DEBUG - 2021-09-08 18:49:09 --> Total execution time: 0.8067
INFO - 2021-09-08 15:04:13 --> Config Class Initialized
INFO - 2021-09-08 15:04:13 --> Hooks Class Initialized
DEBUG - 2021-09-08 15:04:13 --> UTF-8 Support Enabled
INFO - 2021-09-08 15:04:13 --> Utf8 Class Initialized
INFO - 2021-09-08 15:04:13 --> URI Class Initialized
INFO - 2021-09-08 15:04:13 --> Router Class Initialized
INFO - 2021-09-08 15:04:13 --> Output Class Initialized
INFO - 2021-09-08 15:04:13 --> Security Class Initialized
DEBUG - 2021-09-08 15:04:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-08 15:04:13 --> CSRF cookie sent
INFO - 2021-09-08 15:04:13 --> CSRF token verified
INFO - 2021-09-08 15:04:13 --> Input Class Initialized
INFO - 2021-09-08 15:04:13 --> Language Class Initialized
INFO - 2021-09-08 15:04:13 --> Loader Class Initialized
INFO - 2021-09-08 15:04:13 --> Helper loaded: url_helper
INFO - 2021-09-08 15:04:13 --> Helper loaded: file_helper
INFO - 2021-09-08 15:04:13 --> Helper loaded: form_helper
INFO - 2021-09-08 15:04:13 --> Helper loaded: security_helper
INFO - 2021-09-08 15:04:13 --> Helper loaded: directory_helper
INFO - 2021-09-08 15:04:13 --> Helper loaded: general_helper
INFO - 2021-09-08 15:04:13 --> Database Driver Class Initialized
INFO - 2021-09-08 15:04:13 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-08 15:04:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-08 15:04:13 --> Pagination Class Initialized
INFO - 2021-09-08 15:04:13 --> XML-RPC Class Initialized
INFO - 2021-09-08 15:04:13 --> Form Validation Class Initialized
INFO - 2021-09-08 15:04:13 --> Upload Class Initialized
INFO - 2021-09-08 15:04:13 --> MY_Model class loaded
INFO - 2021-09-08 15:04:13 --> Model "Application_model" initialized
INFO - 2021-09-08 15:04:13 --> Controller Class Initialized
INFO - 2021-09-08 18:49:13 --> Model "Ajax_model" initialized
INFO - 2021-09-08 18:49:13 --> Final output sent to browser
DEBUG - 2021-09-08 18:49:13 --> Total execution time: 0.1286
INFO - 2021-09-08 15:04:16 --> Config Class Initialized
INFO - 2021-09-08 15:04:16 --> Hooks Class Initialized
DEBUG - 2021-09-08 15:04:16 --> UTF-8 Support Enabled
INFO - 2021-09-08 15:04:16 --> Utf8 Class Initialized
INFO - 2021-09-08 15:04:16 --> URI Class Initialized
INFO - 2021-09-08 15:04:16 --> Router Class Initialized
INFO - 2021-09-08 15:04:16 --> Output Class Initialized
INFO - 2021-09-08 15:04:16 --> Security Class Initialized
DEBUG - 2021-09-08 15:04:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-08 15:04:16 --> CSRF cookie sent
INFO - 2021-09-08 15:04:16 --> CSRF token verified
INFO - 2021-09-08 15:04:16 --> Input Class Initialized
INFO - 2021-09-08 15:04:16 --> Language Class Initialized
INFO - 2021-09-08 15:04:16 --> Loader Class Initialized
INFO - 2021-09-08 15:04:16 --> Helper loaded: url_helper
INFO - 2021-09-08 15:04:16 --> Helper loaded: file_helper
INFO - 2021-09-08 15:04:16 --> Helper loaded: form_helper
INFO - 2021-09-08 15:04:16 --> Helper loaded: security_helper
INFO - 2021-09-08 15:04:16 --> Helper loaded: directory_helper
INFO - 2021-09-08 15:04:16 --> Helper loaded: general_helper
INFO - 2021-09-08 15:04:16 --> Database Driver Class Initialized
INFO - 2021-09-08 15:04:16 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-08 15:04:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-08 15:04:16 --> Pagination Class Initialized
INFO - 2021-09-08 15:04:16 --> XML-RPC Class Initialized
INFO - 2021-09-08 15:04:16 --> Form Validation Class Initialized
INFO - 2021-09-08 15:04:16 --> Upload Class Initialized
INFO - 2021-09-08 15:04:16 --> MY_Model class loaded
INFO - 2021-09-08 15:04:16 --> Model "Application_model" initialized
INFO - 2021-09-08 15:04:16 --> Controller Class Initialized
INFO - 2021-09-08 18:49:16 --> Model "Sms_model" initialized
INFO - 2021-09-08 18:49:16 --> Model "Fees_model" initialized
INFO - 2021-09-08 18:49:16 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/header.php
INFO - 2021-09-08 18:49:16 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/topbar.php
INFO - 2021-09-08 18:49:17 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/sidebar.php
INFO - 2021-09-08 18:49:17 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\fees/invoice_list.php
INFO - 2021-09-08 18:49:17 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/script.php
INFO - 2021-09-08 18:49:17 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/index.php
INFO - 2021-09-08 18:49:17 --> Final output sent to browser
DEBUG - 2021-09-08 18:49:17 --> Total execution time: 0.9545
INFO - 2021-09-08 15:04:46 --> Config Class Initialized
INFO - 2021-09-08 15:04:46 --> Hooks Class Initialized
DEBUG - 2021-09-08 15:04:46 --> UTF-8 Support Enabled
INFO - 2021-09-08 15:04:46 --> Utf8 Class Initialized
INFO - 2021-09-08 15:04:46 --> URI Class Initialized
INFO - 2021-09-08 15:04:46 --> Router Class Initialized
INFO - 2021-09-08 15:04:46 --> Output Class Initialized
INFO - 2021-09-08 15:04:46 --> Security Class Initialized
DEBUG - 2021-09-08 15:04:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-08 15:04:46 --> CSRF cookie sent
INFO - 2021-09-08 15:04:46 --> Input Class Initialized
INFO - 2021-09-08 15:04:46 --> Language Class Initialized
INFO - 2021-09-08 15:04:46 --> Loader Class Initialized
INFO - 2021-09-08 15:04:46 --> Helper loaded: url_helper
INFO - 2021-09-08 15:04:46 --> Helper loaded: file_helper
INFO - 2021-09-08 15:04:46 --> Helper loaded: form_helper
INFO - 2021-09-08 15:04:46 --> Helper loaded: security_helper
INFO - 2021-09-08 15:04:46 --> Helper loaded: directory_helper
INFO - 2021-09-08 15:04:46 --> Helper loaded: general_helper
INFO - 2021-09-08 15:04:46 --> Database Driver Class Initialized
INFO - 2021-09-08 15:04:46 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-08 15:04:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-08 15:04:46 --> Pagination Class Initialized
INFO - 2021-09-08 15:04:46 --> XML-RPC Class Initialized
INFO - 2021-09-08 15:04:46 --> Form Validation Class Initialized
INFO - 2021-09-08 15:04:46 --> Upload Class Initialized
INFO - 2021-09-08 15:04:46 --> MY_Model class loaded
INFO - 2021-09-08 15:04:46 --> Model "Application_model" initialized
INFO - 2021-09-08 15:04:46 --> Controller Class Initialized
INFO - 2021-09-08 18:49:46 --> Model "Sms_model" initialized
INFO - 2021-09-08 18:49:46 --> Model "Fees_model" initialized
INFO - 2021-09-08 18:49:46 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/header.php
INFO - 2021-09-08 18:49:47 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/topbar.php
INFO - 2021-09-08 18:49:47 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/sidebar.php
INFO - 2021-09-08 18:49:48 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\fees/collect.php
INFO - 2021-09-08 18:49:48 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/script.php
INFO - 2021-09-08 18:49:48 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/index.php
INFO - 2021-09-08 18:49:48 --> Final output sent to browser
DEBUG - 2021-09-08 18:49:48 --> Total execution time: 1.8487
INFO - 2021-09-08 15:06:43 --> Config Class Initialized
INFO - 2021-09-08 15:06:43 --> Hooks Class Initialized
DEBUG - 2021-09-08 15:06:43 --> UTF-8 Support Enabled
INFO - 2021-09-08 15:06:43 --> Utf8 Class Initialized
INFO - 2021-09-08 15:06:43 --> URI Class Initialized
INFO - 2021-09-08 15:06:43 --> Router Class Initialized
INFO - 2021-09-08 15:06:43 --> Output Class Initialized
INFO - 2021-09-08 15:06:43 --> Security Class Initialized
DEBUG - 2021-09-08 15:06:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-08 15:06:43 --> CSRF cookie sent
INFO - 2021-09-08 15:06:43 --> Input Class Initialized
INFO - 2021-09-08 15:06:43 --> Language Class Initialized
INFO - 2021-09-08 15:06:43 --> Loader Class Initialized
INFO - 2021-09-08 15:06:43 --> Helper loaded: url_helper
INFO - 2021-09-08 15:06:43 --> Helper loaded: file_helper
INFO - 2021-09-08 15:06:43 --> Helper loaded: form_helper
INFO - 2021-09-08 15:06:43 --> Helper loaded: security_helper
INFO - 2021-09-08 15:06:43 --> Helper loaded: directory_helper
INFO - 2021-09-08 15:06:43 --> Helper loaded: general_helper
INFO - 2021-09-08 15:06:43 --> Database Driver Class Initialized
INFO - 2021-09-08 15:06:43 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-08 15:06:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-08 15:06:43 --> Pagination Class Initialized
INFO - 2021-09-08 15:06:43 --> XML-RPC Class Initialized
INFO - 2021-09-08 15:06:43 --> Form Validation Class Initialized
INFO - 2021-09-08 15:06:43 --> Upload Class Initialized
INFO - 2021-09-08 15:06:43 --> MY_Model class loaded
INFO - 2021-09-08 15:06:43 --> Model "Application_model" initialized
INFO - 2021-09-08 15:06:43 --> Controller Class Initialized
INFO - 2021-09-08 18:51:43 --> Model "Sms_model" initialized
INFO - 2021-09-08 18:51:43 --> Model "Fees_model" initialized
INFO - 2021-09-08 18:51:43 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/header.php
INFO - 2021-09-08 18:51:43 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/topbar.php
INFO - 2021-09-08 18:51:44 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/sidebar.php
INFO - 2021-09-08 18:51:44 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\fees/invoice_list.php
INFO - 2021-09-08 18:51:44 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/script.php
INFO - 2021-09-08 18:51:44 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/index.php
INFO - 2021-09-08 18:51:44 --> Final output sent to browser
DEBUG - 2021-09-08 18:51:44 --> Total execution time: 0.8099
INFO - 2021-09-08 15:06:49 --> Config Class Initialized
INFO - 2021-09-08 15:06:49 --> Hooks Class Initialized
DEBUG - 2021-09-08 15:06:49 --> UTF-8 Support Enabled
INFO - 2021-09-08 15:06:49 --> Utf8 Class Initialized
INFO - 2021-09-08 15:06:49 --> URI Class Initialized
INFO - 2021-09-08 15:06:49 --> Router Class Initialized
INFO - 2021-09-08 15:06:49 --> Output Class Initialized
INFO - 2021-09-08 15:06:49 --> Security Class Initialized
DEBUG - 2021-09-08 15:06:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-08 15:06:49 --> CSRF cookie sent
INFO - 2021-09-08 15:06:49 --> CSRF token verified
INFO - 2021-09-08 15:06:49 --> Input Class Initialized
INFO - 2021-09-08 15:06:49 --> Language Class Initialized
INFO - 2021-09-08 15:06:49 --> Loader Class Initialized
INFO - 2021-09-08 15:06:49 --> Helper loaded: url_helper
INFO - 2021-09-08 15:06:49 --> Helper loaded: file_helper
INFO - 2021-09-08 15:06:49 --> Helper loaded: form_helper
INFO - 2021-09-08 15:06:49 --> Helper loaded: security_helper
INFO - 2021-09-08 15:06:49 --> Helper loaded: directory_helper
INFO - 2021-09-08 15:06:49 --> Helper loaded: general_helper
INFO - 2021-09-08 15:06:49 --> Database Driver Class Initialized
INFO - 2021-09-08 15:06:49 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-08 15:06:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-08 15:06:49 --> Pagination Class Initialized
INFO - 2021-09-08 15:06:49 --> XML-RPC Class Initialized
INFO - 2021-09-08 15:06:49 --> Form Validation Class Initialized
INFO - 2021-09-08 15:06:49 --> Upload Class Initialized
INFO - 2021-09-08 15:06:49 --> MY_Model class loaded
INFO - 2021-09-08 15:06:49 --> Model "Application_model" initialized
INFO - 2021-09-08 15:06:49 --> Controller Class Initialized
INFO - 2021-09-08 18:51:49 --> Model "Ajax_model" initialized
INFO - 2021-09-08 18:51:49 --> Final output sent to browser
DEBUG - 2021-09-08 18:51:49 --> Total execution time: 0.1791
INFO - 2021-09-08 15:06:54 --> Config Class Initialized
INFO - 2021-09-08 15:06:54 --> Hooks Class Initialized
DEBUG - 2021-09-08 15:06:54 --> UTF-8 Support Enabled
INFO - 2021-09-08 15:06:54 --> Utf8 Class Initialized
INFO - 2021-09-08 15:06:54 --> URI Class Initialized
INFO - 2021-09-08 15:06:54 --> Router Class Initialized
INFO - 2021-09-08 15:06:54 --> Output Class Initialized
INFO - 2021-09-08 15:06:54 --> Security Class Initialized
DEBUG - 2021-09-08 15:06:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-08 15:06:54 --> CSRF cookie sent
INFO - 2021-09-08 15:06:54 --> CSRF token verified
INFO - 2021-09-08 15:06:54 --> Input Class Initialized
INFO - 2021-09-08 15:06:54 --> Language Class Initialized
INFO - 2021-09-08 15:06:54 --> Loader Class Initialized
INFO - 2021-09-08 15:06:54 --> Helper loaded: url_helper
INFO - 2021-09-08 15:06:54 --> Helper loaded: file_helper
INFO - 2021-09-08 15:06:54 --> Helper loaded: form_helper
INFO - 2021-09-08 15:06:54 --> Helper loaded: security_helper
INFO - 2021-09-08 15:06:54 --> Helper loaded: directory_helper
INFO - 2021-09-08 15:06:54 --> Helper loaded: general_helper
INFO - 2021-09-08 15:06:54 --> Database Driver Class Initialized
INFO - 2021-09-08 15:06:54 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-08 15:06:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-08 15:06:54 --> Pagination Class Initialized
INFO - 2021-09-08 15:06:54 --> XML-RPC Class Initialized
INFO - 2021-09-08 15:06:54 --> Form Validation Class Initialized
INFO - 2021-09-08 15:06:54 --> Upload Class Initialized
INFO - 2021-09-08 15:06:54 --> MY_Model class loaded
INFO - 2021-09-08 15:06:54 --> Model "Application_model" initialized
INFO - 2021-09-08 15:06:54 --> Controller Class Initialized
INFO - 2021-09-08 18:51:54 --> Model "Sms_model" initialized
INFO - 2021-09-08 18:51:54 --> Model "Fees_model" initialized
INFO - 2021-09-08 18:51:54 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/header.php
INFO - 2021-09-08 18:51:54 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/topbar.php
INFO - 2021-09-08 18:51:55 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/sidebar.php
INFO - 2021-09-08 18:51:55 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\fees/invoice_list.php
INFO - 2021-09-08 18:51:55 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/script.php
INFO - 2021-09-08 18:51:55 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/index.php
INFO - 2021-09-08 18:51:55 --> Final output sent to browser
DEBUG - 2021-09-08 18:51:55 --> Total execution time: 0.9846
INFO - 2021-09-08 15:14:04 --> Config Class Initialized
INFO - 2021-09-08 15:14:04 --> Hooks Class Initialized
DEBUG - 2021-09-08 15:14:04 --> UTF-8 Support Enabled
INFO - 2021-09-08 15:14:04 --> Utf8 Class Initialized
INFO - 2021-09-08 15:14:04 --> URI Class Initialized
INFO - 2021-09-08 15:14:04 --> Router Class Initialized
INFO - 2021-09-08 15:14:04 --> Output Class Initialized
INFO - 2021-09-08 15:14:04 --> Security Class Initialized
DEBUG - 2021-09-08 15:14:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-08 15:14:04 --> CSRF cookie sent
INFO - 2021-09-08 15:14:04 --> Input Class Initialized
INFO - 2021-09-08 15:14:04 --> Language Class Initialized
INFO - 2021-09-08 15:14:04 --> Loader Class Initialized
INFO - 2021-09-08 15:14:04 --> Helper loaded: url_helper
INFO - 2021-09-08 15:14:04 --> Helper loaded: file_helper
INFO - 2021-09-08 15:14:04 --> Helper loaded: form_helper
INFO - 2021-09-08 15:14:04 --> Helper loaded: security_helper
INFO - 2021-09-08 15:14:04 --> Helper loaded: directory_helper
INFO - 2021-09-08 15:14:04 --> Helper loaded: general_helper
INFO - 2021-09-08 15:14:05 --> Database Driver Class Initialized
INFO - 2021-09-08 15:14:05 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-08 15:14:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-08 15:14:05 --> Pagination Class Initialized
INFO - 2021-09-08 15:14:05 --> XML-RPC Class Initialized
INFO - 2021-09-08 15:14:05 --> Form Validation Class Initialized
INFO - 2021-09-08 15:14:05 --> Upload Class Initialized
INFO - 2021-09-08 15:14:05 --> MY_Model class loaded
INFO - 2021-09-08 15:14:05 --> Model "Application_model" initialized
INFO - 2021-09-08 15:14:05 --> Controller Class Initialized
INFO - 2021-09-08 18:59:05 --> Model "Sms_model" initialized
INFO - 2021-09-08 18:59:05 --> Model "Fees_model" initialized
INFO - 2021-09-08 18:59:05 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/header.php
INFO - 2021-09-08 18:59:05 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/topbar.php
INFO - 2021-09-08 18:59:06 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/sidebar.php
INFO - 2021-09-08 18:59:06 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\fees/collect.php
INFO - 2021-09-08 18:59:06 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/script.php
INFO - 2021-09-08 18:59:06 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/index.php
INFO - 2021-09-08 18:59:06 --> Final output sent to browser
DEBUG - 2021-09-08 18:59:06 --> Total execution time: 2.5693
INFO - 2021-09-08 15:14:27 --> Config Class Initialized
INFO - 2021-09-08 15:14:27 --> Hooks Class Initialized
DEBUG - 2021-09-08 15:14:27 --> UTF-8 Support Enabled
INFO - 2021-09-08 15:14:27 --> Utf8 Class Initialized
INFO - 2021-09-08 15:14:27 --> URI Class Initialized
INFO - 2021-09-08 15:14:27 --> Router Class Initialized
INFO - 2021-09-08 15:14:27 --> Output Class Initialized
INFO - 2021-09-08 15:14:27 --> Security Class Initialized
DEBUG - 2021-09-08 15:14:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-08 15:14:27 --> CSRF cookie sent
INFO - 2021-09-08 15:14:27 --> Input Class Initialized
INFO - 2021-09-08 15:14:27 --> Language Class Initialized
INFO - 2021-09-08 15:14:27 --> Loader Class Initialized
INFO - 2021-09-08 15:14:27 --> Helper loaded: url_helper
INFO - 2021-09-08 15:14:27 --> Helper loaded: file_helper
INFO - 2021-09-08 15:14:27 --> Helper loaded: form_helper
INFO - 2021-09-08 15:14:27 --> Helper loaded: security_helper
INFO - 2021-09-08 15:14:27 --> Helper loaded: directory_helper
INFO - 2021-09-08 15:14:27 --> Helper loaded: general_helper
INFO - 2021-09-08 15:14:28 --> Database Driver Class Initialized
INFO - 2021-09-08 15:14:28 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-08 15:14:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-08 15:14:28 --> Pagination Class Initialized
INFO - 2021-09-08 15:14:28 --> XML-RPC Class Initialized
INFO - 2021-09-08 15:14:28 --> Form Validation Class Initialized
INFO - 2021-09-08 15:14:28 --> Upload Class Initialized
INFO - 2021-09-08 15:14:28 --> MY_Model class loaded
INFO - 2021-09-08 15:14:28 --> Model "Application_model" initialized
INFO - 2021-09-08 15:14:28 --> Controller Class Initialized
INFO - 2021-09-08 18:59:28 --> Model "Sms_model" initialized
INFO - 2021-09-08 18:59:28 --> Model "Fees_model" initialized
INFO - 2021-09-08 18:59:28 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/header.php
INFO - 2021-09-08 18:59:28 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/topbar.php
INFO - 2021-09-08 18:59:28 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/sidebar.php
INFO - 2021-09-08 18:59:28 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\fees/collect.php
INFO - 2021-09-08 18:59:28 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/script.php
INFO - 2021-09-08 18:59:28 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/index.php
INFO - 2021-09-08 18:59:28 --> Final output sent to browser
DEBUG - 2021-09-08 18:59:28 --> Total execution time: 0.9951
INFO - 2021-09-08 15:14:49 --> Config Class Initialized
INFO - 2021-09-08 15:14:49 --> Hooks Class Initialized
DEBUG - 2021-09-08 15:14:49 --> UTF-8 Support Enabled
INFO - 2021-09-08 15:14:49 --> Utf8 Class Initialized
INFO - 2021-09-08 15:14:49 --> URI Class Initialized
INFO - 2021-09-08 15:14:49 --> Router Class Initialized
INFO - 2021-09-08 15:14:49 --> Output Class Initialized
INFO - 2021-09-08 15:14:49 --> Security Class Initialized
DEBUG - 2021-09-08 15:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-08 15:14:49 --> CSRF cookie sent
INFO - 2021-09-08 15:14:49 --> Input Class Initialized
INFO - 2021-09-08 15:14:49 --> Language Class Initialized
INFO - 2021-09-08 15:14:49 --> Loader Class Initialized
INFO - 2021-09-08 15:14:49 --> Helper loaded: url_helper
INFO - 2021-09-08 15:14:49 --> Helper loaded: file_helper
INFO - 2021-09-08 15:14:49 --> Helper loaded: form_helper
INFO - 2021-09-08 15:14:49 --> Helper loaded: security_helper
INFO - 2021-09-08 15:14:49 --> Helper loaded: directory_helper
INFO - 2021-09-08 15:14:49 --> Helper loaded: general_helper
INFO - 2021-09-08 15:14:50 --> Database Driver Class Initialized
INFO - 2021-09-08 15:14:50 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-08 15:14:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-08 15:14:50 --> Pagination Class Initialized
INFO - 2021-09-08 15:14:50 --> XML-RPC Class Initialized
INFO - 2021-09-08 15:14:50 --> Form Validation Class Initialized
INFO - 2021-09-08 15:14:50 --> Upload Class Initialized
INFO - 2021-09-08 15:14:50 --> MY_Model class loaded
INFO - 2021-09-08 15:14:50 --> Model "Application_model" initialized
INFO - 2021-09-08 15:14:50 --> Controller Class Initialized
INFO - 2021-09-08 18:59:50 --> Model "Sms_model" initialized
INFO - 2021-09-08 18:59:50 --> Model "Fees_model" initialized
INFO - 2021-09-08 18:59:50 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/header.php
INFO - 2021-09-08 18:59:50 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/topbar.php
INFO - 2021-09-08 18:59:50 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/sidebar.php
INFO - 2021-09-08 18:59:50 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\fees/invoice_list.php
INFO - 2021-09-08 18:59:50 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/script.php
INFO - 2021-09-08 18:59:50 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/index.php
INFO - 2021-09-08 18:59:50 --> Final output sent to browser
DEBUG - 2021-09-08 18:59:50 --> Total execution time: 0.8050
INFO - 2021-09-08 15:14:57 --> Config Class Initialized
INFO - 2021-09-08 15:14:57 --> Hooks Class Initialized
DEBUG - 2021-09-08 15:14:57 --> UTF-8 Support Enabled
INFO - 2021-09-08 15:14:57 --> Utf8 Class Initialized
INFO - 2021-09-08 15:14:57 --> URI Class Initialized
INFO - 2021-09-08 15:14:57 --> Router Class Initialized
INFO - 2021-09-08 15:14:57 --> Output Class Initialized
INFO - 2021-09-08 15:14:57 --> Security Class Initialized
DEBUG - 2021-09-08 15:14:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-08 15:14:58 --> CSRF cookie sent
INFO - 2021-09-08 15:14:58 --> CSRF token verified
INFO - 2021-09-08 15:14:58 --> Input Class Initialized
INFO - 2021-09-08 15:14:58 --> Language Class Initialized
INFO - 2021-09-08 15:14:58 --> Loader Class Initialized
INFO - 2021-09-08 15:14:58 --> Helper loaded: url_helper
INFO - 2021-09-08 15:14:58 --> Helper loaded: file_helper
INFO - 2021-09-08 15:14:58 --> Helper loaded: form_helper
INFO - 2021-09-08 15:14:58 --> Helper loaded: security_helper
INFO - 2021-09-08 15:14:58 --> Helper loaded: directory_helper
INFO - 2021-09-08 15:14:58 --> Helper loaded: general_helper
INFO - 2021-09-08 15:14:58 --> Database Driver Class Initialized
INFO - 2021-09-08 15:14:58 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-08 15:14:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-08 15:14:58 --> Pagination Class Initialized
INFO - 2021-09-08 15:14:58 --> XML-RPC Class Initialized
INFO - 2021-09-08 15:14:58 --> Form Validation Class Initialized
INFO - 2021-09-08 15:14:58 --> Upload Class Initialized
INFO - 2021-09-08 15:14:58 --> MY_Model class loaded
INFO - 2021-09-08 15:14:58 --> Model "Application_model" initialized
INFO - 2021-09-08 15:14:58 --> Controller Class Initialized
INFO - 2021-09-08 18:59:58 --> Model "Ajax_model" initialized
INFO - 2021-09-08 18:59:58 --> Final output sent to browser
DEBUG - 2021-09-08 18:59:58 --> Total execution time: 0.1477
INFO - 2021-09-08 15:15:01 --> Config Class Initialized
INFO - 2021-09-08 15:15:01 --> Hooks Class Initialized
DEBUG - 2021-09-08 15:15:01 --> UTF-8 Support Enabled
INFO - 2021-09-08 15:15:01 --> Utf8 Class Initialized
INFO - 2021-09-08 15:15:01 --> URI Class Initialized
INFO - 2021-09-08 15:15:01 --> Router Class Initialized
INFO - 2021-09-08 15:15:01 --> Output Class Initialized
INFO - 2021-09-08 15:15:01 --> Security Class Initialized
DEBUG - 2021-09-08 15:15:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-08 15:15:01 --> CSRF cookie sent
INFO - 2021-09-08 15:15:01 --> CSRF token verified
INFO - 2021-09-08 15:15:01 --> Input Class Initialized
INFO - 2021-09-08 15:15:01 --> Language Class Initialized
INFO - 2021-09-08 15:15:01 --> Loader Class Initialized
INFO - 2021-09-08 15:15:01 --> Helper loaded: url_helper
INFO - 2021-09-08 15:15:01 --> Helper loaded: file_helper
INFO - 2021-09-08 15:15:01 --> Helper loaded: form_helper
INFO - 2021-09-08 15:15:01 --> Helper loaded: security_helper
INFO - 2021-09-08 15:15:01 --> Helper loaded: directory_helper
INFO - 2021-09-08 15:15:01 --> Helper loaded: general_helper
INFO - 2021-09-08 15:15:01 --> Database Driver Class Initialized
INFO - 2021-09-08 15:15:01 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-08 15:15:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-08 15:15:01 --> Pagination Class Initialized
INFO - 2021-09-08 15:15:01 --> XML-RPC Class Initialized
INFO - 2021-09-08 15:15:01 --> Form Validation Class Initialized
INFO - 2021-09-08 15:15:01 --> Upload Class Initialized
INFO - 2021-09-08 15:15:01 --> MY_Model class loaded
INFO - 2021-09-08 15:15:01 --> Model "Application_model" initialized
INFO - 2021-09-08 15:15:01 --> Controller Class Initialized
INFO - 2021-09-08 19:00:01 --> Model "Sms_model" initialized
INFO - 2021-09-08 19:00:01 --> Model "Fees_model" initialized
INFO - 2021-09-08 19:00:01 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/header.php
INFO - 2021-09-08 19:00:01 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/topbar.php
INFO - 2021-09-08 19:00:02 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/sidebar.php
INFO - 2021-09-08 19:00:02 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\fees/invoice_list.php
INFO - 2021-09-08 19:00:02 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/script.php
INFO - 2021-09-08 19:00:02 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/index.php
INFO - 2021-09-08 19:00:02 --> Final output sent to browser
DEBUG - 2021-09-08 19:00:02 --> Total execution time: 0.9505
INFO - 2021-09-08 15:15:16 --> Config Class Initialized
INFO - 2021-09-08 15:15:16 --> Hooks Class Initialized
DEBUG - 2021-09-08 15:15:16 --> UTF-8 Support Enabled
INFO - 2021-09-08 15:15:16 --> Utf8 Class Initialized
INFO - 2021-09-08 15:15:16 --> URI Class Initialized
INFO - 2021-09-08 15:15:16 --> Router Class Initialized
INFO - 2021-09-08 15:15:16 --> Output Class Initialized
INFO - 2021-09-08 15:15:16 --> Security Class Initialized
DEBUG - 2021-09-08 15:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-08 15:15:16 --> CSRF cookie sent
INFO - 2021-09-08 15:15:16 --> Input Class Initialized
INFO - 2021-09-08 15:15:16 --> Language Class Initialized
INFO - 2021-09-08 15:15:16 --> Loader Class Initialized
INFO - 2021-09-08 15:15:16 --> Helper loaded: url_helper
INFO - 2021-09-08 15:15:16 --> Helper loaded: file_helper
INFO - 2021-09-08 15:15:16 --> Helper loaded: form_helper
INFO - 2021-09-08 15:15:16 --> Helper loaded: security_helper
INFO - 2021-09-08 15:15:16 --> Helper loaded: directory_helper
INFO - 2021-09-08 15:15:16 --> Helper loaded: general_helper
INFO - 2021-09-08 15:15:16 --> Database Driver Class Initialized
INFO - 2021-09-08 15:15:16 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-08 15:15:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-08 15:15:16 --> Pagination Class Initialized
INFO - 2021-09-08 15:15:16 --> XML-RPC Class Initialized
INFO - 2021-09-08 15:15:16 --> Form Validation Class Initialized
INFO - 2021-09-08 15:15:16 --> Upload Class Initialized
INFO - 2021-09-08 15:15:16 --> MY_Model class loaded
INFO - 2021-09-08 15:15:16 --> Model "Application_model" initialized
INFO - 2021-09-08 15:15:16 --> Controller Class Initialized
INFO - 2021-09-08 19:00:16 --> Model "Sms_model" initialized
INFO - 2021-09-08 19:00:16 --> Model "Fees_model" initialized
INFO - 2021-09-08 19:00:16 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/header.php
INFO - 2021-09-08 19:00:16 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/topbar.php
INFO - 2021-09-08 19:00:17 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/sidebar.php
INFO - 2021-09-08 19:00:17 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\fees/invoice_list.php
INFO - 2021-09-08 19:00:17 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/script.php
INFO - 2021-09-08 19:00:17 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/index.php
INFO - 2021-09-08 19:00:17 --> Final output sent to browser
DEBUG - 2021-09-08 19:00:17 --> Total execution time: 0.7726
INFO - 2021-09-08 15:15:23 --> Config Class Initialized
INFO - 2021-09-08 15:15:23 --> Hooks Class Initialized
DEBUG - 2021-09-08 15:15:23 --> UTF-8 Support Enabled
INFO - 2021-09-08 15:15:23 --> Utf8 Class Initialized
INFO - 2021-09-08 15:15:23 --> URI Class Initialized
INFO - 2021-09-08 15:15:23 --> Router Class Initialized
INFO - 2021-09-08 15:15:23 --> Output Class Initialized
INFO - 2021-09-08 15:15:23 --> Security Class Initialized
DEBUG - 2021-09-08 15:15:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-08 15:15:23 --> CSRF cookie sent
INFO - 2021-09-08 15:15:23 --> CSRF token verified
INFO - 2021-09-08 15:15:23 --> Input Class Initialized
INFO - 2021-09-08 15:15:23 --> Language Class Initialized
INFO - 2021-09-08 15:15:23 --> Loader Class Initialized
INFO - 2021-09-08 15:15:23 --> Helper loaded: url_helper
INFO - 2021-09-08 15:15:23 --> Helper loaded: file_helper
INFO - 2021-09-08 15:15:23 --> Helper loaded: form_helper
INFO - 2021-09-08 15:15:23 --> Helper loaded: security_helper
INFO - 2021-09-08 15:15:23 --> Helper loaded: directory_helper
INFO - 2021-09-08 15:15:23 --> Helper loaded: general_helper
INFO - 2021-09-08 15:15:23 --> Database Driver Class Initialized
INFO - 2021-09-08 15:15:23 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-08 15:15:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-08 15:15:23 --> Pagination Class Initialized
INFO - 2021-09-08 15:15:23 --> XML-RPC Class Initialized
INFO - 2021-09-08 15:15:23 --> Form Validation Class Initialized
INFO - 2021-09-08 15:15:23 --> Upload Class Initialized
INFO - 2021-09-08 15:15:23 --> MY_Model class loaded
INFO - 2021-09-08 15:15:23 --> Model "Application_model" initialized
INFO - 2021-09-08 15:15:23 --> Controller Class Initialized
INFO - 2021-09-08 19:00:23 --> Model "Ajax_model" initialized
INFO - 2021-09-08 19:00:23 --> Final output sent to browser
DEBUG - 2021-09-08 19:00:23 --> Total execution time: 0.1286
INFO - 2021-09-08 15:15:25 --> Config Class Initialized
INFO - 2021-09-08 15:15:25 --> Hooks Class Initialized
DEBUG - 2021-09-08 15:15:25 --> UTF-8 Support Enabled
INFO - 2021-09-08 15:15:25 --> Utf8 Class Initialized
INFO - 2021-09-08 15:15:25 --> URI Class Initialized
INFO - 2021-09-08 15:15:25 --> Router Class Initialized
INFO - 2021-09-08 15:15:25 --> Output Class Initialized
INFO - 2021-09-08 15:15:25 --> Security Class Initialized
DEBUG - 2021-09-08 15:15:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-08 15:15:25 --> CSRF cookie sent
INFO - 2021-09-08 15:15:25 --> CSRF token verified
INFO - 2021-09-08 15:15:25 --> Input Class Initialized
INFO - 2021-09-08 15:15:25 --> Language Class Initialized
INFO - 2021-09-08 15:15:25 --> Loader Class Initialized
INFO - 2021-09-08 15:15:25 --> Helper loaded: url_helper
INFO - 2021-09-08 15:15:25 --> Helper loaded: file_helper
INFO - 2021-09-08 15:15:25 --> Helper loaded: form_helper
INFO - 2021-09-08 15:15:25 --> Helper loaded: security_helper
INFO - 2021-09-08 15:15:25 --> Helper loaded: directory_helper
INFO - 2021-09-08 15:15:25 --> Helper loaded: general_helper
INFO - 2021-09-08 15:15:25 --> Database Driver Class Initialized
INFO - 2021-09-08 15:15:25 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-08 15:15:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-08 15:15:25 --> Pagination Class Initialized
INFO - 2021-09-08 15:15:25 --> XML-RPC Class Initialized
INFO - 2021-09-08 15:15:25 --> Form Validation Class Initialized
INFO - 2021-09-08 15:15:25 --> Upload Class Initialized
INFO - 2021-09-08 15:15:25 --> MY_Model class loaded
INFO - 2021-09-08 15:15:25 --> Model "Application_model" initialized
INFO - 2021-09-08 15:15:25 --> Controller Class Initialized
INFO - 2021-09-08 19:00:25 --> Model "Sms_model" initialized
INFO - 2021-09-08 19:00:25 --> Model "Fees_model" initialized
INFO - 2021-09-08 19:00:25 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/header.php
INFO - 2021-09-08 19:00:25 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/topbar.php
INFO - 2021-09-08 19:00:26 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/sidebar.php
INFO - 2021-09-08 19:00:26 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\fees/invoice_list.php
INFO - 2021-09-08 19:00:26 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/script.php
INFO - 2021-09-08 19:00:26 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/index.php
INFO - 2021-09-08 19:00:26 --> Final output sent to browser
DEBUG - 2021-09-08 19:00:26 --> Total execution time: 0.9367
INFO - 2021-09-08 15:16:50 --> Config Class Initialized
INFO - 2021-09-08 15:16:50 --> Hooks Class Initialized
DEBUG - 2021-09-08 15:16:50 --> UTF-8 Support Enabled
INFO - 2021-09-08 15:16:50 --> Utf8 Class Initialized
INFO - 2021-09-08 15:16:50 --> URI Class Initialized
INFO - 2021-09-08 15:16:50 --> Router Class Initialized
INFO - 2021-09-08 15:16:50 --> Output Class Initialized
INFO - 2021-09-08 15:16:50 --> Security Class Initialized
DEBUG - 2021-09-08 15:16:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-08 15:16:50 --> CSRF cookie sent
INFO - 2021-09-08 15:16:50 --> Input Class Initialized
INFO - 2021-09-08 15:16:50 --> Language Class Initialized
INFO - 2021-09-08 15:16:50 --> Loader Class Initialized
INFO - 2021-09-08 15:16:50 --> Helper loaded: url_helper
INFO - 2021-09-08 15:16:50 --> Helper loaded: file_helper
INFO - 2021-09-08 15:16:50 --> Helper loaded: form_helper
INFO - 2021-09-08 15:16:50 --> Helper loaded: security_helper
INFO - 2021-09-08 15:16:50 --> Helper loaded: directory_helper
INFO - 2021-09-08 15:16:50 --> Helper loaded: general_helper
INFO - 2021-09-08 15:16:50 --> Database Driver Class Initialized
INFO - 2021-09-08 15:16:50 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-08 15:16:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-08 15:16:50 --> Pagination Class Initialized
INFO - 2021-09-08 15:16:50 --> XML-RPC Class Initialized
INFO - 2021-09-08 15:16:50 --> Form Validation Class Initialized
INFO - 2021-09-08 15:16:50 --> Upload Class Initialized
INFO - 2021-09-08 15:16:50 --> MY_Model class loaded
INFO - 2021-09-08 15:16:50 --> Model "Application_model" initialized
INFO - 2021-09-08 15:16:50 --> Controller Class Initialized
INFO - 2021-09-08 19:01:50 --> Model "School_model" initialized
INFO - 2021-09-08 19:01:50 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/header.php
INFO - 2021-09-08 19:01:50 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/topbar.php
INFO - 2021-09-08 19:01:51 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/sidebar.php
INFO - 2021-09-08 19:01:51 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\school_settings/sidebar.php
INFO - 2021-09-08 19:01:51 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\school_settings/school.php
INFO - 2021-09-08 19:01:51 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/script.php
INFO - 2021-09-08 19:01:51 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/index.php
INFO - 2021-09-08 19:01:51 --> Final output sent to browser
DEBUG - 2021-09-08 19:01:51 --> Total execution time: 1.0598
INFO - 2021-09-08 15:41:19 --> Config Class Initialized
INFO - 2021-09-08 15:41:20 --> Hooks Class Initialized
DEBUG - 2021-09-08 15:41:20 --> UTF-8 Support Enabled
INFO - 2021-09-08 15:41:20 --> Utf8 Class Initialized
INFO - 2021-09-08 15:41:20 --> URI Class Initialized
INFO - 2021-09-08 15:41:20 --> Router Class Initialized
INFO - 2021-09-08 15:41:20 --> Output Class Initialized
INFO - 2021-09-08 15:41:20 --> Security Class Initialized
DEBUG - 2021-09-08 15:41:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-08 15:41:20 --> Input Class Initialized
INFO - 2021-09-08 15:41:20 --> Language Class Initialized
INFO - 2021-09-08 15:41:20 --> Loader Class Initialized
INFO - 2021-09-08 15:41:21 --> Helper loaded: url_helper
INFO - 2021-09-08 15:41:21 --> Helper loaded: file_helper
INFO - 2021-09-08 15:41:21 --> Helper loaded: form_helper
INFO - 2021-09-08 15:41:21 --> Helper loaded: security_helper
INFO - 2021-09-08 15:41:21 --> Helper loaded: directory_helper
INFO - 2021-09-08 15:41:21 --> Helper loaded: general_helper
INFO - 2021-09-08 15:41:21 --> Database Driver Class Initialized
INFO - 2021-09-08 15:41:22 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-08 15:41:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-08 15:41:22 --> Pagination Class Initialized
INFO - 2021-09-08 15:41:22 --> XML-RPC Class Initialized
INFO - 2021-09-08 15:41:22 --> Form Validation Class Initialized
INFO - 2021-09-08 15:41:22 --> Upload Class Initialized
INFO - 2021-09-08 15:41:22 --> MY_Model class loaded
INFO - 2021-09-08 15:41:22 --> Model "Application_model" initialized
INFO - 2021-09-08 15:41:22 --> Controller Class Initialized
DEBUG - 2021-09-08 15:41:22 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-08 15:41:22 --> Helper loaded: inflector_helper
INFO - 2021-09-08 15:41:22 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-08 15:41:22 --> Database Driver Class Initialized
ERROR - 2021-09-08 15:41:22 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-08 15:41:22 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-08 15:41:22 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-08 15:41:22 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-08 15:41:22 --> Model "Sms_model" initialized
INFO - 2021-09-08 15:41:22 --> Model "Fees_model" initialized
ERROR - 2021-09-08 15:41:22 --> Severity: Warning --> call_user_func_array() expects parameter 1 to be a valid callback, class 'Fees' does not have a method 'index_post' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 742
INFO - 2021-09-08 15:41:22 --> Final output sent to browser
DEBUG - 2021-09-08 15:41:22 --> Total execution time: 2.8436
INFO - 2021-09-08 15:41:38 --> Config Class Initialized
INFO - 2021-09-08 15:41:38 --> Hooks Class Initialized
DEBUG - 2021-09-08 15:41:38 --> UTF-8 Support Enabled
INFO - 2021-09-08 15:41:38 --> Utf8 Class Initialized
INFO - 2021-09-08 15:41:38 --> URI Class Initialized
INFO - 2021-09-08 15:41:38 --> Router Class Initialized
INFO - 2021-09-08 15:41:38 --> Output Class Initialized
INFO - 2021-09-08 15:41:38 --> Security Class Initialized
DEBUG - 2021-09-08 15:41:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-08 15:41:38 --> Input Class Initialized
INFO - 2021-09-08 15:41:38 --> Language Class Initialized
INFO - 2021-09-08 15:41:38 --> Loader Class Initialized
INFO - 2021-09-08 15:41:38 --> Helper loaded: url_helper
INFO - 2021-09-08 15:41:38 --> Helper loaded: file_helper
INFO - 2021-09-08 15:41:38 --> Helper loaded: form_helper
INFO - 2021-09-08 15:41:38 --> Helper loaded: security_helper
INFO - 2021-09-08 15:41:38 --> Helper loaded: directory_helper
INFO - 2021-09-08 15:41:38 --> Helper loaded: general_helper
INFO - 2021-09-08 15:41:38 --> Database Driver Class Initialized
INFO - 2021-09-08 15:41:38 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-08 15:41:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-08 15:41:38 --> Pagination Class Initialized
INFO - 2021-09-08 15:41:38 --> XML-RPC Class Initialized
INFO - 2021-09-08 15:41:38 --> Form Validation Class Initialized
INFO - 2021-09-08 15:41:38 --> Upload Class Initialized
INFO - 2021-09-08 15:41:38 --> MY_Model class loaded
INFO - 2021-09-08 15:41:38 --> Model "Application_model" initialized
INFO - 2021-09-08 15:41:38 --> Controller Class Initialized
DEBUG - 2021-09-08 15:41:38 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-08 15:41:38 --> Helper loaded: inflector_helper
INFO - 2021-09-08 15:41:38 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-08 15:41:38 --> Database Driver Class Initialized
ERROR - 2021-09-08 15:41:38 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-08 15:41:38 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-08 15:41:38 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-08 15:41:38 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-08 15:41:38 --> Model "Sms_model" initialized
INFO - 2021-09-08 15:41:38 --> Model "Fees_model" initialized
ERROR - 2021-09-08 15:41:38 --> Severity: Warning --> call_user_func_array() expects parameter 1 to be a valid callback, class 'Fees' does not have a method 'index_post' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 742
INFO - 2021-09-08 15:41:38 --> Final output sent to browser
DEBUG - 2021-09-08 15:41:38 --> Total execution time: 0.1525
INFO - 2021-09-08 15:41:51 --> Config Class Initialized
INFO - 2021-09-08 15:41:51 --> Hooks Class Initialized
DEBUG - 2021-09-08 15:41:51 --> UTF-8 Support Enabled
INFO - 2021-09-08 15:41:51 --> Utf8 Class Initialized
INFO - 2021-09-08 15:41:51 --> URI Class Initialized
INFO - 2021-09-08 15:41:51 --> Router Class Initialized
INFO - 2021-09-08 15:41:51 --> Output Class Initialized
INFO - 2021-09-08 15:41:51 --> Security Class Initialized
DEBUG - 2021-09-08 15:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-08 15:41:51 --> Input Class Initialized
INFO - 2021-09-08 15:41:51 --> Language Class Initialized
INFO - 2021-09-08 15:41:51 --> Loader Class Initialized
INFO - 2021-09-08 15:41:51 --> Helper loaded: url_helper
INFO - 2021-09-08 15:41:51 --> Helper loaded: file_helper
INFO - 2021-09-08 15:41:51 --> Helper loaded: form_helper
INFO - 2021-09-08 15:41:51 --> Helper loaded: security_helper
INFO - 2021-09-08 15:41:51 --> Helper loaded: directory_helper
INFO - 2021-09-08 15:41:51 --> Helper loaded: general_helper
INFO - 2021-09-08 15:41:51 --> Database Driver Class Initialized
INFO - 2021-09-08 15:41:51 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-08 15:41:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-08 15:41:51 --> Pagination Class Initialized
INFO - 2021-09-08 15:41:51 --> XML-RPC Class Initialized
INFO - 2021-09-08 15:41:51 --> Form Validation Class Initialized
INFO - 2021-09-08 15:41:51 --> Upload Class Initialized
INFO - 2021-09-08 15:41:51 --> MY_Model class loaded
INFO - 2021-09-08 15:41:51 --> Model "Application_model" initialized
INFO - 2021-09-08 15:41:51 --> Controller Class Initialized
DEBUG - 2021-09-08 15:41:51 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-08 15:41:51 --> Helper loaded: inflector_helper
INFO - 2021-09-08 15:41:51 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-08 15:41:51 --> Database Driver Class Initialized
ERROR - 2021-09-08 15:41:51 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-08 15:41:51 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-08 15:41:51 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-08 15:41:51 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-08 15:41:51 --> Model "Sms_model" initialized
INFO - 2021-09-08 15:41:51 --> Model "Fees_model" initialized
INFO - 2021-09-08 15:41:51 --> Final output sent to browser
DEBUG - 2021-09-08 15:41:51 --> Total execution time: 0.1736
INFO - 2021-09-08 15:42:24 --> Config Class Initialized
INFO - 2021-09-08 15:42:24 --> Hooks Class Initialized
DEBUG - 2021-09-08 15:42:24 --> UTF-8 Support Enabled
INFO - 2021-09-08 15:42:24 --> Utf8 Class Initialized
INFO - 2021-09-08 15:42:24 --> URI Class Initialized
INFO - 2021-09-08 15:42:24 --> Router Class Initialized
INFO - 2021-09-08 15:42:24 --> Output Class Initialized
INFO - 2021-09-08 15:42:24 --> Security Class Initialized
DEBUG - 2021-09-08 15:42:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-08 15:42:24 --> Input Class Initialized
INFO - 2021-09-08 15:42:24 --> Language Class Initialized
INFO - 2021-09-08 15:42:24 --> Loader Class Initialized
INFO - 2021-09-08 15:42:24 --> Helper loaded: url_helper
INFO - 2021-09-08 15:42:24 --> Helper loaded: file_helper
INFO - 2021-09-08 15:42:24 --> Helper loaded: form_helper
INFO - 2021-09-08 15:42:24 --> Helper loaded: security_helper
INFO - 2021-09-08 15:42:24 --> Helper loaded: directory_helper
INFO - 2021-09-08 15:42:24 --> Helper loaded: general_helper
INFO - 2021-09-08 15:42:24 --> Database Driver Class Initialized
INFO - 2021-09-08 15:42:24 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-08 15:42:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-08 15:42:24 --> Pagination Class Initialized
INFO - 2021-09-08 15:42:24 --> XML-RPC Class Initialized
INFO - 2021-09-08 15:42:24 --> Form Validation Class Initialized
INFO - 2021-09-08 15:42:24 --> Upload Class Initialized
INFO - 2021-09-08 15:42:24 --> MY_Model class loaded
INFO - 2021-09-08 15:42:24 --> Model "Application_model" initialized
INFO - 2021-09-08 15:42:24 --> Controller Class Initialized
DEBUG - 2021-09-08 15:42:24 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-08 15:42:24 --> Helper loaded: inflector_helper
INFO - 2021-09-08 15:42:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-08 15:42:24 --> Database Driver Class Initialized
ERROR - 2021-09-08 15:42:26 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-08 15:42:26 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-08 15:42:26 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-08 15:42:26 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-08 15:42:26 --> Model "Sms_model" initialized
INFO - 2021-09-08 15:42:26 --> Model "Fees_model" initialized
INFO - 2021-09-08 15:42:26 --> Final output sent to browser
DEBUG - 2021-09-08 15:42:26 --> Total execution time: 1.6094
INFO - 2021-09-08 15:43:12 --> Config Class Initialized
INFO - 2021-09-08 15:43:12 --> Hooks Class Initialized
DEBUG - 2021-09-08 15:43:12 --> UTF-8 Support Enabled
INFO - 2021-09-08 15:43:12 --> Utf8 Class Initialized
INFO - 2021-09-08 15:43:12 --> URI Class Initialized
INFO - 2021-09-08 15:43:12 --> Router Class Initialized
INFO - 2021-09-08 15:43:12 --> Output Class Initialized
INFO - 2021-09-08 15:43:12 --> Security Class Initialized
DEBUG - 2021-09-08 15:43:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-08 15:43:12 --> Input Class Initialized
INFO - 2021-09-08 15:43:12 --> Language Class Initialized
INFO - 2021-09-08 15:43:12 --> Loader Class Initialized
INFO - 2021-09-08 15:43:12 --> Helper loaded: url_helper
INFO - 2021-09-08 15:43:12 --> Helper loaded: file_helper
INFO - 2021-09-08 15:43:12 --> Helper loaded: form_helper
INFO - 2021-09-08 15:43:12 --> Helper loaded: security_helper
INFO - 2021-09-08 15:43:12 --> Helper loaded: directory_helper
INFO - 2021-09-08 15:43:12 --> Helper loaded: general_helper
INFO - 2021-09-08 15:43:12 --> Database Driver Class Initialized
INFO - 2021-09-08 15:43:12 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-08 15:43:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-08 15:43:12 --> Pagination Class Initialized
INFO - 2021-09-08 15:43:12 --> XML-RPC Class Initialized
INFO - 2021-09-08 15:43:12 --> Form Validation Class Initialized
INFO - 2021-09-08 15:43:12 --> Upload Class Initialized
INFO - 2021-09-08 15:43:12 --> MY_Model class loaded
INFO - 2021-09-08 15:43:12 --> Model "Application_model" initialized
INFO - 2021-09-08 15:43:12 --> Controller Class Initialized
DEBUG - 2021-09-08 15:43:12 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-08 15:43:12 --> Helper loaded: inflector_helper
INFO - 2021-09-08 15:43:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-08 15:43:12 --> Database Driver Class Initialized
ERROR - 2021-09-08 15:43:12 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-08 15:43:12 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-08 15:43:12 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-08 15:43:12 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-08 15:43:12 --> Model "Sms_model" initialized
INFO - 2021-09-08 15:43:12 --> Model "Fees_model" initialized
INFO - 2021-09-08 15:43:12 --> Final output sent to browser
DEBUG - 2021-09-08 15:43:12 --> Total execution time: 0.1398
INFO - 2021-09-08 15:43:14 --> Config Class Initialized
INFO - 2021-09-08 15:43:14 --> Hooks Class Initialized
DEBUG - 2021-09-08 15:43:14 --> UTF-8 Support Enabled
INFO - 2021-09-08 15:43:14 --> Utf8 Class Initialized
INFO - 2021-09-08 15:43:14 --> URI Class Initialized
INFO - 2021-09-08 15:43:14 --> Router Class Initialized
INFO - 2021-09-08 15:43:14 --> Output Class Initialized
INFO - 2021-09-08 15:43:14 --> Security Class Initialized
DEBUG - 2021-09-08 15:43:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-08 15:43:14 --> Input Class Initialized
INFO - 2021-09-08 15:43:14 --> Language Class Initialized
INFO - 2021-09-08 15:43:14 --> Loader Class Initialized
INFO - 2021-09-08 15:43:14 --> Helper loaded: url_helper
INFO - 2021-09-08 15:43:14 --> Helper loaded: file_helper
INFO - 2021-09-08 15:43:14 --> Helper loaded: form_helper
INFO - 2021-09-08 15:43:14 --> Helper loaded: security_helper
INFO - 2021-09-08 15:43:14 --> Helper loaded: directory_helper
INFO - 2021-09-08 15:43:14 --> Helper loaded: general_helper
INFO - 2021-09-08 15:43:14 --> Database Driver Class Initialized
INFO - 2021-09-08 15:43:14 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-08 15:43:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-08 15:43:14 --> Pagination Class Initialized
INFO - 2021-09-08 15:43:14 --> XML-RPC Class Initialized
INFO - 2021-09-08 15:43:14 --> Form Validation Class Initialized
INFO - 2021-09-08 15:43:14 --> Upload Class Initialized
INFO - 2021-09-08 15:43:14 --> MY_Model class loaded
INFO - 2021-09-08 15:43:14 --> Model "Application_model" initialized
INFO - 2021-09-08 15:43:14 --> Controller Class Initialized
DEBUG - 2021-09-08 15:43:14 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-08 15:43:14 --> Helper loaded: inflector_helper
INFO - 2021-09-08 15:43:14 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-08 15:43:14 --> Database Driver Class Initialized
ERROR - 2021-09-08 15:43:14 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-08 15:43:14 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-08 15:43:14 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-08 15:43:14 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-08 15:43:14 --> Model "Sms_model" initialized
INFO - 2021-09-08 15:43:14 --> Model "Fees_model" initialized
INFO - 2021-09-08 15:43:14 --> Final output sent to browser
DEBUG - 2021-09-08 15:43:14 --> Total execution time: 0.1189
INFO - 2021-09-08 15:56:51 --> Config Class Initialized
INFO - 2021-09-08 15:56:51 --> Hooks Class Initialized
DEBUG - 2021-09-08 15:56:51 --> UTF-8 Support Enabled
INFO - 2021-09-08 15:56:51 --> Utf8 Class Initialized
INFO - 2021-09-08 15:56:51 --> URI Class Initialized
INFO - 2021-09-08 15:56:51 --> Router Class Initialized
INFO - 2021-09-08 15:56:51 --> Output Class Initialized
INFO - 2021-09-08 15:56:51 --> Security Class Initialized
DEBUG - 2021-09-08 15:56:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-08 15:56:51 --> Input Class Initialized
INFO - 2021-09-08 15:56:51 --> Language Class Initialized
INFO - 2021-09-08 15:56:51 --> Loader Class Initialized
INFO - 2021-09-08 15:56:51 --> Helper loaded: url_helper
INFO - 2021-09-08 15:56:51 --> Helper loaded: file_helper
INFO - 2021-09-08 15:56:51 --> Helper loaded: form_helper
INFO - 2021-09-08 15:56:51 --> Helper loaded: security_helper
INFO - 2021-09-08 15:56:51 --> Helper loaded: directory_helper
INFO - 2021-09-08 15:56:51 --> Helper loaded: general_helper
INFO - 2021-09-08 15:56:51 --> Database Driver Class Initialized
INFO - 2021-09-08 15:56:51 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-08 15:56:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-08 15:56:51 --> Pagination Class Initialized
INFO - 2021-09-08 15:56:51 --> XML-RPC Class Initialized
INFO - 2021-09-08 15:56:51 --> Form Validation Class Initialized
INFO - 2021-09-08 15:56:51 --> Upload Class Initialized
INFO - 2021-09-08 15:56:51 --> MY_Model class loaded
INFO - 2021-09-08 15:56:51 --> Model "Application_model" initialized
INFO - 2021-09-08 15:56:51 --> Controller Class Initialized
DEBUG - 2021-09-08 15:56:51 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-08 15:56:51 --> Helper loaded: inflector_helper
INFO - 2021-09-08 15:56:51 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-08 15:56:51 --> Database Driver Class Initialized
ERROR - 2021-09-08 15:56:51 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-08 15:56:51 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-08 15:56:51 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-08 15:56:51 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-08 15:56:51 --> Model "Sms_model" initialized
INFO - 2021-09-08 15:56:51 --> Model "Fees_model" initialized
INFO - 2021-09-08 15:56:51 --> Final output sent to browser
DEBUG - 2021-09-08 15:56:51 --> Total execution time: 0.2745
INFO - 2021-09-08 15:57:23 --> Config Class Initialized
INFO - 2021-09-08 15:57:23 --> Hooks Class Initialized
DEBUG - 2021-09-08 15:57:23 --> UTF-8 Support Enabled
INFO - 2021-09-08 15:57:23 --> Utf8 Class Initialized
INFO - 2021-09-08 15:57:23 --> URI Class Initialized
INFO - 2021-09-08 15:57:23 --> Router Class Initialized
INFO - 2021-09-08 15:57:23 --> Output Class Initialized
INFO - 2021-09-08 15:57:23 --> Security Class Initialized
DEBUG - 2021-09-08 15:57:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-08 15:57:23 --> Input Class Initialized
INFO - 2021-09-08 15:57:23 --> Language Class Initialized
INFO - 2021-09-08 15:57:23 --> Loader Class Initialized
INFO - 2021-09-08 15:57:23 --> Helper loaded: url_helper
INFO - 2021-09-08 15:57:23 --> Helper loaded: file_helper
INFO - 2021-09-08 15:57:23 --> Helper loaded: form_helper
INFO - 2021-09-08 15:57:23 --> Helper loaded: security_helper
INFO - 2021-09-08 15:57:23 --> Helper loaded: directory_helper
INFO - 2021-09-08 15:57:23 --> Helper loaded: general_helper
INFO - 2021-09-08 15:57:23 --> Database Driver Class Initialized
INFO - 2021-09-08 15:57:23 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-08 15:57:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-08 15:57:23 --> Pagination Class Initialized
INFO - 2021-09-08 15:57:23 --> XML-RPC Class Initialized
INFO - 2021-09-08 15:57:23 --> Form Validation Class Initialized
INFO - 2021-09-08 15:57:23 --> Upload Class Initialized
INFO - 2021-09-08 15:57:23 --> MY_Model class loaded
INFO - 2021-09-08 15:57:23 --> Model "Application_model" initialized
INFO - 2021-09-08 15:57:23 --> Controller Class Initialized
DEBUG - 2021-09-08 15:57:23 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-08 15:57:23 --> Helper loaded: inflector_helper
INFO - 2021-09-08 15:57:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-08 15:57:23 --> Database Driver Class Initialized
ERROR - 2021-09-08 15:57:23 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-08 15:57:23 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-08 15:57:23 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-08 15:57:23 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-08 15:57:23 --> Model "Sms_model" initialized
INFO - 2021-09-08 15:57:23 --> Model "Fees_model" initialized
INFO - 2021-09-08 15:57:23 --> Final output sent to browser
DEBUG - 2021-09-08 15:57:23 --> Total execution time: 0.1256
