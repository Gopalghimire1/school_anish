<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-09-07 09:33:37 --> Config Class Initialized
INFO - 2021-09-07 09:33:37 --> Hooks Class Initialized
DEBUG - 2021-09-07 09:33:38 --> UTF-8 Support Enabled
INFO - 2021-09-07 09:33:38 --> Utf8 Class Initialized
INFO - 2021-09-07 09:33:38 --> URI Class Initialized
INFO - 2021-09-07 09:33:38 --> Router Class Initialized
INFO - 2021-09-07 09:33:38 --> Output Class Initialized
INFO - 2021-09-07 09:33:38 --> Security Class Initialized
DEBUG - 2021-09-07 09:33:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-07 09:33:39 --> CSRF cookie sent
INFO - 2021-09-07 09:33:39 --> Input Class Initialized
INFO - 2021-09-07 09:33:39 --> Language Class Initialized
INFO - 2021-09-07 09:33:39 --> Loader Class Initialized
INFO - 2021-09-07 09:33:39 --> Helper loaded: url_helper
INFO - 2021-09-07 09:33:39 --> Helper loaded: file_helper
INFO - 2021-09-07 09:33:39 --> Helper loaded: form_helper
INFO - 2021-09-07 09:33:39 --> Helper loaded: security_helper
INFO - 2021-09-07 09:33:39 --> Helper loaded: directory_helper
INFO - 2021-09-07 09:33:39 --> Helper loaded: general_helper
INFO - 2021-09-07 09:33:39 --> Database Driver Class Initialized
INFO - 2021-09-07 09:33:42 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-07 09:33:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-07 09:33:42 --> Pagination Class Initialized
INFO - 2021-09-07 09:33:42 --> XML-RPC Class Initialized
INFO - 2021-09-07 09:33:42 --> Form Validation Class Initialized
INFO - 2021-09-07 09:33:42 --> Upload Class Initialized
INFO - 2021-09-07 09:33:42 --> MY_Model class loaded
INFO - 2021-09-07 09:33:42 --> Model "Application_model" initialized
INFO - 2021-09-07 09:33:42 --> Controller Class Initialized
DEBUG - 2021-09-07 09:33:42 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-07 09:33:42 --> Helper loaded: inflector_helper
INFO - 2021-09-07 09:33:42 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-07 09:33:42 --> Database Driver Class Initialized
ERROR - 2021-09-07 09:33:43 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-07 09:33:43 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-07 09:33:43 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-07 09:33:43 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-07 09:33:43 --> Final output sent to browser
DEBUG - 2021-09-07 09:33:43 --> Total execution time: 5.8792
INFO - 2021-09-07 09:35:35 --> Config Class Initialized
INFO - 2021-09-07 09:35:35 --> Hooks Class Initialized
DEBUG - 2021-09-07 09:35:35 --> UTF-8 Support Enabled
INFO - 2021-09-07 09:35:35 --> Utf8 Class Initialized
INFO - 2021-09-07 09:35:35 --> URI Class Initialized
INFO - 2021-09-07 09:35:35 --> Router Class Initialized
INFO - 2021-09-07 09:35:35 --> Output Class Initialized
INFO - 2021-09-07 09:35:35 --> Security Class Initialized
DEBUG - 2021-09-07 09:35:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-07 09:35:35 --> CSRF cookie sent
INFO - 2021-09-07 09:35:35 --> Input Class Initialized
INFO - 2021-09-07 09:35:35 --> Language Class Initialized
INFO - 2021-09-07 09:35:35 --> Loader Class Initialized
INFO - 2021-09-07 09:35:35 --> Helper loaded: url_helper
INFO - 2021-09-07 09:35:35 --> Helper loaded: file_helper
INFO - 2021-09-07 09:35:35 --> Helper loaded: form_helper
INFO - 2021-09-07 09:35:35 --> Helper loaded: security_helper
INFO - 2021-09-07 09:35:35 --> Helper loaded: directory_helper
INFO - 2021-09-07 09:35:35 --> Helper loaded: general_helper
INFO - 2021-09-07 09:35:35 --> Database Driver Class Initialized
INFO - 2021-09-07 09:35:35 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-07 09:35:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-07 09:35:35 --> Pagination Class Initialized
INFO - 2021-09-07 09:35:35 --> XML-RPC Class Initialized
INFO - 2021-09-07 09:35:35 --> Form Validation Class Initialized
INFO - 2021-09-07 09:35:35 --> Upload Class Initialized
INFO - 2021-09-07 09:35:35 --> MY_Model class loaded
INFO - 2021-09-07 09:35:35 --> Model "Application_model" initialized
INFO - 2021-09-07 09:35:35 --> Controller Class Initialized
DEBUG - 2021-09-07 09:35:35 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-07 09:35:35 --> Helper loaded: inflector_helper
INFO - 2021-09-07 09:35:35 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-07 09:35:35 --> Database Driver Class Initialized
ERROR - 2021-09-07 09:35:35 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-07 09:35:35 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-07 09:35:35 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-07 09:35:35 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-07 09:35:35 --> Final output sent to browser
DEBUG - 2021-09-07 09:35:35 --> Total execution time: 0.2519
INFO - 2021-09-07 09:53:25 --> Config Class Initialized
INFO - 2021-09-07 09:53:25 --> Hooks Class Initialized
DEBUG - 2021-09-07 09:53:25 --> UTF-8 Support Enabled
INFO - 2021-09-07 09:53:25 --> Utf8 Class Initialized
INFO - 2021-09-07 09:53:25 --> URI Class Initialized
INFO - 2021-09-07 09:53:25 --> Router Class Initialized
INFO - 2021-09-07 09:53:25 --> Output Class Initialized
INFO - 2021-09-07 09:53:25 --> Security Class Initialized
DEBUG - 2021-09-07 09:53:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-07 09:53:25 --> Input Class Initialized
INFO - 2021-09-07 09:53:25 --> Language Class Initialized
INFO - 2021-09-07 09:53:25 --> Loader Class Initialized
INFO - 2021-09-07 09:53:25 --> Helper loaded: url_helper
INFO - 2021-09-07 09:53:25 --> Helper loaded: file_helper
INFO - 2021-09-07 09:53:25 --> Helper loaded: form_helper
INFO - 2021-09-07 09:53:25 --> Helper loaded: security_helper
INFO - 2021-09-07 09:53:25 --> Helper loaded: directory_helper
INFO - 2021-09-07 09:53:25 --> Helper loaded: general_helper
INFO - 2021-09-07 09:53:25 --> Database Driver Class Initialized
INFO - 2021-09-07 09:53:26 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-07 09:53:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-07 09:53:26 --> Pagination Class Initialized
INFO - 2021-09-07 09:53:26 --> XML-RPC Class Initialized
INFO - 2021-09-07 09:53:26 --> Form Validation Class Initialized
INFO - 2021-09-07 09:53:26 --> Upload Class Initialized
INFO - 2021-09-07 09:53:26 --> MY_Model class loaded
INFO - 2021-09-07 09:53:26 --> Model "Application_model" initialized
INFO - 2021-09-07 09:53:26 --> Controller Class Initialized
DEBUG - 2021-09-07 09:53:26 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-07 09:53:26 --> Helper loaded: inflector_helper
INFO - 2021-09-07 09:53:26 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-07 09:53:26 --> Database Driver Class Initialized
ERROR - 2021-09-07 09:53:26 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-07 09:53:26 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-07 09:53:26 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-07 09:53:26 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-07 09:53:26 --> Model "Student_model" initialized
INFO - 2021-09-07 09:53:27 --> Final output sent to browser
DEBUG - 2021-09-07 09:53:27 --> Total execution time: 2.1851
INFO - 2021-09-07 13:28:13 --> Config Class Initialized
INFO - 2021-09-07 13:28:13 --> Hooks Class Initialized
DEBUG - 2021-09-07 13:28:14 --> UTF-8 Support Enabled
INFO - 2021-09-07 13:28:14 --> Utf8 Class Initialized
INFO - 2021-09-07 13:28:14 --> URI Class Initialized
INFO - 2021-09-07 13:28:14 --> Router Class Initialized
INFO - 2021-09-07 13:28:14 --> Output Class Initialized
INFO - 2021-09-07 13:28:14 --> Security Class Initialized
DEBUG - 2021-09-07 13:28:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-07 13:28:14 --> Input Class Initialized
INFO - 2021-09-07 13:28:14 --> Language Class Initialized
INFO - 2021-09-07 13:28:14 --> Loader Class Initialized
INFO - 2021-09-07 13:28:14 --> Helper loaded: url_helper
INFO - 2021-09-07 13:28:14 --> Helper loaded: file_helper
INFO - 2021-09-07 13:28:14 --> Helper loaded: form_helper
INFO - 2021-09-07 13:28:14 --> Helper loaded: security_helper
INFO - 2021-09-07 13:28:14 --> Helper loaded: directory_helper
INFO - 2021-09-07 13:28:15 --> Helper loaded: general_helper
INFO - 2021-09-07 13:28:15 --> Database Driver Class Initialized
INFO - 2021-09-07 13:28:16 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-07 13:28:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-07 13:28:16 --> Pagination Class Initialized
INFO - 2021-09-07 13:28:16 --> XML-RPC Class Initialized
INFO - 2021-09-07 13:28:16 --> Form Validation Class Initialized
INFO - 2021-09-07 13:28:16 --> Upload Class Initialized
INFO - 2021-09-07 13:28:16 --> MY_Model class loaded
INFO - 2021-09-07 13:28:16 --> Model "Application_model" initialized
INFO - 2021-09-07 13:28:16 --> Controller Class Initialized
DEBUG - 2021-09-07 13:28:16 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-07 13:28:16 --> Helper loaded: inflector_helper
INFO - 2021-09-07 13:28:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-07 13:28:16 --> Database Driver Class Initialized
ERROR - 2021-09-07 13:28:16 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-07 13:28:16 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-07 13:28:16 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-07 13:28:16 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-07 13:28:16 --> Model "Student_model" initialized
INFO - 2021-09-07 13:28:17 --> Final output sent to browser
DEBUG - 2021-09-07 13:28:17 --> Total execution time: 3.7997
INFO - 2021-09-07 13:29:53 --> Config Class Initialized
INFO - 2021-09-07 13:29:53 --> Hooks Class Initialized
DEBUG - 2021-09-07 13:29:53 --> UTF-8 Support Enabled
INFO - 2021-09-07 13:29:53 --> Utf8 Class Initialized
INFO - 2021-09-07 13:29:53 --> URI Class Initialized
INFO - 2021-09-07 13:29:53 --> Router Class Initialized
INFO - 2021-09-07 13:29:53 --> Output Class Initialized
INFO - 2021-09-07 13:29:53 --> Security Class Initialized
DEBUG - 2021-09-07 13:29:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-07 13:29:53 --> Input Class Initialized
INFO - 2021-09-07 13:29:53 --> Language Class Initialized
INFO - 2021-09-07 13:29:53 --> Loader Class Initialized
INFO - 2021-09-07 13:29:53 --> Helper loaded: url_helper
INFO - 2021-09-07 13:29:53 --> Helper loaded: file_helper
INFO - 2021-09-07 13:29:53 --> Helper loaded: form_helper
INFO - 2021-09-07 13:29:53 --> Helper loaded: security_helper
INFO - 2021-09-07 13:29:53 --> Helper loaded: directory_helper
INFO - 2021-09-07 13:29:53 --> Helper loaded: general_helper
INFO - 2021-09-07 13:29:54 --> Database Driver Class Initialized
INFO - 2021-09-07 13:29:54 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-07 13:29:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-07 13:29:54 --> Pagination Class Initialized
INFO - 2021-09-07 13:29:54 --> XML-RPC Class Initialized
INFO - 2021-09-07 13:29:54 --> Form Validation Class Initialized
INFO - 2021-09-07 13:29:54 --> Upload Class Initialized
INFO - 2021-09-07 13:29:54 --> MY_Model class loaded
INFO - 2021-09-07 13:29:54 --> Model "Application_model" initialized
INFO - 2021-09-07 13:29:54 --> Controller Class Initialized
DEBUG - 2021-09-07 13:29:54 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-07 13:29:54 --> Helper loaded: inflector_helper
INFO - 2021-09-07 13:29:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-07 13:29:54 --> Database Driver Class Initialized
ERROR - 2021-09-07 13:29:54 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-07 13:29:54 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-07 13:29:54 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-07 13:29:54 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-07 13:29:54 --> Model "Student_model" initialized
INFO - 2021-09-07 13:29:54 --> Final output sent to browser
DEBUG - 2021-09-07 13:29:54 --> Total execution time: 1.5576
INFO - 2021-09-07 13:31:37 --> Config Class Initialized
INFO - 2021-09-07 13:31:37 --> Hooks Class Initialized
DEBUG - 2021-09-07 13:31:37 --> UTF-8 Support Enabled
INFO - 2021-09-07 13:31:37 --> Utf8 Class Initialized
INFO - 2021-09-07 13:31:37 --> URI Class Initialized
INFO - 2021-09-07 13:31:37 --> Router Class Initialized
INFO - 2021-09-07 13:31:37 --> Output Class Initialized
INFO - 2021-09-07 13:31:37 --> Security Class Initialized
DEBUG - 2021-09-07 13:31:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-07 13:31:37 --> Input Class Initialized
INFO - 2021-09-07 13:31:37 --> Language Class Initialized
INFO - 2021-09-07 13:31:37 --> Loader Class Initialized
INFO - 2021-09-07 13:31:37 --> Helper loaded: url_helper
INFO - 2021-09-07 13:31:37 --> Helper loaded: file_helper
INFO - 2021-09-07 13:31:37 --> Helper loaded: form_helper
INFO - 2021-09-07 13:31:37 --> Helper loaded: security_helper
INFO - 2021-09-07 13:31:37 --> Helper loaded: directory_helper
INFO - 2021-09-07 13:31:37 --> Helper loaded: general_helper
INFO - 2021-09-07 13:31:37 --> Database Driver Class Initialized
INFO - 2021-09-07 13:31:37 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-07 13:31:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-07 13:31:37 --> Pagination Class Initialized
INFO - 2021-09-07 13:31:37 --> XML-RPC Class Initialized
INFO - 2021-09-07 13:31:37 --> Form Validation Class Initialized
INFO - 2021-09-07 13:31:37 --> Upload Class Initialized
INFO - 2021-09-07 13:31:37 --> MY_Model class loaded
INFO - 2021-09-07 13:31:37 --> Model "Application_model" initialized
INFO - 2021-09-07 13:31:37 --> Controller Class Initialized
DEBUG - 2021-09-07 13:31:37 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-07 13:31:37 --> Helper loaded: inflector_helper
INFO - 2021-09-07 13:31:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-07 13:31:37 --> Database Driver Class Initialized
ERROR - 2021-09-07 13:31:37 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-07 13:31:37 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-07 13:31:37 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-07 13:31:37 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-07 13:31:37 --> Model "Student_model" initialized
INFO - 2021-09-07 13:31:37 --> Final output sent to browser
DEBUG - 2021-09-07 13:31:37 --> Total execution time: 0.1514
INFO - 2021-09-07 13:32:17 --> Config Class Initialized
INFO - 2021-09-07 13:32:17 --> Hooks Class Initialized
DEBUG - 2021-09-07 13:32:17 --> UTF-8 Support Enabled
INFO - 2021-09-07 13:32:17 --> Utf8 Class Initialized
INFO - 2021-09-07 13:32:17 --> URI Class Initialized
INFO - 2021-09-07 13:32:17 --> Router Class Initialized
INFO - 2021-09-07 13:32:17 --> Output Class Initialized
INFO - 2021-09-07 13:32:17 --> Security Class Initialized
DEBUG - 2021-09-07 13:32:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-07 13:32:17 --> Input Class Initialized
INFO - 2021-09-07 13:32:17 --> Language Class Initialized
INFO - 2021-09-07 13:32:17 --> Loader Class Initialized
INFO - 2021-09-07 13:32:17 --> Helper loaded: url_helper
INFO - 2021-09-07 13:32:17 --> Helper loaded: file_helper
INFO - 2021-09-07 13:32:17 --> Helper loaded: form_helper
INFO - 2021-09-07 13:32:17 --> Helper loaded: security_helper
INFO - 2021-09-07 13:32:17 --> Helper loaded: directory_helper
INFO - 2021-09-07 13:32:17 --> Helper loaded: general_helper
INFO - 2021-09-07 13:32:17 --> Database Driver Class Initialized
INFO - 2021-09-07 13:32:17 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-07 13:32:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-07 13:32:17 --> Pagination Class Initialized
INFO - 2021-09-07 13:32:17 --> XML-RPC Class Initialized
INFO - 2021-09-07 13:32:17 --> Form Validation Class Initialized
INFO - 2021-09-07 13:32:17 --> Upload Class Initialized
INFO - 2021-09-07 13:32:17 --> MY_Model class loaded
INFO - 2021-09-07 13:32:17 --> Model "Application_model" initialized
INFO - 2021-09-07 13:32:17 --> Controller Class Initialized
DEBUG - 2021-09-07 13:32:17 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-07 13:32:17 --> Helper loaded: inflector_helper
INFO - 2021-09-07 13:32:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-07 13:32:17 --> Database Driver Class Initialized
ERROR - 2021-09-07 13:32:17 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-07 13:32:17 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-07 13:32:17 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-07 13:32:17 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-07 13:32:17 --> Model "Student_model" initialized
INFO - 2021-09-07 13:32:17 --> Final output sent to browser
DEBUG - 2021-09-07 13:32:17 --> Total execution time: 0.1573
INFO - 2021-09-07 13:33:19 --> Config Class Initialized
INFO - 2021-09-07 13:33:19 --> Hooks Class Initialized
DEBUG - 2021-09-07 13:33:19 --> UTF-8 Support Enabled
INFO - 2021-09-07 13:33:19 --> Utf8 Class Initialized
INFO - 2021-09-07 13:33:19 --> URI Class Initialized
INFO - 2021-09-07 13:33:19 --> Router Class Initialized
INFO - 2021-09-07 13:33:19 --> Output Class Initialized
INFO - 2021-09-07 13:33:19 --> Security Class Initialized
DEBUG - 2021-09-07 13:33:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-07 13:33:19 --> Input Class Initialized
INFO - 2021-09-07 13:33:19 --> Language Class Initialized
INFO - 2021-09-07 13:33:19 --> Loader Class Initialized
INFO - 2021-09-07 13:33:19 --> Helper loaded: url_helper
INFO - 2021-09-07 13:33:19 --> Helper loaded: file_helper
INFO - 2021-09-07 13:33:19 --> Helper loaded: form_helper
INFO - 2021-09-07 13:33:19 --> Helper loaded: security_helper
INFO - 2021-09-07 13:33:19 --> Helper loaded: directory_helper
INFO - 2021-09-07 13:33:19 --> Helper loaded: general_helper
INFO - 2021-09-07 13:33:19 --> Database Driver Class Initialized
INFO - 2021-09-07 13:33:19 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-07 13:33:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-07 13:33:19 --> Pagination Class Initialized
INFO - 2021-09-07 13:33:19 --> XML-RPC Class Initialized
INFO - 2021-09-07 13:33:19 --> Form Validation Class Initialized
INFO - 2021-09-07 13:33:19 --> Upload Class Initialized
INFO - 2021-09-07 13:33:19 --> MY_Model class loaded
INFO - 2021-09-07 13:33:19 --> Model "Application_model" initialized
INFO - 2021-09-07 13:33:19 --> Controller Class Initialized
DEBUG - 2021-09-07 13:33:19 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-07 13:33:19 --> Helper loaded: inflector_helper
INFO - 2021-09-07 13:33:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-07 13:33:19 --> Database Driver Class Initialized
ERROR - 2021-09-07 13:33:19 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-07 13:33:19 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-07 13:33:19 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-07 13:33:19 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-07 13:33:19 --> Model "Student_model" initialized
INFO - 2021-09-07 13:33:19 --> Final output sent to browser
DEBUG - 2021-09-07 13:33:19 --> Total execution time: 0.4027
INFO - 2021-09-07 13:33:32 --> Config Class Initialized
INFO - 2021-09-07 13:33:32 --> Hooks Class Initialized
DEBUG - 2021-09-07 13:33:32 --> UTF-8 Support Enabled
INFO - 2021-09-07 13:33:32 --> Utf8 Class Initialized
INFO - 2021-09-07 13:33:32 --> URI Class Initialized
INFO - 2021-09-07 13:33:32 --> Router Class Initialized
INFO - 2021-09-07 13:33:32 --> Output Class Initialized
INFO - 2021-09-07 13:33:32 --> Security Class Initialized
DEBUG - 2021-09-07 13:33:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-07 13:33:32 --> Input Class Initialized
INFO - 2021-09-07 13:33:32 --> Language Class Initialized
INFO - 2021-09-07 13:33:32 --> Loader Class Initialized
INFO - 2021-09-07 13:33:32 --> Helper loaded: url_helper
INFO - 2021-09-07 13:33:32 --> Helper loaded: file_helper
INFO - 2021-09-07 13:33:32 --> Helper loaded: form_helper
INFO - 2021-09-07 13:33:32 --> Helper loaded: security_helper
INFO - 2021-09-07 13:33:32 --> Helper loaded: directory_helper
INFO - 2021-09-07 13:33:32 --> Helper loaded: general_helper
INFO - 2021-09-07 13:33:32 --> Database Driver Class Initialized
INFO - 2021-09-07 13:33:32 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-07 13:33:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-07 13:33:32 --> Pagination Class Initialized
INFO - 2021-09-07 13:33:32 --> XML-RPC Class Initialized
INFO - 2021-09-07 13:33:32 --> Form Validation Class Initialized
INFO - 2021-09-07 13:33:32 --> Upload Class Initialized
INFO - 2021-09-07 13:33:32 --> MY_Model class loaded
INFO - 2021-09-07 13:33:32 --> Model "Application_model" initialized
INFO - 2021-09-07 13:33:32 --> Controller Class Initialized
DEBUG - 2021-09-07 13:33:32 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-07 13:33:32 --> Helper loaded: inflector_helper
INFO - 2021-09-07 13:33:32 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-07 13:33:32 --> Database Driver Class Initialized
ERROR - 2021-09-07 13:33:32 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-07 13:33:32 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-07 13:33:32 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-07 13:33:32 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-07 13:33:32 --> Model "Student_model" initialized
INFO - 2021-09-07 13:33:32 --> Final output sent to browser
DEBUG - 2021-09-07 13:33:32 --> Total execution time: 0.1343
INFO - 2021-09-07 13:33:52 --> Config Class Initialized
INFO - 2021-09-07 13:33:52 --> Hooks Class Initialized
DEBUG - 2021-09-07 13:33:52 --> UTF-8 Support Enabled
INFO - 2021-09-07 13:33:52 --> Utf8 Class Initialized
INFO - 2021-09-07 13:33:52 --> URI Class Initialized
INFO - 2021-09-07 13:33:52 --> Router Class Initialized
INFO - 2021-09-07 13:33:52 --> Output Class Initialized
INFO - 2021-09-07 13:33:52 --> Security Class Initialized
DEBUG - 2021-09-07 13:33:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-07 13:33:52 --> Input Class Initialized
INFO - 2021-09-07 13:33:52 --> Language Class Initialized
INFO - 2021-09-07 13:33:52 --> Loader Class Initialized
INFO - 2021-09-07 13:33:52 --> Helper loaded: url_helper
INFO - 2021-09-07 13:33:52 --> Helper loaded: file_helper
INFO - 2021-09-07 13:33:52 --> Helper loaded: form_helper
INFO - 2021-09-07 13:33:52 --> Helper loaded: security_helper
INFO - 2021-09-07 13:33:52 --> Helper loaded: directory_helper
INFO - 2021-09-07 13:33:52 --> Helper loaded: general_helper
INFO - 2021-09-07 13:33:52 --> Database Driver Class Initialized
INFO - 2021-09-07 13:33:52 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-07 13:33:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-07 13:33:52 --> Pagination Class Initialized
INFO - 2021-09-07 13:33:52 --> XML-RPC Class Initialized
INFO - 2021-09-07 13:33:52 --> Form Validation Class Initialized
INFO - 2021-09-07 13:33:52 --> Upload Class Initialized
INFO - 2021-09-07 13:33:52 --> MY_Model class loaded
INFO - 2021-09-07 13:33:52 --> Model "Application_model" initialized
INFO - 2021-09-07 13:33:52 --> Controller Class Initialized
DEBUG - 2021-09-07 13:33:52 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-07 13:33:52 --> Helper loaded: inflector_helper
INFO - 2021-09-07 13:33:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-07 13:33:52 --> Database Driver Class Initialized
ERROR - 2021-09-07 13:33:52 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-07 13:33:52 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-07 13:33:52 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-07 13:33:52 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-07 13:33:52 --> Model "Student_model" initialized
INFO - 2021-09-07 13:33:52 --> Final output sent to browser
DEBUG - 2021-09-07 13:33:52 --> Total execution time: 0.1667
INFO - 2021-09-07 13:52:46 --> Config Class Initialized
INFO - 2021-09-07 13:52:46 --> Hooks Class Initialized
DEBUG - 2021-09-07 13:52:46 --> UTF-8 Support Enabled
INFO - 2021-09-07 13:52:46 --> Utf8 Class Initialized
INFO - 2021-09-07 13:52:46 --> URI Class Initialized
INFO - 2021-09-07 13:52:46 --> Router Class Initialized
INFO - 2021-09-07 13:52:46 --> Output Class Initialized
INFO - 2021-09-07 13:52:46 --> Security Class Initialized
DEBUG - 2021-09-07 13:52:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-07 13:52:46 --> Input Class Initialized
INFO - 2021-09-07 13:52:46 --> Language Class Initialized
INFO - 2021-09-07 13:52:46 --> Loader Class Initialized
INFO - 2021-09-07 13:52:46 --> Helper loaded: url_helper
INFO - 2021-09-07 13:52:46 --> Helper loaded: file_helper
INFO - 2021-09-07 13:52:46 --> Helper loaded: form_helper
INFO - 2021-09-07 13:52:46 --> Helper loaded: security_helper
INFO - 2021-09-07 13:52:46 --> Helper loaded: directory_helper
INFO - 2021-09-07 13:52:46 --> Helper loaded: general_helper
INFO - 2021-09-07 13:52:46 --> Database Driver Class Initialized
INFO - 2021-09-07 13:52:47 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-07 13:52:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-07 13:52:47 --> Pagination Class Initialized
INFO - 2021-09-07 13:52:47 --> XML-RPC Class Initialized
INFO - 2021-09-07 13:52:47 --> Form Validation Class Initialized
INFO - 2021-09-07 13:52:47 --> Upload Class Initialized
INFO - 2021-09-07 13:52:47 --> MY_Model class loaded
INFO - 2021-09-07 13:52:47 --> Model "Application_model" initialized
INFO - 2021-09-07 13:52:47 --> Controller Class Initialized
DEBUG - 2021-09-07 13:52:47 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-07 13:52:47 --> Helper loaded: inflector_helper
INFO - 2021-09-07 13:52:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-07 13:52:47 --> Database Driver Class Initialized
ERROR - 2021-09-07 13:52:47 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-07 13:52:47 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-07 13:52:47 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-07 13:52:47 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-07 13:52:47 --> Model "Student_model" initialized
ERROR - 2021-09-07 13:52:47 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_driver::form() C:\Users\Gopal Ghimire\Desktop\New folder\school\application\controllers\api\Student.php 22
INFO - 2021-09-07 13:53:22 --> Config Class Initialized
INFO - 2021-09-07 13:53:22 --> Hooks Class Initialized
DEBUG - 2021-09-07 13:53:22 --> UTF-8 Support Enabled
INFO - 2021-09-07 13:53:22 --> Utf8 Class Initialized
INFO - 2021-09-07 13:53:22 --> URI Class Initialized
INFO - 2021-09-07 13:53:22 --> Router Class Initialized
INFO - 2021-09-07 13:53:22 --> Output Class Initialized
INFO - 2021-09-07 13:53:22 --> Security Class Initialized
DEBUG - 2021-09-07 13:53:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-07 13:53:22 --> Input Class Initialized
INFO - 2021-09-07 13:53:22 --> Language Class Initialized
INFO - 2021-09-07 13:53:22 --> Loader Class Initialized
INFO - 2021-09-07 13:53:22 --> Helper loaded: url_helper
INFO - 2021-09-07 13:53:22 --> Helper loaded: file_helper
INFO - 2021-09-07 13:53:22 --> Helper loaded: form_helper
INFO - 2021-09-07 13:53:22 --> Helper loaded: security_helper
INFO - 2021-09-07 13:53:22 --> Helper loaded: directory_helper
INFO - 2021-09-07 13:53:22 --> Helper loaded: general_helper
INFO - 2021-09-07 13:53:22 --> Database Driver Class Initialized
INFO - 2021-09-07 13:53:22 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-07 13:53:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-07 13:53:22 --> Pagination Class Initialized
INFO - 2021-09-07 13:53:22 --> XML-RPC Class Initialized
INFO - 2021-09-07 13:53:22 --> Form Validation Class Initialized
INFO - 2021-09-07 13:53:22 --> Upload Class Initialized
INFO - 2021-09-07 13:53:22 --> MY_Model class loaded
INFO - 2021-09-07 13:53:22 --> Model "Application_model" initialized
INFO - 2021-09-07 13:53:22 --> Controller Class Initialized
DEBUG - 2021-09-07 13:53:22 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-07 13:53:22 --> Helper loaded: inflector_helper
INFO - 2021-09-07 13:53:22 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-07 13:53:22 --> Database Driver Class Initialized
ERROR - 2021-09-07 13:53:22 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-07 13:53:22 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-07 13:53:22 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-07 13:53:22 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-07 13:53:22 --> Model "Student_model" initialized
ERROR - 2021-09-07 13:53:22 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_driver::form() C:\Users\Gopal Ghimire\Desktop\New folder\school\application\controllers\api\Student.php 22
INFO - 2021-09-07 13:53:24 --> Config Class Initialized
INFO - 2021-09-07 13:53:24 --> Hooks Class Initialized
DEBUG - 2021-09-07 13:53:24 --> UTF-8 Support Enabled
INFO - 2021-09-07 13:53:24 --> Utf8 Class Initialized
INFO - 2021-09-07 13:53:24 --> URI Class Initialized
INFO - 2021-09-07 13:53:24 --> Router Class Initialized
INFO - 2021-09-07 13:53:24 --> Output Class Initialized
INFO - 2021-09-07 13:53:24 --> Security Class Initialized
DEBUG - 2021-09-07 13:53:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-07 13:53:24 --> Input Class Initialized
INFO - 2021-09-07 13:53:25 --> Language Class Initialized
INFO - 2021-09-07 13:53:25 --> Loader Class Initialized
INFO - 2021-09-07 13:53:25 --> Helper loaded: url_helper
INFO - 2021-09-07 13:53:25 --> Helper loaded: file_helper
INFO - 2021-09-07 13:53:25 --> Helper loaded: form_helper
INFO - 2021-09-07 13:53:25 --> Helper loaded: security_helper
INFO - 2021-09-07 13:53:25 --> Helper loaded: directory_helper
INFO - 2021-09-07 13:53:25 --> Helper loaded: general_helper
INFO - 2021-09-07 13:53:25 --> Database Driver Class Initialized
INFO - 2021-09-07 13:53:25 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-07 13:53:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-07 13:53:25 --> Pagination Class Initialized
INFO - 2021-09-07 13:53:25 --> XML-RPC Class Initialized
INFO - 2021-09-07 13:53:25 --> Form Validation Class Initialized
INFO - 2021-09-07 13:53:25 --> Upload Class Initialized
INFO - 2021-09-07 13:53:25 --> MY_Model class loaded
INFO - 2021-09-07 13:53:25 --> Model "Application_model" initialized
INFO - 2021-09-07 13:53:25 --> Controller Class Initialized
DEBUG - 2021-09-07 13:53:25 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-07 13:53:25 --> Helper loaded: inflector_helper
INFO - 2021-09-07 13:53:25 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-07 13:53:25 --> Database Driver Class Initialized
ERROR - 2021-09-07 13:53:25 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-07 13:53:25 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-07 13:53:25 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-07 13:53:25 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-07 13:53:25 --> Model "Student_model" initialized
ERROR - 2021-09-07 13:53:25 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_driver::form() C:\Users\Gopal Ghimire\Desktop\New folder\school\application\controllers\api\Student.php 22
INFO - 2021-09-07 13:54:13 --> Config Class Initialized
INFO - 2021-09-07 13:54:13 --> Hooks Class Initialized
DEBUG - 2021-09-07 13:54:13 --> UTF-8 Support Enabled
INFO - 2021-09-07 13:54:13 --> Utf8 Class Initialized
INFO - 2021-09-07 13:54:13 --> URI Class Initialized
INFO - 2021-09-07 13:54:13 --> Router Class Initialized
INFO - 2021-09-07 13:54:13 --> Output Class Initialized
INFO - 2021-09-07 13:54:13 --> Security Class Initialized
DEBUG - 2021-09-07 13:54:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-07 13:54:13 --> Input Class Initialized
INFO - 2021-09-07 13:54:13 --> Language Class Initialized
INFO - 2021-09-07 13:54:13 --> Loader Class Initialized
INFO - 2021-09-07 13:54:13 --> Helper loaded: url_helper
INFO - 2021-09-07 13:54:13 --> Helper loaded: file_helper
INFO - 2021-09-07 13:54:13 --> Helper loaded: form_helper
INFO - 2021-09-07 13:54:13 --> Helper loaded: security_helper
INFO - 2021-09-07 13:54:13 --> Helper loaded: directory_helper
INFO - 2021-09-07 13:54:13 --> Helper loaded: general_helper
INFO - 2021-09-07 13:54:13 --> Database Driver Class Initialized
INFO - 2021-09-07 13:54:13 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-07 13:54:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-07 13:54:13 --> Pagination Class Initialized
INFO - 2021-09-07 13:54:13 --> XML-RPC Class Initialized
INFO - 2021-09-07 13:54:13 --> Form Validation Class Initialized
INFO - 2021-09-07 13:54:13 --> Upload Class Initialized
INFO - 2021-09-07 13:54:13 --> MY_Model class loaded
INFO - 2021-09-07 13:54:13 --> Model "Application_model" initialized
INFO - 2021-09-07 13:54:13 --> Controller Class Initialized
DEBUG - 2021-09-07 13:54:13 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-07 13:54:13 --> Helper loaded: inflector_helper
INFO - 2021-09-07 13:54:13 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-07 13:54:13 --> Database Driver Class Initialized
ERROR - 2021-09-07 13:54:13 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-07 13:54:13 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-07 13:54:13 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-07 13:54:13 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-07 13:54:13 --> Model "Student_model" initialized
ERROR - 2021-09-07 13:54:13 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_driver::form() C:\Users\Gopal Ghimire\Desktop\New folder\school\application\controllers\api\Student.php 22
INFO - 2021-09-07 13:54:23 --> Config Class Initialized
INFO - 2021-09-07 13:54:23 --> Hooks Class Initialized
DEBUG - 2021-09-07 13:54:23 --> UTF-8 Support Enabled
INFO - 2021-09-07 13:54:23 --> Utf8 Class Initialized
INFO - 2021-09-07 13:54:23 --> URI Class Initialized
INFO - 2021-09-07 13:54:23 --> Router Class Initialized
INFO - 2021-09-07 13:54:23 --> Output Class Initialized
INFO - 2021-09-07 13:54:23 --> Security Class Initialized
DEBUG - 2021-09-07 13:54:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-07 13:54:23 --> Input Class Initialized
INFO - 2021-09-07 13:54:23 --> Language Class Initialized
INFO - 2021-09-07 13:54:23 --> Loader Class Initialized
INFO - 2021-09-07 13:54:23 --> Helper loaded: url_helper
INFO - 2021-09-07 13:54:23 --> Helper loaded: file_helper
INFO - 2021-09-07 13:54:23 --> Helper loaded: form_helper
INFO - 2021-09-07 13:54:23 --> Helper loaded: security_helper
INFO - 2021-09-07 13:54:23 --> Helper loaded: directory_helper
INFO - 2021-09-07 13:54:23 --> Helper loaded: general_helper
INFO - 2021-09-07 13:54:23 --> Database Driver Class Initialized
INFO - 2021-09-07 13:54:23 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-07 13:54:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-07 13:54:23 --> Pagination Class Initialized
INFO - 2021-09-07 13:54:23 --> XML-RPC Class Initialized
INFO - 2021-09-07 13:54:23 --> Form Validation Class Initialized
INFO - 2021-09-07 13:54:23 --> Upload Class Initialized
INFO - 2021-09-07 13:54:23 --> MY_Model class loaded
INFO - 2021-09-07 13:54:23 --> Model "Application_model" initialized
INFO - 2021-09-07 13:54:23 --> Controller Class Initialized
DEBUG - 2021-09-07 13:54:23 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-07 13:54:23 --> Helper loaded: inflector_helper
INFO - 2021-09-07 13:54:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-07 13:54:23 --> Database Driver Class Initialized
ERROR - 2021-09-07 13:54:23 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-07 13:54:23 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-07 13:54:23 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-07 13:54:23 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-07 13:54:23 --> Model "Student_model" initialized
ERROR - 2021-09-07 13:54:23 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_driver::form() C:\Users\Gopal Ghimire\Desktop\New folder\school\application\controllers\api\Student.php 22
INFO - 2021-09-07 13:55:15 --> Config Class Initialized
INFO - 2021-09-07 13:55:15 --> Hooks Class Initialized
DEBUG - 2021-09-07 13:55:15 --> UTF-8 Support Enabled
INFO - 2021-09-07 13:55:15 --> Utf8 Class Initialized
INFO - 2021-09-07 13:55:15 --> URI Class Initialized
INFO - 2021-09-07 13:55:15 --> Router Class Initialized
INFO - 2021-09-07 13:55:15 --> Output Class Initialized
INFO - 2021-09-07 13:55:15 --> Security Class Initialized
DEBUG - 2021-09-07 13:55:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-07 13:55:15 --> Input Class Initialized
INFO - 2021-09-07 13:55:15 --> Language Class Initialized
INFO - 2021-09-07 13:55:15 --> Loader Class Initialized
INFO - 2021-09-07 13:55:15 --> Helper loaded: url_helper
INFO - 2021-09-07 13:55:15 --> Helper loaded: file_helper
INFO - 2021-09-07 13:55:15 --> Helper loaded: form_helper
INFO - 2021-09-07 13:55:15 --> Helper loaded: security_helper
INFO - 2021-09-07 13:55:15 --> Helper loaded: directory_helper
INFO - 2021-09-07 13:55:15 --> Helper loaded: general_helper
INFO - 2021-09-07 13:55:15 --> Database Driver Class Initialized
INFO - 2021-09-07 13:55:15 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-07 13:55:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-07 13:55:15 --> Pagination Class Initialized
INFO - 2021-09-07 13:55:15 --> XML-RPC Class Initialized
INFO - 2021-09-07 13:55:15 --> Form Validation Class Initialized
INFO - 2021-09-07 13:55:15 --> Upload Class Initialized
INFO - 2021-09-07 13:55:15 --> MY_Model class loaded
INFO - 2021-09-07 13:55:15 --> Model "Application_model" initialized
INFO - 2021-09-07 13:55:15 --> Controller Class Initialized
DEBUG - 2021-09-07 13:55:15 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-07 13:55:15 --> Helper loaded: inflector_helper
INFO - 2021-09-07 13:55:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-07 13:55:15 --> Database Driver Class Initialized
ERROR - 2021-09-07 13:55:15 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-07 13:55:15 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-07 13:55:15 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-07 13:55:15 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-07 13:55:15 --> Model "Student_model" initialized
ERROR - 2021-09-07 13:55:15 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_driver::form() C:\Users\Gopal Ghimire\Desktop\New folder\school\application\controllers\api\Student.php 22
INFO - 2021-09-07 13:55:19 --> Config Class Initialized
INFO - 2021-09-07 13:55:19 --> Hooks Class Initialized
DEBUG - 2021-09-07 13:55:19 --> UTF-8 Support Enabled
INFO - 2021-09-07 13:55:19 --> Utf8 Class Initialized
INFO - 2021-09-07 13:55:19 --> URI Class Initialized
INFO - 2021-09-07 13:55:19 --> Router Class Initialized
INFO - 2021-09-07 13:55:19 --> Output Class Initialized
INFO - 2021-09-07 13:55:19 --> Security Class Initialized
DEBUG - 2021-09-07 13:55:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-07 13:55:19 --> Input Class Initialized
INFO - 2021-09-07 13:55:19 --> Language Class Initialized
INFO - 2021-09-07 13:55:19 --> Loader Class Initialized
INFO - 2021-09-07 13:55:19 --> Helper loaded: url_helper
INFO - 2021-09-07 13:55:19 --> Helper loaded: file_helper
INFO - 2021-09-07 13:55:19 --> Helper loaded: form_helper
INFO - 2021-09-07 13:55:19 --> Helper loaded: security_helper
INFO - 2021-09-07 13:55:19 --> Helper loaded: directory_helper
INFO - 2021-09-07 13:55:19 --> Helper loaded: general_helper
INFO - 2021-09-07 13:55:19 --> Database Driver Class Initialized
INFO - 2021-09-07 13:55:19 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-07 13:55:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-07 13:55:19 --> Pagination Class Initialized
INFO - 2021-09-07 13:55:19 --> XML-RPC Class Initialized
INFO - 2021-09-07 13:55:19 --> Form Validation Class Initialized
INFO - 2021-09-07 13:55:19 --> Upload Class Initialized
INFO - 2021-09-07 13:55:19 --> MY_Model class loaded
INFO - 2021-09-07 13:55:19 --> Model "Application_model" initialized
INFO - 2021-09-07 13:55:19 --> Controller Class Initialized
DEBUG - 2021-09-07 13:55:19 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-07 13:55:19 --> Helper loaded: inflector_helper
INFO - 2021-09-07 13:55:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-07 13:55:19 --> Database Driver Class Initialized
ERROR - 2021-09-07 13:55:19 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-07 13:55:19 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-07 13:55:19 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-07 13:55:19 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-07 13:55:19 --> Model "Student_model" initialized
ERROR - 2021-09-07 13:55:19 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_driver::form() C:\Users\Gopal Ghimire\Desktop\New folder\school\application\controllers\api\Student.php 22
INFO - 2021-09-07 13:56:30 --> Config Class Initialized
INFO - 2021-09-07 13:56:30 --> Hooks Class Initialized
DEBUG - 2021-09-07 13:56:30 --> UTF-8 Support Enabled
INFO - 2021-09-07 13:56:30 --> Utf8 Class Initialized
INFO - 2021-09-07 13:56:30 --> URI Class Initialized
INFO - 2021-09-07 13:56:30 --> Router Class Initialized
INFO - 2021-09-07 13:56:30 --> Output Class Initialized
INFO - 2021-09-07 13:56:30 --> Security Class Initialized
DEBUG - 2021-09-07 13:56:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-07 13:56:30 --> Input Class Initialized
INFO - 2021-09-07 13:56:30 --> Language Class Initialized
INFO - 2021-09-07 13:56:30 --> Loader Class Initialized
INFO - 2021-09-07 13:56:30 --> Helper loaded: url_helper
INFO - 2021-09-07 13:56:30 --> Helper loaded: file_helper
INFO - 2021-09-07 13:56:30 --> Helper loaded: form_helper
INFO - 2021-09-07 13:56:30 --> Helper loaded: security_helper
INFO - 2021-09-07 13:56:30 --> Helper loaded: directory_helper
INFO - 2021-09-07 13:56:30 --> Helper loaded: general_helper
INFO - 2021-09-07 13:56:30 --> Database Driver Class Initialized
INFO - 2021-09-07 13:56:30 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-07 13:56:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-07 13:56:30 --> Pagination Class Initialized
INFO - 2021-09-07 13:56:30 --> XML-RPC Class Initialized
INFO - 2021-09-07 13:56:30 --> Form Validation Class Initialized
INFO - 2021-09-07 13:56:30 --> Upload Class Initialized
INFO - 2021-09-07 13:56:30 --> MY_Model class loaded
INFO - 2021-09-07 13:56:30 --> Model "Application_model" initialized
INFO - 2021-09-07 13:56:30 --> Controller Class Initialized
DEBUG - 2021-09-07 13:56:30 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-07 13:56:30 --> Helper loaded: inflector_helper
INFO - 2021-09-07 13:56:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-07 13:56:30 --> Database Driver Class Initialized
ERROR - 2021-09-07 13:56:30 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-07 13:56:30 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-07 13:56:30 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-07 13:56:30 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-07 13:56:30 --> Model "Student_model" initialized
ERROR - 2021-09-07 13:56:30 --> Query error: Unknown table 'anish.b' - Invalid query: SELECT `a`.*, `b`.*
FROM `enroll` `a`
WHERE `a`.`class_id` = '1'
AND `a`.`section_id` = '1'
AND `a`.`branch_id` = '1'
ERROR - 2021-09-07 13:56:30 --> Severity: error --> Exception: Call to a member function result() on bool C:\Users\Gopal Ghimire\Desktop\New folder\school\application\controllers\api\Student.php 24
INFO - 2021-09-07 13:56:51 --> Config Class Initialized
INFO - 2021-09-07 13:56:51 --> Hooks Class Initialized
DEBUG - 2021-09-07 13:56:51 --> UTF-8 Support Enabled
INFO - 2021-09-07 13:56:51 --> Utf8 Class Initialized
INFO - 2021-09-07 13:56:51 --> URI Class Initialized
INFO - 2021-09-07 13:56:51 --> Router Class Initialized
INFO - 2021-09-07 13:56:51 --> Output Class Initialized
INFO - 2021-09-07 13:56:51 --> Security Class Initialized
DEBUG - 2021-09-07 13:56:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-07 13:56:51 --> Input Class Initialized
INFO - 2021-09-07 13:56:51 --> Language Class Initialized
INFO - 2021-09-07 13:56:51 --> Loader Class Initialized
INFO - 2021-09-07 13:56:51 --> Helper loaded: url_helper
INFO - 2021-09-07 13:56:51 --> Helper loaded: file_helper
INFO - 2021-09-07 13:56:51 --> Helper loaded: form_helper
INFO - 2021-09-07 13:56:51 --> Helper loaded: security_helper
INFO - 2021-09-07 13:56:51 --> Helper loaded: directory_helper
INFO - 2021-09-07 13:56:51 --> Helper loaded: general_helper
INFO - 2021-09-07 13:56:51 --> Database Driver Class Initialized
INFO - 2021-09-07 13:56:51 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-07 13:56:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-07 13:56:51 --> Pagination Class Initialized
INFO - 2021-09-07 13:56:51 --> XML-RPC Class Initialized
INFO - 2021-09-07 13:56:51 --> Form Validation Class Initialized
INFO - 2021-09-07 13:56:51 --> Upload Class Initialized
INFO - 2021-09-07 13:56:51 --> MY_Model class loaded
INFO - 2021-09-07 13:56:51 --> Model "Application_model" initialized
INFO - 2021-09-07 13:56:51 --> Controller Class Initialized
DEBUG - 2021-09-07 13:56:51 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-07 13:56:51 --> Helper loaded: inflector_helper
INFO - 2021-09-07 13:56:51 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-07 13:56:51 --> Database Driver Class Initialized
ERROR - 2021-09-07 13:56:51 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-07 13:56:51 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-07 13:56:51 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-07 13:56:51 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-07 13:56:51 --> Model "Student_model" initialized
INFO - 2021-09-07 13:56:51 --> Final output sent to browser
DEBUG - 2021-09-07 13:56:51 --> Total execution time: 0.1345
INFO - 2021-09-07 13:58:18 --> Config Class Initialized
INFO - 2021-09-07 13:58:18 --> Hooks Class Initialized
DEBUG - 2021-09-07 13:58:18 --> UTF-8 Support Enabled
INFO - 2021-09-07 13:58:18 --> Utf8 Class Initialized
INFO - 2021-09-07 13:58:18 --> URI Class Initialized
INFO - 2021-09-07 13:58:18 --> Router Class Initialized
INFO - 2021-09-07 13:58:18 --> Output Class Initialized
INFO - 2021-09-07 13:58:18 --> Security Class Initialized
DEBUG - 2021-09-07 13:58:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-07 13:58:18 --> Input Class Initialized
INFO - 2021-09-07 13:58:18 --> Language Class Initialized
INFO - 2021-09-07 13:58:18 --> Loader Class Initialized
INFO - 2021-09-07 13:58:18 --> Helper loaded: url_helper
INFO - 2021-09-07 13:58:18 --> Helper loaded: file_helper
INFO - 2021-09-07 13:58:18 --> Helper loaded: form_helper
INFO - 2021-09-07 13:58:18 --> Helper loaded: security_helper
INFO - 2021-09-07 13:58:18 --> Helper loaded: directory_helper
INFO - 2021-09-07 13:58:18 --> Helper loaded: general_helper
INFO - 2021-09-07 13:58:18 --> Database Driver Class Initialized
INFO - 2021-09-07 13:58:18 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-07 13:58:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-07 13:58:18 --> Pagination Class Initialized
INFO - 2021-09-07 13:58:18 --> XML-RPC Class Initialized
INFO - 2021-09-07 13:58:18 --> Form Validation Class Initialized
INFO - 2021-09-07 13:58:18 --> Upload Class Initialized
INFO - 2021-09-07 13:58:18 --> MY_Model class loaded
INFO - 2021-09-07 13:58:18 --> Model "Application_model" initialized
INFO - 2021-09-07 13:58:18 --> Controller Class Initialized
DEBUG - 2021-09-07 13:58:18 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-07 13:58:18 --> Helper loaded: inflector_helper
INFO - 2021-09-07 13:58:18 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-07 13:58:18 --> Database Driver Class Initialized
ERROR - 2021-09-07 13:58:18 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-07 13:58:18 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-07 13:58:18 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-07 13:58:18 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-07 13:58:18 --> Model "Student_model" initialized
ERROR - 2021-09-07 13:58:18 --> Query error: Unknown column 'e.student_id' in 'on clause' - Invalid query: SELECT `a`.*
FROM `enroll` as `a`
INNER JOIN `student` as `s` ON `e`.`student_id` = `s`.`id`
WHERE `a`.`class_id` = '1'
AND `a`.`section_id` = '1'
AND `a`.`branch_id` = '1'
ERROR - 2021-09-07 13:58:18 --> Severity: error --> Exception: Call to a member function result() on bool C:\Users\Gopal Ghimire\Desktop\New folder\school\application\controllers\api\Student.php 25
INFO - 2021-09-07 13:59:02 --> Config Class Initialized
INFO - 2021-09-07 13:59:02 --> Hooks Class Initialized
DEBUG - 2021-09-07 13:59:02 --> UTF-8 Support Enabled
INFO - 2021-09-07 13:59:02 --> Utf8 Class Initialized
INFO - 2021-09-07 13:59:02 --> URI Class Initialized
INFO - 2021-09-07 13:59:02 --> Router Class Initialized
INFO - 2021-09-07 13:59:02 --> Output Class Initialized
INFO - 2021-09-07 13:59:02 --> Security Class Initialized
DEBUG - 2021-09-07 13:59:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-07 13:59:02 --> Input Class Initialized
INFO - 2021-09-07 13:59:02 --> Language Class Initialized
INFO - 2021-09-07 13:59:02 --> Loader Class Initialized
INFO - 2021-09-07 13:59:02 --> Helper loaded: url_helper
INFO - 2021-09-07 13:59:02 --> Helper loaded: file_helper
INFO - 2021-09-07 13:59:02 --> Helper loaded: form_helper
INFO - 2021-09-07 13:59:02 --> Helper loaded: security_helper
INFO - 2021-09-07 13:59:02 --> Helper loaded: directory_helper
INFO - 2021-09-07 13:59:02 --> Helper loaded: general_helper
INFO - 2021-09-07 13:59:02 --> Database Driver Class Initialized
INFO - 2021-09-07 13:59:02 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-07 13:59:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-07 13:59:02 --> Pagination Class Initialized
INFO - 2021-09-07 13:59:02 --> XML-RPC Class Initialized
INFO - 2021-09-07 13:59:02 --> Form Validation Class Initialized
INFO - 2021-09-07 13:59:02 --> Upload Class Initialized
INFO - 2021-09-07 13:59:02 --> MY_Model class loaded
INFO - 2021-09-07 13:59:02 --> Model "Application_model" initialized
INFO - 2021-09-07 13:59:02 --> Controller Class Initialized
DEBUG - 2021-09-07 13:59:02 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-07 13:59:02 --> Helper loaded: inflector_helper
INFO - 2021-09-07 13:59:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-07 13:59:02 --> Database Driver Class Initialized
ERROR - 2021-09-07 13:59:02 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-07 13:59:02 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-07 13:59:02 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-07 13:59:02 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-07 13:59:02 --> Model "Student_model" initialized
INFO - 2021-09-07 13:59:02 --> Final output sent to browser
DEBUG - 2021-09-07 13:59:02 --> Total execution time: 0.1744
INFO - 2021-09-07 14:02:16 --> Config Class Initialized
INFO - 2021-09-07 14:02:16 --> Hooks Class Initialized
DEBUG - 2021-09-07 14:02:16 --> UTF-8 Support Enabled
INFO - 2021-09-07 14:02:16 --> Utf8 Class Initialized
INFO - 2021-09-07 14:02:16 --> URI Class Initialized
INFO - 2021-09-07 14:02:16 --> Router Class Initialized
INFO - 2021-09-07 14:02:16 --> Output Class Initialized
INFO - 2021-09-07 14:02:16 --> Security Class Initialized
DEBUG - 2021-09-07 14:02:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-07 14:02:16 --> Input Class Initialized
INFO - 2021-09-07 14:02:16 --> Language Class Initialized
INFO - 2021-09-07 14:02:16 --> Loader Class Initialized
INFO - 2021-09-07 14:02:16 --> Helper loaded: url_helper
INFO - 2021-09-07 14:02:16 --> Helper loaded: file_helper
INFO - 2021-09-07 14:02:16 --> Helper loaded: form_helper
INFO - 2021-09-07 14:02:16 --> Helper loaded: security_helper
INFO - 2021-09-07 14:02:16 --> Helper loaded: directory_helper
INFO - 2021-09-07 14:02:16 --> Helper loaded: general_helper
INFO - 2021-09-07 14:02:16 --> Database Driver Class Initialized
INFO - 2021-09-07 14:02:16 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-07 14:02:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-07 14:02:16 --> Pagination Class Initialized
INFO - 2021-09-07 14:02:16 --> XML-RPC Class Initialized
INFO - 2021-09-07 14:02:16 --> Form Validation Class Initialized
INFO - 2021-09-07 14:02:16 --> Upload Class Initialized
INFO - 2021-09-07 14:02:16 --> MY_Model class loaded
INFO - 2021-09-07 14:02:16 --> Model "Application_model" initialized
INFO - 2021-09-07 14:02:16 --> Controller Class Initialized
DEBUG - 2021-09-07 14:02:16 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-07 14:02:16 --> Helper loaded: inflector_helper
INFO - 2021-09-07 14:02:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-07 14:02:16 --> Database Driver Class Initialized
ERROR - 2021-09-07 14:02:16 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-07 14:02:16 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-07 14:02:16 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-07 14:02:16 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-07 14:02:16 --> Model "Student_model" initialized
INFO - 2021-09-07 14:02:16 --> Final output sent to browser
DEBUG - 2021-09-07 14:02:16 --> Total execution time: 0.1132
INFO - 2021-09-07 14:02:32 --> Config Class Initialized
INFO - 2021-09-07 14:02:32 --> Hooks Class Initialized
DEBUG - 2021-09-07 14:02:32 --> UTF-8 Support Enabled
INFO - 2021-09-07 14:02:32 --> Utf8 Class Initialized
INFO - 2021-09-07 14:02:32 --> URI Class Initialized
INFO - 2021-09-07 14:02:32 --> Router Class Initialized
INFO - 2021-09-07 14:02:32 --> Output Class Initialized
INFO - 2021-09-07 14:02:32 --> Security Class Initialized
DEBUG - 2021-09-07 14:02:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-07 14:02:32 --> Input Class Initialized
INFO - 2021-09-07 14:02:32 --> Language Class Initialized
INFO - 2021-09-07 14:02:32 --> Loader Class Initialized
INFO - 2021-09-07 14:02:32 --> Helper loaded: url_helper
INFO - 2021-09-07 14:02:32 --> Helper loaded: file_helper
INFO - 2021-09-07 14:02:32 --> Helper loaded: form_helper
INFO - 2021-09-07 14:02:32 --> Helper loaded: security_helper
INFO - 2021-09-07 14:02:32 --> Helper loaded: directory_helper
INFO - 2021-09-07 14:02:32 --> Helper loaded: general_helper
INFO - 2021-09-07 14:02:32 --> Database Driver Class Initialized
INFO - 2021-09-07 14:02:32 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-07 14:02:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-07 14:02:32 --> Pagination Class Initialized
INFO - 2021-09-07 14:02:32 --> XML-RPC Class Initialized
INFO - 2021-09-07 14:02:32 --> Form Validation Class Initialized
INFO - 2021-09-07 14:02:32 --> Upload Class Initialized
INFO - 2021-09-07 14:02:32 --> MY_Model class loaded
INFO - 2021-09-07 14:02:32 --> Model "Application_model" initialized
INFO - 2021-09-07 14:02:32 --> Controller Class Initialized
DEBUG - 2021-09-07 14:02:32 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-07 14:02:32 --> Helper loaded: inflector_helper
INFO - 2021-09-07 14:02:32 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-07 14:02:32 --> Database Driver Class Initialized
ERROR - 2021-09-07 14:02:32 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-07 14:02:32 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-07 14:02:32 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-07 14:02:32 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-07 14:02:32 --> Model "Student_model" initialized
INFO - 2021-09-07 14:02:32 --> Final output sent to browser
DEBUG - 2021-09-07 14:02:32 --> Total execution time: 0.0970
INFO - 2021-09-07 14:02:38 --> Config Class Initialized
INFO - 2021-09-07 14:02:38 --> Hooks Class Initialized
DEBUG - 2021-09-07 14:02:38 --> UTF-8 Support Enabled
INFO - 2021-09-07 14:02:38 --> Utf8 Class Initialized
INFO - 2021-09-07 14:02:38 --> URI Class Initialized
INFO - 2021-09-07 14:02:38 --> Router Class Initialized
INFO - 2021-09-07 14:02:38 --> Output Class Initialized
INFO - 2021-09-07 14:02:38 --> Security Class Initialized
DEBUG - 2021-09-07 14:02:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-07 14:02:38 --> Input Class Initialized
INFO - 2021-09-07 14:02:38 --> Language Class Initialized
INFO - 2021-09-07 14:02:38 --> Loader Class Initialized
INFO - 2021-09-07 14:02:38 --> Helper loaded: url_helper
INFO - 2021-09-07 14:02:38 --> Helper loaded: file_helper
INFO - 2021-09-07 14:02:38 --> Helper loaded: form_helper
INFO - 2021-09-07 14:02:38 --> Helper loaded: security_helper
INFO - 2021-09-07 14:02:38 --> Helper loaded: directory_helper
INFO - 2021-09-07 14:02:38 --> Helper loaded: general_helper
INFO - 2021-09-07 14:02:38 --> Database Driver Class Initialized
INFO - 2021-09-07 14:02:38 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-07 14:02:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-07 14:02:38 --> Pagination Class Initialized
INFO - 2021-09-07 14:02:38 --> XML-RPC Class Initialized
INFO - 2021-09-07 14:02:38 --> Form Validation Class Initialized
INFO - 2021-09-07 14:02:38 --> Upload Class Initialized
INFO - 2021-09-07 14:02:38 --> MY_Model class loaded
INFO - 2021-09-07 14:02:38 --> Model "Application_model" initialized
INFO - 2021-09-07 14:02:38 --> Controller Class Initialized
DEBUG - 2021-09-07 14:02:38 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-07 14:02:38 --> Helper loaded: inflector_helper
INFO - 2021-09-07 14:02:38 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-07 14:02:38 --> Database Driver Class Initialized
ERROR - 2021-09-07 14:02:38 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-07 14:02:38 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-07 14:02:38 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-07 14:02:38 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-07 14:02:38 --> Model "Student_model" initialized
INFO - 2021-09-07 14:02:38 --> Final output sent to browser
DEBUG - 2021-09-07 14:02:38 --> Total execution time: 0.1151
INFO - 2021-09-07 14:04:03 --> Config Class Initialized
INFO - 2021-09-07 14:04:03 --> Hooks Class Initialized
DEBUG - 2021-09-07 14:04:03 --> UTF-8 Support Enabled
INFO - 2021-09-07 14:04:03 --> Utf8 Class Initialized
INFO - 2021-09-07 14:04:03 --> URI Class Initialized
INFO - 2021-09-07 14:04:03 --> Router Class Initialized
INFO - 2021-09-07 14:04:03 --> Output Class Initialized
INFO - 2021-09-07 14:04:03 --> Security Class Initialized
DEBUG - 2021-09-07 14:04:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-07 14:04:03 --> Input Class Initialized
INFO - 2021-09-07 14:04:03 --> Language Class Initialized
INFO - 2021-09-07 14:04:03 --> Loader Class Initialized
INFO - 2021-09-07 14:04:03 --> Helper loaded: url_helper
INFO - 2021-09-07 14:04:03 --> Helper loaded: file_helper
INFO - 2021-09-07 14:04:03 --> Helper loaded: form_helper
INFO - 2021-09-07 14:04:03 --> Helper loaded: security_helper
INFO - 2021-09-07 14:04:03 --> Helper loaded: directory_helper
INFO - 2021-09-07 14:04:03 --> Helper loaded: general_helper
INFO - 2021-09-07 14:04:03 --> Database Driver Class Initialized
INFO - 2021-09-07 14:04:03 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-07 14:04:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-07 14:04:03 --> Pagination Class Initialized
INFO - 2021-09-07 14:04:03 --> XML-RPC Class Initialized
INFO - 2021-09-07 14:04:03 --> Form Validation Class Initialized
INFO - 2021-09-07 14:04:03 --> Upload Class Initialized
INFO - 2021-09-07 14:04:03 --> MY_Model class loaded
INFO - 2021-09-07 14:04:03 --> Model "Application_model" initialized
INFO - 2021-09-07 14:04:03 --> Controller Class Initialized
DEBUG - 2021-09-07 14:04:03 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-07 14:04:03 --> Helper loaded: inflector_helper
INFO - 2021-09-07 14:04:03 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-07 14:04:03 --> Database Driver Class Initialized
ERROR - 2021-09-07 14:04:03 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-07 14:04:03 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-07 14:04:03 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-07 14:04:03 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-07 14:04:03 --> Model "Student_model" initialized
INFO - 2021-09-07 14:04:03 --> Final output sent to browser
DEBUG - 2021-09-07 14:04:03 --> Total execution time: 0.2885
INFO - 2021-09-07 14:04:08 --> Config Class Initialized
INFO - 2021-09-07 14:04:08 --> Hooks Class Initialized
DEBUG - 2021-09-07 14:04:08 --> UTF-8 Support Enabled
INFO - 2021-09-07 14:04:08 --> Utf8 Class Initialized
INFO - 2021-09-07 14:04:08 --> URI Class Initialized
INFO - 2021-09-07 14:04:08 --> Router Class Initialized
INFO - 2021-09-07 14:04:08 --> Output Class Initialized
INFO - 2021-09-07 14:04:08 --> Security Class Initialized
DEBUG - 2021-09-07 14:04:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-07 14:04:08 --> Input Class Initialized
INFO - 2021-09-07 14:04:08 --> Language Class Initialized
INFO - 2021-09-07 14:04:08 --> Loader Class Initialized
INFO - 2021-09-07 14:04:09 --> Helper loaded: url_helper
INFO - 2021-09-07 14:04:09 --> Helper loaded: file_helper
INFO - 2021-09-07 14:04:09 --> Helper loaded: form_helper
INFO - 2021-09-07 14:04:09 --> Helper loaded: security_helper
INFO - 2021-09-07 14:04:09 --> Helper loaded: directory_helper
INFO - 2021-09-07 14:04:09 --> Helper loaded: general_helper
INFO - 2021-09-07 14:04:09 --> Database Driver Class Initialized
INFO - 2021-09-07 14:04:09 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-07 14:04:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-07 14:04:09 --> Pagination Class Initialized
INFO - 2021-09-07 14:04:09 --> XML-RPC Class Initialized
INFO - 2021-09-07 14:04:09 --> Form Validation Class Initialized
INFO - 2021-09-07 14:04:09 --> Upload Class Initialized
INFO - 2021-09-07 14:04:09 --> MY_Model class loaded
INFO - 2021-09-07 14:04:09 --> Model "Application_model" initialized
INFO - 2021-09-07 14:04:09 --> Controller Class Initialized
DEBUG - 2021-09-07 14:04:09 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-07 14:04:09 --> Helper loaded: inflector_helper
INFO - 2021-09-07 14:04:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-07 14:04:09 --> Database Driver Class Initialized
ERROR - 2021-09-07 14:04:09 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-07 14:04:09 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-07 14:04:09 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-07 14:04:09 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-07 14:04:09 --> Model "Student_model" initialized
INFO - 2021-09-07 14:04:09 --> Final output sent to browser
DEBUG - 2021-09-07 14:04:09 --> Total execution time: 0.2645
INFO - 2021-09-07 14:10:30 --> Config Class Initialized
INFO - 2021-09-07 14:10:30 --> Hooks Class Initialized
DEBUG - 2021-09-07 14:10:30 --> UTF-8 Support Enabled
INFO - 2021-09-07 14:10:30 --> Utf8 Class Initialized
INFO - 2021-09-07 14:10:30 --> URI Class Initialized
INFO - 2021-09-07 14:10:30 --> Router Class Initialized
INFO - 2021-09-07 14:10:30 --> Output Class Initialized
INFO - 2021-09-07 14:10:30 --> Security Class Initialized
DEBUG - 2021-09-07 14:10:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-07 14:10:30 --> CSRF cookie sent
INFO - 2021-09-07 14:10:30 --> Input Class Initialized
INFO - 2021-09-07 14:10:30 --> Language Class Initialized
INFO - 2021-09-07 14:10:30 --> Loader Class Initialized
INFO - 2021-09-07 14:10:30 --> Helper loaded: url_helper
INFO - 2021-09-07 14:10:30 --> Helper loaded: file_helper
INFO - 2021-09-07 14:10:30 --> Helper loaded: form_helper
INFO - 2021-09-07 14:10:30 --> Helper loaded: security_helper
INFO - 2021-09-07 14:10:30 --> Helper loaded: directory_helper
INFO - 2021-09-07 14:10:30 --> Helper loaded: general_helper
INFO - 2021-09-07 14:10:30 --> Database Driver Class Initialized
INFO - 2021-09-07 14:10:30 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-07 14:10:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-07 14:10:30 --> Pagination Class Initialized
INFO - 2021-09-07 14:10:30 --> XML-RPC Class Initialized
INFO - 2021-09-07 14:10:30 --> Form Validation Class Initialized
INFO - 2021-09-07 14:10:30 --> Upload Class Initialized
INFO - 2021-09-07 14:10:30 --> MY_Model class loaded
INFO - 2021-09-07 14:10:30 --> Model "Application_model" initialized
INFO - 2021-09-07 14:10:30 --> Controller Class Initialized
INFO - 2021-09-07 14:10:31 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\errors/error_404_message.php
INFO - 2021-09-07 14:10:31 --> Final output sent to browser
DEBUG - 2021-09-07 14:10:31 --> Total execution time: 0.7298
INFO - 2021-09-07 14:11:24 --> Config Class Initialized
INFO - 2021-09-07 14:11:24 --> Hooks Class Initialized
DEBUG - 2021-09-07 14:11:24 --> UTF-8 Support Enabled
INFO - 2021-09-07 14:11:24 --> Utf8 Class Initialized
INFO - 2021-09-07 14:11:24 --> URI Class Initialized
INFO - 2021-09-07 14:11:24 --> Router Class Initialized
INFO - 2021-09-07 14:11:24 --> Output Class Initialized
INFO - 2021-09-07 14:11:24 --> Security Class Initialized
DEBUG - 2021-09-07 14:11:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-07 14:11:24 --> CSRF cookie sent
INFO - 2021-09-07 14:11:24 --> Input Class Initialized
INFO - 2021-09-07 14:11:24 --> Language Class Initialized
INFO - 2021-09-07 14:11:24 --> Loader Class Initialized
INFO - 2021-09-07 14:11:24 --> Helper loaded: url_helper
INFO - 2021-09-07 14:11:24 --> Helper loaded: file_helper
INFO - 2021-09-07 14:11:24 --> Helper loaded: form_helper
INFO - 2021-09-07 14:11:24 --> Helper loaded: security_helper
INFO - 2021-09-07 14:11:24 --> Helper loaded: directory_helper
INFO - 2021-09-07 14:11:24 --> Helper loaded: general_helper
INFO - 2021-09-07 14:11:24 --> Database Driver Class Initialized
INFO - 2021-09-07 14:11:24 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-07 14:11:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-07 14:11:24 --> Pagination Class Initialized
INFO - 2021-09-07 14:11:24 --> XML-RPC Class Initialized
INFO - 2021-09-07 14:11:24 --> Form Validation Class Initialized
INFO - 2021-09-07 14:11:24 --> Upload Class Initialized
INFO - 2021-09-07 14:11:24 --> MY_Model class loaded
INFO - 2021-09-07 14:11:24 --> Model "Application_model" initialized
INFO - 2021-09-07 14:11:24 --> Controller Class Initialized
DEBUG - 2021-09-07 14:11:24 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-07 14:11:24 --> Helper loaded: inflector_helper
INFO - 2021-09-07 14:11:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-07 14:11:24 --> Database Driver Class Initialized
ERROR - 2021-09-07 14:11:24 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-07 14:11:24 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-07 14:11:24 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-07 14:11:24 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-07 14:11:24 --> Model "Student_model" initialized
INFO - 2021-09-07 14:11:24 --> Final output sent to browser
DEBUG - 2021-09-07 14:11:24 --> Total execution time: 0.1788
INFO - 2021-09-07 14:12:20 --> Config Class Initialized
INFO - 2021-09-07 14:12:20 --> Hooks Class Initialized
DEBUG - 2021-09-07 14:12:20 --> UTF-8 Support Enabled
INFO - 2021-09-07 14:12:20 --> Utf8 Class Initialized
INFO - 2021-09-07 14:12:20 --> URI Class Initialized
INFO - 2021-09-07 14:12:20 --> Router Class Initialized
INFO - 2021-09-07 14:12:20 --> Output Class Initialized
INFO - 2021-09-07 14:12:20 --> Security Class Initialized
DEBUG - 2021-09-07 14:12:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-07 14:12:20 --> CSRF cookie sent
INFO - 2021-09-07 14:12:20 --> Input Class Initialized
INFO - 2021-09-07 14:12:20 --> Language Class Initialized
INFO - 2021-09-07 14:12:20 --> Loader Class Initialized
INFO - 2021-09-07 14:12:20 --> Helper loaded: url_helper
INFO - 2021-09-07 14:12:20 --> Helper loaded: file_helper
INFO - 2021-09-07 14:12:20 --> Helper loaded: form_helper
INFO - 2021-09-07 14:12:20 --> Helper loaded: security_helper
INFO - 2021-09-07 14:12:20 --> Helper loaded: directory_helper
INFO - 2021-09-07 14:12:20 --> Helper loaded: general_helper
INFO - 2021-09-07 14:12:20 --> Database Driver Class Initialized
INFO - 2021-09-07 14:12:21 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-07 14:12:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-07 14:12:21 --> Pagination Class Initialized
INFO - 2021-09-07 14:12:21 --> XML-RPC Class Initialized
INFO - 2021-09-07 14:12:21 --> Form Validation Class Initialized
INFO - 2021-09-07 14:12:21 --> Upload Class Initialized
INFO - 2021-09-07 14:12:21 --> MY_Model class loaded
INFO - 2021-09-07 14:12:21 --> Model "Application_model" initialized
INFO - 2021-09-07 14:12:21 --> Controller Class Initialized
DEBUG - 2021-09-07 14:12:21 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-07 14:12:21 --> Helper loaded: inflector_helper
INFO - 2021-09-07 14:12:21 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-07 14:12:21 --> Database Driver Class Initialized
ERROR - 2021-09-07 14:12:21 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-07 14:12:21 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-07 14:12:21 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-07 14:12:21 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-07 14:12:21 --> Model "Student_model" initialized
INFO - 2021-09-07 14:12:21 --> Final output sent to browser
DEBUG - 2021-09-07 14:12:21 --> Total execution time: 0.1376
INFO - 2021-09-07 14:15:43 --> Config Class Initialized
INFO - 2021-09-07 14:15:43 --> Hooks Class Initialized
DEBUG - 2021-09-07 14:15:43 --> UTF-8 Support Enabled
INFO - 2021-09-07 14:15:43 --> Utf8 Class Initialized
INFO - 2021-09-07 14:15:43 --> URI Class Initialized
INFO - 2021-09-07 14:15:43 --> Router Class Initialized
INFO - 2021-09-07 14:15:43 --> Output Class Initialized
INFO - 2021-09-07 14:15:43 --> Security Class Initialized
DEBUG - 2021-09-07 14:15:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-07 14:15:43 --> CSRF cookie sent
INFO - 2021-09-07 14:15:43 --> Input Class Initialized
INFO - 2021-09-07 14:15:43 --> Language Class Initialized
INFO - 2021-09-07 14:15:43 --> Loader Class Initialized
INFO - 2021-09-07 14:15:43 --> Helper loaded: url_helper
INFO - 2021-09-07 14:15:43 --> Helper loaded: file_helper
INFO - 2021-09-07 14:15:43 --> Helper loaded: form_helper
INFO - 2021-09-07 14:15:43 --> Helper loaded: security_helper
INFO - 2021-09-07 14:15:43 --> Helper loaded: directory_helper
INFO - 2021-09-07 14:15:43 --> Helper loaded: general_helper
INFO - 2021-09-07 14:15:43 --> Database Driver Class Initialized
INFO - 2021-09-07 14:15:43 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-07 14:15:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-07 14:15:43 --> Pagination Class Initialized
INFO - 2021-09-07 14:15:43 --> XML-RPC Class Initialized
INFO - 2021-09-07 14:15:43 --> Form Validation Class Initialized
INFO - 2021-09-07 14:15:43 --> Upload Class Initialized
INFO - 2021-09-07 14:15:43 --> MY_Model class loaded
INFO - 2021-09-07 14:15:43 --> Model "Application_model" initialized
INFO - 2021-09-07 14:15:43 --> Controller Class Initialized
DEBUG - 2021-09-07 14:15:43 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-07 14:15:43 --> Helper loaded: inflector_helper
INFO - 2021-09-07 14:15:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-07 14:15:43 --> Database Driver Class Initialized
ERROR - 2021-09-07 14:15:43 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-07 14:15:43 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-07 14:15:43 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-07 14:15:43 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-07 14:15:43 --> Model "Branch_model" initialized
INFO - 2021-09-07 14:15:43 --> Final output sent to browser
DEBUG - 2021-09-07 14:15:43 --> Total execution time: 0.3543
INFO - 2021-09-07 14:17:18 --> Config Class Initialized
INFO - 2021-09-07 14:17:18 --> Hooks Class Initialized
DEBUG - 2021-09-07 14:17:18 --> UTF-8 Support Enabled
INFO - 2021-09-07 14:17:18 --> Utf8 Class Initialized
INFO - 2021-09-07 14:17:18 --> URI Class Initialized
INFO - 2021-09-07 14:17:18 --> Router Class Initialized
INFO - 2021-09-07 14:17:18 --> Output Class Initialized
INFO - 2021-09-07 14:17:18 --> Security Class Initialized
DEBUG - 2021-09-07 14:17:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-07 14:17:18 --> CSRF cookie sent
INFO - 2021-09-07 14:17:18 --> Input Class Initialized
INFO - 2021-09-07 14:17:18 --> Language Class Initialized
INFO - 2021-09-07 14:17:18 --> Loader Class Initialized
INFO - 2021-09-07 14:17:18 --> Helper loaded: url_helper
INFO - 2021-09-07 14:17:18 --> Helper loaded: file_helper
INFO - 2021-09-07 14:17:18 --> Helper loaded: form_helper
INFO - 2021-09-07 14:17:18 --> Helper loaded: security_helper
INFO - 2021-09-07 14:17:18 --> Helper loaded: directory_helper
INFO - 2021-09-07 14:17:18 --> Helper loaded: general_helper
INFO - 2021-09-07 14:17:18 --> Database Driver Class Initialized
INFO - 2021-09-07 14:17:18 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-07 14:17:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-07 14:17:18 --> Pagination Class Initialized
INFO - 2021-09-07 14:17:18 --> XML-RPC Class Initialized
INFO - 2021-09-07 14:17:18 --> Form Validation Class Initialized
INFO - 2021-09-07 14:17:18 --> Upload Class Initialized
INFO - 2021-09-07 14:17:18 --> MY_Model class loaded
INFO - 2021-09-07 14:17:18 --> Model "Application_model" initialized
INFO - 2021-09-07 14:17:18 --> Controller Class Initialized
DEBUG - 2021-09-07 14:17:18 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-07 14:17:18 --> Helper loaded: inflector_helper
INFO - 2021-09-07 14:17:18 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-07 14:17:18 --> Database Driver Class Initialized
ERROR - 2021-09-07 14:17:18 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-07 14:17:18 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-07 14:17:18 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-07 14:17:18 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-07 14:17:19 --> Final output sent to browser
DEBUG - 2021-09-07 14:17:19 --> Total execution time: 0.1427
INFO - 2021-09-07 14:18:33 --> Config Class Initialized
INFO - 2021-09-07 14:18:33 --> Hooks Class Initialized
DEBUG - 2021-09-07 14:18:33 --> UTF-8 Support Enabled
INFO - 2021-09-07 14:18:33 --> Utf8 Class Initialized
INFO - 2021-09-07 14:18:33 --> URI Class Initialized
INFO - 2021-09-07 14:18:33 --> Router Class Initialized
INFO - 2021-09-07 14:18:33 --> Output Class Initialized
INFO - 2021-09-07 14:18:33 --> Security Class Initialized
DEBUG - 2021-09-07 14:18:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-07 14:18:33 --> CSRF cookie sent
INFO - 2021-09-07 14:18:33 --> Input Class Initialized
INFO - 2021-09-07 14:18:33 --> Language Class Initialized
INFO - 2021-09-07 14:18:33 --> Loader Class Initialized
INFO - 2021-09-07 14:18:33 --> Helper loaded: url_helper
INFO - 2021-09-07 14:18:33 --> Helper loaded: file_helper
INFO - 2021-09-07 14:18:33 --> Helper loaded: form_helper
INFO - 2021-09-07 14:18:33 --> Helper loaded: security_helper
INFO - 2021-09-07 14:18:33 --> Helper loaded: directory_helper
INFO - 2021-09-07 14:18:33 --> Helper loaded: general_helper
INFO - 2021-09-07 14:18:33 --> Database Driver Class Initialized
INFO - 2021-09-07 14:18:33 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-07 14:18:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-07 14:18:33 --> Pagination Class Initialized
INFO - 2021-09-07 14:18:33 --> XML-RPC Class Initialized
INFO - 2021-09-07 14:18:33 --> Form Validation Class Initialized
INFO - 2021-09-07 14:18:33 --> Upload Class Initialized
INFO - 2021-09-07 14:18:33 --> MY_Model class loaded
INFO - 2021-09-07 14:18:33 --> Model "Application_model" initialized
INFO - 2021-09-07 14:18:33 --> Controller Class Initialized
DEBUG - 2021-09-07 14:18:33 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-07 14:18:33 --> Helper loaded: inflector_helper
INFO - 2021-09-07 14:18:33 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-07 14:18:33 --> Database Driver Class Initialized
ERROR - 2021-09-07 14:18:33 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-07 14:18:33 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-07 14:18:33 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-07 14:18:33 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-07 14:18:33 --> Final output sent to browser
DEBUG - 2021-09-07 14:18:33 --> Total execution time: 0.1440
