<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-09-09 09:20:13 --> Config Class Initialized
INFO - 2021-09-09 09:20:13 --> Hooks Class Initialized
DEBUG - 2021-09-09 09:20:13 --> UTF-8 Support Enabled
INFO - 2021-09-09 09:20:13 --> Utf8 Class Initialized
INFO - 2021-09-09 09:20:13 --> URI Class Initialized
DEBUG - 2021-09-09 09:20:13 --> No URI present. Default controller set.
INFO - 2021-09-09 09:20:13 --> Router Class Initialized
INFO - 2021-09-09 09:20:13 --> Output Class Initialized
INFO - 2021-09-09 09:20:13 --> Security Class Initialized
DEBUG - 2021-09-09 09:20:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 09:20:13 --> CSRF cookie sent
INFO - 2021-09-09 09:20:13 --> Input Class Initialized
INFO - 2021-09-09 09:20:13 --> Language Class Initialized
INFO - 2021-09-09 09:20:13 --> Loader Class Initialized
INFO - 2021-09-09 09:20:13 --> Helper loaded: url_helper
INFO - 2021-09-09 09:20:13 --> Helper loaded: file_helper
INFO - 2021-09-09 09:20:13 --> Helper loaded: form_helper
INFO - 2021-09-09 09:20:13 --> Helper loaded: security_helper
INFO - 2021-09-09 09:20:13 --> Helper loaded: directory_helper
INFO - 2021-09-09 09:20:13 --> Helper loaded: general_helper
INFO - 2021-09-09 09:20:13 --> Database Driver Class Initialized
INFO - 2021-09-09 09:20:16 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 09:20:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 09:20:17 --> Pagination Class Initialized
INFO - 2021-09-09 09:20:17 --> XML-RPC Class Initialized
INFO - 2021-09-09 09:20:17 --> Form Validation Class Initialized
INFO - 2021-09-09 09:20:17 --> Upload Class Initialized
INFO - 2021-09-09 09:20:17 --> MY_Model class loaded
INFO - 2021-09-09 09:20:17 --> Model "Application_model" initialized
INFO - 2021-09-09 09:20:17 --> Controller Class Initialized
INFO - 2021-09-09 13:05:17 --> Model "Home_model" initialized
INFO - 2021-09-09 09:20:18 --> Config Class Initialized
INFO - 2021-09-09 09:20:18 --> Hooks Class Initialized
DEBUG - 2021-09-09 09:20:18 --> UTF-8 Support Enabled
INFO - 2021-09-09 09:20:18 --> Utf8 Class Initialized
INFO - 2021-09-09 09:20:18 --> URI Class Initialized
INFO - 2021-09-09 09:20:18 --> Router Class Initialized
INFO - 2021-09-09 09:20:18 --> Output Class Initialized
INFO - 2021-09-09 09:20:18 --> Security Class Initialized
DEBUG - 2021-09-09 09:20:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 09:20:18 --> CSRF cookie sent
INFO - 2021-09-09 09:20:18 --> Input Class Initialized
INFO - 2021-09-09 09:20:18 --> Language Class Initialized
INFO - 2021-09-09 09:20:18 --> Loader Class Initialized
INFO - 2021-09-09 09:20:18 --> Helper loaded: url_helper
INFO - 2021-09-09 09:20:18 --> Helper loaded: file_helper
INFO - 2021-09-09 09:20:18 --> Helper loaded: form_helper
INFO - 2021-09-09 09:20:18 --> Helper loaded: security_helper
INFO - 2021-09-09 09:20:18 --> Helper loaded: directory_helper
INFO - 2021-09-09 09:20:18 --> Helper loaded: general_helper
INFO - 2021-09-09 09:20:18 --> Database Driver Class Initialized
INFO - 2021-09-09 09:20:18 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 09:20:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 09:20:18 --> Pagination Class Initialized
INFO - 2021-09-09 09:20:18 --> XML-RPC Class Initialized
INFO - 2021-09-09 09:20:18 --> Form Validation Class Initialized
INFO - 2021-09-09 09:20:18 --> Upload Class Initialized
INFO - 2021-09-09 09:20:18 --> MY_Model class loaded
INFO - 2021-09-09 09:20:18 --> Model "Application_model" initialized
INFO - 2021-09-09 09:20:18 --> Controller Class Initialized
INFO - 2021-09-09 13:05:18 --> Model "Authentication_model" initialized
INFO - 2021-09-09 13:05:18 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\authentication/login.php
INFO - 2021-09-09 13:05:18 --> Final output sent to browser
DEBUG - 2021-09-09 13:05:18 --> Total execution time: 0.5613
INFO - 2021-09-09 09:22:46 --> Config Class Initialized
INFO - 2021-09-09 09:22:46 --> Hooks Class Initialized
DEBUG - 2021-09-09 09:22:46 --> UTF-8 Support Enabled
INFO - 2021-09-09 09:22:46 --> Utf8 Class Initialized
INFO - 2021-09-09 09:22:46 --> URI Class Initialized
INFO - 2021-09-09 09:22:46 --> Router Class Initialized
INFO - 2021-09-09 09:22:46 --> Output Class Initialized
INFO - 2021-09-09 09:22:46 --> Security Class Initialized
DEBUG - 2021-09-09 09:22:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 09:22:46 --> CSRF cookie sent
INFO - 2021-09-09 09:22:46 --> CSRF token verified
INFO - 2021-09-09 09:22:46 --> Input Class Initialized
INFO - 2021-09-09 09:22:46 --> Language Class Initialized
INFO - 2021-09-09 09:22:46 --> Loader Class Initialized
INFO - 2021-09-09 09:22:46 --> Helper loaded: url_helper
INFO - 2021-09-09 09:22:46 --> Helper loaded: file_helper
INFO - 2021-09-09 09:22:46 --> Helper loaded: form_helper
INFO - 2021-09-09 09:22:46 --> Helper loaded: security_helper
INFO - 2021-09-09 09:22:46 --> Helper loaded: directory_helper
INFO - 2021-09-09 09:22:46 --> Helper loaded: general_helper
INFO - 2021-09-09 09:22:46 --> Database Driver Class Initialized
INFO - 2021-09-09 09:22:46 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 09:22:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 09:22:46 --> Pagination Class Initialized
INFO - 2021-09-09 09:22:46 --> XML-RPC Class Initialized
INFO - 2021-09-09 09:22:46 --> Form Validation Class Initialized
INFO - 2021-09-09 09:22:46 --> Upload Class Initialized
INFO - 2021-09-09 09:22:46 --> MY_Model class loaded
INFO - 2021-09-09 09:22:46 --> Model "Application_model" initialized
INFO - 2021-09-09 09:22:46 --> Controller Class Initialized
INFO - 2021-09-09 13:07:46 --> Model "Authentication_model" initialized
INFO - 2021-09-09 13:07:46 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-09-09 09:22:47 --> Config Class Initialized
INFO - 2021-09-09 09:22:47 --> Hooks Class Initialized
DEBUG - 2021-09-09 09:22:47 --> UTF-8 Support Enabled
INFO - 2021-09-09 09:22:47 --> Utf8 Class Initialized
INFO - 2021-09-09 09:22:47 --> URI Class Initialized
INFO - 2021-09-09 09:22:47 --> Router Class Initialized
INFO - 2021-09-09 09:22:47 --> Output Class Initialized
INFO - 2021-09-09 09:22:47 --> Security Class Initialized
DEBUG - 2021-09-09 09:22:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 09:22:47 --> CSRF cookie sent
INFO - 2021-09-09 09:22:47 --> Input Class Initialized
INFO - 2021-09-09 09:22:47 --> Language Class Initialized
INFO - 2021-09-09 09:22:47 --> Loader Class Initialized
INFO - 2021-09-09 09:22:47 --> Helper loaded: url_helper
INFO - 2021-09-09 09:22:47 --> Helper loaded: file_helper
INFO - 2021-09-09 09:22:47 --> Helper loaded: form_helper
INFO - 2021-09-09 09:22:47 --> Helper loaded: security_helper
INFO - 2021-09-09 09:22:47 --> Helper loaded: directory_helper
INFO - 2021-09-09 09:22:47 --> Helper loaded: general_helper
INFO - 2021-09-09 09:22:47 --> Database Driver Class Initialized
INFO - 2021-09-09 09:22:47 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 09:22:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 09:22:47 --> Pagination Class Initialized
INFO - 2021-09-09 09:22:47 --> XML-RPC Class Initialized
INFO - 2021-09-09 09:22:47 --> Form Validation Class Initialized
INFO - 2021-09-09 09:22:47 --> Upload Class Initialized
INFO - 2021-09-09 09:22:47 --> MY_Model class loaded
INFO - 2021-09-09 09:22:47 --> Model "Application_model" initialized
INFO - 2021-09-09 09:22:47 --> Controller Class Initialized
INFO - 2021-09-09 13:07:47 --> Model "Dashboard_model" initialized
INFO - 2021-09-09 13:07:48 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/header.php
INFO - 2021-09-09 13:07:48 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/topbar.php
INFO - 2021-09-09 13:07:49 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/sidebar.php
INFO - 2021-09-09 13:07:49 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\dashboard/index.php
INFO - 2021-09-09 13:07:49 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/script.php
INFO - 2021-09-09 13:07:49 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/index.php
INFO - 2021-09-09 13:07:49 --> Final output sent to browser
DEBUG - 2021-09-09 13:07:49 --> Total execution time: 1.9492
INFO - 2021-09-09 09:40:08 --> Config Class Initialized
INFO - 2021-09-09 09:40:08 --> Hooks Class Initialized
DEBUG - 2021-09-09 09:40:08 --> UTF-8 Support Enabled
INFO - 2021-09-09 09:40:08 --> Utf8 Class Initialized
INFO - 2021-09-09 09:40:08 --> URI Class Initialized
INFO - 2021-09-09 09:40:08 --> Router Class Initialized
INFO - 2021-09-09 09:40:08 --> Output Class Initialized
INFO - 2021-09-09 09:40:08 --> Security Class Initialized
DEBUG - 2021-09-09 09:40:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 09:40:08 --> Input Class Initialized
INFO - 2021-09-09 09:40:08 --> Language Class Initialized
INFO - 2021-09-09 09:40:08 --> Loader Class Initialized
INFO - 2021-09-09 09:40:08 --> Helper loaded: url_helper
INFO - 2021-09-09 09:40:08 --> Helper loaded: file_helper
INFO - 2021-09-09 09:40:08 --> Helper loaded: form_helper
INFO - 2021-09-09 09:40:08 --> Helper loaded: security_helper
INFO - 2021-09-09 09:40:08 --> Helper loaded: directory_helper
INFO - 2021-09-09 09:40:09 --> Helper loaded: general_helper
INFO - 2021-09-09 09:40:09 --> Database Driver Class Initialized
INFO - 2021-09-09 09:40:09 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 09:40:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 09:40:09 --> Pagination Class Initialized
INFO - 2021-09-09 09:40:09 --> XML-RPC Class Initialized
INFO - 2021-09-09 09:40:09 --> Form Validation Class Initialized
INFO - 2021-09-09 09:40:09 --> Upload Class Initialized
INFO - 2021-09-09 09:40:09 --> MY_Model class loaded
INFO - 2021-09-09 09:40:09 --> Model "Application_model" initialized
INFO - 2021-09-09 09:40:09 --> Controller Class Initialized
DEBUG - 2021-09-09 09:40:09 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-09 09:40:09 --> Helper loaded: inflector_helper
INFO - 2021-09-09 09:40:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-09 09:40:09 --> Database Driver Class Initialized
ERROR - 2021-09-09 09:40:09 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 09:40:09 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 09:40:09 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-09 09:40:09 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-09 09:40:10 --> Model "Sms_model" initialized
INFO - 2021-09-09 09:40:10 --> Model "Fees_model" initialized
ERROR - 2021-09-09 09:40:10 --> Severity: Warning --> call_user_func_array() expects parameter 1 to be a valid callback, class 'Fees' does not have a method 'index_post' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 742
INFO - 2021-09-09 09:40:10 --> Final output sent to browser
DEBUG - 2021-09-09 09:40:10 --> Total execution time: 2.0313
INFO - 2021-09-09 09:40:52 --> Config Class Initialized
INFO - 2021-09-09 09:40:52 --> Hooks Class Initialized
DEBUG - 2021-09-09 09:40:52 --> UTF-8 Support Enabled
INFO - 2021-09-09 09:40:52 --> Utf8 Class Initialized
INFO - 2021-09-09 09:40:52 --> URI Class Initialized
INFO - 2021-09-09 09:40:52 --> Router Class Initialized
INFO - 2021-09-09 09:40:52 --> Output Class Initialized
INFO - 2021-09-09 09:40:52 --> Security Class Initialized
DEBUG - 2021-09-09 09:40:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 09:40:52 --> Input Class Initialized
INFO - 2021-09-09 09:40:52 --> Language Class Initialized
INFO - 2021-09-09 09:40:52 --> Loader Class Initialized
INFO - 2021-09-09 09:40:52 --> Helper loaded: url_helper
INFO - 2021-09-09 09:40:52 --> Helper loaded: file_helper
INFO - 2021-09-09 09:40:52 --> Helper loaded: form_helper
INFO - 2021-09-09 09:40:52 --> Helper loaded: security_helper
INFO - 2021-09-09 09:40:52 --> Helper loaded: directory_helper
INFO - 2021-09-09 09:40:52 --> Helper loaded: general_helper
INFO - 2021-09-09 09:40:52 --> Database Driver Class Initialized
INFO - 2021-09-09 09:40:52 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 09:40:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 09:40:52 --> Pagination Class Initialized
INFO - 2021-09-09 09:40:52 --> XML-RPC Class Initialized
INFO - 2021-09-09 09:40:52 --> Form Validation Class Initialized
INFO - 2021-09-09 09:40:52 --> Upload Class Initialized
INFO - 2021-09-09 09:40:52 --> MY_Model class loaded
INFO - 2021-09-09 09:40:52 --> Model "Application_model" initialized
INFO - 2021-09-09 09:40:52 --> Controller Class Initialized
DEBUG - 2021-09-09 09:40:52 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-09 09:40:52 --> Helper loaded: inflector_helper
INFO - 2021-09-09 09:40:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-09 09:40:52 --> Database Driver Class Initialized
ERROR - 2021-09-09 09:40:52 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 09:40:52 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 09:40:52 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-09 09:40:52 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-09 09:40:52 --> Model "Sms_model" initialized
INFO - 2021-09-09 09:40:52 --> Model "Fees_model" initialized
ERROR - 2021-09-09 09:40:52 --> Severity: Warning --> call_user_func_array() expects parameter 1 to be a valid callback, class 'Fees' does not have a method 'index_post' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 742
INFO - 2021-09-09 09:40:52 --> Final output sent to browser
DEBUG - 2021-09-09 09:40:52 --> Total execution time: 0.1251
INFO - 2021-09-09 09:41:19 --> Config Class Initialized
INFO - 2021-09-09 09:41:19 --> Hooks Class Initialized
DEBUG - 2021-09-09 09:41:19 --> UTF-8 Support Enabled
INFO - 2021-09-09 09:41:19 --> Utf8 Class Initialized
INFO - 2021-09-09 09:41:19 --> URI Class Initialized
INFO - 2021-09-09 09:41:19 --> Router Class Initialized
INFO - 2021-09-09 09:41:19 --> Output Class Initialized
INFO - 2021-09-09 09:41:19 --> Security Class Initialized
DEBUG - 2021-09-09 09:41:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 09:41:19 --> Input Class Initialized
INFO - 2021-09-09 09:41:19 --> Language Class Initialized
INFO - 2021-09-09 09:41:19 --> Loader Class Initialized
INFO - 2021-09-09 09:41:19 --> Helper loaded: url_helper
INFO - 2021-09-09 09:41:19 --> Helper loaded: file_helper
INFO - 2021-09-09 09:41:19 --> Helper loaded: form_helper
INFO - 2021-09-09 09:41:19 --> Helper loaded: security_helper
INFO - 2021-09-09 09:41:19 --> Helper loaded: directory_helper
INFO - 2021-09-09 09:41:19 --> Helper loaded: general_helper
INFO - 2021-09-09 09:41:19 --> Database Driver Class Initialized
INFO - 2021-09-09 09:41:19 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 09:41:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 09:41:19 --> Pagination Class Initialized
INFO - 2021-09-09 09:41:19 --> XML-RPC Class Initialized
INFO - 2021-09-09 09:41:19 --> Form Validation Class Initialized
INFO - 2021-09-09 09:41:19 --> Upload Class Initialized
INFO - 2021-09-09 09:41:19 --> MY_Model class loaded
INFO - 2021-09-09 09:41:19 --> Model "Application_model" initialized
INFO - 2021-09-09 09:41:19 --> Controller Class Initialized
DEBUG - 2021-09-09 09:41:19 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-09 09:41:19 --> Helper loaded: inflector_helper
INFO - 2021-09-09 09:41:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-09 09:41:19 --> Database Driver Class Initialized
ERROR - 2021-09-09 09:41:19 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 09:41:19 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 09:41:19 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-09 09:41:19 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-09 09:41:19 --> Model "Sms_model" initialized
INFO - 2021-09-09 09:41:19 --> Model "Fees_model" initialized
INFO - 2021-09-09 09:41:19 --> Final output sent to browser
DEBUG - 2021-09-09 09:41:19 --> Total execution time: 0.1375
INFO - 2021-09-09 09:41:47 --> Config Class Initialized
INFO - 2021-09-09 09:41:47 --> Hooks Class Initialized
DEBUG - 2021-09-09 09:41:47 --> UTF-8 Support Enabled
INFO - 2021-09-09 09:41:47 --> Utf8 Class Initialized
INFO - 2021-09-09 09:41:47 --> URI Class Initialized
INFO - 2021-09-09 09:41:47 --> Router Class Initialized
INFO - 2021-09-09 09:41:47 --> Output Class Initialized
INFO - 2021-09-09 09:41:47 --> Security Class Initialized
DEBUG - 2021-09-09 09:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 09:41:47 --> Input Class Initialized
INFO - 2021-09-09 09:41:47 --> Language Class Initialized
INFO - 2021-09-09 09:41:47 --> Loader Class Initialized
INFO - 2021-09-09 09:41:47 --> Helper loaded: url_helper
INFO - 2021-09-09 09:41:47 --> Helper loaded: file_helper
INFO - 2021-09-09 09:41:47 --> Helper loaded: form_helper
INFO - 2021-09-09 09:41:47 --> Helper loaded: security_helper
INFO - 2021-09-09 09:41:47 --> Helper loaded: directory_helper
INFO - 2021-09-09 09:41:47 --> Helper loaded: general_helper
INFO - 2021-09-09 09:41:47 --> Database Driver Class Initialized
INFO - 2021-09-09 09:41:48 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 09:41:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 09:41:48 --> Pagination Class Initialized
INFO - 2021-09-09 09:41:48 --> XML-RPC Class Initialized
INFO - 2021-09-09 09:41:48 --> Form Validation Class Initialized
INFO - 2021-09-09 09:41:48 --> Upload Class Initialized
INFO - 2021-09-09 09:41:48 --> MY_Model class loaded
INFO - 2021-09-09 09:41:48 --> Model "Application_model" initialized
INFO - 2021-09-09 09:41:48 --> Controller Class Initialized
DEBUG - 2021-09-09 09:41:48 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-09 09:41:48 --> Helper loaded: inflector_helper
INFO - 2021-09-09 09:41:48 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-09 09:41:48 --> Database Driver Class Initialized
ERROR - 2021-09-09 09:41:48 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 09:41:48 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 09:41:48 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-09 09:41:48 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-09 09:41:48 --> Model "Sms_model" initialized
INFO - 2021-09-09 09:41:48 --> Model "Fees_model" initialized
INFO - 2021-09-09 09:41:48 --> Final output sent to browser
DEBUG - 2021-09-09 09:41:48 --> Total execution time: 0.1317
INFO - 2021-09-09 09:42:02 --> Config Class Initialized
INFO - 2021-09-09 09:42:02 --> Hooks Class Initialized
DEBUG - 2021-09-09 09:42:02 --> UTF-8 Support Enabled
INFO - 2021-09-09 09:42:02 --> Utf8 Class Initialized
INFO - 2021-09-09 09:42:02 --> URI Class Initialized
INFO - 2021-09-09 09:42:02 --> Router Class Initialized
INFO - 2021-09-09 09:42:02 --> Output Class Initialized
INFO - 2021-09-09 09:42:02 --> Security Class Initialized
DEBUG - 2021-09-09 09:42:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 09:42:02 --> Input Class Initialized
INFO - 2021-09-09 09:42:02 --> Language Class Initialized
INFO - 2021-09-09 09:42:02 --> Loader Class Initialized
INFO - 2021-09-09 09:42:02 --> Helper loaded: url_helper
INFO - 2021-09-09 09:42:02 --> Helper loaded: file_helper
INFO - 2021-09-09 09:42:02 --> Helper loaded: form_helper
INFO - 2021-09-09 09:42:02 --> Helper loaded: security_helper
INFO - 2021-09-09 09:42:02 --> Helper loaded: directory_helper
INFO - 2021-09-09 09:42:02 --> Helper loaded: general_helper
INFO - 2021-09-09 09:42:02 --> Database Driver Class Initialized
INFO - 2021-09-09 09:42:02 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 09:42:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 09:42:02 --> Pagination Class Initialized
INFO - 2021-09-09 09:42:02 --> XML-RPC Class Initialized
INFO - 2021-09-09 09:42:02 --> Form Validation Class Initialized
INFO - 2021-09-09 09:42:02 --> Upload Class Initialized
INFO - 2021-09-09 09:42:02 --> MY_Model class loaded
INFO - 2021-09-09 09:42:02 --> Model "Application_model" initialized
INFO - 2021-09-09 09:42:02 --> Controller Class Initialized
DEBUG - 2021-09-09 09:42:02 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-09 09:42:02 --> Helper loaded: inflector_helper
INFO - 2021-09-09 09:42:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-09 09:42:02 --> Database Driver Class Initialized
ERROR - 2021-09-09 09:42:02 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 09:42:02 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 09:42:02 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-09 09:42:02 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-09 09:42:02 --> Model "Sms_model" initialized
INFO - 2021-09-09 09:42:02 --> Model "Fees_model" initialized
INFO - 2021-09-09 09:42:02 --> Final output sent to browser
DEBUG - 2021-09-09 09:42:02 --> Total execution time: 0.1207
INFO - 2021-09-09 09:42:21 --> Config Class Initialized
INFO - 2021-09-09 09:42:21 --> Hooks Class Initialized
DEBUG - 2021-09-09 09:42:21 --> UTF-8 Support Enabled
INFO - 2021-09-09 09:42:21 --> Utf8 Class Initialized
INFO - 2021-09-09 09:42:21 --> URI Class Initialized
INFO - 2021-09-09 09:42:21 --> Router Class Initialized
INFO - 2021-09-09 09:42:21 --> Output Class Initialized
INFO - 2021-09-09 09:42:21 --> Security Class Initialized
DEBUG - 2021-09-09 09:42:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 09:42:21 --> Input Class Initialized
INFO - 2021-09-09 09:42:21 --> Language Class Initialized
INFO - 2021-09-09 09:42:21 --> Loader Class Initialized
INFO - 2021-09-09 09:42:21 --> Helper loaded: url_helper
INFO - 2021-09-09 09:42:21 --> Helper loaded: file_helper
INFO - 2021-09-09 09:42:21 --> Helper loaded: form_helper
INFO - 2021-09-09 09:42:21 --> Helper loaded: security_helper
INFO - 2021-09-09 09:42:21 --> Helper loaded: directory_helper
INFO - 2021-09-09 09:42:21 --> Helper loaded: general_helper
INFO - 2021-09-09 09:42:21 --> Database Driver Class Initialized
INFO - 2021-09-09 09:42:21 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 09:42:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 09:42:21 --> Pagination Class Initialized
INFO - 2021-09-09 09:42:21 --> XML-RPC Class Initialized
INFO - 2021-09-09 09:42:21 --> Form Validation Class Initialized
INFO - 2021-09-09 09:42:21 --> Upload Class Initialized
INFO - 2021-09-09 09:42:21 --> MY_Model class loaded
INFO - 2021-09-09 09:42:21 --> Model "Application_model" initialized
INFO - 2021-09-09 09:42:21 --> Controller Class Initialized
DEBUG - 2021-09-09 09:42:21 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-09 09:42:21 --> Helper loaded: inflector_helper
INFO - 2021-09-09 09:42:21 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-09 09:42:21 --> Database Driver Class Initialized
ERROR - 2021-09-09 09:42:21 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 09:42:21 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 09:42:21 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-09 09:42:21 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-09 09:42:21 --> Model "Sms_model" initialized
INFO - 2021-09-09 09:42:21 --> Model "Fees_model" initialized
INFO - 2021-09-09 09:42:21 --> Final output sent to browser
DEBUG - 2021-09-09 09:42:21 --> Total execution time: 0.1221
INFO - 2021-09-09 09:42:26 --> Config Class Initialized
INFO - 2021-09-09 09:42:26 --> Hooks Class Initialized
DEBUG - 2021-09-09 09:42:26 --> UTF-8 Support Enabled
INFO - 2021-09-09 09:42:26 --> Utf8 Class Initialized
INFO - 2021-09-09 09:42:26 --> URI Class Initialized
INFO - 2021-09-09 09:42:26 --> Router Class Initialized
INFO - 2021-09-09 09:42:26 --> Output Class Initialized
INFO - 2021-09-09 09:42:26 --> Security Class Initialized
DEBUG - 2021-09-09 09:42:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 09:42:26 --> Input Class Initialized
INFO - 2021-09-09 09:42:26 --> Language Class Initialized
INFO - 2021-09-09 09:42:26 --> Loader Class Initialized
INFO - 2021-09-09 09:42:26 --> Helper loaded: url_helper
INFO - 2021-09-09 09:42:26 --> Helper loaded: file_helper
INFO - 2021-09-09 09:42:26 --> Helper loaded: form_helper
INFO - 2021-09-09 09:42:26 --> Helper loaded: security_helper
INFO - 2021-09-09 09:42:26 --> Helper loaded: directory_helper
INFO - 2021-09-09 09:42:26 --> Helper loaded: general_helper
INFO - 2021-09-09 09:42:26 --> Database Driver Class Initialized
INFO - 2021-09-09 09:42:26 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 09:42:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 09:42:26 --> Pagination Class Initialized
INFO - 2021-09-09 09:42:26 --> XML-RPC Class Initialized
INFO - 2021-09-09 09:42:26 --> Form Validation Class Initialized
INFO - 2021-09-09 09:42:26 --> Upload Class Initialized
INFO - 2021-09-09 09:42:26 --> MY_Model class loaded
INFO - 2021-09-09 09:42:26 --> Model "Application_model" initialized
INFO - 2021-09-09 09:42:26 --> Controller Class Initialized
DEBUG - 2021-09-09 09:42:26 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-09 09:42:26 --> Helper loaded: inflector_helper
INFO - 2021-09-09 09:42:26 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-09 09:42:26 --> Database Driver Class Initialized
ERROR - 2021-09-09 09:42:26 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 09:42:26 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 09:42:26 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-09 09:42:26 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-09 09:42:26 --> Model "Sms_model" initialized
INFO - 2021-09-09 09:42:26 --> Model "Fees_model" initialized
INFO - 2021-09-09 09:42:26 --> Final output sent to browser
DEBUG - 2021-09-09 09:42:26 --> Total execution time: 0.1395
INFO - 2021-09-09 09:42:45 --> Config Class Initialized
INFO - 2021-09-09 09:42:45 --> Hooks Class Initialized
DEBUG - 2021-09-09 09:42:45 --> UTF-8 Support Enabled
INFO - 2021-09-09 09:42:45 --> Utf8 Class Initialized
INFO - 2021-09-09 09:42:45 --> URI Class Initialized
INFO - 2021-09-09 09:42:45 --> Router Class Initialized
INFO - 2021-09-09 09:42:45 --> Output Class Initialized
INFO - 2021-09-09 09:42:45 --> Security Class Initialized
DEBUG - 2021-09-09 09:42:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 09:42:45 --> Input Class Initialized
INFO - 2021-09-09 09:42:45 --> Language Class Initialized
INFO - 2021-09-09 09:42:45 --> Loader Class Initialized
INFO - 2021-09-09 09:42:45 --> Helper loaded: url_helper
INFO - 2021-09-09 09:42:45 --> Helper loaded: file_helper
INFO - 2021-09-09 09:42:45 --> Helper loaded: form_helper
INFO - 2021-09-09 09:42:45 --> Helper loaded: security_helper
INFO - 2021-09-09 09:42:45 --> Helper loaded: directory_helper
INFO - 2021-09-09 09:42:45 --> Helper loaded: general_helper
INFO - 2021-09-09 09:42:45 --> Database Driver Class Initialized
INFO - 2021-09-09 09:42:45 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 09:42:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 09:42:45 --> Pagination Class Initialized
INFO - 2021-09-09 09:42:45 --> XML-RPC Class Initialized
INFO - 2021-09-09 09:42:45 --> Form Validation Class Initialized
INFO - 2021-09-09 09:42:45 --> Upload Class Initialized
INFO - 2021-09-09 09:42:45 --> MY_Model class loaded
INFO - 2021-09-09 09:42:45 --> Model "Application_model" initialized
INFO - 2021-09-09 09:42:45 --> Controller Class Initialized
DEBUG - 2021-09-09 09:42:45 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-09 09:42:45 --> Helper loaded: inflector_helper
INFO - 2021-09-09 09:42:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-09 09:42:45 --> Database Driver Class Initialized
ERROR - 2021-09-09 09:42:45 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 09:42:45 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 09:42:45 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-09 09:42:45 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-09 09:42:45 --> Model "Sms_model" initialized
INFO - 2021-09-09 09:42:45 --> Model "Fees_model" initialized
INFO - 2021-09-09 09:42:45 --> Final output sent to browser
DEBUG - 2021-09-09 09:42:45 --> Total execution time: 0.1346
INFO - 2021-09-09 10:02:22 --> Config Class Initialized
INFO - 2021-09-09 10:02:22 --> Hooks Class Initialized
DEBUG - 2021-09-09 10:02:22 --> UTF-8 Support Enabled
INFO - 2021-09-09 10:02:22 --> Utf8 Class Initialized
INFO - 2021-09-09 10:02:22 --> URI Class Initialized
INFO - 2021-09-09 10:02:22 --> Router Class Initialized
INFO - 2021-09-09 10:02:22 --> Output Class Initialized
INFO - 2021-09-09 10:02:22 --> Security Class Initialized
DEBUG - 2021-09-09 10:02:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 10:02:22 --> Input Class Initialized
INFO - 2021-09-09 10:02:22 --> Language Class Initialized
INFO - 2021-09-09 10:02:22 --> Loader Class Initialized
INFO - 2021-09-09 10:02:22 --> Helper loaded: url_helper
INFO - 2021-09-09 10:02:22 --> Helper loaded: file_helper
INFO - 2021-09-09 10:02:22 --> Helper loaded: form_helper
INFO - 2021-09-09 10:02:22 --> Helper loaded: security_helper
INFO - 2021-09-09 10:02:22 --> Helper loaded: directory_helper
INFO - 2021-09-09 10:02:22 --> Helper loaded: general_helper
INFO - 2021-09-09 10:02:22 --> Database Driver Class Initialized
INFO - 2021-09-09 10:02:22 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 10:02:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 10:02:22 --> Pagination Class Initialized
INFO - 2021-09-09 10:02:22 --> XML-RPC Class Initialized
INFO - 2021-09-09 10:02:22 --> Form Validation Class Initialized
INFO - 2021-09-09 10:02:22 --> Upload Class Initialized
INFO - 2021-09-09 10:02:23 --> MY_Model class loaded
INFO - 2021-09-09 10:02:23 --> Model "Application_model" initialized
INFO - 2021-09-09 10:02:23 --> Controller Class Initialized
DEBUG - 2021-09-09 10:02:23 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-09 10:02:23 --> Helper loaded: inflector_helper
INFO - 2021-09-09 10:02:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-09 10:02:23 --> Database Driver Class Initialized
ERROR - 2021-09-09 10:02:23 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 10:02:23 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 10:02:23 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-09 10:02:23 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-09 10:02:23 --> Model "Sms_model" initialized
INFO - 2021-09-09 10:02:23 --> Model "Fees_model" initialized
ERROR - 2021-09-09 10:02:23 --> Severity: error --> Exception: Object of class stdClass could not be converted to string C:\Users\Gopal Ghimire\Desktop\New folder\school\application\controllers\api\Fees.php 15
INFO - 2021-09-09 10:02:39 --> Config Class Initialized
INFO - 2021-09-09 10:02:39 --> Hooks Class Initialized
DEBUG - 2021-09-09 10:02:39 --> UTF-8 Support Enabled
INFO - 2021-09-09 10:02:39 --> Utf8 Class Initialized
INFO - 2021-09-09 10:02:39 --> URI Class Initialized
INFO - 2021-09-09 10:02:39 --> Router Class Initialized
INFO - 2021-09-09 10:02:39 --> Output Class Initialized
INFO - 2021-09-09 10:02:39 --> Security Class Initialized
DEBUG - 2021-09-09 10:02:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 10:02:39 --> Input Class Initialized
INFO - 2021-09-09 10:02:39 --> Language Class Initialized
INFO - 2021-09-09 10:02:39 --> Loader Class Initialized
INFO - 2021-09-09 10:02:39 --> Helper loaded: url_helper
INFO - 2021-09-09 10:02:39 --> Helper loaded: file_helper
INFO - 2021-09-09 10:02:39 --> Helper loaded: form_helper
INFO - 2021-09-09 10:02:39 --> Helper loaded: security_helper
INFO - 2021-09-09 10:02:39 --> Helper loaded: directory_helper
INFO - 2021-09-09 10:02:39 --> Helper loaded: general_helper
INFO - 2021-09-09 10:02:39 --> Database Driver Class Initialized
INFO - 2021-09-09 10:02:39 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 10:02:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 10:02:39 --> Pagination Class Initialized
INFO - 2021-09-09 10:02:39 --> XML-RPC Class Initialized
INFO - 2021-09-09 10:02:39 --> Form Validation Class Initialized
INFO - 2021-09-09 10:02:39 --> Upload Class Initialized
INFO - 2021-09-09 10:02:39 --> MY_Model class loaded
INFO - 2021-09-09 10:02:39 --> Model "Application_model" initialized
INFO - 2021-09-09 10:02:39 --> Controller Class Initialized
DEBUG - 2021-09-09 10:02:39 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-09 10:02:39 --> Helper loaded: inflector_helper
INFO - 2021-09-09 10:02:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-09 10:02:39 --> Database Driver Class Initialized
ERROR - 2021-09-09 10:02:39 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 10:02:39 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 10:02:39 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-09 10:02:39 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-09 10:02:39 --> Model "Sms_model" initialized
INFO - 2021-09-09 10:02:39 --> Model "Fees_model" initialized
ERROR - 2021-09-09 10:02:39 --> Severity: error --> Exception: Object of class stdClass could not be converted to string C:\Users\Gopal Ghimire\Desktop\New folder\school\application\controllers\api\Fees.php 15
INFO - 2021-09-09 10:03:57 --> Config Class Initialized
INFO - 2021-09-09 10:03:57 --> Hooks Class Initialized
DEBUG - 2021-09-09 10:03:57 --> UTF-8 Support Enabled
INFO - 2021-09-09 10:03:57 --> Utf8 Class Initialized
INFO - 2021-09-09 10:03:57 --> URI Class Initialized
INFO - 2021-09-09 10:03:57 --> Router Class Initialized
INFO - 2021-09-09 10:03:57 --> Output Class Initialized
INFO - 2021-09-09 10:03:57 --> Security Class Initialized
DEBUG - 2021-09-09 10:03:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 10:03:57 --> Input Class Initialized
INFO - 2021-09-09 10:03:57 --> Language Class Initialized
INFO - 2021-09-09 10:03:57 --> Loader Class Initialized
INFO - 2021-09-09 10:03:57 --> Helper loaded: url_helper
INFO - 2021-09-09 10:03:57 --> Helper loaded: file_helper
INFO - 2021-09-09 10:03:57 --> Helper loaded: form_helper
INFO - 2021-09-09 10:03:57 --> Helper loaded: security_helper
INFO - 2021-09-09 10:03:57 --> Helper loaded: directory_helper
INFO - 2021-09-09 10:03:57 --> Helper loaded: general_helper
INFO - 2021-09-09 10:03:57 --> Database Driver Class Initialized
INFO - 2021-09-09 10:03:57 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 10:03:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 10:03:57 --> Pagination Class Initialized
INFO - 2021-09-09 10:03:57 --> XML-RPC Class Initialized
INFO - 2021-09-09 10:03:57 --> Form Validation Class Initialized
INFO - 2021-09-09 10:03:57 --> Upload Class Initialized
INFO - 2021-09-09 10:03:57 --> MY_Model class loaded
INFO - 2021-09-09 10:03:57 --> Model "Application_model" initialized
INFO - 2021-09-09 10:03:57 --> Controller Class Initialized
DEBUG - 2021-09-09 10:03:57 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-09 10:03:57 --> Helper loaded: inflector_helper
INFO - 2021-09-09 10:03:57 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-09 10:03:57 --> Database Driver Class Initialized
ERROR - 2021-09-09 10:03:57 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 10:03:57 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 10:03:57 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-09 10:03:57 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-09 10:03:57 --> Model "Sms_model" initialized
INFO - 2021-09-09 10:03:57 --> Model "Fees_model" initialized
INFO - 2021-09-09 10:03:57 --> Final output sent to browser
DEBUG - 2021-09-09 10:03:57 --> Total execution time: 0.2783
INFO - 2021-09-09 10:08:29 --> Config Class Initialized
INFO - 2021-09-09 10:08:29 --> Hooks Class Initialized
DEBUG - 2021-09-09 10:08:29 --> UTF-8 Support Enabled
INFO - 2021-09-09 10:08:29 --> Utf8 Class Initialized
INFO - 2021-09-09 10:08:29 --> URI Class Initialized
INFO - 2021-09-09 10:08:29 --> Router Class Initialized
INFO - 2021-09-09 10:08:29 --> Output Class Initialized
INFO - 2021-09-09 10:08:29 --> Security Class Initialized
DEBUG - 2021-09-09 10:08:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 10:08:29 --> Input Class Initialized
INFO - 2021-09-09 10:08:30 --> Language Class Initialized
INFO - 2021-09-09 10:08:30 --> Loader Class Initialized
INFO - 2021-09-09 10:08:30 --> Helper loaded: url_helper
INFO - 2021-09-09 10:08:30 --> Helper loaded: file_helper
INFO - 2021-09-09 10:08:30 --> Helper loaded: form_helper
INFO - 2021-09-09 10:08:30 --> Helper loaded: security_helper
INFO - 2021-09-09 10:08:30 --> Helper loaded: directory_helper
INFO - 2021-09-09 10:08:30 --> Helper loaded: general_helper
INFO - 2021-09-09 10:08:30 --> Database Driver Class Initialized
INFO - 2021-09-09 10:08:30 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 10:08:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 10:08:30 --> Pagination Class Initialized
INFO - 2021-09-09 10:08:30 --> XML-RPC Class Initialized
INFO - 2021-09-09 10:08:30 --> Form Validation Class Initialized
INFO - 2021-09-09 10:08:30 --> Upload Class Initialized
INFO - 2021-09-09 10:08:30 --> MY_Model class loaded
INFO - 2021-09-09 10:08:30 --> Model "Application_model" initialized
INFO - 2021-09-09 10:08:30 --> Controller Class Initialized
DEBUG - 2021-09-09 10:08:31 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-09 10:08:31 --> Helper loaded: inflector_helper
INFO - 2021-09-09 10:08:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-09 10:08:31 --> Database Driver Class Initialized
ERROR - 2021-09-09 10:08:31 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 10:08:31 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 10:08:31 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-09 10:08:31 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-09 10:08:31 --> Model "Sms_model" initialized
INFO - 2021-09-09 10:08:31 --> Model "Fees_model" initialized
ERROR - 2021-09-09 10:08:31 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'WHERE `fa`.`session_id` = 'SELECT `e`.`student_id`, `e`.`roll`, `s`.`first_name`' at line 2 - Invalid query: SELECT *
WHERE `fa`.`session_id` = 'SELECT `e`.`student_id`, `e`.`roll`, `s`.`first_name`, `s`.`last_name`, `s`.`register_no`, `s`.`mobileno`, `c`.`name` as `class_name`, `se`.`name` as `section_name`\nFROM (`fee_allocation` as `fa`, `global_settings`)\nINNER JOIN `enroll` as `e` ON `e`.`student_id` = `fa`.`student_id`\nLEFT JOIN `student` as `s` ON `s`.`id` = `e`.`student_id`\nLEFT JOIN `class` as `c` ON `c`.`id` = `e`.`class_id`\nLEFT JOIN `section` as `se` ON `se`.`id` = `e`.`section_id`\nWHERE `fa`.`branch_id` IS NULL'
AND `e`.`class_id` IS NULL
AND `e`.`section_id` IS NULL
GROUP BY `fa`.`student_id`
ORDER BY `e`.`id` ASC
ERROR - 2021-09-09 10:08:31 --> Severity: error --> Exception: Call to a member function result_array() on bool C:\Users\Gopal Ghimire\Desktop\New folder\school\application\models\Fees_model.php 197
INFO - 2021-09-09 10:10:19 --> Config Class Initialized
INFO - 2021-09-09 10:10:19 --> Hooks Class Initialized
DEBUG - 2021-09-09 10:10:20 --> UTF-8 Support Enabled
INFO - 2021-09-09 10:10:20 --> Utf8 Class Initialized
INFO - 2021-09-09 10:10:20 --> URI Class Initialized
INFO - 2021-09-09 10:10:20 --> Router Class Initialized
INFO - 2021-09-09 10:10:20 --> Output Class Initialized
INFO - 2021-09-09 10:10:20 --> Security Class Initialized
DEBUG - 2021-09-09 10:10:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 10:10:20 --> Input Class Initialized
INFO - 2021-09-09 10:10:20 --> Language Class Initialized
INFO - 2021-09-09 10:10:20 --> Loader Class Initialized
INFO - 2021-09-09 10:10:20 --> Helper loaded: url_helper
INFO - 2021-09-09 10:10:20 --> Helper loaded: file_helper
INFO - 2021-09-09 10:10:20 --> Helper loaded: form_helper
INFO - 2021-09-09 10:10:20 --> Helper loaded: security_helper
INFO - 2021-09-09 10:10:20 --> Helper loaded: directory_helper
INFO - 2021-09-09 10:10:20 --> Helper loaded: general_helper
INFO - 2021-09-09 10:10:20 --> Database Driver Class Initialized
INFO - 2021-09-09 10:10:20 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 10:10:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 10:10:20 --> Pagination Class Initialized
INFO - 2021-09-09 10:10:20 --> XML-RPC Class Initialized
INFO - 2021-09-09 10:10:20 --> Form Validation Class Initialized
INFO - 2021-09-09 10:10:20 --> Upload Class Initialized
INFO - 2021-09-09 10:10:20 --> MY_Model class loaded
INFO - 2021-09-09 10:10:20 --> Model "Application_model" initialized
INFO - 2021-09-09 10:10:20 --> Controller Class Initialized
DEBUG - 2021-09-09 10:10:20 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-09 10:10:20 --> Helper loaded: inflector_helper
INFO - 2021-09-09 10:10:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-09 10:10:20 --> Database Driver Class Initialized
ERROR - 2021-09-09 10:10:20 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 10:10:20 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 10:10:20 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-09 10:10:20 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-09 10:10:20 --> Model "Sms_model" initialized
INFO - 2021-09-09 10:10:20 --> Model "Fees_model" initialized
INFO - 2021-09-09 10:10:20 --> Final output sent to browser
DEBUG - 2021-09-09 10:10:20 --> Total execution time: 0.1286
INFO - 2021-09-09 10:14:27 --> Config Class Initialized
INFO - 2021-09-09 10:14:27 --> Hooks Class Initialized
DEBUG - 2021-09-09 10:14:27 --> UTF-8 Support Enabled
INFO - 2021-09-09 10:14:27 --> Utf8 Class Initialized
INFO - 2021-09-09 10:14:27 --> URI Class Initialized
INFO - 2021-09-09 10:14:27 --> Router Class Initialized
INFO - 2021-09-09 10:14:27 --> Output Class Initialized
INFO - 2021-09-09 10:14:27 --> Security Class Initialized
DEBUG - 2021-09-09 10:14:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 10:14:27 --> Input Class Initialized
INFO - 2021-09-09 10:14:27 --> Language Class Initialized
INFO - 2021-09-09 10:14:27 --> Loader Class Initialized
INFO - 2021-09-09 10:14:27 --> Helper loaded: url_helper
INFO - 2021-09-09 10:14:27 --> Helper loaded: file_helper
INFO - 2021-09-09 10:14:27 --> Helper loaded: form_helper
INFO - 2021-09-09 10:14:27 --> Helper loaded: security_helper
INFO - 2021-09-09 10:14:27 --> Helper loaded: directory_helper
INFO - 2021-09-09 10:14:27 --> Helper loaded: general_helper
INFO - 2021-09-09 10:14:27 --> Database Driver Class Initialized
INFO - 2021-09-09 10:14:27 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 10:14:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 10:14:27 --> Pagination Class Initialized
INFO - 2021-09-09 10:14:27 --> XML-RPC Class Initialized
INFO - 2021-09-09 10:14:27 --> Form Validation Class Initialized
INFO - 2021-09-09 10:14:27 --> Upload Class Initialized
INFO - 2021-09-09 10:14:27 --> MY_Model class loaded
INFO - 2021-09-09 10:14:27 --> Model "Application_model" initialized
INFO - 2021-09-09 10:14:27 --> Controller Class Initialized
DEBUG - 2021-09-09 10:14:27 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-09 10:14:27 --> Helper loaded: inflector_helper
INFO - 2021-09-09 10:14:27 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-09 10:14:27 --> Database Driver Class Initialized
ERROR - 2021-09-09 10:14:27 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 10:14:27 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 10:14:27 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-09 10:14:27 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-09 10:14:27 --> Model "Sms_model" initialized
INFO - 2021-09-09 10:14:27 --> Model "Fees_model" initialized
INFO - 2021-09-09 10:14:27 --> Final output sent to browser
DEBUG - 2021-09-09 10:14:27 --> Total execution time: 0.4076
INFO - 2021-09-09 10:14:29 --> Config Class Initialized
INFO - 2021-09-09 10:14:29 --> Hooks Class Initialized
DEBUG - 2021-09-09 10:14:29 --> UTF-8 Support Enabled
INFO - 2021-09-09 10:14:29 --> Utf8 Class Initialized
INFO - 2021-09-09 10:14:29 --> URI Class Initialized
INFO - 2021-09-09 10:14:29 --> Router Class Initialized
INFO - 2021-09-09 10:14:29 --> Output Class Initialized
INFO - 2021-09-09 10:14:29 --> Security Class Initialized
DEBUG - 2021-09-09 10:14:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 10:14:29 --> Input Class Initialized
INFO - 2021-09-09 10:14:29 --> Language Class Initialized
INFO - 2021-09-09 10:14:29 --> Loader Class Initialized
INFO - 2021-09-09 10:14:29 --> Helper loaded: url_helper
INFO - 2021-09-09 10:14:29 --> Helper loaded: file_helper
INFO - 2021-09-09 10:14:29 --> Helper loaded: form_helper
INFO - 2021-09-09 10:14:29 --> Helper loaded: security_helper
INFO - 2021-09-09 10:14:29 --> Helper loaded: directory_helper
INFO - 2021-09-09 10:14:29 --> Helper loaded: general_helper
INFO - 2021-09-09 10:14:29 --> Database Driver Class Initialized
INFO - 2021-09-09 10:14:29 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 10:14:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 10:14:29 --> Pagination Class Initialized
INFO - 2021-09-09 10:14:29 --> XML-RPC Class Initialized
INFO - 2021-09-09 10:14:29 --> Form Validation Class Initialized
INFO - 2021-09-09 10:14:29 --> Upload Class Initialized
INFO - 2021-09-09 10:14:29 --> MY_Model class loaded
INFO - 2021-09-09 10:14:29 --> Model "Application_model" initialized
INFO - 2021-09-09 10:14:29 --> Controller Class Initialized
DEBUG - 2021-09-09 10:14:29 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-09 10:14:29 --> Helper loaded: inflector_helper
INFO - 2021-09-09 10:14:29 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-09 10:14:29 --> Database Driver Class Initialized
ERROR - 2021-09-09 10:14:29 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 10:14:29 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 10:14:29 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-09 10:14:29 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-09 10:14:29 --> Model "Sms_model" initialized
INFO - 2021-09-09 10:14:29 --> Model "Fees_model" initialized
INFO - 2021-09-09 10:14:29 --> Final output sent to browser
DEBUG - 2021-09-09 10:14:29 --> Total execution time: 0.2127
INFO - 2021-09-09 10:15:04 --> Config Class Initialized
INFO - 2021-09-09 10:15:04 --> Hooks Class Initialized
DEBUG - 2021-09-09 10:15:04 --> UTF-8 Support Enabled
INFO - 2021-09-09 10:15:04 --> Utf8 Class Initialized
INFO - 2021-09-09 10:15:04 --> URI Class Initialized
INFO - 2021-09-09 10:15:04 --> Router Class Initialized
INFO - 2021-09-09 10:15:04 --> Output Class Initialized
INFO - 2021-09-09 10:15:04 --> Security Class Initialized
DEBUG - 2021-09-09 10:15:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 10:15:04 --> Input Class Initialized
INFO - 2021-09-09 10:15:04 --> Language Class Initialized
INFO - 2021-09-09 10:15:04 --> Loader Class Initialized
INFO - 2021-09-09 10:15:04 --> Helper loaded: url_helper
INFO - 2021-09-09 10:15:04 --> Helper loaded: file_helper
INFO - 2021-09-09 10:15:04 --> Helper loaded: form_helper
INFO - 2021-09-09 10:15:04 --> Helper loaded: security_helper
INFO - 2021-09-09 10:15:04 --> Helper loaded: directory_helper
INFO - 2021-09-09 10:15:04 --> Helper loaded: general_helper
INFO - 2021-09-09 10:15:04 --> Database Driver Class Initialized
INFO - 2021-09-09 10:15:05 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 10:15:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 10:15:05 --> Pagination Class Initialized
INFO - 2021-09-09 10:15:05 --> XML-RPC Class Initialized
INFO - 2021-09-09 10:15:05 --> Form Validation Class Initialized
INFO - 2021-09-09 10:15:05 --> Upload Class Initialized
INFO - 2021-09-09 10:15:05 --> MY_Model class loaded
INFO - 2021-09-09 10:15:05 --> Model "Application_model" initialized
INFO - 2021-09-09 10:15:05 --> Controller Class Initialized
DEBUG - 2021-09-09 10:15:05 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-09 10:15:05 --> Helper loaded: inflector_helper
INFO - 2021-09-09 10:15:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-09 10:15:05 --> Database Driver Class Initialized
ERROR - 2021-09-09 10:15:05 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 10:15:05 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 10:15:05 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-09 10:15:05 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-09 10:15:05 --> Model "Sms_model" initialized
INFO - 2021-09-09 10:15:05 --> Model "Fees_model" initialized
INFO - 2021-09-09 10:15:05 --> Final output sent to browser
DEBUG - 2021-09-09 10:15:05 --> Total execution time: 0.4030
INFO - 2021-09-09 10:15:11 --> Config Class Initialized
INFO - 2021-09-09 10:15:11 --> Hooks Class Initialized
DEBUG - 2021-09-09 10:15:11 --> UTF-8 Support Enabled
INFO - 2021-09-09 10:15:11 --> Utf8 Class Initialized
INFO - 2021-09-09 10:15:11 --> URI Class Initialized
INFO - 2021-09-09 10:15:11 --> Router Class Initialized
INFO - 2021-09-09 10:15:11 --> Output Class Initialized
INFO - 2021-09-09 10:15:11 --> Security Class Initialized
DEBUG - 2021-09-09 10:15:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 10:15:11 --> Input Class Initialized
INFO - 2021-09-09 10:15:11 --> Language Class Initialized
INFO - 2021-09-09 10:15:11 --> Loader Class Initialized
INFO - 2021-09-09 10:15:11 --> Helper loaded: url_helper
INFO - 2021-09-09 10:15:11 --> Helper loaded: file_helper
INFO - 2021-09-09 10:15:11 --> Helper loaded: form_helper
INFO - 2021-09-09 10:15:11 --> Helper loaded: security_helper
INFO - 2021-09-09 10:15:11 --> Helper loaded: directory_helper
INFO - 2021-09-09 10:15:11 --> Helper loaded: general_helper
INFO - 2021-09-09 10:15:11 --> Database Driver Class Initialized
INFO - 2021-09-09 10:15:11 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 10:15:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 10:15:11 --> Pagination Class Initialized
INFO - 2021-09-09 10:15:11 --> XML-RPC Class Initialized
INFO - 2021-09-09 10:15:11 --> Form Validation Class Initialized
INFO - 2021-09-09 10:15:11 --> Upload Class Initialized
INFO - 2021-09-09 10:15:11 --> MY_Model class loaded
INFO - 2021-09-09 10:15:11 --> Model "Application_model" initialized
INFO - 2021-09-09 10:15:11 --> Controller Class Initialized
DEBUG - 2021-09-09 10:15:11 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-09 10:15:11 --> Helper loaded: inflector_helper
INFO - 2021-09-09 10:15:11 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-09 10:15:11 --> Database Driver Class Initialized
ERROR - 2021-09-09 10:15:11 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 10:15:11 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 10:15:11 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-09 10:15:11 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-09 10:15:11 --> Model "Sms_model" initialized
INFO - 2021-09-09 10:15:11 --> Model "Fees_model" initialized
INFO - 2021-09-09 10:15:11 --> Final output sent to browser
DEBUG - 2021-09-09 10:15:11 --> Total execution time: 0.2509
INFO - 2021-09-09 10:15:30 --> Config Class Initialized
INFO - 2021-09-09 10:15:30 --> Hooks Class Initialized
DEBUG - 2021-09-09 10:15:30 --> UTF-8 Support Enabled
INFO - 2021-09-09 10:15:30 --> Utf8 Class Initialized
INFO - 2021-09-09 10:15:30 --> URI Class Initialized
INFO - 2021-09-09 10:15:30 --> Router Class Initialized
INFO - 2021-09-09 10:15:30 --> Output Class Initialized
INFO - 2021-09-09 10:15:30 --> Security Class Initialized
DEBUG - 2021-09-09 10:15:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 10:15:30 --> Input Class Initialized
INFO - 2021-09-09 10:15:30 --> Language Class Initialized
INFO - 2021-09-09 10:15:30 --> Loader Class Initialized
INFO - 2021-09-09 10:15:30 --> Helper loaded: url_helper
INFO - 2021-09-09 10:15:30 --> Helper loaded: file_helper
INFO - 2021-09-09 10:15:30 --> Helper loaded: form_helper
INFO - 2021-09-09 10:15:30 --> Helper loaded: security_helper
INFO - 2021-09-09 10:15:30 --> Helper loaded: directory_helper
INFO - 2021-09-09 10:15:30 --> Helper loaded: general_helper
INFO - 2021-09-09 10:15:30 --> Database Driver Class Initialized
INFO - 2021-09-09 10:15:30 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 10:15:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 10:15:30 --> Pagination Class Initialized
INFO - 2021-09-09 10:15:30 --> XML-RPC Class Initialized
INFO - 2021-09-09 10:15:30 --> Form Validation Class Initialized
INFO - 2021-09-09 10:15:30 --> Upload Class Initialized
INFO - 2021-09-09 10:15:30 --> MY_Model class loaded
INFO - 2021-09-09 10:15:30 --> Model "Application_model" initialized
INFO - 2021-09-09 10:15:30 --> Controller Class Initialized
DEBUG - 2021-09-09 10:15:30 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-09 10:15:30 --> Helper loaded: inflector_helper
INFO - 2021-09-09 10:15:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-09 10:15:30 --> Database Driver Class Initialized
ERROR - 2021-09-09 10:15:30 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 10:15:30 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 10:15:30 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-09 10:15:30 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-09 10:15:30 --> Model "Sms_model" initialized
INFO - 2021-09-09 10:15:30 --> Model "Fees_model" initialized
INFO - 2021-09-09 10:15:30 --> Final output sent to browser
DEBUG - 2021-09-09 10:15:30 --> Total execution time: 0.2815
INFO - 2021-09-09 10:15:35 --> Config Class Initialized
INFO - 2021-09-09 10:15:35 --> Hooks Class Initialized
DEBUG - 2021-09-09 10:15:35 --> UTF-8 Support Enabled
INFO - 2021-09-09 10:15:35 --> Utf8 Class Initialized
INFO - 2021-09-09 10:15:35 --> URI Class Initialized
INFO - 2021-09-09 10:15:35 --> Router Class Initialized
INFO - 2021-09-09 10:15:35 --> Output Class Initialized
INFO - 2021-09-09 10:15:35 --> Security Class Initialized
DEBUG - 2021-09-09 10:15:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 10:15:35 --> Input Class Initialized
INFO - 2021-09-09 10:15:35 --> Language Class Initialized
INFO - 2021-09-09 10:15:35 --> Loader Class Initialized
INFO - 2021-09-09 10:15:35 --> Helper loaded: url_helper
INFO - 2021-09-09 10:15:35 --> Helper loaded: file_helper
INFO - 2021-09-09 10:15:35 --> Helper loaded: form_helper
INFO - 2021-09-09 10:15:35 --> Helper loaded: security_helper
INFO - 2021-09-09 10:15:35 --> Helper loaded: directory_helper
INFO - 2021-09-09 10:15:35 --> Helper loaded: general_helper
INFO - 2021-09-09 10:15:35 --> Database Driver Class Initialized
INFO - 2021-09-09 10:15:35 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 10:15:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 10:15:35 --> Pagination Class Initialized
INFO - 2021-09-09 10:15:35 --> XML-RPC Class Initialized
INFO - 2021-09-09 10:15:35 --> Form Validation Class Initialized
INFO - 2021-09-09 10:15:35 --> Upload Class Initialized
INFO - 2021-09-09 10:15:35 --> MY_Model class loaded
INFO - 2021-09-09 10:15:35 --> Model "Application_model" initialized
INFO - 2021-09-09 10:15:35 --> Controller Class Initialized
DEBUG - 2021-09-09 10:15:35 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-09 10:15:35 --> Helper loaded: inflector_helper
INFO - 2021-09-09 10:15:35 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-09 10:15:35 --> Database Driver Class Initialized
ERROR - 2021-09-09 10:15:35 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 10:15:35 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 10:15:35 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-09 10:15:35 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-09 10:15:35 --> Model "Sms_model" initialized
INFO - 2021-09-09 10:15:35 --> Model "Fees_model" initialized
INFO - 2021-09-09 10:15:35 --> Final output sent to browser
DEBUG - 2021-09-09 10:15:35 --> Total execution time: 0.2718
INFO - 2021-09-09 10:16:58 --> Config Class Initialized
INFO - 2021-09-09 10:16:58 --> Hooks Class Initialized
DEBUG - 2021-09-09 10:16:58 --> UTF-8 Support Enabled
INFO - 2021-09-09 10:16:58 --> Utf8 Class Initialized
INFO - 2021-09-09 10:16:58 --> URI Class Initialized
INFO - 2021-09-09 10:16:58 --> Router Class Initialized
INFO - 2021-09-09 10:16:58 --> Output Class Initialized
INFO - 2021-09-09 10:16:58 --> Security Class Initialized
DEBUG - 2021-09-09 10:16:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 10:16:58 --> Input Class Initialized
INFO - 2021-09-09 10:16:58 --> Language Class Initialized
INFO - 2021-09-09 10:16:58 --> Loader Class Initialized
INFO - 2021-09-09 10:16:58 --> Helper loaded: url_helper
INFO - 2021-09-09 10:16:58 --> Helper loaded: file_helper
INFO - 2021-09-09 10:16:58 --> Helper loaded: form_helper
INFO - 2021-09-09 10:16:58 --> Helper loaded: security_helper
INFO - 2021-09-09 10:16:58 --> Helper loaded: directory_helper
INFO - 2021-09-09 10:16:58 --> Helper loaded: general_helper
INFO - 2021-09-09 10:16:58 --> Database Driver Class Initialized
INFO - 2021-09-09 10:16:58 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 10:16:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 10:16:58 --> Pagination Class Initialized
INFO - 2021-09-09 10:16:58 --> XML-RPC Class Initialized
INFO - 2021-09-09 10:16:58 --> Form Validation Class Initialized
INFO - 2021-09-09 10:16:58 --> Upload Class Initialized
INFO - 2021-09-09 10:16:58 --> MY_Model class loaded
INFO - 2021-09-09 10:16:58 --> Model "Application_model" initialized
INFO - 2021-09-09 10:16:58 --> Controller Class Initialized
DEBUG - 2021-09-09 10:16:58 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-09 10:16:58 --> Helper loaded: inflector_helper
INFO - 2021-09-09 10:16:58 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-09 10:16:58 --> Database Driver Class Initialized
ERROR - 2021-09-09 10:16:58 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 10:16:58 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 10:16:58 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-09 10:16:58 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-09 10:16:58 --> Model "Sms_model" initialized
INFO - 2021-09-09 10:16:58 --> Model "Fees_model" initialized
INFO - 2021-09-09 10:16:58 --> Final output sent to browser
DEBUG - 2021-09-09 10:16:58 --> Total execution time: 0.2991
INFO - 2021-09-09 10:20:48 --> Config Class Initialized
INFO - 2021-09-09 10:20:48 --> Hooks Class Initialized
DEBUG - 2021-09-09 10:20:48 --> UTF-8 Support Enabled
INFO - 2021-09-09 10:20:48 --> Utf8 Class Initialized
INFO - 2021-09-09 10:20:48 --> URI Class Initialized
INFO - 2021-09-09 10:20:48 --> Router Class Initialized
INFO - 2021-09-09 10:20:48 --> Output Class Initialized
INFO - 2021-09-09 10:20:48 --> Security Class Initialized
DEBUG - 2021-09-09 10:20:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 10:20:48 --> CSRF cookie sent
INFO - 2021-09-09 10:20:48 --> Input Class Initialized
INFO - 2021-09-09 10:20:48 --> Language Class Initialized
INFO - 2021-09-09 10:20:48 --> Loader Class Initialized
INFO - 2021-09-09 10:20:48 --> Helper loaded: url_helper
INFO - 2021-09-09 10:20:48 --> Helper loaded: file_helper
INFO - 2021-09-09 10:20:48 --> Helper loaded: form_helper
INFO - 2021-09-09 10:20:48 --> Helper loaded: security_helper
INFO - 2021-09-09 10:20:48 --> Helper loaded: directory_helper
INFO - 2021-09-09 10:20:48 --> Helper loaded: general_helper
INFO - 2021-09-09 10:20:48 --> Database Driver Class Initialized
INFO - 2021-09-09 10:20:48 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 10:20:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 10:20:48 --> Pagination Class Initialized
INFO - 2021-09-09 10:20:48 --> XML-RPC Class Initialized
INFO - 2021-09-09 10:20:48 --> Form Validation Class Initialized
INFO - 2021-09-09 10:20:48 --> Upload Class Initialized
INFO - 2021-09-09 10:20:48 --> MY_Model class loaded
INFO - 2021-09-09 10:20:48 --> Model "Application_model" initialized
INFO - 2021-09-09 10:20:48 --> Controller Class Initialized
INFO - 2021-09-09 14:05:49 --> Model "Dashboard_model" initialized
INFO - 2021-09-09 14:05:49 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/header.php
INFO - 2021-09-09 14:05:49 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/topbar.php
INFO - 2021-09-09 14:05:50 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/sidebar.php
INFO - 2021-09-09 14:05:50 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\dashboard/index.php
INFO - 2021-09-09 14:05:51 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/script.php
INFO - 2021-09-09 14:05:51 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\layout/index.php
INFO - 2021-09-09 14:05:51 --> Final output sent to browser
DEBUG - 2021-09-09 14:05:51 --> Total execution time: 2.4959
INFO - 2021-09-09 10:25:13 --> Config Class Initialized
INFO - 2021-09-09 10:25:13 --> Hooks Class Initialized
DEBUG - 2021-09-09 10:25:13 --> UTF-8 Support Enabled
INFO - 2021-09-09 10:25:13 --> Utf8 Class Initialized
INFO - 2021-09-09 10:25:13 --> URI Class Initialized
INFO - 2021-09-09 10:25:13 --> Router Class Initialized
INFO - 2021-09-09 10:25:13 --> Output Class Initialized
INFO - 2021-09-09 10:25:13 --> Security Class Initialized
DEBUG - 2021-09-09 10:25:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 10:25:13 --> CSRF cookie sent
INFO - 2021-09-09 10:25:13 --> Input Class Initialized
INFO - 2021-09-09 10:25:13 --> Language Class Initialized
INFO - 2021-09-09 10:25:14 --> Loader Class Initialized
INFO - 2021-09-09 10:25:14 --> Helper loaded: url_helper
INFO - 2021-09-09 10:25:14 --> Helper loaded: file_helper
INFO - 2021-09-09 10:25:14 --> Helper loaded: form_helper
INFO - 2021-09-09 10:25:14 --> Helper loaded: security_helper
INFO - 2021-09-09 10:25:14 --> Helper loaded: directory_helper
INFO - 2021-09-09 10:25:14 --> Helper loaded: general_helper
INFO - 2021-09-09 10:25:14 --> Database Driver Class Initialized
INFO - 2021-09-09 10:25:14 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 10:25:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 10:25:14 --> Pagination Class Initialized
INFO - 2021-09-09 10:25:14 --> XML-RPC Class Initialized
INFO - 2021-09-09 10:25:14 --> Form Validation Class Initialized
INFO - 2021-09-09 10:25:14 --> Upload Class Initialized
INFO - 2021-09-09 10:25:14 --> MY_Model class loaded
INFO - 2021-09-09 10:25:14 --> Model "Application_model" initialized
INFO - 2021-09-09 10:25:14 --> Controller Class Initialized
INFO - 2021-09-09 14:10:14 --> Model "Authentication_model" initialized
INFO - 2021-09-09 10:25:14 --> Config Class Initialized
INFO - 2021-09-09 10:25:14 --> Hooks Class Initialized
DEBUG - 2021-09-09 10:25:14 --> UTF-8 Support Enabled
INFO - 2021-09-09 10:25:14 --> Utf8 Class Initialized
INFO - 2021-09-09 10:25:14 --> URI Class Initialized
DEBUG - 2021-09-09 10:25:15 --> No URI present. Default controller set.
INFO - 2021-09-09 10:25:15 --> Router Class Initialized
INFO - 2021-09-09 10:25:15 --> Output Class Initialized
INFO - 2021-09-09 10:25:15 --> Security Class Initialized
DEBUG - 2021-09-09 10:25:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 10:25:15 --> CSRF cookie sent
INFO - 2021-09-09 10:25:15 --> Input Class Initialized
INFO - 2021-09-09 10:25:15 --> Language Class Initialized
INFO - 2021-09-09 10:25:15 --> Loader Class Initialized
INFO - 2021-09-09 10:25:15 --> Helper loaded: url_helper
INFO - 2021-09-09 10:25:15 --> Helper loaded: file_helper
INFO - 2021-09-09 10:25:15 --> Helper loaded: form_helper
INFO - 2021-09-09 10:25:15 --> Helper loaded: security_helper
INFO - 2021-09-09 10:25:15 --> Helper loaded: directory_helper
INFO - 2021-09-09 10:25:15 --> Helper loaded: general_helper
INFO - 2021-09-09 10:25:15 --> Database Driver Class Initialized
INFO - 2021-09-09 10:25:15 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 10:25:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 10:25:15 --> Pagination Class Initialized
INFO - 2021-09-09 10:25:15 --> XML-RPC Class Initialized
INFO - 2021-09-09 10:25:15 --> Form Validation Class Initialized
INFO - 2021-09-09 10:25:15 --> Upload Class Initialized
INFO - 2021-09-09 10:25:15 --> MY_Model class loaded
INFO - 2021-09-09 10:25:15 --> Model "Application_model" initialized
INFO - 2021-09-09 10:25:15 --> Controller Class Initialized
INFO - 2021-09-09 14:10:15 --> Model "Home_model" initialized
INFO - 2021-09-09 10:25:15 --> Config Class Initialized
INFO - 2021-09-09 10:25:15 --> Hooks Class Initialized
DEBUG - 2021-09-09 10:25:15 --> UTF-8 Support Enabled
INFO - 2021-09-09 10:25:15 --> Utf8 Class Initialized
INFO - 2021-09-09 10:25:15 --> URI Class Initialized
INFO - 2021-09-09 10:25:15 --> Router Class Initialized
INFO - 2021-09-09 10:25:15 --> Output Class Initialized
INFO - 2021-09-09 10:25:15 --> Security Class Initialized
DEBUG - 2021-09-09 10:25:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 10:25:15 --> CSRF cookie sent
INFO - 2021-09-09 10:25:15 --> Input Class Initialized
INFO - 2021-09-09 10:25:15 --> Language Class Initialized
INFO - 2021-09-09 10:25:15 --> Loader Class Initialized
INFO - 2021-09-09 10:25:15 --> Helper loaded: url_helper
INFO - 2021-09-09 10:25:15 --> Helper loaded: file_helper
INFO - 2021-09-09 10:25:15 --> Helper loaded: form_helper
INFO - 2021-09-09 10:25:15 --> Helper loaded: security_helper
INFO - 2021-09-09 10:25:15 --> Helper loaded: directory_helper
INFO - 2021-09-09 10:25:15 --> Helper loaded: general_helper
INFO - 2021-09-09 10:25:15 --> Database Driver Class Initialized
INFO - 2021-09-09 10:25:15 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 10:25:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 10:25:15 --> Pagination Class Initialized
INFO - 2021-09-09 10:25:15 --> XML-RPC Class Initialized
INFO - 2021-09-09 10:25:15 --> Form Validation Class Initialized
INFO - 2021-09-09 10:25:15 --> Upload Class Initialized
INFO - 2021-09-09 10:25:15 --> MY_Model class loaded
INFO - 2021-09-09 10:25:15 --> Model "Application_model" initialized
INFO - 2021-09-09 10:25:15 --> Controller Class Initialized
INFO - 2021-09-09 14:10:15 --> Model "Authentication_model" initialized
INFO - 2021-09-09 14:10:15 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\authentication/login.php
INFO - 2021-09-09 14:10:15 --> Final output sent to browser
DEBUG - 2021-09-09 14:10:15 --> Total execution time: 0.2589
INFO - 2021-09-09 11:04:02 --> Config Class Initialized
INFO - 2021-09-09 11:04:02 --> Hooks Class Initialized
DEBUG - 2021-09-09 11:04:02 --> UTF-8 Support Enabled
INFO - 2021-09-09 11:04:02 --> Utf8 Class Initialized
INFO - 2021-09-09 11:04:02 --> URI Class Initialized
INFO - 2021-09-09 11:04:02 --> Router Class Initialized
INFO - 2021-09-09 11:04:02 --> Output Class Initialized
INFO - 2021-09-09 11:04:02 --> Security Class Initialized
DEBUG - 2021-09-09 11:04:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 11:04:02 --> Input Class Initialized
INFO - 2021-09-09 11:04:03 --> Language Class Initialized
INFO - 2021-09-09 11:04:03 --> Loader Class Initialized
INFO - 2021-09-09 11:04:03 --> Helper loaded: url_helper
INFO - 2021-09-09 11:04:03 --> Helper loaded: file_helper
INFO - 2021-09-09 11:04:03 --> Helper loaded: form_helper
INFO - 2021-09-09 11:04:03 --> Helper loaded: security_helper
INFO - 2021-09-09 11:04:03 --> Helper loaded: directory_helper
INFO - 2021-09-09 11:04:03 --> Helper loaded: general_helper
INFO - 2021-09-09 11:04:03 --> Database Driver Class Initialized
INFO - 2021-09-09 11:04:03 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 11:04:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 11:04:04 --> Pagination Class Initialized
INFO - 2021-09-09 11:04:04 --> XML-RPC Class Initialized
INFO - 2021-09-09 11:04:04 --> Form Validation Class Initialized
INFO - 2021-09-09 11:04:04 --> Upload Class Initialized
INFO - 2021-09-09 11:04:04 --> MY_Model class loaded
INFO - 2021-09-09 11:04:04 --> Model "Application_model" initialized
INFO - 2021-09-09 11:04:04 --> Controller Class Initialized
INFO - 2021-09-09 11:04:04 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\errors/error_404_message.php
INFO - 2021-09-09 11:04:04 --> Final output sent to browser
DEBUG - 2021-09-09 11:04:04 --> Total execution time: 1.7079
INFO - 2021-09-09 11:04:23 --> Config Class Initialized
INFO - 2021-09-09 11:04:23 --> Hooks Class Initialized
DEBUG - 2021-09-09 11:04:23 --> UTF-8 Support Enabled
INFO - 2021-09-09 11:04:23 --> Utf8 Class Initialized
INFO - 2021-09-09 11:04:23 --> URI Class Initialized
INFO - 2021-09-09 11:04:23 --> Router Class Initialized
INFO - 2021-09-09 11:04:23 --> Output Class Initialized
INFO - 2021-09-09 11:04:23 --> Security Class Initialized
DEBUG - 2021-09-09 11:04:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 11:04:23 --> Input Class Initialized
INFO - 2021-09-09 11:04:23 --> Language Class Initialized
INFO - 2021-09-09 11:04:23 --> Loader Class Initialized
INFO - 2021-09-09 11:04:23 --> Helper loaded: url_helper
INFO - 2021-09-09 11:04:23 --> Helper loaded: file_helper
INFO - 2021-09-09 11:04:23 --> Helper loaded: form_helper
INFO - 2021-09-09 11:04:23 --> Helper loaded: security_helper
INFO - 2021-09-09 11:04:23 --> Helper loaded: directory_helper
INFO - 2021-09-09 11:04:23 --> Helper loaded: general_helper
INFO - 2021-09-09 11:04:23 --> Database Driver Class Initialized
INFO - 2021-09-09 11:04:23 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 11:04:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 11:04:23 --> Pagination Class Initialized
INFO - 2021-09-09 11:04:23 --> XML-RPC Class Initialized
INFO - 2021-09-09 11:04:23 --> Form Validation Class Initialized
INFO - 2021-09-09 11:04:23 --> Upload Class Initialized
INFO - 2021-09-09 11:04:23 --> MY_Model class loaded
INFO - 2021-09-09 11:04:23 --> Model "Application_model" initialized
INFO - 2021-09-09 11:04:23 --> Controller Class Initialized
INFO - 2021-09-09 11:04:23 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\errors/error_404_message.php
INFO - 2021-09-09 11:04:23 --> Final output sent to browser
DEBUG - 2021-09-09 11:04:23 --> Total execution time: 0.1599
INFO - 2021-09-09 11:04:28 --> Config Class Initialized
INFO - 2021-09-09 11:04:28 --> Hooks Class Initialized
DEBUG - 2021-09-09 11:04:28 --> UTF-8 Support Enabled
INFO - 2021-09-09 11:04:28 --> Utf8 Class Initialized
INFO - 2021-09-09 11:04:28 --> URI Class Initialized
INFO - 2021-09-09 11:04:28 --> Router Class Initialized
INFO - 2021-09-09 11:04:28 --> Output Class Initialized
INFO - 2021-09-09 11:04:28 --> Security Class Initialized
DEBUG - 2021-09-09 11:04:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 11:04:28 --> Input Class Initialized
INFO - 2021-09-09 11:04:28 --> Language Class Initialized
INFO - 2021-09-09 11:04:29 --> Loader Class Initialized
INFO - 2021-09-09 11:04:29 --> Helper loaded: url_helper
INFO - 2021-09-09 11:04:29 --> Helper loaded: file_helper
INFO - 2021-09-09 11:04:29 --> Helper loaded: form_helper
INFO - 2021-09-09 11:04:29 --> Helper loaded: security_helper
INFO - 2021-09-09 11:04:29 --> Helper loaded: directory_helper
INFO - 2021-09-09 11:04:29 --> Helper loaded: general_helper
INFO - 2021-09-09 11:04:29 --> Database Driver Class Initialized
INFO - 2021-09-09 11:04:29 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 11:04:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 11:04:29 --> Pagination Class Initialized
INFO - 2021-09-09 11:04:29 --> XML-RPC Class Initialized
INFO - 2021-09-09 11:04:29 --> Form Validation Class Initialized
INFO - 2021-09-09 11:04:29 --> Upload Class Initialized
INFO - 2021-09-09 11:04:29 --> MY_Model class loaded
INFO - 2021-09-09 11:04:29 --> Model "Application_model" initialized
INFO - 2021-09-09 11:04:29 --> Controller Class Initialized
INFO - 2021-09-09 11:04:29 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\errors/error_404_message.php
INFO - 2021-09-09 11:04:29 --> Final output sent to browser
DEBUG - 2021-09-09 11:04:29 --> Total execution time: 0.1084
INFO - 2021-09-09 11:25:44 --> Config Class Initialized
INFO - 2021-09-09 11:25:44 --> Hooks Class Initialized
DEBUG - 2021-09-09 11:25:44 --> UTF-8 Support Enabled
INFO - 2021-09-09 11:25:44 --> Utf8 Class Initialized
INFO - 2021-09-09 11:25:44 --> URI Class Initialized
INFO - 2021-09-09 11:25:44 --> Router Class Initialized
INFO - 2021-09-09 11:25:45 --> Output Class Initialized
INFO - 2021-09-09 11:25:45 --> Security Class Initialized
DEBUG - 2021-09-09 11:25:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 11:25:45 --> CSRF cookie sent
INFO - 2021-09-09 11:25:45 --> Input Class Initialized
INFO - 2021-09-09 11:25:45 --> Language Class Initialized
INFO - 2021-09-09 11:25:45 --> Loader Class Initialized
INFO - 2021-09-09 11:25:45 --> Helper loaded: url_helper
INFO - 2021-09-09 11:25:45 --> Helper loaded: file_helper
INFO - 2021-09-09 11:25:45 --> Helper loaded: form_helper
INFO - 2021-09-09 11:25:45 --> Helper loaded: security_helper
INFO - 2021-09-09 11:25:45 --> Helper loaded: directory_helper
INFO - 2021-09-09 11:25:45 --> Helper loaded: general_helper
INFO - 2021-09-09 11:25:46 --> Database Driver Class Initialized
INFO - 2021-09-09 11:25:48 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 11:25:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 11:25:48 --> Pagination Class Initialized
INFO - 2021-09-09 11:25:48 --> XML-RPC Class Initialized
INFO - 2021-09-09 11:25:48 --> Form Validation Class Initialized
INFO - 2021-09-09 11:25:48 --> Upload Class Initialized
INFO - 2021-09-09 11:25:48 --> MY_Model class loaded
INFO - 2021-09-09 11:25:48 --> Model "Application_model" initialized
INFO - 2021-09-09 11:25:48 --> Controller Class Initialized
INFO - 2021-09-09 15:10:48 --> Model "Authentication_model" initialized
INFO - 2021-09-09 15:10:48 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\authentication/login.php
INFO - 2021-09-09 15:10:48 --> Final output sent to browser
DEBUG - 2021-09-09 15:10:48 --> Total execution time: 4.6857
INFO - 2021-09-09 11:26:15 --> Config Class Initialized
INFO - 2021-09-09 11:26:15 --> Hooks Class Initialized
DEBUG - 2021-09-09 11:26:15 --> UTF-8 Support Enabled
INFO - 2021-09-09 11:26:15 --> Utf8 Class Initialized
INFO - 2021-09-09 11:26:15 --> URI Class Initialized
INFO - 2021-09-09 11:26:15 --> Router Class Initialized
INFO - 2021-09-09 11:26:15 --> Output Class Initialized
INFO - 2021-09-09 11:26:15 --> Security Class Initialized
DEBUG - 2021-09-09 11:26:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 11:26:15 --> Input Class Initialized
INFO - 2021-09-09 11:26:15 --> Language Class Initialized
INFO - 2021-09-09 11:26:15 --> Loader Class Initialized
INFO - 2021-09-09 11:26:15 --> Helper loaded: url_helper
INFO - 2021-09-09 11:26:15 --> Helper loaded: file_helper
INFO - 2021-09-09 11:26:15 --> Helper loaded: form_helper
INFO - 2021-09-09 11:26:15 --> Helper loaded: security_helper
INFO - 2021-09-09 11:26:15 --> Helper loaded: directory_helper
INFO - 2021-09-09 11:26:15 --> Helper loaded: general_helper
INFO - 2021-09-09 11:26:15 --> Database Driver Class Initialized
INFO - 2021-09-09 11:26:16 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 11:26:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 11:26:16 --> Pagination Class Initialized
INFO - 2021-09-09 11:26:16 --> XML-RPC Class Initialized
INFO - 2021-09-09 11:26:16 --> Form Validation Class Initialized
INFO - 2021-09-09 11:26:16 --> Upload Class Initialized
INFO - 2021-09-09 11:26:16 --> MY_Model class loaded
INFO - 2021-09-09 11:26:16 --> Model "Application_model" initialized
INFO - 2021-09-09 11:26:16 --> Controller Class Initialized
INFO - 2021-09-09 11:26:17 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\errors/error_404_message.php
INFO - 2021-09-09 11:26:17 --> Final output sent to browser
DEBUG - 2021-09-09 11:26:17 --> Total execution time: 1.7834
INFO - 2021-09-09 11:26:45 --> Config Class Initialized
INFO - 2021-09-09 11:26:45 --> Hooks Class Initialized
DEBUG - 2021-09-09 11:26:45 --> UTF-8 Support Enabled
INFO - 2021-09-09 11:26:45 --> Utf8 Class Initialized
INFO - 2021-09-09 11:26:45 --> URI Class Initialized
INFO - 2021-09-09 11:26:45 --> Router Class Initialized
INFO - 2021-09-09 11:26:45 --> Output Class Initialized
INFO - 2021-09-09 11:26:45 --> Security Class Initialized
DEBUG - 2021-09-09 11:26:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 11:26:45 --> Input Class Initialized
INFO - 2021-09-09 11:26:45 --> Language Class Initialized
INFO - 2021-09-09 11:26:45 --> Loader Class Initialized
INFO - 2021-09-09 11:26:45 --> Helper loaded: url_helper
INFO - 2021-09-09 11:26:45 --> Helper loaded: file_helper
INFO - 2021-09-09 11:26:45 --> Helper loaded: form_helper
INFO - 2021-09-09 11:26:45 --> Helper loaded: security_helper
INFO - 2021-09-09 11:26:45 --> Helper loaded: directory_helper
INFO - 2021-09-09 11:26:45 --> Helper loaded: general_helper
INFO - 2021-09-09 11:26:45 --> Database Driver Class Initialized
INFO - 2021-09-09 11:26:45 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 11:26:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 11:26:45 --> Pagination Class Initialized
INFO - 2021-09-09 11:26:45 --> XML-RPC Class Initialized
INFO - 2021-09-09 11:26:45 --> Form Validation Class Initialized
INFO - 2021-09-09 11:26:45 --> Upload Class Initialized
INFO - 2021-09-09 11:26:45 --> MY_Model class loaded
INFO - 2021-09-09 11:26:45 --> Model "Application_model" initialized
INFO - 2021-09-09 11:26:45 --> Controller Class Initialized
DEBUG - 2021-09-09 11:26:45 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-09 11:26:45 --> Helper loaded: inflector_helper
INFO - 2021-09-09 11:26:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-09 11:26:45 --> Database Driver Class Initialized
ERROR - 2021-09-09 11:26:46 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 11:26:46 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 11:26:46 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-09 11:26:46 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-09 11:26:46 --> Model "Authentication_model" initialized
INFO - 2021-09-09 11:26:46 --> Model "Branch_model" initialized
INFO - 2021-09-09 11:26:46 --> Final output sent to browser
DEBUG - 2021-09-09 11:26:46 --> Total execution time: 1.2870
INFO - 2021-09-09 11:36:27 --> Config Class Initialized
INFO - 2021-09-09 11:36:27 --> Hooks Class Initialized
DEBUG - 2021-09-09 11:36:28 --> UTF-8 Support Enabled
INFO - 2021-09-09 11:36:28 --> Utf8 Class Initialized
INFO - 2021-09-09 11:36:28 --> URI Class Initialized
INFO - 2021-09-09 11:36:28 --> Router Class Initialized
INFO - 2021-09-09 11:36:28 --> Output Class Initialized
INFO - 2021-09-09 11:36:28 --> Security Class Initialized
DEBUG - 2021-09-09 11:36:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 11:36:28 --> CSRF cookie sent
INFO - 2021-09-09 11:36:28 --> Input Class Initialized
INFO - 2021-09-09 11:36:28 --> Language Class Initialized
INFO - 2021-09-09 11:36:28 --> Loader Class Initialized
INFO - 2021-09-09 11:36:28 --> Helper loaded: url_helper
INFO - 2021-09-09 11:36:28 --> Helper loaded: file_helper
INFO - 2021-09-09 11:36:28 --> Helper loaded: form_helper
INFO - 2021-09-09 11:36:28 --> Helper loaded: security_helper
INFO - 2021-09-09 11:36:28 --> Helper loaded: directory_helper
INFO - 2021-09-09 11:36:28 --> Helper loaded: general_helper
INFO - 2021-09-09 11:36:29 --> Database Driver Class Initialized
INFO - 2021-09-09 11:36:29 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 11:36:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 11:36:29 --> Pagination Class Initialized
INFO - 2021-09-09 11:36:29 --> XML-RPC Class Initialized
INFO - 2021-09-09 11:36:29 --> Form Validation Class Initialized
INFO - 2021-09-09 11:36:29 --> Upload Class Initialized
INFO - 2021-09-09 11:36:29 --> MY_Model class loaded
INFO - 2021-09-09 11:36:29 --> Model "Application_model" initialized
INFO - 2021-09-09 11:36:29 --> Controller Class Initialized
INFO - 2021-09-09 11:36:29 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\errors/error_404_message.php
INFO - 2021-09-09 11:36:29 --> Final output sent to browser
DEBUG - 2021-09-09 11:36:29 --> Total execution time: 2.0212
INFO - 2021-09-09 11:36:46 --> Config Class Initialized
INFO - 2021-09-09 11:36:46 --> Hooks Class Initialized
DEBUG - 2021-09-09 11:36:46 --> UTF-8 Support Enabled
INFO - 2021-09-09 11:36:46 --> Utf8 Class Initialized
INFO - 2021-09-09 11:36:46 --> URI Class Initialized
INFO - 2021-09-09 11:36:46 --> Router Class Initialized
INFO - 2021-09-09 11:36:46 --> Output Class Initialized
INFO - 2021-09-09 11:36:46 --> Security Class Initialized
DEBUG - 2021-09-09 11:36:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 11:36:46 --> CSRF cookie sent
INFO - 2021-09-09 11:36:46 --> Input Class Initialized
INFO - 2021-09-09 11:36:46 --> Language Class Initialized
INFO - 2021-09-09 11:36:46 --> Loader Class Initialized
INFO - 2021-09-09 11:36:46 --> Helper loaded: url_helper
INFO - 2021-09-09 11:36:46 --> Helper loaded: file_helper
INFO - 2021-09-09 11:36:46 --> Helper loaded: form_helper
INFO - 2021-09-09 11:36:46 --> Helper loaded: security_helper
INFO - 2021-09-09 11:36:46 --> Helper loaded: directory_helper
INFO - 2021-09-09 11:36:46 --> Helper loaded: general_helper
INFO - 2021-09-09 11:36:46 --> Database Driver Class Initialized
INFO - 2021-09-09 11:36:46 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 11:36:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 11:36:46 --> Pagination Class Initialized
INFO - 2021-09-09 11:36:46 --> XML-RPC Class Initialized
INFO - 2021-09-09 11:36:46 --> Form Validation Class Initialized
INFO - 2021-09-09 11:36:46 --> Upload Class Initialized
INFO - 2021-09-09 11:36:46 --> MY_Model class loaded
INFO - 2021-09-09 11:36:46 --> Model "Application_model" initialized
INFO - 2021-09-09 11:36:46 --> Controller Class Initialized
DEBUG - 2021-09-09 11:36:46 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-09 11:36:46 --> Helper loaded: inflector_helper
INFO - 2021-09-09 11:36:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-09 11:36:46 --> Database Driver Class Initialized
ERROR - 2021-09-09 11:36:47 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 11:36:47 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 11:36:47 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-09 11:36:47 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-09 11:36:47 --> Model "Authentication_model" initialized
INFO - 2021-09-09 11:36:47 --> Model "Branch_model" initialized
INFO - 2021-09-09 11:36:47 --> Final output sent to browser
DEBUG - 2021-09-09 11:36:47 --> Total execution time: 0.3669
INFO - 2021-09-09 11:39:42 --> Config Class Initialized
INFO - 2021-09-09 11:39:42 --> Hooks Class Initialized
DEBUG - 2021-09-09 11:39:42 --> UTF-8 Support Enabled
INFO - 2021-09-09 11:39:42 --> Utf8 Class Initialized
INFO - 2021-09-09 11:39:42 --> URI Class Initialized
INFO - 2021-09-09 11:39:42 --> Router Class Initialized
INFO - 2021-09-09 11:39:42 --> Output Class Initialized
INFO - 2021-09-09 11:39:42 --> Security Class Initialized
DEBUG - 2021-09-09 11:39:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 11:39:42 --> Input Class Initialized
INFO - 2021-09-09 11:39:42 --> Language Class Initialized
INFO - 2021-09-09 11:39:42 --> Loader Class Initialized
INFO - 2021-09-09 11:39:42 --> Helper loaded: url_helper
INFO - 2021-09-09 11:39:42 --> Helper loaded: file_helper
INFO - 2021-09-09 11:39:42 --> Helper loaded: form_helper
INFO - 2021-09-09 11:39:42 --> Helper loaded: security_helper
INFO - 2021-09-09 11:39:42 --> Helper loaded: directory_helper
INFO - 2021-09-09 11:39:42 --> Helper loaded: general_helper
INFO - 2021-09-09 11:39:42 --> Database Driver Class Initialized
INFO - 2021-09-09 11:39:42 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 11:39:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 11:39:42 --> Pagination Class Initialized
INFO - 2021-09-09 11:39:42 --> XML-RPC Class Initialized
INFO - 2021-09-09 11:39:42 --> Form Validation Class Initialized
INFO - 2021-09-09 11:39:42 --> Upload Class Initialized
INFO - 2021-09-09 11:39:42 --> MY_Model class loaded
INFO - 2021-09-09 11:39:42 --> Model "Application_model" initialized
INFO - 2021-09-09 11:39:42 --> Controller Class Initialized
DEBUG - 2021-09-09 11:39:42 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-09 11:39:42 --> Helper loaded: inflector_helper
INFO - 2021-09-09 11:39:42 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-09 11:39:42 --> Database Driver Class Initialized
ERROR - 2021-09-09 11:39:42 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 11:39:42 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 11:39:42 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-09 11:39:42 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-09 11:39:42 --> Model "Authentication_model" initialized
INFO - 2021-09-09 11:39:42 --> Model "Branch_model" initialized
INFO - 2021-09-09 11:39:42 --> Final output sent to browser
DEBUG - 2021-09-09 11:39:42 --> Total execution time: 0.3610
INFO - 2021-09-09 11:41:04 --> Config Class Initialized
INFO - 2021-09-09 11:41:04 --> Hooks Class Initialized
DEBUG - 2021-09-09 11:41:04 --> UTF-8 Support Enabled
INFO - 2021-09-09 11:41:04 --> Utf8 Class Initialized
INFO - 2021-09-09 11:41:04 --> URI Class Initialized
INFO - 2021-09-09 11:41:04 --> Router Class Initialized
INFO - 2021-09-09 11:41:04 --> Output Class Initialized
INFO - 2021-09-09 11:41:04 --> Security Class Initialized
DEBUG - 2021-09-09 11:41:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 11:41:04 --> CSRF cookie sent
INFO - 2021-09-09 11:41:04 --> Input Class Initialized
INFO - 2021-09-09 11:41:04 --> Language Class Initialized
INFO - 2021-09-09 11:41:04 --> Loader Class Initialized
INFO - 2021-09-09 11:41:04 --> Helper loaded: url_helper
INFO - 2021-09-09 11:41:04 --> Helper loaded: file_helper
INFO - 2021-09-09 11:41:04 --> Helper loaded: form_helper
INFO - 2021-09-09 11:41:04 --> Helper loaded: security_helper
INFO - 2021-09-09 11:41:04 --> Helper loaded: directory_helper
INFO - 2021-09-09 11:41:04 --> Helper loaded: general_helper
INFO - 2021-09-09 11:41:04 --> Database Driver Class Initialized
INFO - 2021-09-09 11:41:04 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 11:41:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 11:41:04 --> Pagination Class Initialized
INFO - 2021-09-09 11:41:04 --> XML-RPC Class Initialized
INFO - 2021-09-09 11:41:04 --> Form Validation Class Initialized
INFO - 2021-09-09 11:41:04 --> Upload Class Initialized
INFO - 2021-09-09 11:41:04 --> MY_Model class loaded
INFO - 2021-09-09 11:41:04 --> Model "Application_model" initialized
INFO - 2021-09-09 11:41:04 --> Controller Class Initialized
INFO - 2021-09-09 15:26:04 --> Model "Authentication_model" initialized
INFO - 2021-09-09 15:26:04 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\authentication/login.php
INFO - 2021-09-09 15:26:04 --> Final output sent to browser
DEBUG - 2021-09-09 15:26:04 --> Total execution time: 0.3912
INFO - 2021-09-09 11:41:31 --> Config Class Initialized
INFO - 2021-09-09 11:41:31 --> Hooks Class Initialized
DEBUG - 2021-09-09 11:41:31 --> UTF-8 Support Enabled
INFO - 2021-09-09 11:41:31 --> Utf8 Class Initialized
INFO - 2021-09-09 11:41:31 --> URI Class Initialized
INFO - 2021-09-09 11:41:31 --> Router Class Initialized
INFO - 2021-09-09 11:41:31 --> Output Class Initialized
INFO - 2021-09-09 11:41:31 --> Security Class Initialized
DEBUG - 2021-09-09 11:41:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 11:41:31 --> Input Class Initialized
INFO - 2021-09-09 11:41:31 --> Language Class Initialized
INFO - 2021-09-09 11:41:31 --> Loader Class Initialized
INFO - 2021-09-09 11:41:31 --> Helper loaded: url_helper
INFO - 2021-09-09 11:41:31 --> Helper loaded: file_helper
INFO - 2021-09-09 11:41:31 --> Helper loaded: form_helper
INFO - 2021-09-09 11:41:31 --> Helper loaded: security_helper
INFO - 2021-09-09 11:41:31 --> Helper loaded: directory_helper
INFO - 2021-09-09 11:41:31 --> Helper loaded: general_helper
INFO - 2021-09-09 11:41:31 --> Database Driver Class Initialized
INFO - 2021-09-09 11:41:31 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 11:41:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 11:41:31 --> Pagination Class Initialized
INFO - 2021-09-09 11:41:31 --> XML-RPC Class Initialized
INFO - 2021-09-09 11:41:31 --> Form Validation Class Initialized
INFO - 2021-09-09 11:41:31 --> Upload Class Initialized
INFO - 2021-09-09 11:41:31 --> MY_Model class loaded
INFO - 2021-09-09 11:41:31 --> Model "Application_model" initialized
INFO - 2021-09-09 11:41:31 --> Controller Class Initialized
DEBUG - 2021-09-09 11:41:31 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-09 11:41:31 --> Helper loaded: inflector_helper
INFO - 2021-09-09 11:41:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-09 11:41:31 --> Database Driver Class Initialized
ERROR - 2021-09-09 11:41:31 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 11:41:31 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 11:41:31 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-09 11:41:31 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-09 11:41:31 --> Model "Authentication_model" initialized
INFO - 2021-09-09 11:41:31 --> Model "Branch_model" initialized
INFO - 2021-09-09 11:41:31 --> Final output sent to browser
DEBUG - 2021-09-09 11:41:31 --> Total execution time: 0.5500
INFO - 2021-09-09 12:14:19 --> Config Class Initialized
INFO - 2021-09-09 12:14:19 --> Hooks Class Initialized
DEBUG - 2021-09-09 12:14:19 --> UTF-8 Support Enabled
INFO - 2021-09-09 12:14:19 --> Utf8 Class Initialized
INFO - 2021-09-09 12:14:20 --> URI Class Initialized
INFO - 2021-09-09 12:14:20 --> Router Class Initialized
INFO - 2021-09-09 12:14:20 --> Output Class Initialized
INFO - 2021-09-09 12:14:20 --> Security Class Initialized
DEBUG - 2021-09-09 12:14:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 12:14:20 --> Input Class Initialized
INFO - 2021-09-09 12:14:20 --> Language Class Initialized
INFO - 2021-09-09 12:14:21 --> Loader Class Initialized
INFO - 2021-09-09 12:14:22 --> Helper loaded: url_helper
INFO - 2021-09-09 12:14:23 --> Helper loaded: file_helper
INFO - 2021-09-09 12:14:23 --> Helper loaded: form_helper
INFO - 2021-09-09 12:14:23 --> Helper loaded: security_helper
INFO - 2021-09-09 12:14:23 --> Helper loaded: directory_helper
INFO - 2021-09-09 12:14:23 --> Helper loaded: general_helper
INFO - 2021-09-09 12:14:24 --> Database Driver Class Initialized
INFO - 2021-09-09 12:14:27 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 12:14:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 12:14:28 --> Pagination Class Initialized
INFO - 2021-09-09 12:14:28 --> XML-RPC Class Initialized
INFO - 2021-09-09 12:14:28 --> Form Validation Class Initialized
INFO - 2021-09-09 12:14:28 --> Upload Class Initialized
INFO - 2021-09-09 12:14:29 --> MY_Model class loaded
INFO - 2021-09-09 12:14:29 --> Model "Application_model" initialized
INFO - 2021-09-09 12:14:29 --> Controller Class Initialized
DEBUG - 2021-09-09 12:14:29 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-09 12:14:29 --> Helper loaded: inflector_helper
INFO - 2021-09-09 12:14:29 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-09 12:14:29 --> Database Driver Class Initialized
ERROR - 2021-09-09 12:14:29 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 12:14:29 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 12:14:29 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-09 12:14:29 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-09 12:14:29 --> Model "Authentication_model" initialized
INFO - 2021-09-09 12:14:29 --> Model "Branch_model" initialized
INFO - 2021-09-09 12:14:30 --> Final output sent to browser
DEBUG - 2021-09-09 12:14:30 --> Total execution time: 11.7028
INFO - 2021-09-09 12:16:43 --> Config Class Initialized
INFO - 2021-09-09 12:16:43 --> Hooks Class Initialized
DEBUG - 2021-09-09 12:16:43 --> UTF-8 Support Enabled
INFO - 2021-09-09 12:16:43 --> Utf8 Class Initialized
INFO - 2021-09-09 12:16:43 --> URI Class Initialized
INFO - 2021-09-09 12:16:43 --> Router Class Initialized
INFO - 2021-09-09 12:16:43 --> Output Class Initialized
INFO - 2021-09-09 12:16:43 --> Security Class Initialized
DEBUG - 2021-09-09 12:16:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 12:16:43 --> CSRF cookie sent
INFO - 2021-09-09 12:16:43 --> Input Class Initialized
INFO - 2021-09-09 12:16:44 --> Language Class Initialized
INFO - 2021-09-09 12:16:45 --> Loader Class Initialized
INFO - 2021-09-09 12:16:45 --> Helper loaded: url_helper
INFO - 2021-09-09 12:16:46 --> Helper loaded: file_helper
INFO - 2021-09-09 12:16:46 --> Helper loaded: form_helper
INFO - 2021-09-09 12:16:46 --> Helper loaded: security_helper
INFO - 2021-09-09 12:16:46 --> Helper loaded: directory_helper
INFO - 2021-09-09 12:16:47 --> Helper loaded: general_helper
INFO - 2021-09-09 12:16:47 --> Database Driver Class Initialized
INFO - 2021-09-09 12:16:48 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 12:16:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 12:16:48 --> Pagination Class Initialized
INFO - 2021-09-09 12:16:48 --> XML-RPC Class Initialized
INFO - 2021-09-09 12:16:48 --> Form Validation Class Initialized
INFO - 2021-09-09 12:16:48 --> Upload Class Initialized
INFO - 2021-09-09 12:16:49 --> MY_Model class loaded
INFO - 2021-09-09 12:16:49 --> Model "Application_model" initialized
INFO - 2021-09-09 12:16:49 --> Controller Class Initialized
DEBUG - 2021-09-09 12:16:49 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-09 12:16:49 --> Helper loaded: inflector_helper
INFO - 2021-09-09 12:16:49 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-09 12:16:49 --> Database Driver Class Initialized
ERROR - 2021-09-09 12:16:49 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 12:16:49 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 12:16:49 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-09 12:16:49 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-09 12:16:49 --> Model "Authentication_model" initialized
INFO - 2021-09-09 12:16:49 --> Model "Student_model" initialized
INFO - 2021-09-09 12:16:49 --> Final output sent to browser
DEBUG - 2021-09-09 12:16:49 --> Total execution time: 6.3819
INFO - 2021-09-09 12:17:32 --> Config Class Initialized
INFO - 2021-09-09 12:17:32 --> Hooks Class Initialized
DEBUG - 2021-09-09 12:17:32 --> UTF-8 Support Enabled
INFO - 2021-09-09 12:17:32 --> Utf8 Class Initialized
INFO - 2021-09-09 12:17:32 --> URI Class Initialized
INFO - 2021-09-09 12:17:32 --> Router Class Initialized
INFO - 2021-09-09 12:17:32 --> Output Class Initialized
INFO - 2021-09-09 12:17:32 --> Security Class Initialized
DEBUG - 2021-09-09 12:17:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 12:17:32 --> CSRF cookie sent
INFO - 2021-09-09 12:17:32 --> Input Class Initialized
INFO - 2021-09-09 12:17:32 --> Language Class Initialized
INFO - 2021-09-09 12:17:32 --> Loader Class Initialized
INFO - 2021-09-09 12:17:32 --> Helper loaded: url_helper
INFO - 2021-09-09 12:17:32 --> Helper loaded: file_helper
INFO - 2021-09-09 12:17:32 --> Helper loaded: form_helper
INFO - 2021-09-09 12:17:32 --> Helper loaded: security_helper
INFO - 2021-09-09 12:17:32 --> Helper loaded: directory_helper
INFO - 2021-09-09 12:17:32 --> Helper loaded: general_helper
INFO - 2021-09-09 12:17:32 --> Database Driver Class Initialized
INFO - 2021-09-09 12:17:32 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 12:17:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 12:17:32 --> Pagination Class Initialized
INFO - 2021-09-09 12:17:32 --> XML-RPC Class Initialized
INFO - 2021-09-09 12:17:32 --> Form Validation Class Initialized
INFO - 2021-09-09 12:17:32 --> Upload Class Initialized
INFO - 2021-09-09 12:17:32 --> MY_Model class loaded
INFO - 2021-09-09 12:17:32 --> Model "Application_model" initialized
INFO - 2021-09-09 12:17:32 --> Controller Class Initialized
DEBUG - 2021-09-09 12:17:32 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-09 12:17:32 --> Helper loaded: inflector_helper
INFO - 2021-09-09 12:17:32 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-09 12:17:32 --> Database Driver Class Initialized
ERROR - 2021-09-09 12:17:32 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 12:17:32 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 12:17:32 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-09 12:17:32 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-09 12:17:32 --> Model "Authentication_model" initialized
INFO - 2021-09-09 12:17:32 --> Model "Student_model" initialized
INFO - 2021-09-09 12:17:32 --> Final output sent to browser
DEBUG - 2021-09-09 12:17:32 --> Total execution time: 0.2060
INFO - 2021-09-09 12:18:30 --> Config Class Initialized
INFO - 2021-09-09 12:18:30 --> Hooks Class Initialized
DEBUG - 2021-09-09 12:18:30 --> UTF-8 Support Enabled
INFO - 2021-09-09 12:18:30 --> Utf8 Class Initialized
INFO - 2021-09-09 12:18:30 --> URI Class Initialized
INFO - 2021-09-09 12:18:30 --> Router Class Initialized
INFO - 2021-09-09 12:18:30 --> Output Class Initialized
INFO - 2021-09-09 12:18:30 --> Security Class Initialized
DEBUG - 2021-09-09 12:18:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 12:18:30 --> CSRF cookie sent
INFO - 2021-09-09 12:18:30 --> Input Class Initialized
INFO - 2021-09-09 12:18:30 --> Language Class Initialized
INFO - 2021-09-09 12:18:30 --> Loader Class Initialized
INFO - 2021-09-09 12:18:30 --> Helper loaded: url_helper
INFO - 2021-09-09 12:18:30 --> Helper loaded: file_helper
INFO - 2021-09-09 12:18:30 --> Helper loaded: form_helper
INFO - 2021-09-09 12:18:30 --> Helper loaded: security_helper
INFO - 2021-09-09 12:18:30 --> Helper loaded: directory_helper
INFO - 2021-09-09 12:18:30 --> Helper loaded: general_helper
INFO - 2021-09-09 12:18:30 --> Database Driver Class Initialized
INFO - 2021-09-09 12:18:30 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 12:18:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 12:18:30 --> Pagination Class Initialized
INFO - 2021-09-09 12:18:30 --> XML-RPC Class Initialized
INFO - 2021-09-09 12:18:30 --> Form Validation Class Initialized
INFO - 2021-09-09 12:18:30 --> Upload Class Initialized
INFO - 2021-09-09 12:18:30 --> MY_Model class loaded
INFO - 2021-09-09 12:18:30 --> Model "Application_model" initialized
INFO - 2021-09-09 12:18:30 --> Controller Class Initialized
DEBUG - 2021-09-09 12:18:30 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-09 12:18:30 --> Helper loaded: inflector_helper
INFO - 2021-09-09 12:18:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-09 12:18:30 --> Database Driver Class Initialized
ERROR - 2021-09-09 12:18:30 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 12:18:30 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 12:18:30 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-09 12:18:30 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-09 12:18:30 --> Model "Authentication_model" initialized
INFO - 2021-09-09 12:18:30 --> Model "Student_model" initialized
INFO - 2021-09-09 12:18:30 --> Final output sent to browser
DEBUG - 2021-09-09 12:18:30 --> Total execution time: 0.1642
INFO - 2021-09-09 12:19:24 --> Config Class Initialized
INFO - 2021-09-09 12:19:24 --> Hooks Class Initialized
DEBUG - 2021-09-09 12:19:24 --> UTF-8 Support Enabled
INFO - 2021-09-09 12:19:24 --> Utf8 Class Initialized
INFO - 2021-09-09 12:19:24 --> URI Class Initialized
INFO - 2021-09-09 12:19:24 --> Router Class Initialized
INFO - 2021-09-09 12:19:24 --> Output Class Initialized
INFO - 2021-09-09 12:19:24 --> Security Class Initialized
DEBUG - 2021-09-09 12:19:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 12:19:24 --> CSRF cookie sent
INFO - 2021-09-09 12:19:24 --> Input Class Initialized
INFO - 2021-09-09 12:19:24 --> Language Class Initialized
INFO - 2021-09-09 12:19:24 --> Loader Class Initialized
INFO - 2021-09-09 12:19:24 --> Helper loaded: url_helper
INFO - 2021-09-09 12:19:24 --> Helper loaded: file_helper
INFO - 2021-09-09 12:19:24 --> Helper loaded: form_helper
INFO - 2021-09-09 12:19:24 --> Helper loaded: security_helper
INFO - 2021-09-09 12:19:24 --> Helper loaded: directory_helper
INFO - 2021-09-09 12:19:24 --> Helper loaded: general_helper
INFO - 2021-09-09 12:19:24 --> Database Driver Class Initialized
INFO - 2021-09-09 12:19:24 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 12:19:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 12:19:24 --> Pagination Class Initialized
INFO - 2021-09-09 12:19:24 --> XML-RPC Class Initialized
INFO - 2021-09-09 12:19:24 --> Form Validation Class Initialized
INFO - 2021-09-09 12:19:24 --> Upload Class Initialized
INFO - 2021-09-09 12:19:24 --> MY_Model class loaded
INFO - 2021-09-09 12:19:24 --> Model "Application_model" initialized
INFO - 2021-09-09 12:19:24 --> Controller Class Initialized
DEBUG - 2021-09-09 12:19:24 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-09 12:19:24 --> Helper loaded: inflector_helper
INFO - 2021-09-09 12:19:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-09 12:19:24 --> Database Driver Class Initialized
ERROR - 2021-09-09 12:19:24 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 12:19:24 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 12:19:24 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-09 12:19:24 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-09 12:19:24 --> Model "Authentication_model" initialized
INFO - 2021-09-09 12:19:24 --> Model "Student_model" initialized
INFO - 2021-09-09 12:19:24 --> Final output sent to browser
DEBUG - 2021-09-09 12:19:24 --> Total execution time: 0.1969
INFO - 2021-09-09 12:19:27 --> Config Class Initialized
INFO - 2021-09-09 12:19:27 --> Hooks Class Initialized
DEBUG - 2021-09-09 12:19:27 --> UTF-8 Support Enabled
INFO - 2021-09-09 12:19:27 --> Utf8 Class Initialized
INFO - 2021-09-09 12:19:27 --> URI Class Initialized
INFO - 2021-09-09 12:19:27 --> Router Class Initialized
INFO - 2021-09-09 12:19:27 --> Output Class Initialized
INFO - 2021-09-09 12:19:27 --> Security Class Initialized
DEBUG - 2021-09-09 12:19:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 12:19:27 --> CSRF cookie sent
INFO - 2021-09-09 12:19:27 --> Input Class Initialized
INFO - 2021-09-09 12:19:27 --> Language Class Initialized
INFO - 2021-09-09 12:19:27 --> Loader Class Initialized
INFO - 2021-09-09 12:19:27 --> Helper loaded: url_helper
INFO - 2021-09-09 12:19:27 --> Helper loaded: file_helper
INFO - 2021-09-09 12:19:27 --> Helper loaded: form_helper
INFO - 2021-09-09 12:19:27 --> Helper loaded: security_helper
INFO - 2021-09-09 12:19:27 --> Helper loaded: directory_helper
INFO - 2021-09-09 12:19:27 --> Helper loaded: general_helper
INFO - 2021-09-09 12:19:27 --> Database Driver Class Initialized
INFO - 2021-09-09 12:19:27 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 12:19:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 12:19:27 --> Pagination Class Initialized
INFO - 2021-09-09 12:19:27 --> XML-RPC Class Initialized
INFO - 2021-09-09 12:19:27 --> Form Validation Class Initialized
INFO - 2021-09-09 12:19:27 --> Upload Class Initialized
INFO - 2021-09-09 12:19:27 --> MY_Model class loaded
INFO - 2021-09-09 12:19:27 --> Model "Application_model" initialized
INFO - 2021-09-09 12:19:27 --> Controller Class Initialized
DEBUG - 2021-09-09 12:19:27 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-09 12:19:27 --> Helper loaded: inflector_helper
INFO - 2021-09-09 12:19:27 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-09 12:19:27 --> Database Driver Class Initialized
ERROR - 2021-09-09 12:19:27 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 12:19:27 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 12:19:27 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-09 12:19:27 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-09 12:19:27 --> Model "Authentication_model" initialized
INFO - 2021-09-09 12:19:27 --> Model "Student_model" initialized
INFO - 2021-09-09 12:19:27 --> Final output sent to browser
DEBUG - 2021-09-09 12:19:27 --> Total execution time: 0.3569
INFO - 2021-09-09 12:20:55 --> Config Class Initialized
INFO - 2021-09-09 12:20:55 --> Hooks Class Initialized
DEBUG - 2021-09-09 12:20:55 --> UTF-8 Support Enabled
INFO - 2021-09-09 12:20:56 --> Utf8 Class Initialized
INFO - 2021-09-09 12:20:56 --> URI Class Initialized
INFO - 2021-09-09 12:20:56 --> Router Class Initialized
INFO - 2021-09-09 12:20:56 --> Output Class Initialized
INFO - 2021-09-09 12:20:56 --> Security Class Initialized
DEBUG - 2021-09-09 12:20:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 12:20:56 --> CSRF cookie sent
INFO - 2021-09-09 12:20:56 --> Input Class Initialized
INFO - 2021-09-09 12:20:56 --> Language Class Initialized
INFO - 2021-09-09 12:20:56 --> Loader Class Initialized
INFO - 2021-09-09 12:20:56 --> Helper loaded: url_helper
INFO - 2021-09-09 12:20:56 --> Helper loaded: file_helper
INFO - 2021-09-09 12:20:56 --> Helper loaded: form_helper
INFO - 2021-09-09 12:20:56 --> Helper loaded: security_helper
INFO - 2021-09-09 12:20:56 --> Helper loaded: directory_helper
INFO - 2021-09-09 12:20:56 --> Helper loaded: general_helper
INFO - 2021-09-09 12:20:56 --> Database Driver Class Initialized
INFO - 2021-09-09 12:20:56 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 12:20:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 12:20:56 --> Pagination Class Initialized
INFO - 2021-09-09 12:20:56 --> XML-RPC Class Initialized
INFO - 2021-09-09 12:20:56 --> Form Validation Class Initialized
INFO - 2021-09-09 12:20:56 --> Upload Class Initialized
INFO - 2021-09-09 12:20:56 --> MY_Model class loaded
INFO - 2021-09-09 12:20:56 --> Model "Application_model" initialized
INFO - 2021-09-09 12:20:56 --> Controller Class Initialized
DEBUG - 2021-09-09 12:20:56 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-09 12:20:56 --> Helper loaded: inflector_helper
INFO - 2021-09-09 12:20:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-09 12:20:58 --> Config Class Initialized
INFO - 2021-09-09 12:20:59 --> Hooks Class Initialized
DEBUG - 2021-09-09 12:20:59 --> UTF-8 Support Enabled
INFO - 2021-09-09 12:20:59 --> Utf8 Class Initialized
INFO - 2021-09-09 12:20:59 --> URI Class Initialized
INFO - 2021-09-09 12:20:59 --> Router Class Initialized
INFO - 2021-09-09 12:20:59 --> Output Class Initialized
INFO - 2021-09-09 12:20:59 --> Security Class Initialized
DEBUG - 2021-09-09 12:20:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 12:20:59 --> CSRF cookie sent
INFO - 2021-09-09 12:20:59 --> Input Class Initialized
INFO - 2021-09-09 12:20:59 --> Language Class Initialized
INFO - 2021-09-09 12:20:59 --> Loader Class Initialized
INFO - 2021-09-09 12:20:59 --> Helper loaded: url_helper
INFO - 2021-09-09 12:20:59 --> Helper loaded: file_helper
INFO - 2021-09-09 12:20:59 --> Helper loaded: form_helper
INFO - 2021-09-09 12:20:59 --> Helper loaded: security_helper
INFO - 2021-09-09 12:20:59 --> Helper loaded: directory_helper
INFO - 2021-09-09 12:20:59 --> Helper loaded: general_helper
INFO - 2021-09-09 12:20:59 --> Database Driver Class Initialized
INFO - 2021-09-09 12:20:59 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 12:20:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 12:20:59 --> Pagination Class Initialized
INFO - 2021-09-09 12:20:59 --> XML-RPC Class Initialized
INFO - 2021-09-09 12:20:59 --> Form Validation Class Initialized
INFO - 2021-09-09 12:20:59 --> Upload Class Initialized
INFO - 2021-09-09 12:20:59 --> MY_Model class loaded
INFO - 2021-09-09 12:20:59 --> Model "Application_model" initialized
INFO - 2021-09-09 12:20:59 --> Controller Class Initialized
DEBUG - 2021-09-09 12:20:59 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-09 12:20:59 --> Helper loaded: inflector_helper
INFO - 2021-09-09 12:20:59 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-09 12:20:59 --> Database Driver Class Initialized
ERROR - 2021-09-09 12:20:59 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 12:20:59 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 12:20:59 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-09 12:20:59 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-09 12:20:59 --> Model "Authentication_model" initialized
INFO - 2021-09-09 12:20:59 --> Model "Student_model" initialized
INFO - 2021-09-09 12:20:59 --> Final output sent to browser
DEBUG - 2021-09-09 12:20:59 --> Total execution time: 0.4249
INFO - 2021-09-09 12:22:35 --> Config Class Initialized
INFO - 2021-09-09 12:22:35 --> Hooks Class Initialized
DEBUG - 2021-09-09 12:22:35 --> UTF-8 Support Enabled
INFO - 2021-09-09 12:22:35 --> Utf8 Class Initialized
INFO - 2021-09-09 12:22:35 --> URI Class Initialized
INFO - 2021-09-09 12:22:35 --> Router Class Initialized
INFO - 2021-09-09 12:22:35 --> Output Class Initialized
INFO - 2021-09-09 12:22:35 --> Security Class Initialized
DEBUG - 2021-09-09 12:22:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 12:22:35 --> CSRF cookie sent
INFO - 2021-09-09 12:22:35 --> Input Class Initialized
INFO - 2021-09-09 12:22:35 --> Language Class Initialized
INFO - 2021-09-09 12:22:35 --> Loader Class Initialized
INFO - 2021-09-09 12:22:36 --> Helper loaded: url_helper
INFO - 2021-09-09 12:22:36 --> Helper loaded: file_helper
INFO - 2021-09-09 12:22:36 --> Helper loaded: form_helper
INFO - 2021-09-09 12:22:37 --> Helper loaded: security_helper
INFO - 2021-09-09 12:22:37 --> Helper loaded: directory_helper
INFO - 2021-09-09 12:22:37 --> Helper loaded: general_helper
INFO - 2021-09-09 12:22:38 --> Database Driver Class Initialized
INFO - 2021-09-09 12:22:38 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 12:22:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 12:22:38 --> Pagination Class Initialized
INFO - 2021-09-09 12:22:38 --> XML-RPC Class Initialized
INFO - 2021-09-09 12:22:38 --> Form Validation Class Initialized
INFO - 2021-09-09 12:22:38 --> Upload Class Initialized
INFO - 2021-09-09 12:22:38 --> MY_Model class loaded
INFO - 2021-09-09 12:22:38 --> Model "Application_model" initialized
INFO - 2021-09-09 12:22:38 --> Controller Class Initialized
DEBUG - 2021-09-09 12:22:38 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-09 12:22:39 --> Helper loaded: inflector_helper
INFO - 2021-09-09 12:22:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-09 12:22:39 --> Config Class Initialized
INFO - 2021-09-09 12:22:39 --> Hooks Class Initialized
DEBUG - 2021-09-09 12:22:39 --> UTF-8 Support Enabled
INFO - 2021-09-09 12:22:39 --> Utf8 Class Initialized
INFO - 2021-09-09 12:22:39 --> URI Class Initialized
INFO - 2021-09-09 12:22:39 --> Router Class Initialized
INFO - 2021-09-09 12:22:39 --> Output Class Initialized
INFO - 2021-09-09 12:22:39 --> Security Class Initialized
DEBUG - 2021-09-09 12:22:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 12:22:39 --> CSRF cookie sent
INFO - 2021-09-09 12:22:39 --> Input Class Initialized
INFO - 2021-09-09 12:22:39 --> Language Class Initialized
INFO - 2021-09-09 12:22:39 --> Loader Class Initialized
INFO - 2021-09-09 12:22:39 --> Helper loaded: url_helper
INFO - 2021-09-09 12:22:39 --> Helper loaded: file_helper
INFO - 2021-09-09 12:22:39 --> Helper loaded: form_helper
INFO - 2021-09-09 12:22:39 --> Helper loaded: security_helper
INFO - 2021-09-09 12:22:39 --> Helper loaded: directory_helper
INFO - 2021-09-09 12:22:39 --> Helper loaded: general_helper
INFO - 2021-09-09 12:22:39 --> Database Driver Class Initialized
INFO - 2021-09-09 12:22:39 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 12:22:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 12:22:39 --> Pagination Class Initialized
INFO - 2021-09-09 12:22:39 --> XML-RPC Class Initialized
INFO - 2021-09-09 12:22:39 --> Form Validation Class Initialized
INFO - 2021-09-09 12:22:39 --> Upload Class Initialized
INFO - 2021-09-09 12:22:39 --> MY_Model class loaded
INFO - 2021-09-09 12:22:39 --> Model "Application_model" initialized
INFO - 2021-09-09 12:22:39 --> Controller Class Initialized
DEBUG - 2021-09-09 12:22:39 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-09 12:22:39 --> Helper loaded: inflector_helper
INFO - 2021-09-09 12:22:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-09 12:22:39 --> Database Driver Class Initialized
ERROR - 2021-09-09 12:22:39 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 12:22:39 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 12:22:39 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-09 12:22:39 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-09 12:22:39 --> Model "Authentication_model" initialized
INFO - 2021-09-09 12:22:39 --> Model "Student_model" initialized
INFO - 2021-09-09 12:22:39 --> Final output sent to browser
DEBUG - 2021-09-09 12:22:39 --> Total execution time: 0.5520
INFO - 2021-09-09 12:24:36 --> Config Class Initialized
INFO - 2021-09-09 12:24:36 --> Hooks Class Initialized
DEBUG - 2021-09-09 12:24:36 --> UTF-8 Support Enabled
INFO - 2021-09-09 12:24:36 --> Utf8 Class Initialized
INFO - 2021-09-09 12:24:36 --> URI Class Initialized
INFO - 2021-09-09 12:24:36 --> Router Class Initialized
INFO - 2021-09-09 12:24:36 --> Output Class Initialized
INFO - 2021-09-09 12:24:36 --> Security Class Initialized
DEBUG - 2021-09-09 12:24:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 12:24:37 --> CSRF cookie sent
INFO - 2021-09-09 12:24:37 --> Input Class Initialized
INFO - 2021-09-09 12:24:38 --> Language Class Initialized
INFO - 2021-09-09 12:24:39 --> Loader Class Initialized
INFO - 2021-09-09 12:24:39 --> Helper loaded: url_helper
INFO - 2021-09-09 12:24:40 --> Helper loaded: file_helper
INFO - 2021-09-09 12:24:40 --> Helper loaded: form_helper
INFO - 2021-09-09 12:24:40 --> Helper loaded: security_helper
INFO - 2021-09-09 12:24:40 --> Helper loaded: directory_helper
INFO - 2021-09-09 12:24:40 --> Helper loaded: general_helper
INFO - 2021-09-09 12:24:42 --> Database Driver Class Initialized
INFO - 2021-09-09 12:24:45 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 12:24:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 12:24:45 --> Pagination Class Initialized
INFO - 2021-09-09 12:24:45 --> XML-RPC Class Initialized
INFO - 2021-09-09 12:24:45 --> Form Validation Class Initialized
INFO - 2021-09-09 12:24:46 --> Upload Class Initialized
INFO - 2021-09-09 12:24:46 --> MY_Model class loaded
INFO - 2021-09-09 12:24:46 --> Model "Application_model" initialized
INFO - 2021-09-09 12:24:46 --> Controller Class Initialized
DEBUG - 2021-09-09 12:24:47 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-09 12:24:47 --> Helper loaded: inflector_helper
INFO - 2021-09-09 12:24:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-09 12:24:48 --> Config Class Initialized
INFO - 2021-09-09 12:24:48 --> Hooks Class Initialized
DEBUG - 2021-09-09 12:24:48 --> UTF-8 Support Enabled
INFO - 2021-09-09 12:24:48 --> Utf8 Class Initialized
INFO - 2021-09-09 12:24:48 --> URI Class Initialized
INFO - 2021-09-09 12:24:48 --> Router Class Initialized
INFO - 2021-09-09 12:24:48 --> Output Class Initialized
INFO - 2021-09-09 12:24:48 --> Security Class Initialized
DEBUG - 2021-09-09 12:24:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 12:24:48 --> CSRF cookie sent
INFO - 2021-09-09 12:24:48 --> Input Class Initialized
INFO - 2021-09-09 12:24:48 --> Language Class Initialized
INFO - 2021-09-09 12:24:48 --> Loader Class Initialized
INFO - 2021-09-09 12:24:48 --> Helper loaded: url_helper
INFO - 2021-09-09 12:24:48 --> Helper loaded: file_helper
INFO - 2021-09-09 12:24:48 --> Helper loaded: form_helper
INFO - 2021-09-09 12:24:48 --> Helper loaded: security_helper
INFO - 2021-09-09 12:24:48 --> Helper loaded: directory_helper
INFO - 2021-09-09 12:24:48 --> Helper loaded: general_helper
INFO - 2021-09-09 12:24:48 --> Database Driver Class Initialized
INFO - 2021-09-09 12:24:48 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 12:24:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 12:24:48 --> Pagination Class Initialized
INFO - 2021-09-09 12:24:48 --> XML-RPC Class Initialized
INFO - 2021-09-09 12:24:48 --> Form Validation Class Initialized
INFO - 2021-09-09 12:24:48 --> Upload Class Initialized
INFO - 2021-09-09 12:24:49 --> MY_Model class loaded
INFO - 2021-09-09 12:24:49 --> Model "Application_model" initialized
INFO - 2021-09-09 12:24:49 --> Controller Class Initialized
DEBUG - 2021-09-09 12:24:49 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-09 12:24:49 --> Helper loaded: inflector_helper
INFO - 2021-09-09 12:24:49 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-09 12:24:49 --> Database Driver Class Initialized
ERROR - 2021-09-09 12:24:49 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 12:24:49 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 12:24:49 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-09 12:24:49 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-09 12:24:49 --> Model "Authentication_model" initialized
INFO - 2021-09-09 12:24:49 --> Model "Student_model" initialized
INFO - 2021-09-09 12:24:49 --> Final output sent to browser
DEBUG - 2021-09-09 12:24:49 --> Total execution time: 0.8254
INFO - 2021-09-09 12:30:31 --> Config Class Initialized
INFO - 2021-09-09 12:30:31 --> Hooks Class Initialized
DEBUG - 2021-09-09 12:30:31 --> UTF-8 Support Enabled
INFO - 2021-09-09 12:30:31 --> Utf8 Class Initialized
INFO - 2021-09-09 12:30:31 --> URI Class Initialized
INFO - 2021-09-09 12:30:31 --> Router Class Initialized
INFO - 2021-09-09 12:30:31 --> Output Class Initialized
INFO - 2021-09-09 12:30:31 --> Security Class Initialized
DEBUG - 2021-09-09 12:30:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 12:30:31 --> CSRF cookie sent
INFO - 2021-09-09 12:30:31 --> Input Class Initialized
INFO - 2021-09-09 12:30:32 --> Language Class Initialized
INFO - 2021-09-09 12:30:32 --> Loader Class Initialized
INFO - 2021-09-09 12:30:33 --> Helper loaded: url_helper
INFO - 2021-09-09 12:30:34 --> Helper loaded: file_helper
INFO - 2021-09-09 12:30:34 --> Helper loaded: form_helper
INFO - 2021-09-09 12:30:34 --> Helper loaded: security_helper
INFO - 2021-09-09 12:30:34 --> Helper loaded: directory_helper
INFO - 2021-09-09 12:30:34 --> Helper loaded: general_helper
INFO - 2021-09-09 12:30:34 --> Database Driver Class Initialized
INFO - 2021-09-09 12:30:35 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 12:30:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 12:30:35 --> Pagination Class Initialized
INFO - 2021-09-09 12:30:35 --> XML-RPC Class Initialized
INFO - 2021-09-09 12:30:35 --> Form Validation Class Initialized
INFO - 2021-09-09 12:30:35 --> Upload Class Initialized
INFO - 2021-09-09 12:30:35 --> MY_Model class loaded
INFO - 2021-09-09 12:30:35 --> Model "Application_model" initialized
INFO - 2021-09-09 12:30:35 --> Controller Class Initialized
DEBUG - 2021-09-09 12:30:35 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-09 12:30:35 --> Helper loaded: inflector_helper
INFO - 2021-09-09 12:30:35 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-09 12:30:36 --> Config Class Initialized
INFO - 2021-09-09 12:30:36 --> Hooks Class Initialized
DEBUG - 2021-09-09 12:30:36 --> UTF-8 Support Enabled
INFO - 2021-09-09 12:30:36 --> Utf8 Class Initialized
INFO - 2021-09-09 12:30:36 --> URI Class Initialized
INFO - 2021-09-09 12:30:36 --> Router Class Initialized
INFO - 2021-09-09 12:30:36 --> Output Class Initialized
INFO - 2021-09-09 12:30:36 --> Security Class Initialized
DEBUG - 2021-09-09 12:30:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 12:30:36 --> CSRF cookie sent
INFO - 2021-09-09 12:30:36 --> Input Class Initialized
INFO - 2021-09-09 12:30:36 --> Language Class Initialized
INFO - 2021-09-09 12:30:36 --> Loader Class Initialized
INFO - 2021-09-09 12:30:36 --> Helper loaded: url_helper
INFO - 2021-09-09 12:30:36 --> Helper loaded: file_helper
INFO - 2021-09-09 12:30:36 --> Helper loaded: form_helper
INFO - 2021-09-09 12:30:36 --> Helper loaded: security_helper
INFO - 2021-09-09 12:30:36 --> Helper loaded: directory_helper
INFO - 2021-09-09 12:30:36 --> Helper loaded: general_helper
INFO - 2021-09-09 12:30:36 --> Database Driver Class Initialized
INFO - 2021-09-09 12:30:36 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 12:30:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 12:30:36 --> Pagination Class Initialized
INFO - 2021-09-09 12:30:36 --> XML-RPC Class Initialized
INFO - 2021-09-09 12:30:36 --> Form Validation Class Initialized
INFO - 2021-09-09 12:30:36 --> Upload Class Initialized
INFO - 2021-09-09 12:30:36 --> MY_Model class loaded
INFO - 2021-09-09 12:30:36 --> Model "Application_model" initialized
INFO - 2021-09-09 12:30:36 --> Controller Class Initialized
DEBUG - 2021-09-09 12:30:36 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-09 12:30:36 --> Helper loaded: inflector_helper
INFO - 2021-09-09 12:30:36 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-09 12:30:36 --> Database Driver Class Initialized
ERROR - 2021-09-09 12:30:36 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 12:30:36 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 12:30:36 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-09 12:30:36 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-09 12:30:36 --> Model "Authentication_model" initialized
INFO - 2021-09-09 12:30:36 --> Model "Student_model" initialized
INFO - 2021-09-09 12:30:36 --> Final output sent to browser
DEBUG - 2021-09-09 12:30:36 --> Total execution time: 0.2070
INFO - 2021-09-09 12:38:37 --> Config Class Initialized
INFO - 2021-09-09 12:38:37 --> Hooks Class Initialized
DEBUG - 2021-09-09 12:38:38 --> UTF-8 Support Enabled
INFO - 2021-09-09 12:38:38 --> Utf8 Class Initialized
INFO - 2021-09-09 12:38:39 --> URI Class Initialized
INFO - 2021-09-09 12:38:39 --> Router Class Initialized
INFO - 2021-09-09 12:38:39 --> Output Class Initialized
INFO - 2021-09-09 12:38:39 --> Security Class Initialized
DEBUG - 2021-09-09 12:38:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 12:38:39 --> CSRF cookie sent
INFO - 2021-09-09 12:38:39 --> Input Class Initialized
INFO - 2021-09-09 12:38:39 --> Language Class Initialized
INFO - 2021-09-09 12:38:41 --> Loader Class Initialized
INFO - 2021-09-09 12:38:41 --> Helper loaded: url_helper
INFO - 2021-09-09 12:38:41 --> Helper loaded: file_helper
INFO - 2021-09-09 12:38:41 --> Helper loaded: form_helper
INFO - 2021-09-09 12:38:41 --> Helper loaded: security_helper
INFO - 2021-09-09 12:38:41 --> Helper loaded: directory_helper
INFO - 2021-09-09 12:38:41 --> Helper loaded: general_helper
INFO - 2021-09-09 12:38:42 --> Database Driver Class Initialized
INFO - 2021-09-09 12:38:42 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 12:38:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 12:38:42 --> Pagination Class Initialized
INFO - 2021-09-09 12:38:42 --> XML-RPC Class Initialized
INFO - 2021-09-09 12:38:42 --> Form Validation Class Initialized
INFO - 2021-09-09 12:38:43 --> Upload Class Initialized
INFO - 2021-09-09 12:38:43 --> MY_Model class loaded
INFO - 2021-09-09 12:38:43 --> Model "Application_model" initialized
INFO - 2021-09-09 12:38:43 --> Controller Class Initialized
DEBUG - 2021-09-09 12:38:43 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-09 12:38:43 --> Helper loaded: inflector_helper
INFO - 2021-09-09 12:38:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-09 12:38:43 --> Config Class Initialized
INFO - 2021-09-09 12:38:43 --> Hooks Class Initialized
DEBUG - 2021-09-09 12:38:43 --> UTF-8 Support Enabled
INFO - 2021-09-09 12:38:43 --> Utf8 Class Initialized
INFO - 2021-09-09 12:38:43 --> URI Class Initialized
INFO - 2021-09-09 12:38:43 --> Router Class Initialized
INFO - 2021-09-09 12:38:43 --> Output Class Initialized
INFO - 2021-09-09 12:38:43 --> Security Class Initialized
DEBUG - 2021-09-09 12:38:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 12:38:43 --> CSRF cookie sent
INFO - 2021-09-09 12:38:43 --> Input Class Initialized
INFO - 2021-09-09 12:38:43 --> Language Class Initialized
INFO - 2021-09-09 12:38:43 --> Loader Class Initialized
INFO - 2021-09-09 12:38:43 --> Helper loaded: url_helper
INFO - 2021-09-09 12:38:43 --> Helper loaded: file_helper
INFO - 2021-09-09 12:38:43 --> Helper loaded: form_helper
INFO - 2021-09-09 12:38:43 --> Helper loaded: security_helper
INFO - 2021-09-09 12:38:43 --> Helper loaded: directory_helper
INFO - 2021-09-09 12:38:43 --> Helper loaded: general_helper
INFO - 2021-09-09 12:38:43 --> Database Driver Class Initialized
INFO - 2021-09-09 12:38:43 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 12:38:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 12:38:43 --> Pagination Class Initialized
INFO - 2021-09-09 12:38:43 --> XML-RPC Class Initialized
INFO - 2021-09-09 12:38:43 --> Form Validation Class Initialized
INFO - 2021-09-09 12:38:43 --> Upload Class Initialized
INFO - 2021-09-09 12:38:43 --> MY_Model class loaded
INFO - 2021-09-09 12:38:43 --> Model "Application_model" initialized
INFO - 2021-09-09 12:38:43 --> Controller Class Initialized
DEBUG - 2021-09-09 12:38:43 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-09 12:38:43 --> Helper loaded: inflector_helper
INFO - 2021-09-09 12:38:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-09 12:38:43 --> Database Driver Class Initialized
ERROR - 2021-09-09 12:38:44 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 12:38:44 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 12:38:44 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-09 12:38:44 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-09 12:38:44 --> Model "Authentication_model" initialized
INFO - 2021-09-09 12:38:44 --> Model "Student_model" initialized
ERROR - 2021-09-09 12:38:44 --> Severity: error --> Exception: Call to a member function request_headers() on null C:\Users\Gopal Ghimire\Desktop\New folder\school\application\controllers\api\Student.php 32
INFO - 2021-09-09 12:38:53 --> Config Class Initialized
INFO - 2021-09-09 12:38:53 --> Hooks Class Initialized
DEBUG - 2021-09-09 12:38:53 --> UTF-8 Support Enabled
INFO - 2021-09-09 12:38:53 --> Utf8 Class Initialized
INFO - 2021-09-09 12:38:53 --> URI Class Initialized
INFO - 2021-09-09 12:38:53 --> Router Class Initialized
INFO - 2021-09-09 12:38:53 --> Output Class Initialized
INFO - 2021-09-09 12:38:53 --> Security Class Initialized
DEBUG - 2021-09-09 12:38:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 12:38:53 --> CSRF cookie sent
INFO - 2021-09-09 12:38:53 --> Input Class Initialized
INFO - 2021-09-09 12:38:53 --> Language Class Initialized
INFO - 2021-09-09 12:38:53 --> Loader Class Initialized
INFO - 2021-09-09 12:38:53 --> Helper loaded: url_helper
INFO - 2021-09-09 12:38:53 --> Helper loaded: file_helper
INFO - 2021-09-09 12:38:53 --> Helper loaded: form_helper
INFO - 2021-09-09 12:38:53 --> Helper loaded: security_helper
INFO - 2021-09-09 12:38:53 --> Helper loaded: directory_helper
INFO - 2021-09-09 12:38:53 --> Helper loaded: general_helper
INFO - 2021-09-09 12:38:53 --> Database Driver Class Initialized
INFO - 2021-09-09 12:38:53 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 12:38:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 12:38:53 --> Pagination Class Initialized
INFO - 2021-09-09 12:38:53 --> XML-RPC Class Initialized
INFO - 2021-09-09 12:38:53 --> Form Validation Class Initialized
INFO - 2021-09-09 12:38:53 --> Upload Class Initialized
INFO - 2021-09-09 12:38:53 --> MY_Model class loaded
INFO - 2021-09-09 12:38:53 --> Model "Application_model" initialized
INFO - 2021-09-09 12:38:53 --> Controller Class Initialized
DEBUG - 2021-09-09 12:38:53 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-09 12:38:53 --> Helper loaded: inflector_helper
INFO - 2021-09-09 12:38:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-09 12:38:54 --> Config Class Initialized
INFO - 2021-09-09 12:38:54 --> Hooks Class Initialized
DEBUG - 2021-09-09 12:38:54 --> UTF-8 Support Enabled
INFO - 2021-09-09 12:38:54 --> Utf8 Class Initialized
INFO - 2021-09-09 12:38:54 --> URI Class Initialized
INFO - 2021-09-09 12:38:54 --> Router Class Initialized
INFO - 2021-09-09 12:38:54 --> Output Class Initialized
INFO - 2021-09-09 12:38:54 --> Security Class Initialized
DEBUG - 2021-09-09 12:38:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 12:38:54 --> CSRF cookie sent
INFO - 2021-09-09 12:38:54 --> Input Class Initialized
INFO - 2021-09-09 12:38:54 --> Language Class Initialized
INFO - 2021-09-09 12:38:54 --> Loader Class Initialized
INFO - 2021-09-09 12:38:54 --> Helper loaded: url_helper
INFO - 2021-09-09 12:38:54 --> Helper loaded: file_helper
INFO - 2021-09-09 12:38:54 --> Helper loaded: form_helper
INFO - 2021-09-09 12:38:54 --> Helper loaded: security_helper
INFO - 2021-09-09 12:38:54 --> Helper loaded: directory_helper
INFO - 2021-09-09 12:38:54 --> Helper loaded: general_helper
INFO - 2021-09-09 12:38:54 --> Database Driver Class Initialized
INFO - 2021-09-09 12:38:54 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 12:38:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 12:38:54 --> Pagination Class Initialized
INFO - 2021-09-09 12:38:54 --> XML-RPC Class Initialized
INFO - 2021-09-09 12:38:54 --> Form Validation Class Initialized
INFO - 2021-09-09 12:38:54 --> Upload Class Initialized
INFO - 2021-09-09 12:38:54 --> MY_Model class loaded
INFO - 2021-09-09 12:38:54 --> Model "Application_model" initialized
INFO - 2021-09-09 12:38:54 --> Controller Class Initialized
DEBUG - 2021-09-09 12:38:54 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-09 12:38:54 --> Helper loaded: inflector_helper
INFO - 2021-09-09 12:38:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-09 12:38:54 --> Database Driver Class Initialized
ERROR - 2021-09-09 12:38:54 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 12:38:54 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 12:38:54 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-09 12:38:54 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-09 12:38:54 --> Model "Authentication_model" initialized
INFO - 2021-09-09 12:38:54 --> Model "Student_model" initialized
ERROR - 2021-09-09 12:38:54 --> Severity: error --> Exception: Call to a member function request_headers() on null C:\Users\Gopal Ghimire\Desktop\New folder\school\application\controllers\api\Student.php 32
INFO - 2021-09-09 12:39:00 --> Config Class Initialized
INFO - 2021-09-09 12:39:00 --> Hooks Class Initialized
DEBUG - 2021-09-09 12:39:00 --> UTF-8 Support Enabled
INFO - 2021-09-09 12:39:00 --> Utf8 Class Initialized
INFO - 2021-09-09 12:39:00 --> URI Class Initialized
INFO - 2021-09-09 12:39:00 --> Router Class Initialized
INFO - 2021-09-09 12:39:00 --> Output Class Initialized
INFO - 2021-09-09 12:39:00 --> Security Class Initialized
DEBUG - 2021-09-09 12:39:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 12:39:00 --> CSRF cookie sent
INFO - 2021-09-09 12:39:00 --> Input Class Initialized
INFO - 2021-09-09 12:39:00 --> Language Class Initialized
INFO - 2021-09-09 12:39:00 --> Loader Class Initialized
INFO - 2021-09-09 12:39:00 --> Helper loaded: url_helper
INFO - 2021-09-09 12:39:00 --> Helper loaded: file_helper
INFO - 2021-09-09 12:39:00 --> Helper loaded: form_helper
INFO - 2021-09-09 12:39:00 --> Helper loaded: security_helper
INFO - 2021-09-09 12:39:00 --> Helper loaded: directory_helper
INFO - 2021-09-09 12:39:00 --> Helper loaded: general_helper
INFO - 2021-09-09 12:39:00 --> Database Driver Class Initialized
INFO - 2021-09-09 12:39:00 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 12:39:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 12:39:00 --> Pagination Class Initialized
INFO - 2021-09-09 12:39:00 --> XML-RPC Class Initialized
INFO - 2021-09-09 12:39:00 --> Form Validation Class Initialized
INFO - 2021-09-09 12:39:00 --> Upload Class Initialized
INFO - 2021-09-09 12:39:00 --> MY_Model class loaded
INFO - 2021-09-09 12:39:00 --> Model "Application_model" initialized
INFO - 2021-09-09 12:39:00 --> Controller Class Initialized
DEBUG - 2021-09-09 12:39:00 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-09 12:39:00 --> Helper loaded: inflector_helper
INFO - 2021-09-09 12:39:00 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-09 12:39:00 --> Config Class Initialized
INFO - 2021-09-09 12:39:00 --> Hooks Class Initialized
DEBUG - 2021-09-09 12:39:00 --> UTF-8 Support Enabled
INFO - 2021-09-09 12:39:00 --> Utf8 Class Initialized
INFO - 2021-09-09 12:39:00 --> URI Class Initialized
INFO - 2021-09-09 12:39:00 --> Router Class Initialized
INFO - 2021-09-09 12:39:00 --> Output Class Initialized
INFO - 2021-09-09 12:39:00 --> Security Class Initialized
DEBUG - 2021-09-09 12:39:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 12:39:00 --> CSRF cookie sent
INFO - 2021-09-09 12:39:00 --> Input Class Initialized
INFO - 2021-09-09 12:39:00 --> Language Class Initialized
INFO - 2021-09-09 12:39:00 --> Loader Class Initialized
INFO - 2021-09-09 12:39:00 --> Helper loaded: url_helper
INFO - 2021-09-09 12:39:00 --> Helper loaded: file_helper
INFO - 2021-09-09 12:39:00 --> Helper loaded: form_helper
INFO - 2021-09-09 12:39:00 --> Helper loaded: security_helper
INFO - 2021-09-09 12:39:00 --> Helper loaded: directory_helper
INFO - 2021-09-09 12:39:00 --> Helper loaded: general_helper
INFO - 2021-09-09 12:39:00 --> Database Driver Class Initialized
INFO - 2021-09-09 12:39:00 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 12:39:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 12:39:00 --> Pagination Class Initialized
INFO - 2021-09-09 12:39:00 --> XML-RPC Class Initialized
INFO - 2021-09-09 12:39:00 --> Form Validation Class Initialized
INFO - 2021-09-09 12:39:00 --> Upload Class Initialized
INFO - 2021-09-09 12:39:00 --> MY_Model class loaded
INFO - 2021-09-09 12:39:00 --> Model "Application_model" initialized
INFO - 2021-09-09 12:39:00 --> Controller Class Initialized
DEBUG - 2021-09-09 12:39:00 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-09 12:39:00 --> Helper loaded: inflector_helper
INFO - 2021-09-09 12:39:00 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-09 12:39:00 --> Database Driver Class Initialized
ERROR - 2021-09-09 12:39:00 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 12:39:00 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 12:39:00 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-09 12:39:00 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-09 12:39:00 --> Model "Authentication_model" initialized
INFO - 2021-09-09 12:39:00 --> Model "Student_model" initialized
ERROR - 2021-09-09 12:39:00 --> Severity: error --> Exception: Call to a member function request_headers() on null C:\Users\Gopal Ghimire\Desktop\New folder\school\application\controllers\api\Student.php 32
INFO - 2021-09-09 12:39:52 --> Config Class Initialized
INFO - 2021-09-09 12:39:52 --> Hooks Class Initialized
DEBUG - 2021-09-09 12:39:52 --> UTF-8 Support Enabled
INFO - 2021-09-09 12:39:52 --> Utf8 Class Initialized
INFO - 2021-09-09 12:39:52 --> URI Class Initialized
INFO - 2021-09-09 12:39:52 --> Router Class Initialized
INFO - 2021-09-09 12:39:52 --> Output Class Initialized
INFO - 2021-09-09 12:39:52 --> Security Class Initialized
DEBUG - 2021-09-09 12:39:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 12:39:52 --> CSRF cookie sent
INFO - 2021-09-09 12:39:52 --> Input Class Initialized
INFO - 2021-09-09 12:39:52 --> Language Class Initialized
INFO - 2021-09-09 12:39:52 --> Loader Class Initialized
INFO - 2021-09-09 12:39:53 --> Helper loaded: url_helper
INFO - 2021-09-09 12:39:53 --> Helper loaded: file_helper
INFO - 2021-09-09 12:39:53 --> Helper loaded: form_helper
INFO - 2021-09-09 12:39:53 --> Helper loaded: security_helper
INFO - 2021-09-09 12:39:53 --> Helper loaded: directory_helper
INFO - 2021-09-09 12:39:53 --> Helper loaded: general_helper
INFO - 2021-09-09 12:39:53 --> Database Driver Class Initialized
INFO - 2021-09-09 12:39:54 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 12:39:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 12:39:54 --> Pagination Class Initialized
INFO - 2021-09-09 12:39:54 --> XML-RPC Class Initialized
INFO - 2021-09-09 12:39:54 --> Form Validation Class Initialized
INFO - 2021-09-09 12:39:54 --> Upload Class Initialized
INFO - 2021-09-09 12:39:54 --> MY_Model class loaded
INFO - 2021-09-09 12:39:54 --> Model "Application_model" initialized
INFO - 2021-09-09 12:39:54 --> Controller Class Initialized
DEBUG - 2021-09-09 12:39:54 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-09 12:39:54 --> Helper loaded: inflector_helper
INFO - 2021-09-09 12:39:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-09 12:39:55 --> Config Class Initialized
INFO - 2021-09-09 12:39:55 --> Hooks Class Initialized
DEBUG - 2021-09-09 12:39:55 --> UTF-8 Support Enabled
INFO - 2021-09-09 12:39:55 --> Utf8 Class Initialized
INFO - 2021-09-09 12:39:55 --> URI Class Initialized
INFO - 2021-09-09 12:39:55 --> Router Class Initialized
INFO - 2021-09-09 12:39:55 --> Output Class Initialized
INFO - 2021-09-09 12:39:55 --> Security Class Initialized
DEBUG - 2021-09-09 12:39:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 12:39:55 --> CSRF cookie sent
INFO - 2021-09-09 12:39:55 --> Input Class Initialized
INFO - 2021-09-09 12:39:55 --> Language Class Initialized
INFO - 2021-09-09 12:39:55 --> Loader Class Initialized
INFO - 2021-09-09 12:39:55 --> Helper loaded: url_helper
INFO - 2021-09-09 12:39:55 --> Helper loaded: file_helper
INFO - 2021-09-09 12:39:55 --> Helper loaded: form_helper
INFO - 2021-09-09 12:39:55 --> Helper loaded: security_helper
INFO - 2021-09-09 12:39:55 --> Helper loaded: directory_helper
INFO - 2021-09-09 12:39:55 --> Helper loaded: general_helper
INFO - 2021-09-09 12:39:55 --> Database Driver Class Initialized
INFO - 2021-09-09 12:39:55 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 12:39:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 12:39:55 --> Pagination Class Initialized
INFO - 2021-09-09 12:39:55 --> XML-RPC Class Initialized
INFO - 2021-09-09 12:39:55 --> Form Validation Class Initialized
INFO - 2021-09-09 12:39:55 --> Upload Class Initialized
INFO - 2021-09-09 12:39:55 --> MY_Model class loaded
INFO - 2021-09-09 12:39:55 --> Model "Application_model" initialized
INFO - 2021-09-09 12:39:55 --> Controller Class Initialized
DEBUG - 2021-09-09 12:39:55 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-09 12:39:55 --> Helper loaded: inflector_helper
INFO - 2021-09-09 12:39:55 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-09 12:39:55 --> Database Driver Class Initialized
ERROR - 2021-09-09 12:39:55 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 12:39:55 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 12:39:55 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-09 12:39:55 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-09 12:39:55 --> Model "Authentication_model" initialized
INFO - 2021-09-09 12:39:55 --> Model "Student_model" initialized
ERROR - 2021-09-09 12:39:55 --> Severity: error --> Exception: Call to a member function request_headers() on null C:\Users\Gopal Ghimire\Desktop\New folder\school\application\controllers\api\Student.php 32
INFO - 2021-09-09 12:42:21 --> Config Class Initialized
INFO - 2021-09-09 12:42:21 --> Hooks Class Initialized
DEBUG - 2021-09-09 12:42:21 --> UTF-8 Support Enabled
INFO - 2021-09-09 12:42:21 --> Utf8 Class Initialized
INFO - 2021-09-09 12:42:21 --> URI Class Initialized
INFO - 2021-09-09 12:42:21 --> Router Class Initialized
INFO - 2021-09-09 12:42:22 --> Output Class Initialized
INFO - 2021-09-09 12:42:22 --> Security Class Initialized
DEBUG - 2021-09-09 12:42:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 12:42:22 --> CSRF cookie sent
INFO - 2021-09-09 12:42:22 --> Input Class Initialized
INFO - 2021-09-09 12:42:22 --> Language Class Initialized
INFO - 2021-09-09 12:42:22 --> Loader Class Initialized
INFO - 2021-09-09 12:42:22 --> Helper loaded: url_helper
INFO - 2021-09-09 12:42:22 --> Helper loaded: file_helper
INFO - 2021-09-09 12:42:22 --> Helper loaded: form_helper
INFO - 2021-09-09 12:42:22 --> Helper loaded: security_helper
INFO - 2021-09-09 12:42:22 --> Helper loaded: directory_helper
INFO - 2021-09-09 12:42:23 --> Helper loaded: general_helper
INFO - 2021-09-09 12:42:23 --> Database Driver Class Initialized
INFO - 2021-09-09 12:42:23 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 12:42:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 12:42:23 --> Pagination Class Initialized
INFO - 2021-09-09 12:42:23 --> XML-RPC Class Initialized
INFO - 2021-09-09 12:42:23 --> Form Validation Class Initialized
INFO - 2021-09-09 12:42:23 --> Upload Class Initialized
INFO - 2021-09-09 12:42:23 --> MY_Model class loaded
INFO - 2021-09-09 12:42:23 --> Model "Application_model" initialized
INFO - 2021-09-09 12:42:23 --> Controller Class Initialized
INFO - 2021-09-09 16:27:24 --> Model "Authentication_model" initialized
INFO - 2021-09-09 16:27:25 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\authentication/login.php
INFO - 2021-09-09 16:27:25 --> Final output sent to browser
DEBUG - 2021-09-09 16:27:25 --> Total execution time: 4.9589
INFO - 2021-09-09 12:42:29 --> Config Class Initialized
INFO - 2021-09-09 12:42:29 --> Hooks Class Initialized
DEBUG - 2021-09-09 12:42:29 --> UTF-8 Support Enabled
INFO - 2021-09-09 12:42:29 --> Utf8 Class Initialized
INFO - 2021-09-09 12:42:29 --> URI Class Initialized
INFO - 2021-09-09 12:42:29 --> Router Class Initialized
INFO - 2021-09-09 12:42:29 --> Output Class Initialized
INFO - 2021-09-09 12:42:29 --> Security Class Initialized
DEBUG - 2021-09-09 12:42:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 12:42:29 --> CSRF cookie sent
INFO - 2021-09-09 12:42:29 --> Input Class Initialized
INFO - 2021-09-09 12:42:29 --> Language Class Initialized
INFO - 2021-09-09 12:42:29 --> Loader Class Initialized
INFO - 2021-09-09 12:42:29 --> Helper loaded: url_helper
INFO - 2021-09-09 12:42:29 --> Helper loaded: file_helper
INFO - 2021-09-09 12:42:29 --> Helper loaded: form_helper
INFO - 2021-09-09 12:42:29 --> Helper loaded: security_helper
INFO - 2021-09-09 12:42:29 --> Helper loaded: directory_helper
INFO - 2021-09-09 12:42:29 --> Helper loaded: general_helper
INFO - 2021-09-09 12:42:29 --> Database Driver Class Initialized
INFO - 2021-09-09 12:42:29 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 12:42:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 12:42:29 --> Pagination Class Initialized
INFO - 2021-09-09 12:42:29 --> XML-RPC Class Initialized
INFO - 2021-09-09 12:42:29 --> Form Validation Class Initialized
INFO - 2021-09-09 12:42:29 --> Upload Class Initialized
INFO - 2021-09-09 12:42:29 --> MY_Model class loaded
INFO - 2021-09-09 12:42:29 --> Model "Application_model" initialized
INFO - 2021-09-09 12:42:29 --> Controller Class Initialized
DEBUG - 2021-09-09 12:42:29 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-09 12:42:29 --> Helper loaded: inflector_helper
INFO - 2021-09-09 12:42:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-09 12:42:30 --> Config Class Initialized
INFO - 2021-09-09 12:42:30 --> Hooks Class Initialized
DEBUG - 2021-09-09 12:42:30 --> UTF-8 Support Enabled
INFO - 2021-09-09 12:42:30 --> Utf8 Class Initialized
INFO - 2021-09-09 12:42:30 --> URI Class Initialized
INFO - 2021-09-09 12:42:30 --> Router Class Initialized
INFO - 2021-09-09 12:42:30 --> Output Class Initialized
INFO - 2021-09-09 12:42:30 --> Security Class Initialized
DEBUG - 2021-09-09 12:42:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 12:42:30 --> CSRF cookie sent
INFO - 2021-09-09 12:42:30 --> Input Class Initialized
INFO - 2021-09-09 12:42:30 --> Language Class Initialized
INFO - 2021-09-09 12:42:30 --> Loader Class Initialized
INFO - 2021-09-09 12:42:30 --> Helper loaded: url_helper
INFO - 2021-09-09 12:42:30 --> Helper loaded: file_helper
INFO - 2021-09-09 12:42:30 --> Helper loaded: form_helper
INFO - 2021-09-09 12:42:30 --> Helper loaded: security_helper
INFO - 2021-09-09 12:42:30 --> Helper loaded: directory_helper
INFO - 2021-09-09 12:42:30 --> Helper loaded: general_helper
INFO - 2021-09-09 12:42:30 --> Database Driver Class Initialized
INFO - 2021-09-09 12:42:30 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 12:42:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 12:42:30 --> Pagination Class Initialized
INFO - 2021-09-09 12:42:30 --> XML-RPC Class Initialized
INFO - 2021-09-09 12:42:30 --> Form Validation Class Initialized
INFO - 2021-09-09 12:42:30 --> Upload Class Initialized
INFO - 2021-09-09 12:42:30 --> MY_Model class loaded
INFO - 2021-09-09 12:42:30 --> Model "Application_model" initialized
INFO - 2021-09-09 12:42:30 --> Controller Class Initialized
DEBUG - 2021-09-09 12:42:30 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-09 12:42:30 --> Helper loaded: inflector_helper
INFO - 2021-09-09 12:42:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-09 12:42:30 --> Database Driver Class Initialized
ERROR - 2021-09-09 12:42:30 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 12:42:30 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 12:42:30 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-09 12:42:30 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-09 12:42:30 --> Model "Authentication_model" initialized
INFO - 2021-09-09 12:42:30 --> Model "Student_model" initialized
ERROR - 2021-09-09 12:42:30 --> Severity: error --> Exception: Call to a member function get_request_header() on null C:\Users\Gopal Ghimire\Desktop\New folder\school\application\controllers\api\Student.php 32
INFO - 2021-09-09 12:46:28 --> Config Class Initialized
INFO - 2021-09-09 12:46:28 --> Hooks Class Initialized
DEBUG - 2021-09-09 12:46:28 --> UTF-8 Support Enabled
INFO - 2021-09-09 12:46:28 --> Utf8 Class Initialized
INFO - 2021-09-09 12:46:28 --> URI Class Initialized
INFO - 2021-09-09 12:46:28 --> Router Class Initialized
INFO - 2021-09-09 12:46:28 --> Output Class Initialized
INFO - 2021-09-09 12:46:28 --> Security Class Initialized
DEBUG - 2021-09-09 12:46:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 12:46:28 --> CSRF cookie sent
INFO - 2021-09-09 12:46:28 --> Input Class Initialized
INFO - 2021-09-09 12:46:29 --> Language Class Initialized
INFO - 2021-09-09 12:46:29 --> Loader Class Initialized
INFO - 2021-09-09 12:46:29 --> Helper loaded: url_helper
INFO - 2021-09-09 12:46:29 --> Helper loaded: file_helper
INFO - 2021-09-09 12:46:30 --> Helper loaded: form_helper
INFO - 2021-09-09 12:46:30 --> Helper loaded: security_helper
INFO - 2021-09-09 12:46:30 --> Helper loaded: directory_helper
INFO - 2021-09-09 12:46:30 --> Helper loaded: general_helper
INFO - 2021-09-09 12:46:30 --> Database Driver Class Initialized
INFO - 2021-09-09 12:46:30 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 12:46:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 12:46:30 --> Pagination Class Initialized
INFO - 2021-09-09 12:46:30 --> XML-RPC Class Initialized
INFO - 2021-09-09 12:46:30 --> Form Validation Class Initialized
INFO - 2021-09-09 12:46:30 --> Upload Class Initialized
INFO - 2021-09-09 12:46:31 --> MY_Model class loaded
INFO - 2021-09-09 12:46:31 --> Model "Application_model" initialized
INFO - 2021-09-09 12:46:31 --> Controller Class Initialized
DEBUG - 2021-09-09 12:46:31 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-09 12:46:31 --> Helper loaded: inflector_helper
INFO - 2021-09-09 12:46:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-09 12:46:31 --> Config Class Initialized
INFO - 2021-09-09 12:46:31 --> Hooks Class Initialized
DEBUG - 2021-09-09 12:46:31 --> UTF-8 Support Enabled
INFO - 2021-09-09 12:46:31 --> Utf8 Class Initialized
INFO - 2021-09-09 12:46:31 --> URI Class Initialized
INFO - 2021-09-09 12:46:31 --> Router Class Initialized
INFO - 2021-09-09 12:46:31 --> Output Class Initialized
INFO - 2021-09-09 12:46:31 --> Security Class Initialized
DEBUG - 2021-09-09 12:46:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 12:46:31 --> CSRF cookie sent
INFO - 2021-09-09 12:46:31 --> Input Class Initialized
INFO - 2021-09-09 12:46:31 --> Language Class Initialized
INFO - 2021-09-09 12:46:31 --> Loader Class Initialized
INFO - 2021-09-09 12:46:31 --> Helper loaded: url_helper
INFO - 2021-09-09 12:46:31 --> Helper loaded: file_helper
INFO - 2021-09-09 12:46:31 --> Helper loaded: form_helper
INFO - 2021-09-09 12:46:31 --> Helper loaded: security_helper
INFO - 2021-09-09 12:46:31 --> Helper loaded: directory_helper
INFO - 2021-09-09 12:46:31 --> Helper loaded: general_helper
INFO - 2021-09-09 12:46:31 --> Database Driver Class Initialized
INFO - 2021-09-09 12:46:31 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 12:46:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 12:46:31 --> Pagination Class Initialized
INFO - 2021-09-09 12:46:31 --> XML-RPC Class Initialized
INFO - 2021-09-09 12:46:31 --> Form Validation Class Initialized
INFO - 2021-09-09 12:46:31 --> Upload Class Initialized
INFO - 2021-09-09 12:46:31 --> MY_Model class loaded
INFO - 2021-09-09 12:46:31 --> Model "Application_model" initialized
INFO - 2021-09-09 12:46:31 --> Controller Class Initialized
DEBUG - 2021-09-09 12:46:31 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-09 12:46:31 --> Helper loaded: inflector_helper
INFO - 2021-09-09 12:46:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-09 12:46:31 --> Database Driver Class Initialized
ERROR - 2021-09-09 12:46:31 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 12:46:31 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 12:46:31 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-09 12:46:31 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-09 12:46:31 --> Model "Authentication_model" initialized
INFO - 2021-09-09 12:46:31 --> Model "Student_model" initialized
ERROR - 2021-09-09 12:46:31 --> Severity: error --> Exception: Call to a member function getHeader() on null C:\Users\Gopal Ghimire\Desktop\New folder\school\application\controllers\api\Student.php 32
INFO - 2021-09-09 12:46:50 --> Config Class Initialized
INFO - 2021-09-09 12:46:50 --> Hooks Class Initialized
DEBUG - 2021-09-09 12:46:50 --> UTF-8 Support Enabled
INFO - 2021-09-09 12:46:50 --> Utf8 Class Initialized
INFO - 2021-09-09 12:46:50 --> URI Class Initialized
INFO - 2021-09-09 12:46:50 --> Router Class Initialized
INFO - 2021-09-09 12:46:50 --> Output Class Initialized
INFO - 2021-09-09 12:46:50 --> Security Class Initialized
DEBUG - 2021-09-09 12:46:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 12:46:50 --> CSRF cookie sent
INFO - 2021-09-09 12:46:50 --> Input Class Initialized
INFO - 2021-09-09 12:46:50 --> Language Class Initialized
INFO - 2021-09-09 12:46:50 --> Loader Class Initialized
INFO - 2021-09-09 12:46:50 --> Helper loaded: url_helper
INFO - 2021-09-09 12:46:50 --> Helper loaded: file_helper
INFO - 2021-09-09 12:46:50 --> Helper loaded: form_helper
INFO - 2021-09-09 12:46:50 --> Helper loaded: security_helper
INFO - 2021-09-09 12:46:50 --> Helper loaded: directory_helper
INFO - 2021-09-09 12:46:50 --> Helper loaded: general_helper
INFO - 2021-09-09 12:46:50 --> Database Driver Class Initialized
INFO - 2021-09-09 12:46:50 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 12:46:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 12:46:50 --> Pagination Class Initialized
INFO - 2021-09-09 12:46:50 --> XML-RPC Class Initialized
INFO - 2021-09-09 12:46:50 --> Form Validation Class Initialized
INFO - 2021-09-09 12:46:50 --> Upload Class Initialized
INFO - 2021-09-09 12:46:50 --> MY_Model class loaded
INFO - 2021-09-09 12:46:50 --> Model "Application_model" initialized
INFO - 2021-09-09 12:46:50 --> Controller Class Initialized
DEBUG - 2021-09-09 12:46:50 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-09 12:46:50 --> Helper loaded: inflector_helper
INFO - 2021-09-09 12:46:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-09 12:46:51 --> Config Class Initialized
INFO - 2021-09-09 12:46:51 --> Hooks Class Initialized
DEBUG - 2021-09-09 12:46:51 --> UTF-8 Support Enabled
INFO - 2021-09-09 12:46:51 --> Utf8 Class Initialized
INFO - 2021-09-09 12:46:51 --> URI Class Initialized
INFO - 2021-09-09 12:46:51 --> Router Class Initialized
INFO - 2021-09-09 12:46:51 --> Output Class Initialized
INFO - 2021-09-09 12:46:51 --> Security Class Initialized
DEBUG - 2021-09-09 12:46:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 12:46:51 --> CSRF cookie sent
INFO - 2021-09-09 12:46:51 --> Input Class Initialized
INFO - 2021-09-09 12:46:51 --> Language Class Initialized
INFO - 2021-09-09 12:46:51 --> Loader Class Initialized
INFO - 2021-09-09 12:46:51 --> Helper loaded: url_helper
INFO - 2021-09-09 12:46:51 --> Helper loaded: file_helper
INFO - 2021-09-09 12:46:51 --> Helper loaded: form_helper
INFO - 2021-09-09 12:46:51 --> Helper loaded: security_helper
INFO - 2021-09-09 12:46:51 --> Helper loaded: directory_helper
INFO - 2021-09-09 12:46:51 --> Helper loaded: general_helper
INFO - 2021-09-09 12:46:51 --> Database Driver Class Initialized
INFO - 2021-09-09 12:46:51 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 12:46:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 12:46:51 --> Pagination Class Initialized
INFO - 2021-09-09 12:46:51 --> XML-RPC Class Initialized
INFO - 2021-09-09 12:46:51 --> Form Validation Class Initialized
INFO - 2021-09-09 12:46:51 --> Upload Class Initialized
INFO - 2021-09-09 12:46:51 --> MY_Model class loaded
INFO - 2021-09-09 12:46:51 --> Model "Application_model" initialized
INFO - 2021-09-09 12:46:51 --> Controller Class Initialized
DEBUG - 2021-09-09 12:46:51 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-09 12:46:51 --> Helper loaded: inflector_helper
INFO - 2021-09-09 12:46:51 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-09 12:46:51 --> Database Driver Class Initialized
ERROR - 2021-09-09 12:46:51 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 12:46:51 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 12:46:51 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-09 12:46:51 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-09 12:46:51 --> Model "Authentication_model" initialized
INFO - 2021-09-09 12:46:51 --> Model "Student_model" initialized
ERROR - 2021-09-09 12:46:52 --> Severity: error --> Exception: Call to undefined method Student::getHeader() C:\Users\Gopal Ghimire\Desktop\New folder\school\application\controllers\api\Student.php 32
INFO - 2021-09-09 13:18:43 --> Config Class Initialized
INFO - 2021-09-09 13:18:44 --> Hooks Class Initialized
DEBUG - 2021-09-09 13:18:45 --> UTF-8 Support Enabled
INFO - 2021-09-09 13:18:45 --> Utf8 Class Initialized
INFO - 2021-09-09 13:18:45 --> URI Class Initialized
INFO - 2021-09-09 13:18:45 --> Router Class Initialized
INFO - 2021-09-09 13:18:46 --> Output Class Initialized
INFO - 2021-09-09 13:18:46 --> Security Class Initialized
DEBUG - 2021-09-09 13:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 13:18:47 --> CSRF cookie sent
INFO - 2021-09-09 13:18:47 --> Input Class Initialized
INFO - 2021-09-09 13:18:47 --> Language Class Initialized
INFO - 2021-09-09 13:18:48 --> Loader Class Initialized
INFO - 2021-09-09 13:18:50 --> Helper loaded: url_helper
INFO - 2021-09-09 13:18:50 --> Helper loaded: file_helper
INFO - 2021-09-09 13:18:51 --> Helper loaded: form_helper
INFO - 2021-09-09 13:18:51 --> Helper loaded: security_helper
INFO - 2021-09-09 13:18:51 --> Helper loaded: directory_helper
INFO - 2021-09-09 13:18:51 --> Helper loaded: general_helper
INFO - 2021-09-09 13:18:51 --> Database Driver Class Initialized
INFO - 2021-09-09 13:18:53 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 13:18:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 13:18:53 --> Pagination Class Initialized
INFO - 2021-09-09 13:18:53 --> XML-RPC Class Initialized
INFO - 2021-09-09 13:18:53 --> Form Validation Class Initialized
INFO - 2021-09-09 13:18:53 --> Upload Class Initialized
INFO - 2021-09-09 13:18:53 --> MY_Model class loaded
INFO - 2021-09-09 13:18:54 --> Model "Application_model" initialized
INFO - 2021-09-09 13:18:54 --> Controller Class Initialized
DEBUG - 2021-09-09 13:18:54 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-09 13:18:54 --> Helper loaded: inflector_helper
INFO - 2021-09-09 13:18:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-09 13:18:54 --> Config Class Initialized
INFO - 2021-09-09 13:18:54 --> Hooks Class Initialized
DEBUG - 2021-09-09 13:18:54 --> UTF-8 Support Enabled
INFO - 2021-09-09 13:18:54 --> Utf8 Class Initialized
INFO - 2021-09-09 13:18:54 --> URI Class Initialized
INFO - 2021-09-09 13:18:54 --> Router Class Initialized
INFO - 2021-09-09 13:18:54 --> Output Class Initialized
INFO - 2021-09-09 13:18:54 --> Security Class Initialized
DEBUG - 2021-09-09 13:18:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 13:18:54 --> CSRF cookie sent
INFO - 2021-09-09 13:18:54 --> Input Class Initialized
INFO - 2021-09-09 13:18:54 --> Language Class Initialized
INFO - 2021-09-09 13:18:54 --> Loader Class Initialized
INFO - 2021-09-09 13:18:54 --> Helper loaded: url_helper
INFO - 2021-09-09 13:18:54 --> Helper loaded: file_helper
INFO - 2021-09-09 13:18:54 --> Helper loaded: form_helper
INFO - 2021-09-09 13:18:54 --> Helper loaded: security_helper
INFO - 2021-09-09 13:18:54 --> Helper loaded: directory_helper
INFO - 2021-09-09 13:18:54 --> Helper loaded: general_helper
INFO - 2021-09-09 13:18:54 --> Database Driver Class Initialized
INFO - 2021-09-09 13:18:54 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 13:18:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 13:18:54 --> Pagination Class Initialized
INFO - 2021-09-09 13:18:54 --> XML-RPC Class Initialized
INFO - 2021-09-09 13:18:54 --> Form Validation Class Initialized
INFO - 2021-09-09 13:18:54 --> Upload Class Initialized
INFO - 2021-09-09 13:18:54 --> MY_Model class loaded
INFO - 2021-09-09 13:18:54 --> Model "Application_model" initialized
INFO - 2021-09-09 13:18:54 --> Controller Class Initialized
DEBUG - 2021-09-09 13:18:54 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-09 13:18:55 --> Helper loaded: inflector_helper
INFO - 2021-09-09 13:18:55 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-09 13:18:55 --> Database Driver Class Initialized
ERROR - 2021-09-09 13:18:55 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 13:18:55 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 13:18:55 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-09 13:18:55 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-09 13:18:55 --> Model "Authentication_model" initialized
INFO - 2021-09-09 13:18:55 --> Model "Student_model" initialized
INFO - 2021-09-09 13:18:55 --> Final output sent to browser
DEBUG - 2021-09-09 13:18:55 --> Total execution time: 0.6507
INFO - 2021-09-09 13:20:12 --> Config Class Initialized
INFO - 2021-09-09 13:20:12 --> Hooks Class Initialized
DEBUG - 2021-09-09 13:20:13 --> UTF-8 Support Enabled
INFO - 2021-09-09 13:20:13 --> Utf8 Class Initialized
INFO - 2021-09-09 13:20:13 --> URI Class Initialized
INFO - 2021-09-09 13:20:13 --> Router Class Initialized
INFO - 2021-09-09 13:20:13 --> Output Class Initialized
INFO - 2021-09-09 13:20:13 --> Security Class Initialized
DEBUG - 2021-09-09 13:20:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 13:20:13 --> CSRF cookie sent
INFO - 2021-09-09 13:20:13 --> Input Class Initialized
INFO - 2021-09-09 13:20:14 --> Language Class Initialized
INFO - 2021-09-09 13:20:14 --> Loader Class Initialized
INFO - 2021-09-09 13:20:14 --> Helper loaded: url_helper
INFO - 2021-09-09 13:20:14 --> Helper loaded: file_helper
INFO - 2021-09-09 13:20:14 --> Helper loaded: form_helper
INFO - 2021-09-09 13:20:14 --> Helper loaded: security_helper
INFO - 2021-09-09 13:20:15 --> Helper loaded: directory_helper
INFO - 2021-09-09 13:20:15 --> Helper loaded: general_helper
INFO - 2021-09-09 13:20:15 --> Database Driver Class Initialized
INFO - 2021-09-09 13:20:15 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 13:20:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 13:20:16 --> Pagination Class Initialized
INFO - 2021-09-09 13:20:16 --> XML-RPC Class Initialized
INFO - 2021-09-09 13:20:16 --> Form Validation Class Initialized
INFO - 2021-09-09 13:20:16 --> Upload Class Initialized
INFO - 2021-09-09 13:20:16 --> MY_Model class loaded
INFO - 2021-09-09 13:20:17 --> Model "Application_model" initialized
INFO - 2021-09-09 13:20:17 --> Controller Class Initialized
DEBUG - 2021-09-09 13:20:17 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-09 13:20:17 --> Helper loaded: inflector_helper
INFO - 2021-09-09 13:20:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-09 13:20:17 --> Config Class Initialized
INFO - 2021-09-09 13:20:17 --> Hooks Class Initialized
DEBUG - 2021-09-09 13:20:17 --> UTF-8 Support Enabled
INFO - 2021-09-09 13:20:17 --> Utf8 Class Initialized
INFO - 2021-09-09 13:20:17 --> URI Class Initialized
INFO - 2021-09-09 13:20:17 --> Router Class Initialized
INFO - 2021-09-09 13:20:17 --> Output Class Initialized
INFO - 2021-09-09 13:20:17 --> Security Class Initialized
DEBUG - 2021-09-09 13:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 13:20:17 --> CSRF cookie sent
INFO - 2021-09-09 13:20:17 --> Input Class Initialized
INFO - 2021-09-09 13:20:17 --> Language Class Initialized
INFO - 2021-09-09 13:20:17 --> Loader Class Initialized
INFO - 2021-09-09 13:20:17 --> Helper loaded: url_helper
INFO - 2021-09-09 13:20:17 --> Helper loaded: file_helper
INFO - 2021-09-09 13:20:17 --> Helper loaded: form_helper
INFO - 2021-09-09 13:20:17 --> Helper loaded: security_helper
INFO - 2021-09-09 13:20:17 --> Helper loaded: directory_helper
INFO - 2021-09-09 13:20:17 --> Helper loaded: general_helper
INFO - 2021-09-09 13:20:17 --> Database Driver Class Initialized
INFO - 2021-09-09 13:20:17 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 13:20:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 13:20:17 --> Pagination Class Initialized
INFO - 2021-09-09 13:20:17 --> XML-RPC Class Initialized
INFO - 2021-09-09 13:20:17 --> Form Validation Class Initialized
INFO - 2021-09-09 13:20:17 --> Upload Class Initialized
INFO - 2021-09-09 13:20:17 --> MY_Model class loaded
INFO - 2021-09-09 13:20:17 --> Model "Application_model" initialized
INFO - 2021-09-09 13:20:17 --> Controller Class Initialized
DEBUG - 2021-09-09 13:20:17 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-09 13:20:17 --> Helper loaded: inflector_helper
INFO - 2021-09-09 13:20:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-09 13:20:17 --> Database Driver Class Initialized
ERROR - 2021-09-09 13:20:18 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 13:20:18 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 13:20:18 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-09 13:20:18 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-09 13:20:18 --> Model "Authentication_model" initialized
ERROR - 2021-09-09 13:20:18 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\Users\Gopal Ghimire\Desktop\New folder\school\application\models\Authentication_model.php 18
INFO - 2021-09-09 13:20:49 --> Config Class Initialized
INFO - 2021-09-09 13:20:49 --> Hooks Class Initialized
DEBUG - 2021-09-09 13:20:49 --> UTF-8 Support Enabled
INFO - 2021-09-09 13:20:49 --> Utf8 Class Initialized
INFO - 2021-09-09 13:20:49 --> URI Class Initialized
INFO - 2021-09-09 13:20:49 --> Router Class Initialized
INFO - 2021-09-09 13:20:49 --> Output Class Initialized
INFO - 2021-09-09 13:20:49 --> Security Class Initialized
DEBUG - 2021-09-09 13:20:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 13:20:49 --> CSRF cookie sent
INFO - 2021-09-09 13:20:49 --> Input Class Initialized
INFO - 2021-09-09 13:20:49 --> Language Class Initialized
INFO - 2021-09-09 13:20:49 --> Loader Class Initialized
INFO - 2021-09-09 13:20:49 --> Helper loaded: url_helper
INFO - 2021-09-09 13:20:49 --> Helper loaded: file_helper
INFO - 2021-09-09 13:20:49 --> Helper loaded: form_helper
INFO - 2021-09-09 13:20:49 --> Helper loaded: security_helper
INFO - 2021-09-09 13:20:49 --> Helper loaded: directory_helper
INFO - 2021-09-09 13:20:49 --> Helper loaded: general_helper
INFO - 2021-09-09 13:20:49 --> Database Driver Class Initialized
INFO - 2021-09-09 13:20:49 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 13:20:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 13:20:50 --> Pagination Class Initialized
INFO - 2021-09-09 13:20:50 --> XML-RPC Class Initialized
INFO - 2021-09-09 13:20:50 --> Form Validation Class Initialized
INFO - 2021-09-09 13:20:50 --> Upload Class Initialized
INFO - 2021-09-09 13:20:50 --> MY_Model class loaded
INFO - 2021-09-09 13:20:50 --> Model "Application_model" initialized
INFO - 2021-09-09 13:20:50 --> Controller Class Initialized
DEBUG - 2021-09-09 13:20:50 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-09 13:20:50 --> Helper loaded: inflector_helper
INFO - 2021-09-09 13:20:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-09 13:20:50 --> Config Class Initialized
INFO - 2021-09-09 13:20:50 --> Hooks Class Initialized
DEBUG - 2021-09-09 13:20:50 --> UTF-8 Support Enabled
INFO - 2021-09-09 13:20:50 --> Utf8 Class Initialized
INFO - 2021-09-09 13:20:50 --> URI Class Initialized
INFO - 2021-09-09 13:20:50 --> Router Class Initialized
INFO - 2021-09-09 13:20:50 --> Output Class Initialized
INFO - 2021-09-09 13:20:50 --> Security Class Initialized
DEBUG - 2021-09-09 13:20:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 13:20:50 --> CSRF cookie sent
INFO - 2021-09-09 13:20:50 --> Input Class Initialized
INFO - 2021-09-09 13:20:50 --> Language Class Initialized
INFO - 2021-09-09 13:20:50 --> Loader Class Initialized
INFO - 2021-09-09 13:20:50 --> Helper loaded: url_helper
INFO - 2021-09-09 13:20:50 --> Helper loaded: file_helper
INFO - 2021-09-09 13:20:50 --> Helper loaded: form_helper
INFO - 2021-09-09 13:20:50 --> Helper loaded: security_helper
INFO - 2021-09-09 13:20:50 --> Helper loaded: directory_helper
INFO - 2021-09-09 13:20:50 --> Helper loaded: general_helper
INFO - 2021-09-09 13:20:50 --> Database Driver Class Initialized
INFO - 2021-09-09 13:20:50 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 13:20:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 13:20:50 --> Pagination Class Initialized
INFO - 2021-09-09 13:20:50 --> XML-RPC Class Initialized
INFO - 2021-09-09 13:20:50 --> Form Validation Class Initialized
INFO - 2021-09-09 13:20:50 --> Upload Class Initialized
INFO - 2021-09-09 13:20:50 --> MY_Model class loaded
INFO - 2021-09-09 13:20:50 --> Model "Application_model" initialized
INFO - 2021-09-09 13:20:50 --> Controller Class Initialized
DEBUG - 2021-09-09 13:20:50 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-09 13:20:50 --> Helper loaded: inflector_helper
INFO - 2021-09-09 13:20:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-09 13:20:50 --> Database Driver Class Initialized
ERROR - 2021-09-09 13:20:50 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 13:20:50 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 13:20:50 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-09 13:20:51 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-09 13:20:51 --> Model "Authentication_model" initialized
ERROR - 2021-09-09 13:20:51 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\Users\Gopal Ghimire\Desktop\New folder\school\application\models\Authentication_model.php 18
INFO - 2021-09-09 13:21:06 --> Config Class Initialized
INFO - 2021-09-09 13:21:06 --> Hooks Class Initialized
DEBUG - 2021-09-09 13:21:06 --> UTF-8 Support Enabled
INFO - 2021-09-09 13:21:06 --> Utf8 Class Initialized
INFO - 2021-09-09 13:21:06 --> URI Class Initialized
INFO - 2021-09-09 13:21:06 --> Router Class Initialized
INFO - 2021-09-09 13:21:06 --> Output Class Initialized
INFO - 2021-09-09 13:21:06 --> Security Class Initialized
DEBUG - 2021-09-09 13:21:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 13:21:06 --> CSRF cookie sent
INFO - 2021-09-09 13:21:06 --> Input Class Initialized
INFO - 2021-09-09 13:21:06 --> Language Class Initialized
INFO - 2021-09-09 13:21:06 --> Loader Class Initialized
INFO - 2021-09-09 13:21:06 --> Helper loaded: url_helper
INFO - 2021-09-09 13:21:07 --> Helper loaded: file_helper
INFO - 2021-09-09 13:21:07 --> Helper loaded: form_helper
INFO - 2021-09-09 13:21:07 --> Helper loaded: security_helper
INFO - 2021-09-09 13:21:07 --> Helper loaded: directory_helper
INFO - 2021-09-09 13:21:07 --> Helper loaded: general_helper
INFO - 2021-09-09 13:21:07 --> Database Driver Class Initialized
INFO - 2021-09-09 13:21:07 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 13:21:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 13:21:07 --> Pagination Class Initialized
INFO - 2021-09-09 13:21:07 --> XML-RPC Class Initialized
INFO - 2021-09-09 13:21:07 --> Form Validation Class Initialized
INFO - 2021-09-09 13:21:07 --> Upload Class Initialized
INFO - 2021-09-09 13:21:07 --> MY_Model class loaded
INFO - 2021-09-09 13:21:07 --> Model "Application_model" initialized
INFO - 2021-09-09 13:21:07 --> Controller Class Initialized
DEBUG - 2021-09-09 13:21:07 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-09 13:21:07 --> Helper loaded: inflector_helper
INFO - 2021-09-09 13:21:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-09 13:21:07 --> Config Class Initialized
INFO - 2021-09-09 13:21:07 --> Hooks Class Initialized
DEBUG - 2021-09-09 13:21:07 --> UTF-8 Support Enabled
INFO - 2021-09-09 13:21:07 --> Utf8 Class Initialized
INFO - 2021-09-09 13:21:07 --> URI Class Initialized
INFO - 2021-09-09 13:21:07 --> Router Class Initialized
INFO - 2021-09-09 13:21:07 --> Output Class Initialized
INFO - 2021-09-09 13:21:07 --> Security Class Initialized
DEBUG - 2021-09-09 13:21:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 13:21:07 --> CSRF cookie sent
INFO - 2021-09-09 13:21:07 --> Input Class Initialized
INFO - 2021-09-09 13:21:07 --> Language Class Initialized
INFO - 2021-09-09 13:21:07 --> Loader Class Initialized
INFO - 2021-09-09 13:21:07 --> Helper loaded: url_helper
INFO - 2021-09-09 13:21:08 --> Helper loaded: file_helper
INFO - 2021-09-09 13:21:08 --> Helper loaded: form_helper
INFO - 2021-09-09 13:21:08 --> Helper loaded: security_helper
INFO - 2021-09-09 13:21:08 --> Helper loaded: directory_helper
INFO - 2021-09-09 13:21:08 --> Helper loaded: general_helper
INFO - 2021-09-09 13:21:08 --> Database Driver Class Initialized
INFO - 2021-09-09 13:21:08 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 13:21:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 13:21:08 --> Pagination Class Initialized
INFO - 2021-09-09 13:21:08 --> XML-RPC Class Initialized
INFO - 2021-09-09 13:21:08 --> Form Validation Class Initialized
INFO - 2021-09-09 13:21:08 --> Upload Class Initialized
INFO - 2021-09-09 13:21:08 --> MY_Model class loaded
INFO - 2021-09-09 13:21:08 --> Model "Application_model" initialized
INFO - 2021-09-09 13:21:08 --> Controller Class Initialized
DEBUG - 2021-09-09 13:21:08 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-09 13:21:08 --> Helper loaded: inflector_helper
INFO - 2021-09-09 13:21:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-09 13:21:08 --> Database Driver Class Initialized
ERROR - 2021-09-09 13:21:08 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 13:21:08 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 13:21:08 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-09 13:21:08 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-09 13:21:08 --> Model "Authentication_model" initialized
INFO - 2021-09-09 13:21:08 --> Model "Student_model" initialized
INFO - 2021-09-09 13:21:08 --> Final output sent to browser
DEBUG - 2021-09-09 13:21:08 --> Total execution time: 0.4381
INFO - 2021-09-09 13:25:30 --> Config Class Initialized
INFO - 2021-09-09 13:25:30 --> Hooks Class Initialized
DEBUG - 2021-09-09 13:25:30 --> UTF-8 Support Enabled
INFO - 2021-09-09 13:25:30 --> Utf8 Class Initialized
INFO - 2021-09-09 13:25:30 --> URI Class Initialized
INFO - 2021-09-09 13:25:30 --> Router Class Initialized
INFO - 2021-09-09 13:25:30 --> Output Class Initialized
INFO - 2021-09-09 13:25:30 --> Security Class Initialized
DEBUG - 2021-09-09 13:25:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 13:25:30 --> CSRF cookie sent
INFO - 2021-09-09 13:25:30 --> Input Class Initialized
INFO - 2021-09-09 13:25:31 --> Language Class Initialized
INFO - 2021-09-09 13:25:31 --> Loader Class Initialized
INFO - 2021-09-09 13:25:31 --> Helper loaded: url_helper
INFO - 2021-09-09 13:25:31 --> Helper loaded: file_helper
INFO - 2021-09-09 13:25:31 --> Helper loaded: form_helper
INFO - 2021-09-09 13:25:31 --> Helper loaded: security_helper
INFO - 2021-09-09 13:25:31 --> Helper loaded: directory_helper
INFO - 2021-09-09 13:25:31 --> Helper loaded: general_helper
INFO - 2021-09-09 13:25:31 --> Database Driver Class Initialized
INFO - 2021-09-09 13:25:31 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 13:25:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 13:25:31 --> Pagination Class Initialized
INFO - 2021-09-09 13:25:31 --> XML-RPC Class Initialized
INFO - 2021-09-09 13:25:31 --> Form Validation Class Initialized
INFO - 2021-09-09 13:25:31 --> Upload Class Initialized
INFO - 2021-09-09 13:25:31 --> MY_Model class loaded
INFO - 2021-09-09 13:25:31 --> Model "Application_model" initialized
INFO - 2021-09-09 13:25:31 --> Controller Class Initialized
DEBUG - 2021-09-09 13:25:31 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-09 13:25:32 --> Helper loaded: inflector_helper
INFO - 2021-09-09 13:25:32 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-09 13:25:32 --> Config Class Initialized
INFO - 2021-09-09 13:25:32 --> Hooks Class Initialized
DEBUG - 2021-09-09 13:25:32 --> UTF-8 Support Enabled
INFO - 2021-09-09 13:25:32 --> Utf8 Class Initialized
INFO - 2021-09-09 13:25:32 --> URI Class Initialized
INFO - 2021-09-09 13:25:32 --> Router Class Initialized
INFO - 2021-09-09 13:25:32 --> Output Class Initialized
INFO - 2021-09-09 13:25:32 --> Security Class Initialized
DEBUG - 2021-09-09 13:25:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 13:25:32 --> CSRF cookie sent
INFO - 2021-09-09 13:25:32 --> Input Class Initialized
INFO - 2021-09-09 13:25:32 --> Language Class Initialized
INFO - 2021-09-09 13:25:32 --> Loader Class Initialized
INFO - 2021-09-09 13:25:32 --> Helper loaded: url_helper
INFO - 2021-09-09 13:25:32 --> Helper loaded: file_helper
INFO - 2021-09-09 13:25:32 --> Helper loaded: form_helper
INFO - 2021-09-09 13:25:32 --> Helper loaded: security_helper
INFO - 2021-09-09 13:25:32 --> Helper loaded: directory_helper
INFO - 2021-09-09 13:25:32 --> Helper loaded: general_helper
INFO - 2021-09-09 13:25:32 --> Database Driver Class Initialized
INFO - 2021-09-09 13:25:32 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 13:25:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 13:25:32 --> Pagination Class Initialized
INFO - 2021-09-09 13:25:32 --> XML-RPC Class Initialized
INFO - 2021-09-09 13:25:32 --> Form Validation Class Initialized
INFO - 2021-09-09 13:25:32 --> Upload Class Initialized
INFO - 2021-09-09 13:25:32 --> MY_Model class loaded
INFO - 2021-09-09 13:25:32 --> Model "Application_model" initialized
INFO - 2021-09-09 13:25:32 --> Controller Class Initialized
DEBUG - 2021-09-09 13:25:32 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-09 13:25:32 --> Helper loaded: inflector_helper
INFO - 2021-09-09 13:25:32 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-09 13:25:32 --> Database Driver Class Initialized
ERROR - 2021-09-09 13:25:32 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 13:25:32 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 13:25:32 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-09 13:25:32 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-09 13:25:32 --> Model "Authentication_model" initialized
INFO - 2021-09-09 13:25:32 --> Model "Student_model" initialized
INFO - 2021-09-09 13:25:32 --> Final output sent to browser
DEBUG - 2021-09-09 13:25:32 --> Total execution time: 0.5953
INFO - 2021-09-09 13:26:42 --> Config Class Initialized
INFO - 2021-09-09 13:26:42 --> Hooks Class Initialized
DEBUG - 2021-09-09 13:26:42 --> UTF-8 Support Enabled
INFO - 2021-09-09 13:26:42 --> Utf8 Class Initialized
INFO - 2021-09-09 13:26:43 --> URI Class Initialized
INFO - 2021-09-09 13:26:43 --> Router Class Initialized
INFO - 2021-09-09 13:26:43 --> Output Class Initialized
INFO - 2021-09-09 13:26:43 --> Security Class Initialized
DEBUG - 2021-09-09 13:26:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 13:26:43 --> CSRF cookie sent
INFO - 2021-09-09 13:26:43 --> Input Class Initialized
INFO - 2021-09-09 13:26:43 --> Language Class Initialized
INFO - 2021-09-09 13:26:43 --> Loader Class Initialized
INFO - 2021-09-09 13:26:43 --> Helper loaded: url_helper
INFO - 2021-09-09 13:26:43 --> Helper loaded: file_helper
INFO - 2021-09-09 13:26:43 --> Helper loaded: form_helper
INFO - 2021-09-09 13:26:44 --> Helper loaded: security_helper
INFO - 2021-09-09 13:26:44 --> Helper loaded: directory_helper
INFO - 2021-09-09 13:26:44 --> Helper loaded: general_helper
INFO - 2021-09-09 13:26:44 --> Database Driver Class Initialized
INFO - 2021-09-09 13:26:44 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 13:26:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 13:26:44 --> Pagination Class Initialized
INFO - 2021-09-09 13:26:44 --> XML-RPC Class Initialized
INFO - 2021-09-09 13:26:44 --> Form Validation Class Initialized
INFO - 2021-09-09 13:26:44 --> Upload Class Initialized
INFO - 2021-09-09 13:26:44 --> MY_Model class loaded
INFO - 2021-09-09 13:26:44 --> Model "Application_model" initialized
INFO - 2021-09-09 13:26:44 --> Controller Class Initialized
DEBUG - 2021-09-09 13:26:44 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-09 13:26:44 --> Helper loaded: inflector_helper
INFO - 2021-09-09 13:26:44 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-09 13:26:45 --> Config Class Initialized
INFO - 2021-09-09 13:26:45 --> Hooks Class Initialized
DEBUG - 2021-09-09 13:26:45 --> UTF-8 Support Enabled
INFO - 2021-09-09 13:26:45 --> Utf8 Class Initialized
INFO - 2021-09-09 13:26:45 --> URI Class Initialized
INFO - 2021-09-09 13:26:45 --> Router Class Initialized
INFO - 2021-09-09 13:26:45 --> Output Class Initialized
INFO - 2021-09-09 13:26:45 --> Security Class Initialized
DEBUG - 2021-09-09 13:26:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 13:26:45 --> CSRF cookie sent
INFO - 2021-09-09 13:26:45 --> Input Class Initialized
INFO - 2021-09-09 13:26:45 --> Language Class Initialized
INFO - 2021-09-09 13:26:45 --> Loader Class Initialized
INFO - 2021-09-09 13:26:45 --> Helper loaded: url_helper
INFO - 2021-09-09 13:26:45 --> Helper loaded: file_helper
INFO - 2021-09-09 13:26:45 --> Helper loaded: form_helper
INFO - 2021-09-09 13:26:45 --> Helper loaded: security_helper
INFO - 2021-09-09 13:26:45 --> Helper loaded: directory_helper
INFO - 2021-09-09 13:26:45 --> Helper loaded: general_helper
INFO - 2021-09-09 13:26:45 --> Database Driver Class Initialized
INFO - 2021-09-09 13:26:45 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 13:26:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 13:26:45 --> Pagination Class Initialized
INFO - 2021-09-09 13:26:45 --> XML-RPC Class Initialized
INFO - 2021-09-09 13:26:45 --> Form Validation Class Initialized
INFO - 2021-09-09 13:26:45 --> Upload Class Initialized
INFO - 2021-09-09 13:26:45 --> MY_Model class loaded
INFO - 2021-09-09 13:26:45 --> Model "Application_model" initialized
INFO - 2021-09-09 13:26:45 --> Controller Class Initialized
DEBUG - 2021-09-09 13:26:45 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-09 13:26:45 --> Helper loaded: inflector_helper
INFO - 2021-09-09 13:26:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-09 13:26:45 --> Database Driver Class Initialized
ERROR - 2021-09-09 13:26:45 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 13:26:45 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 13:26:45 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-09 13:26:45 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-09 13:26:45 --> Model "Authentication_model" initialized
INFO - 2021-09-09 13:26:45 --> Model "Student_model" initialized
INFO - 2021-09-09 13:26:45 --> Final output sent to browser
DEBUG - 2021-09-09 13:26:45 --> Total execution time: 0.5057
INFO - 2021-09-09 13:29:45 --> Config Class Initialized
INFO - 2021-09-09 13:29:45 --> Hooks Class Initialized
DEBUG - 2021-09-09 13:29:45 --> UTF-8 Support Enabled
INFO - 2021-09-09 13:29:45 --> Utf8 Class Initialized
INFO - 2021-09-09 13:29:45 --> URI Class Initialized
INFO - 2021-09-09 13:29:45 --> Router Class Initialized
INFO - 2021-09-09 13:29:45 --> Output Class Initialized
INFO - 2021-09-09 13:29:45 --> Security Class Initialized
DEBUG - 2021-09-09 13:29:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 13:29:45 --> CSRF cookie sent
INFO - 2021-09-09 13:29:45 --> Input Class Initialized
INFO - 2021-09-09 13:29:46 --> Language Class Initialized
INFO - 2021-09-09 13:29:46 --> Loader Class Initialized
INFO - 2021-09-09 13:29:46 --> Helper loaded: url_helper
INFO - 2021-09-09 13:29:46 --> Helper loaded: file_helper
INFO - 2021-09-09 13:29:46 --> Helper loaded: form_helper
INFO - 2021-09-09 13:29:46 --> Helper loaded: security_helper
INFO - 2021-09-09 13:29:46 --> Helper loaded: directory_helper
INFO - 2021-09-09 13:29:46 --> Helper loaded: general_helper
INFO - 2021-09-09 13:29:46 --> Database Driver Class Initialized
INFO - 2021-09-09 13:29:46 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 13:29:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 13:29:46 --> Pagination Class Initialized
INFO - 2021-09-09 13:29:46 --> XML-RPC Class Initialized
INFO - 2021-09-09 13:29:47 --> Form Validation Class Initialized
INFO - 2021-09-09 13:29:47 --> Upload Class Initialized
INFO - 2021-09-09 13:29:47 --> MY_Model class loaded
INFO - 2021-09-09 13:29:47 --> Model "Application_model" initialized
INFO - 2021-09-09 13:29:47 --> Controller Class Initialized
DEBUG - 2021-09-09 13:29:47 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-09 13:29:47 --> Helper loaded: inflector_helper
INFO - 2021-09-09 13:29:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-09 13:29:47 --> Config Class Initialized
INFO - 2021-09-09 13:29:47 --> Hooks Class Initialized
DEBUG - 2021-09-09 13:29:47 --> UTF-8 Support Enabled
INFO - 2021-09-09 13:29:47 --> Utf8 Class Initialized
INFO - 2021-09-09 13:29:47 --> URI Class Initialized
INFO - 2021-09-09 13:29:47 --> Router Class Initialized
INFO - 2021-09-09 13:29:47 --> Output Class Initialized
INFO - 2021-09-09 13:29:47 --> Security Class Initialized
DEBUG - 2021-09-09 13:29:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 13:29:47 --> CSRF cookie sent
INFO - 2021-09-09 13:29:47 --> Input Class Initialized
INFO - 2021-09-09 13:29:47 --> Language Class Initialized
INFO - 2021-09-09 13:29:47 --> Loader Class Initialized
INFO - 2021-09-09 13:29:47 --> Helper loaded: url_helper
INFO - 2021-09-09 13:29:47 --> Helper loaded: file_helper
INFO - 2021-09-09 13:29:47 --> Helper loaded: form_helper
INFO - 2021-09-09 13:29:47 --> Helper loaded: security_helper
INFO - 2021-09-09 13:29:47 --> Helper loaded: directory_helper
INFO - 2021-09-09 13:29:47 --> Helper loaded: general_helper
INFO - 2021-09-09 13:29:47 --> Database Driver Class Initialized
INFO - 2021-09-09 13:29:47 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 13:29:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 13:29:47 --> Pagination Class Initialized
INFO - 2021-09-09 13:29:47 --> XML-RPC Class Initialized
INFO - 2021-09-09 13:29:47 --> Form Validation Class Initialized
INFO - 2021-09-09 13:29:47 --> Upload Class Initialized
INFO - 2021-09-09 13:29:47 --> MY_Model class loaded
INFO - 2021-09-09 13:29:47 --> Model "Application_model" initialized
INFO - 2021-09-09 13:29:47 --> Controller Class Initialized
DEBUG - 2021-09-09 13:29:47 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-09 13:29:47 --> Helper loaded: inflector_helper
INFO - 2021-09-09 13:29:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-09 13:29:47 --> Database Driver Class Initialized
ERROR - 2021-09-09 13:29:47 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 13:29:47 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 13:29:47 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-09 13:29:47 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-09 13:29:47 --> Model "Authentication_model" initialized
INFO - 2021-09-09 13:29:47 --> Model "Student_model" initialized
INFO - 2021-09-09 13:29:47 --> Final output sent to browser
DEBUG - 2021-09-09 13:29:47 --> Total execution time: 0.3389
INFO - 2021-09-09 13:30:53 --> Config Class Initialized
INFO - 2021-09-09 13:30:53 --> Hooks Class Initialized
DEBUG - 2021-09-09 13:30:53 --> UTF-8 Support Enabled
INFO - 2021-09-09 13:30:53 --> Utf8 Class Initialized
INFO - 2021-09-09 13:30:53 --> URI Class Initialized
INFO - 2021-09-09 13:30:53 --> Router Class Initialized
INFO - 2021-09-09 13:30:53 --> Output Class Initialized
INFO - 2021-09-09 13:30:53 --> Security Class Initialized
DEBUG - 2021-09-09 13:30:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 13:30:53 --> CSRF cookie sent
INFO - 2021-09-09 13:30:53 --> Input Class Initialized
INFO - 2021-09-09 13:30:53 --> Language Class Initialized
INFO - 2021-09-09 13:30:53 --> Loader Class Initialized
INFO - 2021-09-09 13:30:53 --> Helper loaded: url_helper
INFO - 2021-09-09 13:30:53 --> Helper loaded: file_helper
INFO - 2021-09-09 13:30:54 --> Helper loaded: form_helper
INFO - 2021-09-09 13:30:54 --> Helper loaded: security_helper
INFO - 2021-09-09 13:30:54 --> Helper loaded: directory_helper
INFO - 2021-09-09 13:30:54 --> Helper loaded: general_helper
INFO - 2021-09-09 13:30:54 --> Database Driver Class Initialized
INFO - 2021-09-09 13:30:54 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 13:30:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 13:30:54 --> Pagination Class Initialized
INFO - 2021-09-09 13:30:54 --> XML-RPC Class Initialized
INFO - 2021-09-09 13:30:54 --> Form Validation Class Initialized
INFO - 2021-09-09 13:30:54 --> Upload Class Initialized
INFO - 2021-09-09 13:30:54 --> MY_Model class loaded
INFO - 2021-09-09 13:30:54 --> Model "Application_model" initialized
INFO - 2021-09-09 13:30:54 --> Controller Class Initialized
DEBUG - 2021-09-09 13:30:54 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-09 13:30:54 --> Helper loaded: inflector_helper
INFO - 2021-09-09 13:30:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-09 13:30:55 --> Config Class Initialized
INFO - 2021-09-09 13:30:55 --> Hooks Class Initialized
DEBUG - 2021-09-09 13:30:55 --> UTF-8 Support Enabled
INFO - 2021-09-09 13:30:55 --> Utf8 Class Initialized
INFO - 2021-09-09 13:30:55 --> URI Class Initialized
INFO - 2021-09-09 13:30:55 --> Router Class Initialized
INFO - 2021-09-09 13:30:55 --> Output Class Initialized
INFO - 2021-09-09 13:30:55 --> Security Class Initialized
DEBUG - 2021-09-09 13:30:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 13:30:55 --> CSRF cookie sent
INFO - 2021-09-09 13:30:55 --> Input Class Initialized
INFO - 2021-09-09 13:30:55 --> Language Class Initialized
INFO - 2021-09-09 13:30:55 --> Loader Class Initialized
INFO - 2021-09-09 13:30:55 --> Helper loaded: url_helper
INFO - 2021-09-09 13:30:55 --> Helper loaded: file_helper
INFO - 2021-09-09 13:30:55 --> Helper loaded: form_helper
INFO - 2021-09-09 13:30:55 --> Helper loaded: security_helper
INFO - 2021-09-09 13:30:55 --> Helper loaded: directory_helper
INFO - 2021-09-09 13:30:55 --> Helper loaded: general_helper
INFO - 2021-09-09 13:30:55 --> Database Driver Class Initialized
INFO - 2021-09-09 13:30:55 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 13:30:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 13:30:55 --> Pagination Class Initialized
INFO - 2021-09-09 13:30:55 --> XML-RPC Class Initialized
INFO - 2021-09-09 13:30:55 --> Form Validation Class Initialized
INFO - 2021-09-09 13:30:55 --> Upload Class Initialized
INFO - 2021-09-09 13:30:55 --> MY_Model class loaded
INFO - 2021-09-09 13:30:55 --> Model "Application_model" initialized
INFO - 2021-09-09 13:30:55 --> Controller Class Initialized
DEBUG - 2021-09-09 13:30:55 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-09 13:30:55 --> Helper loaded: inflector_helper
INFO - 2021-09-09 13:30:55 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-09 13:30:55 --> Database Driver Class Initialized
ERROR - 2021-09-09 13:30:55 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 13:30:55 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 13:30:55 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-09 13:30:55 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-09 13:30:55 --> Model "Authentication_model" initialized
INFO - 2021-09-09 13:30:55 --> Model "Student_model" initialized
INFO - 2021-09-09 13:30:56 --> Final output sent to browser
DEBUG - 2021-09-09 13:30:56 --> Total execution time: 0.7620
INFO - 2021-09-09 13:33:09 --> Config Class Initialized
INFO - 2021-09-09 13:33:09 --> Hooks Class Initialized
DEBUG - 2021-09-09 13:33:09 --> UTF-8 Support Enabled
INFO - 2021-09-09 13:33:09 --> Utf8 Class Initialized
INFO - 2021-09-09 13:33:09 --> URI Class Initialized
INFO - 2021-09-09 13:33:09 --> Router Class Initialized
INFO - 2021-09-09 13:33:09 --> Output Class Initialized
INFO - 2021-09-09 13:33:10 --> Security Class Initialized
DEBUG - 2021-09-09 13:33:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 13:33:10 --> CSRF cookie sent
INFO - 2021-09-09 13:33:10 --> Input Class Initialized
INFO - 2021-09-09 13:33:10 --> Language Class Initialized
INFO - 2021-09-09 13:33:11 --> Loader Class Initialized
INFO - 2021-09-09 13:33:11 --> Helper loaded: url_helper
INFO - 2021-09-09 13:33:11 --> Helper loaded: file_helper
INFO - 2021-09-09 13:33:11 --> Helper loaded: form_helper
INFO - 2021-09-09 13:33:11 --> Helper loaded: security_helper
INFO - 2021-09-09 13:33:11 --> Helper loaded: directory_helper
INFO - 2021-09-09 13:33:11 --> Helper loaded: general_helper
INFO - 2021-09-09 13:33:11 --> Database Driver Class Initialized
INFO - 2021-09-09 13:33:11 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 13:33:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 13:33:11 --> Pagination Class Initialized
INFO - 2021-09-09 13:33:11 --> XML-RPC Class Initialized
INFO - 2021-09-09 13:33:11 --> Form Validation Class Initialized
INFO - 2021-09-09 13:33:11 --> Upload Class Initialized
INFO - 2021-09-09 13:33:11 --> MY_Model class loaded
INFO - 2021-09-09 13:33:11 --> Model "Application_model" initialized
INFO - 2021-09-09 13:33:11 --> Controller Class Initialized
DEBUG - 2021-09-09 13:33:11 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-09 13:33:11 --> Helper loaded: inflector_helper
INFO - 2021-09-09 13:33:11 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-09 13:33:12 --> Config Class Initialized
INFO - 2021-09-09 13:33:12 --> Hooks Class Initialized
DEBUG - 2021-09-09 13:33:12 --> UTF-8 Support Enabled
INFO - 2021-09-09 13:33:12 --> Utf8 Class Initialized
INFO - 2021-09-09 13:33:12 --> URI Class Initialized
INFO - 2021-09-09 13:33:12 --> Router Class Initialized
INFO - 2021-09-09 13:33:12 --> Output Class Initialized
INFO - 2021-09-09 13:33:12 --> Security Class Initialized
DEBUG - 2021-09-09 13:33:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 13:33:12 --> CSRF cookie sent
INFO - 2021-09-09 13:33:12 --> Input Class Initialized
INFO - 2021-09-09 13:33:12 --> Language Class Initialized
INFO - 2021-09-09 13:33:12 --> Loader Class Initialized
INFO - 2021-09-09 13:33:12 --> Helper loaded: url_helper
INFO - 2021-09-09 13:33:12 --> Helper loaded: file_helper
INFO - 2021-09-09 13:33:12 --> Helper loaded: form_helper
INFO - 2021-09-09 13:33:12 --> Helper loaded: security_helper
INFO - 2021-09-09 13:33:12 --> Helper loaded: directory_helper
INFO - 2021-09-09 13:33:12 --> Helper loaded: general_helper
INFO - 2021-09-09 13:33:12 --> Database Driver Class Initialized
INFO - 2021-09-09 13:33:12 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 13:33:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 13:33:12 --> Pagination Class Initialized
INFO - 2021-09-09 13:33:12 --> XML-RPC Class Initialized
INFO - 2021-09-09 13:33:12 --> Form Validation Class Initialized
INFO - 2021-09-09 13:33:12 --> Upload Class Initialized
INFO - 2021-09-09 13:33:12 --> MY_Model class loaded
INFO - 2021-09-09 13:33:12 --> Model "Application_model" initialized
INFO - 2021-09-09 13:33:12 --> Controller Class Initialized
DEBUG - 2021-09-09 13:33:12 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-09 13:33:12 --> Helper loaded: inflector_helper
INFO - 2021-09-09 13:33:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-09 13:33:12 --> Database Driver Class Initialized
ERROR - 2021-09-09 13:33:12 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 13:33:12 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 13:33:12 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-09 13:33:12 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-09 13:33:12 --> Model "Authentication_model" initialized
INFO - 2021-09-09 13:33:12 --> Model "Student_model" initialized
INFO - 2021-09-09 13:33:12 --> Final output sent to browser
DEBUG - 2021-09-09 13:33:12 --> Total execution time: 0.3371
INFO - 2021-09-09 13:33:59 --> Config Class Initialized
INFO - 2021-09-09 13:34:00 --> Hooks Class Initialized
DEBUG - 2021-09-09 13:34:03 --> UTF-8 Support Enabled
INFO - 2021-09-09 13:34:03 --> Utf8 Class Initialized
INFO - 2021-09-09 13:34:03 --> URI Class Initialized
INFO - 2021-09-09 13:34:05 --> Router Class Initialized
INFO - 2021-09-09 13:34:05 --> Output Class Initialized
INFO - 2021-09-09 13:34:05 --> Security Class Initialized
DEBUG - 2021-09-09 13:34:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 13:34:05 --> CSRF cookie sent
INFO - 2021-09-09 13:34:05 --> Input Class Initialized
INFO - 2021-09-09 13:34:06 --> Language Class Initialized
INFO - 2021-09-09 13:34:07 --> Loader Class Initialized
INFO - 2021-09-09 13:34:07 --> Helper loaded: url_helper
INFO - 2021-09-09 13:34:08 --> Helper loaded: file_helper
INFO - 2021-09-09 13:34:08 --> Helper loaded: form_helper
INFO - 2021-09-09 13:34:08 --> Helper loaded: security_helper
INFO - 2021-09-09 13:34:08 --> Helper loaded: directory_helper
INFO - 2021-09-09 13:34:08 --> Helper loaded: general_helper
INFO - 2021-09-09 13:34:09 --> Database Driver Class Initialized
INFO - 2021-09-09 13:34:09 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 13:34:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 13:34:09 --> Pagination Class Initialized
INFO - 2021-09-09 13:34:09 --> XML-RPC Class Initialized
INFO - 2021-09-09 13:34:09 --> Form Validation Class Initialized
INFO - 2021-09-09 13:34:09 --> Upload Class Initialized
INFO - 2021-09-09 13:34:09 --> MY_Model class loaded
INFO - 2021-09-09 13:34:10 --> Model "Application_model" initialized
INFO - 2021-09-09 13:34:10 --> Controller Class Initialized
DEBUG - 2021-09-09 13:34:10 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-09 13:34:10 --> Helper loaded: inflector_helper
INFO - 2021-09-09 13:34:10 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-09 13:34:11 --> Config Class Initialized
INFO - 2021-09-09 13:34:11 --> Hooks Class Initialized
DEBUG - 2021-09-09 13:34:11 --> UTF-8 Support Enabled
INFO - 2021-09-09 13:34:11 --> Utf8 Class Initialized
INFO - 2021-09-09 13:34:11 --> URI Class Initialized
INFO - 2021-09-09 13:34:11 --> Router Class Initialized
INFO - 2021-09-09 13:34:11 --> Output Class Initialized
INFO - 2021-09-09 13:34:11 --> Security Class Initialized
DEBUG - 2021-09-09 13:34:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 13:34:11 --> CSRF cookie sent
INFO - 2021-09-09 13:34:11 --> Input Class Initialized
INFO - 2021-09-09 13:34:11 --> Language Class Initialized
INFO - 2021-09-09 13:34:11 --> Loader Class Initialized
INFO - 2021-09-09 13:34:11 --> Helper loaded: url_helper
INFO - 2021-09-09 13:34:11 --> Helper loaded: file_helper
INFO - 2021-09-09 13:34:11 --> Helper loaded: form_helper
INFO - 2021-09-09 13:34:11 --> Helper loaded: security_helper
INFO - 2021-09-09 13:34:11 --> Helper loaded: directory_helper
INFO - 2021-09-09 13:34:11 --> Helper loaded: general_helper
INFO - 2021-09-09 13:34:12 --> Database Driver Class Initialized
INFO - 2021-09-09 13:34:12 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 13:34:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 13:34:12 --> Pagination Class Initialized
INFO - 2021-09-09 13:34:12 --> XML-RPC Class Initialized
INFO - 2021-09-09 13:34:12 --> Form Validation Class Initialized
INFO - 2021-09-09 13:34:12 --> Upload Class Initialized
INFO - 2021-09-09 13:34:12 --> MY_Model class loaded
INFO - 2021-09-09 13:34:12 --> Model "Application_model" initialized
INFO - 2021-09-09 13:34:12 --> Controller Class Initialized
DEBUG - 2021-09-09 13:34:12 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-09 13:34:12 --> Helper loaded: inflector_helper
INFO - 2021-09-09 13:34:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-09 13:34:12 --> Database Driver Class Initialized
ERROR - 2021-09-09 13:34:12 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 13:34:12 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 13:34:12 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-09 13:34:12 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-09 13:34:12 --> Model "Authentication_model" initialized
INFO - 2021-09-09 13:34:13 --> Model "Student_model" initialized
INFO - 2021-09-09 13:34:13 --> Final output sent to browser
DEBUG - 2021-09-09 13:34:13 --> Total execution time: 2.3169
INFO - 2021-09-09 13:34:47 --> Config Class Initialized
INFO - 2021-09-09 13:34:47 --> Hooks Class Initialized
DEBUG - 2021-09-09 13:34:47 --> UTF-8 Support Enabled
INFO - 2021-09-09 13:34:47 --> Utf8 Class Initialized
INFO - 2021-09-09 13:34:47 --> URI Class Initialized
INFO - 2021-09-09 13:34:47 --> Router Class Initialized
INFO - 2021-09-09 13:34:47 --> Output Class Initialized
INFO - 2021-09-09 13:34:47 --> Security Class Initialized
DEBUG - 2021-09-09 13:34:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 13:34:47 --> CSRF cookie sent
INFO - 2021-09-09 13:34:47 --> Input Class Initialized
INFO - 2021-09-09 13:34:47 --> Language Class Initialized
INFO - 2021-09-09 13:34:47 --> Loader Class Initialized
INFO - 2021-09-09 13:34:47 --> Helper loaded: url_helper
INFO - 2021-09-09 13:34:47 --> Helper loaded: file_helper
INFO - 2021-09-09 13:34:47 --> Helper loaded: form_helper
INFO - 2021-09-09 13:34:47 --> Helper loaded: security_helper
INFO - 2021-09-09 13:34:47 --> Helper loaded: directory_helper
INFO - 2021-09-09 13:34:47 --> Helper loaded: general_helper
INFO - 2021-09-09 13:34:47 --> Database Driver Class Initialized
INFO - 2021-09-09 13:34:47 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 13:34:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 13:34:47 --> Pagination Class Initialized
INFO - 2021-09-09 13:34:47 --> XML-RPC Class Initialized
INFO - 2021-09-09 13:34:47 --> Form Validation Class Initialized
INFO - 2021-09-09 13:34:47 --> Upload Class Initialized
INFO - 2021-09-09 13:34:47 --> MY_Model class loaded
INFO - 2021-09-09 13:34:47 --> Model "Application_model" initialized
INFO - 2021-09-09 13:34:47 --> Controller Class Initialized
DEBUG - 2021-09-09 13:34:47 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-09 13:34:47 --> Helper loaded: inflector_helper
INFO - 2021-09-09 13:34:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-09 13:34:47 --> Config Class Initialized
INFO - 2021-09-09 13:34:47 --> Hooks Class Initialized
DEBUG - 2021-09-09 13:34:47 --> UTF-8 Support Enabled
INFO - 2021-09-09 13:34:47 --> Utf8 Class Initialized
INFO - 2021-09-09 13:34:47 --> URI Class Initialized
INFO - 2021-09-09 13:34:47 --> Router Class Initialized
INFO - 2021-09-09 13:34:47 --> Output Class Initialized
INFO - 2021-09-09 13:34:47 --> Security Class Initialized
DEBUG - 2021-09-09 13:34:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 13:34:47 --> CSRF cookie sent
INFO - 2021-09-09 13:34:47 --> Input Class Initialized
INFO - 2021-09-09 13:34:47 --> Language Class Initialized
INFO - 2021-09-09 13:34:47 --> Loader Class Initialized
INFO - 2021-09-09 13:34:47 --> Helper loaded: url_helper
INFO - 2021-09-09 13:34:47 --> Helper loaded: file_helper
INFO - 2021-09-09 13:34:47 --> Helper loaded: form_helper
INFO - 2021-09-09 13:34:47 --> Helper loaded: security_helper
INFO - 2021-09-09 13:34:47 --> Helper loaded: directory_helper
INFO - 2021-09-09 13:34:47 --> Helper loaded: general_helper
INFO - 2021-09-09 13:34:47 --> Database Driver Class Initialized
INFO - 2021-09-09 13:34:47 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 13:34:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 13:34:47 --> Pagination Class Initialized
INFO - 2021-09-09 13:34:47 --> XML-RPC Class Initialized
INFO - 2021-09-09 13:34:47 --> Form Validation Class Initialized
INFO - 2021-09-09 13:34:47 --> Upload Class Initialized
INFO - 2021-09-09 13:34:47 --> MY_Model class loaded
INFO - 2021-09-09 13:34:47 --> Model "Application_model" initialized
INFO - 2021-09-09 13:34:47 --> Controller Class Initialized
DEBUG - 2021-09-09 13:34:47 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-09 13:34:47 --> Helper loaded: inflector_helper
INFO - 2021-09-09 13:34:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-09 13:34:47 --> Database Driver Class Initialized
ERROR - 2021-09-09 13:34:47 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 13:34:47 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 13:34:47 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-09 13:34:47 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-09 13:34:47 --> Model "Authentication_model" initialized
INFO - 2021-09-09 13:34:47 --> Model "Student_model" initialized
INFO - 2021-09-09 13:34:47 --> Final output sent to browser
DEBUG - 2021-09-09 13:34:47 --> Total execution time: 0.3229
INFO - 2021-09-09 13:35:55 --> Config Class Initialized
INFO - 2021-09-09 13:35:55 --> Hooks Class Initialized
DEBUG - 2021-09-09 13:35:56 --> UTF-8 Support Enabled
INFO - 2021-09-09 13:35:56 --> Utf8 Class Initialized
INFO - 2021-09-09 13:35:56 --> URI Class Initialized
INFO - 2021-09-09 13:35:56 --> Router Class Initialized
INFO - 2021-09-09 13:35:56 --> Output Class Initialized
INFO - 2021-09-09 13:35:56 --> Security Class Initialized
DEBUG - 2021-09-09 13:35:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 13:35:57 --> CSRF cookie sent
INFO - 2021-09-09 13:35:57 --> Input Class Initialized
INFO - 2021-09-09 13:35:57 --> Language Class Initialized
INFO - 2021-09-09 13:35:57 --> Loader Class Initialized
INFO - 2021-09-09 13:35:57 --> Helper loaded: url_helper
INFO - 2021-09-09 13:35:57 --> Helper loaded: file_helper
INFO - 2021-09-09 13:35:57 --> Helper loaded: form_helper
INFO - 2021-09-09 13:35:57 --> Helper loaded: security_helper
INFO - 2021-09-09 13:35:57 --> Helper loaded: directory_helper
INFO - 2021-09-09 13:35:57 --> Helper loaded: general_helper
INFO - 2021-09-09 13:35:57 --> Database Driver Class Initialized
INFO - 2021-09-09 13:35:59 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 13:36:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 13:36:00 --> Pagination Class Initialized
INFO - 2021-09-09 13:36:00 --> XML-RPC Class Initialized
INFO - 2021-09-09 13:36:00 --> Form Validation Class Initialized
INFO - 2021-09-09 13:36:01 --> Upload Class Initialized
INFO - 2021-09-09 13:36:01 --> MY_Model class loaded
INFO - 2021-09-09 13:36:01 --> Model "Application_model" initialized
INFO - 2021-09-09 13:36:01 --> Controller Class Initialized
DEBUG - 2021-09-09 13:36:01 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-09 13:36:01 --> Helper loaded: inflector_helper
INFO - 2021-09-09 13:36:01 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-09 13:36:02 --> Config Class Initialized
INFO - 2021-09-09 13:36:02 --> Hooks Class Initialized
DEBUG - 2021-09-09 13:36:02 --> UTF-8 Support Enabled
INFO - 2021-09-09 13:36:02 --> Utf8 Class Initialized
INFO - 2021-09-09 13:36:02 --> URI Class Initialized
INFO - 2021-09-09 13:36:02 --> Router Class Initialized
INFO - 2021-09-09 13:36:02 --> Output Class Initialized
INFO - 2021-09-09 13:36:02 --> Security Class Initialized
DEBUG - 2021-09-09 13:36:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 13:36:02 --> CSRF cookie sent
INFO - 2021-09-09 13:36:02 --> Input Class Initialized
INFO - 2021-09-09 13:36:02 --> Language Class Initialized
INFO - 2021-09-09 13:36:02 --> Loader Class Initialized
INFO - 2021-09-09 13:36:02 --> Helper loaded: url_helper
INFO - 2021-09-09 13:36:02 --> Helper loaded: file_helper
INFO - 2021-09-09 13:36:02 --> Helper loaded: form_helper
INFO - 2021-09-09 13:36:02 --> Helper loaded: security_helper
INFO - 2021-09-09 13:36:02 --> Helper loaded: directory_helper
INFO - 2021-09-09 13:36:02 --> Helper loaded: general_helper
INFO - 2021-09-09 13:36:02 --> Database Driver Class Initialized
INFO - 2021-09-09 13:36:02 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 13:36:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 13:36:02 --> Pagination Class Initialized
INFO - 2021-09-09 13:36:02 --> XML-RPC Class Initialized
INFO - 2021-09-09 13:36:02 --> Form Validation Class Initialized
INFO - 2021-09-09 13:36:02 --> Upload Class Initialized
INFO - 2021-09-09 13:36:02 --> MY_Model class loaded
INFO - 2021-09-09 13:36:02 --> Model "Application_model" initialized
INFO - 2021-09-09 13:36:02 --> Controller Class Initialized
DEBUG - 2021-09-09 13:36:02 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-09 13:36:02 --> Helper loaded: inflector_helper
INFO - 2021-09-09 13:36:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-09 13:36:02 --> Database Driver Class Initialized
ERROR - 2021-09-09 13:36:02 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 13:36:02 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 13:36:02 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-09 13:36:02 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-09 13:36:02 --> Model "Authentication_model" initialized
INFO - 2021-09-09 13:36:02 --> Model "Student_model" initialized
INFO - 2021-09-09 13:36:02 --> Final output sent to browser
DEBUG - 2021-09-09 13:36:02 --> Total execution time: 0.2697
INFO - 2021-09-09 13:38:38 --> Config Class Initialized
INFO - 2021-09-09 13:38:38 --> Hooks Class Initialized
DEBUG - 2021-09-09 13:38:40 --> UTF-8 Support Enabled
INFO - 2021-09-09 13:38:41 --> Utf8 Class Initialized
INFO - 2021-09-09 13:38:41 --> URI Class Initialized
INFO - 2021-09-09 13:38:42 --> Router Class Initialized
INFO - 2021-09-09 13:38:42 --> Output Class Initialized
INFO - 2021-09-09 13:38:42 --> Security Class Initialized
DEBUG - 2021-09-09 13:38:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 13:38:42 --> CSRF cookie sent
INFO - 2021-09-09 13:38:42 --> Input Class Initialized
INFO - 2021-09-09 13:38:42 --> Language Class Initialized
INFO - 2021-09-09 13:38:42 --> Loader Class Initialized
INFO - 2021-09-09 13:38:42 --> Helper loaded: url_helper
INFO - 2021-09-09 13:38:43 --> Helper loaded: file_helper
INFO - 2021-09-09 13:38:43 --> Helper loaded: form_helper
INFO - 2021-09-09 13:38:43 --> Helper loaded: security_helper
INFO - 2021-09-09 13:38:43 --> Helper loaded: directory_helper
INFO - 2021-09-09 13:38:43 --> Helper loaded: general_helper
INFO - 2021-09-09 13:38:44 --> Database Driver Class Initialized
INFO - 2021-09-09 13:38:44 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 13:38:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 13:38:44 --> Pagination Class Initialized
INFO - 2021-09-09 13:38:44 --> XML-RPC Class Initialized
INFO - 2021-09-09 13:38:44 --> Form Validation Class Initialized
INFO - 2021-09-09 13:38:44 --> Upload Class Initialized
INFO - 2021-09-09 13:38:44 --> MY_Model class loaded
INFO - 2021-09-09 13:38:44 --> Model "Application_model" initialized
INFO - 2021-09-09 13:38:44 --> Controller Class Initialized
DEBUG - 2021-09-09 13:38:44 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-09 13:38:44 --> Helper loaded: inflector_helper
INFO - 2021-09-09 13:38:44 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-09 13:38:45 --> Config Class Initialized
INFO - 2021-09-09 13:38:45 --> Hooks Class Initialized
DEBUG - 2021-09-09 13:38:45 --> UTF-8 Support Enabled
INFO - 2021-09-09 13:38:45 --> Utf8 Class Initialized
INFO - 2021-09-09 13:38:45 --> URI Class Initialized
INFO - 2021-09-09 13:38:45 --> Router Class Initialized
INFO - 2021-09-09 13:38:45 --> Output Class Initialized
INFO - 2021-09-09 13:38:45 --> Security Class Initialized
DEBUG - 2021-09-09 13:38:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 13:38:45 --> CSRF cookie sent
INFO - 2021-09-09 13:38:45 --> Input Class Initialized
INFO - 2021-09-09 13:38:45 --> Language Class Initialized
INFO - 2021-09-09 13:38:45 --> Loader Class Initialized
INFO - 2021-09-09 13:38:45 --> Helper loaded: url_helper
INFO - 2021-09-09 13:38:45 --> Helper loaded: file_helper
INFO - 2021-09-09 13:38:45 --> Helper loaded: form_helper
INFO - 2021-09-09 13:38:45 --> Helper loaded: security_helper
INFO - 2021-09-09 13:38:45 --> Helper loaded: directory_helper
INFO - 2021-09-09 13:38:45 --> Helper loaded: general_helper
INFO - 2021-09-09 13:38:45 --> Database Driver Class Initialized
INFO - 2021-09-09 13:38:45 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 13:38:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 13:38:45 --> Pagination Class Initialized
INFO - 2021-09-09 13:38:45 --> XML-RPC Class Initialized
INFO - 2021-09-09 13:38:45 --> Form Validation Class Initialized
INFO - 2021-09-09 13:38:45 --> Upload Class Initialized
INFO - 2021-09-09 13:38:45 --> MY_Model class loaded
INFO - 2021-09-09 13:38:45 --> Model "Application_model" initialized
INFO - 2021-09-09 13:38:45 --> Controller Class Initialized
DEBUG - 2021-09-09 13:38:45 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-09 13:38:45 --> Helper loaded: inflector_helper
INFO - 2021-09-09 13:38:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-09 13:38:45 --> Database Driver Class Initialized
ERROR - 2021-09-09 13:38:45 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 13:38:45 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 13:38:45 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-09 13:38:45 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-09 13:38:45 --> Model "Authentication_model" initialized
INFO - 2021-09-09 13:38:45 --> Model "Student_model" initialized
INFO - 2021-09-09 13:38:45 --> Final output sent to browser
DEBUG - 2021-09-09 13:38:45 --> Total execution time: 0.2087
INFO - 2021-09-09 13:39:34 --> Config Class Initialized
INFO - 2021-09-09 13:39:34 --> Hooks Class Initialized
DEBUG - 2021-09-09 13:39:34 --> UTF-8 Support Enabled
INFO - 2021-09-09 13:39:34 --> Utf8 Class Initialized
INFO - 2021-09-09 13:39:34 --> URI Class Initialized
INFO - 2021-09-09 13:39:34 --> Router Class Initialized
INFO - 2021-09-09 13:39:34 --> Output Class Initialized
INFO - 2021-09-09 13:39:34 --> Security Class Initialized
DEBUG - 2021-09-09 13:39:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 13:39:34 --> CSRF cookie sent
INFO - 2021-09-09 13:39:34 --> Input Class Initialized
INFO - 2021-09-09 13:39:34 --> Language Class Initialized
INFO - 2021-09-09 13:39:34 --> Loader Class Initialized
INFO - 2021-09-09 13:39:34 --> Helper loaded: url_helper
INFO - 2021-09-09 13:39:34 --> Helper loaded: file_helper
INFO - 2021-09-09 13:39:34 --> Helper loaded: form_helper
INFO - 2021-09-09 13:39:34 --> Helper loaded: security_helper
INFO - 2021-09-09 13:39:34 --> Helper loaded: directory_helper
INFO - 2021-09-09 13:39:34 --> Helper loaded: general_helper
INFO - 2021-09-09 13:39:34 --> Database Driver Class Initialized
INFO - 2021-09-09 13:39:34 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 13:39:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 13:39:34 --> Pagination Class Initialized
INFO - 2021-09-09 13:39:34 --> XML-RPC Class Initialized
INFO - 2021-09-09 13:39:34 --> Form Validation Class Initialized
INFO - 2021-09-09 13:39:34 --> Upload Class Initialized
INFO - 2021-09-09 13:39:34 --> MY_Model class loaded
INFO - 2021-09-09 13:39:34 --> Model "Application_model" initialized
INFO - 2021-09-09 13:39:34 --> Controller Class Initialized
DEBUG - 2021-09-09 13:39:34 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-09 13:39:34 --> Helper loaded: inflector_helper
INFO - 2021-09-09 13:39:34 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-09 13:39:34 --> Config Class Initialized
INFO - 2021-09-09 13:39:34 --> Hooks Class Initialized
DEBUG - 2021-09-09 13:39:34 --> UTF-8 Support Enabled
INFO - 2021-09-09 13:39:34 --> Utf8 Class Initialized
INFO - 2021-09-09 13:39:34 --> URI Class Initialized
INFO - 2021-09-09 13:39:34 --> Router Class Initialized
INFO - 2021-09-09 13:39:34 --> Output Class Initialized
INFO - 2021-09-09 13:39:34 --> Security Class Initialized
DEBUG - 2021-09-09 13:39:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 13:39:34 --> CSRF cookie sent
INFO - 2021-09-09 13:39:34 --> Input Class Initialized
INFO - 2021-09-09 13:39:34 --> Language Class Initialized
INFO - 2021-09-09 13:39:34 --> Loader Class Initialized
INFO - 2021-09-09 13:39:34 --> Helper loaded: url_helper
INFO - 2021-09-09 13:39:34 --> Helper loaded: file_helper
INFO - 2021-09-09 13:39:34 --> Helper loaded: form_helper
INFO - 2021-09-09 13:39:34 --> Helper loaded: security_helper
INFO - 2021-09-09 13:39:34 --> Helper loaded: directory_helper
INFO - 2021-09-09 13:39:34 --> Helper loaded: general_helper
INFO - 2021-09-09 13:39:34 --> Database Driver Class Initialized
INFO - 2021-09-09 13:39:34 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 13:39:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 13:39:34 --> Pagination Class Initialized
INFO - 2021-09-09 13:39:34 --> XML-RPC Class Initialized
INFO - 2021-09-09 13:39:34 --> Form Validation Class Initialized
INFO - 2021-09-09 13:39:34 --> Upload Class Initialized
INFO - 2021-09-09 13:39:34 --> MY_Model class loaded
INFO - 2021-09-09 13:39:35 --> Model "Application_model" initialized
INFO - 2021-09-09 13:39:35 --> Controller Class Initialized
DEBUG - 2021-09-09 13:39:35 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-09 13:39:35 --> Helper loaded: inflector_helper
INFO - 2021-09-09 13:39:35 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-09 13:39:35 --> Database Driver Class Initialized
ERROR - 2021-09-09 13:39:35 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 13:39:35 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 13:39:35 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-09 13:39:35 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-09 13:39:35 --> Model "Authentication_model" initialized
INFO - 2021-09-09 13:39:35 --> Model "Student_model" initialized
INFO - 2021-09-09 13:39:35 --> Final output sent to browser
DEBUG - 2021-09-09 13:39:35 --> Total execution time: 0.1998
INFO - 2021-09-09 13:40:26 --> Config Class Initialized
INFO - 2021-09-09 13:40:26 --> Hooks Class Initialized
DEBUG - 2021-09-09 13:40:27 --> UTF-8 Support Enabled
INFO - 2021-09-09 13:40:27 --> Utf8 Class Initialized
INFO - 2021-09-09 13:40:27 --> URI Class Initialized
INFO - 2021-09-09 13:40:27 --> Router Class Initialized
INFO - 2021-09-09 13:40:27 --> Output Class Initialized
INFO - 2021-09-09 13:40:28 --> Security Class Initialized
DEBUG - 2021-09-09 13:40:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 13:40:28 --> CSRF cookie sent
INFO - 2021-09-09 13:40:28 --> Input Class Initialized
INFO - 2021-09-09 13:40:28 --> Language Class Initialized
INFO - 2021-09-09 13:40:28 --> Loader Class Initialized
INFO - 2021-09-09 13:40:28 --> Helper loaded: url_helper
INFO - 2021-09-09 13:40:28 --> Helper loaded: file_helper
INFO - 2021-09-09 13:40:28 --> Helper loaded: form_helper
INFO - 2021-09-09 13:40:28 --> Helper loaded: security_helper
INFO - 2021-09-09 13:40:28 --> Helper loaded: directory_helper
INFO - 2021-09-09 13:40:28 --> Helper loaded: general_helper
INFO - 2021-09-09 13:40:29 --> Database Driver Class Initialized
INFO - 2021-09-09 13:40:29 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 13:40:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 13:40:29 --> Pagination Class Initialized
INFO - 2021-09-09 13:40:29 --> XML-RPC Class Initialized
INFO - 2021-09-09 13:40:29 --> Form Validation Class Initialized
INFO - 2021-09-09 13:40:29 --> Upload Class Initialized
INFO - 2021-09-09 13:40:29 --> MY_Model class loaded
INFO - 2021-09-09 13:40:29 --> Model "Application_model" initialized
INFO - 2021-09-09 13:40:30 --> Controller Class Initialized
DEBUG - 2021-09-09 13:40:30 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-09 13:40:30 --> Helper loaded: inflector_helper
INFO - 2021-09-09 13:40:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-09 13:40:30 --> Config Class Initialized
INFO - 2021-09-09 13:40:30 --> Hooks Class Initialized
DEBUG - 2021-09-09 13:40:30 --> UTF-8 Support Enabled
INFO - 2021-09-09 13:40:30 --> Utf8 Class Initialized
INFO - 2021-09-09 13:40:30 --> URI Class Initialized
INFO - 2021-09-09 13:40:30 --> Router Class Initialized
INFO - 2021-09-09 13:40:30 --> Output Class Initialized
INFO - 2021-09-09 13:40:30 --> Security Class Initialized
DEBUG - 2021-09-09 13:40:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 13:40:30 --> CSRF cookie sent
INFO - 2021-09-09 13:40:30 --> Input Class Initialized
INFO - 2021-09-09 13:40:30 --> Language Class Initialized
INFO - 2021-09-09 13:40:30 --> Loader Class Initialized
INFO - 2021-09-09 13:40:30 --> Helper loaded: url_helper
INFO - 2021-09-09 13:40:30 --> Helper loaded: file_helper
INFO - 2021-09-09 13:40:30 --> Helper loaded: form_helper
INFO - 2021-09-09 13:40:30 --> Helper loaded: security_helper
INFO - 2021-09-09 13:40:30 --> Helper loaded: directory_helper
INFO - 2021-09-09 13:40:30 --> Helper loaded: general_helper
INFO - 2021-09-09 13:40:30 --> Database Driver Class Initialized
INFO - 2021-09-09 13:40:30 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 13:40:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 13:40:30 --> Pagination Class Initialized
INFO - 2021-09-09 13:40:30 --> XML-RPC Class Initialized
INFO - 2021-09-09 13:40:30 --> Form Validation Class Initialized
INFO - 2021-09-09 13:40:30 --> Upload Class Initialized
INFO - 2021-09-09 13:40:30 --> MY_Model class loaded
INFO - 2021-09-09 13:40:30 --> Model "Application_model" initialized
INFO - 2021-09-09 13:40:30 --> Controller Class Initialized
DEBUG - 2021-09-09 13:40:30 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-09 13:40:30 --> Helper loaded: inflector_helper
INFO - 2021-09-09 13:40:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-09 13:40:30 --> Database Driver Class Initialized
ERROR - 2021-09-09 13:40:31 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 13:40:31 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 13:40:31 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-09 13:40:31 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-09 13:40:31 --> Model "Authentication_model" initialized
ERROR - 2021-09-09 13:40:31 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_result::nums_rows() C:\Users\Gopal Ghimire\Desktop\New folder\school\application\models\Authentication_model.php 22
INFO - 2021-09-09 13:42:14 --> Config Class Initialized
INFO - 2021-09-09 13:42:14 --> Hooks Class Initialized
DEBUG - 2021-09-09 13:42:14 --> UTF-8 Support Enabled
INFO - 2021-09-09 13:42:14 --> Utf8 Class Initialized
INFO - 2021-09-09 13:42:14 --> URI Class Initialized
INFO - 2021-09-09 13:42:14 --> Router Class Initialized
INFO - 2021-09-09 13:42:14 --> Output Class Initialized
INFO - 2021-09-09 13:42:14 --> Security Class Initialized
DEBUG - 2021-09-09 13:42:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 13:42:14 --> CSRF cookie sent
INFO - 2021-09-09 13:42:14 --> Input Class Initialized
INFO - 2021-09-09 13:42:14 --> Language Class Initialized
INFO - 2021-09-09 13:42:14 --> Loader Class Initialized
INFO - 2021-09-09 13:42:14 --> Helper loaded: url_helper
INFO - 2021-09-09 13:42:14 --> Helper loaded: file_helper
INFO - 2021-09-09 13:42:14 --> Helper loaded: form_helper
INFO - 2021-09-09 13:42:14 --> Helper loaded: security_helper
INFO - 2021-09-09 13:42:14 --> Helper loaded: directory_helper
INFO - 2021-09-09 13:42:14 --> Helper loaded: general_helper
INFO - 2021-09-09 13:42:14 --> Database Driver Class Initialized
INFO - 2021-09-09 13:42:14 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 13:42:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 13:42:14 --> Pagination Class Initialized
INFO - 2021-09-09 13:42:14 --> XML-RPC Class Initialized
INFO - 2021-09-09 13:42:14 --> Form Validation Class Initialized
INFO - 2021-09-09 13:42:14 --> Upload Class Initialized
INFO - 2021-09-09 13:42:14 --> MY_Model class loaded
INFO - 2021-09-09 13:42:14 --> Model "Application_model" initialized
INFO - 2021-09-09 13:42:14 --> Controller Class Initialized
DEBUG - 2021-09-09 13:42:14 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-09 13:42:14 --> Helper loaded: inflector_helper
INFO - 2021-09-09 13:42:14 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-09 13:42:15 --> Config Class Initialized
INFO - 2021-09-09 13:42:15 --> Hooks Class Initialized
DEBUG - 2021-09-09 13:42:15 --> UTF-8 Support Enabled
INFO - 2021-09-09 13:42:15 --> Utf8 Class Initialized
INFO - 2021-09-09 13:42:15 --> URI Class Initialized
INFO - 2021-09-09 13:42:15 --> Router Class Initialized
INFO - 2021-09-09 13:42:15 --> Output Class Initialized
INFO - 2021-09-09 13:42:15 --> Security Class Initialized
DEBUG - 2021-09-09 13:42:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 13:42:15 --> CSRF cookie sent
INFO - 2021-09-09 13:42:15 --> Input Class Initialized
INFO - 2021-09-09 13:42:15 --> Language Class Initialized
INFO - 2021-09-09 13:42:15 --> Loader Class Initialized
INFO - 2021-09-09 13:42:15 --> Helper loaded: url_helper
INFO - 2021-09-09 13:42:15 --> Helper loaded: file_helper
INFO - 2021-09-09 13:42:15 --> Helper loaded: form_helper
INFO - 2021-09-09 13:42:15 --> Helper loaded: security_helper
INFO - 2021-09-09 13:42:15 --> Helper loaded: directory_helper
INFO - 2021-09-09 13:42:15 --> Helper loaded: general_helper
INFO - 2021-09-09 13:42:15 --> Database Driver Class Initialized
INFO - 2021-09-09 13:42:15 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 13:42:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 13:42:15 --> Pagination Class Initialized
INFO - 2021-09-09 13:42:15 --> XML-RPC Class Initialized
INFO - 2021-09-09 13:42:15 --> Form Validation Class Initialized
INFO - 2021-09-09 13:42:15 --> Upload Class Initialized
INFO - 2021-09-09 13:42:15 --> MY_Model class loaded
INFO - 2021-09-09 13:42:15 --> Model "Application_model" initialized
INFO - 2021-09-09 13:42:15 --> Controller Class Initialized
DEBUG - 2021-09-09 13:42:15 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-09 13:42:15 --> Helper loaded: inflector_helper
INFO - 2021-09-09 13:42:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-09 13:42:15 --> Database Driver Class Initialized
ERROR - 2021-09-09 13:42:15 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 13:42:15 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 13:42:15 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-09 13:42:15 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-09 13:42:15 --> Model "Authentication_model" initialized
ERROR - 2021-09-09 13:42:15 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_result::nums_rows() C:\Users\Gopal Ghimire\Desktop\New folder\school\application\models\Authentication_model.php 22
INFO - 2021-09-09 13:44:50 --> Config Class Initialized
INFO - 2021-09-09 13:44:50 --> Hooks Class Initialized
DEBUG - 2021-09-09 13:44:50 --> UTF-8 Support Enabled
INFO - 2021-09-09 13:44:50 --> Utf8 Class Initialized
INFO - 2021-09-09 13:44:50 --> URI Class Initialized
INFO - 2021-09-09 13:44:50 --> Router Class Initialized
INFO - 2021-09-09 13:44:50 --> Output Class Initialized
INFO - 2021-09-09 13:44:50 --> Security Class Initialized
DEBUG - 2021-09-09 13:44:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 13:44:50 --> CSRF cookie sent
INFO - 2021-09-09 13:44:50 --> Input Class Initialized
INFO - 2021-09-09 13:44:50 --> Language Class Initialized
INFO - 2021-09-09 13:44:50 --> Loader Class Initialized
INFO - 2021-09-09 13:44:50 --> Helper loaded: url_helper
INFO - 2021-09-09 13:44:50 --> Helper loaded: file_helper
INFO - 2021-09-09 13:44:50 --> Helper loaded: form_helper
INFO - 2021-09-09 13:44:50 --> Helper loaded: security_helper
INFO - 2021-09-09 13:44:50 --> Helper loaded: directory_helper
INFO - 2021-09-09 13:44:50 --> Helper loaded: general_helper
INFO - 2021-09-09 13:44:50 --> Database Driver Class Initialized
INFO - 2021-09-09 13:44:50 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 13:44:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 13:44:50 --> Pagination Class Initialized
INFO - 2021-09-09 13:44:50 --> XML-RPC Class Initialized
INFO - 2021-09-09 13:44:50 --> Form Validation Class Initialized
INFO - 2021-09-09 13:44:50 --> Upload Class Initialized
INFO - 2021-09-09 13:44:50 --> MY_Model class loaded
INFO - 2021-09-09 13:44:50 --> Model "Application_model" initialized
INFO - 2021-09-09 13:44:50 --> Controller Class Initialized
DEBUG - 2021-09-09 13:44:50 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-09 13:44:50 --> Helper loaded: inflector_helper
INFO - 2021-09-09 13:44:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-09 13:44:50 --> Config Class Initialized
INFO - 2021-09-09 13:44:50 --> Hooks Class Initialized
DEBUG - 2021-09-09 13:44:50 --> UTF-8 Support Enabled
INFO - 2021-09-09 13:44:50 --> Utf8 Class Initialized
INFO - 2021-09-09 13:44:50 --> URI Class Initialized
INFO - 2021-09-09 13:44:50 --> Router Class Initialized
INFO - 2021-09-09 13:44:50 --> Output Class Initialized
INFO - 2021-09-09 13:44:50 --> Security Class Initialized
DEBUG - 2021-09-09 13:44:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 13:44:50 --> CSRF cookie sent
INFO - 2021-09-09 13:44:50 --> Input Class Initialized
INFO - 2021-09-09 13:44:50 --> Language Class Initialized
INFO - 2021-09-09 13:44:50 --> Loader Class Initialized
INFO - 2021-09-09 13:44:50 --> Helper loaded: url_helper
INFO - 2021-09-09 13:44:50 --> Helper loaded: file_helper
INFO - 2021-09-09 13:44:50 --> Helper loaded: form_helper
INFO - 2021-09-09 13:44:50 --> Helper loaded: security_helper
INFO - 2021-09-09 13:44:50 --> Helper loaded: directory_helper
INFO - 2021-09-09 13:44:50 --> Helper loaded: general_helper
INFO - 2021-09-09 13:44:50 --> Database Driver Class Initialized
INFO - 2021-09-09 13:44:50 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 13:44:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 13:44:50 --> Pagination Class Initialized
INFO - 2021-09-09 13:44:50 --> XML-RPC Class Initialized
INFO - 2021-09-09 13:44:50 --> Form Validation Class Initialized
INFO - 2021-09-09 13:44:50 --> Upload Class Initialized
INFO - 2021-09-09 13:44:50 --> MY_Model class loaded
INFO - 2021-09-09 13:44:50 --> Model "Application_model" initialized
INFO - 2021-09-09 13:44:50 --> Controller Class Initialized
DEBUG - 2021-09-09 13:44:50 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-09 13:44:50 --> Helper loaded: inflector_helper
INFO - 2021-09-09 13:44:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-09 13:44:50 --> Database Driver Class Initialized
ERROR - 2021-09-09 13:44:51 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 13:44:51 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 13:44:51 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-09 13:44:51 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-09 13:44:51 --> Model "Authentication_model" initialized
INFO - 2021-09-09 13:44:51 --> Model "Student_model" initialized
INFO - 2021-09-09 13:44:51 --> Final output sent to browser
DEBUG - 2021-09-09 13:44:51 --> Total execution time: 0.4261
INFO - 2021-09-09 13:45:25 --> Config Class Initialized
INFO - 2021-09-09 13:45:25 --> Hooks Class Initialized
DEBUG - 2021-09-09 13:45:25 --> UTF-8 Support Enabled
INFO - 2021-09-09 13:45:25 --> Utf8 Class Initialized
INFO - 2021-09-09 13:45:25 --> URI Class Initialized
INFO - 2021-09-09 13:45:25 --> Router Class Initialized
INFO - 2021-09-09 13:45:25 --> Output Class Initialized
INFO - 2021-09-09 13:45:25 --> Security Class Initialized
DEBUG - 2021-09-09 13:45:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 13:45:25 --> CSRF cookie sent
INFO - 2021-09-09 13:45:25 --> Input Class Initialized
INFO - 2021-09-09 13:45:25 --> Language Class Initialized
INFO - 2021-09-09 13:45:25 --> Loader Class Initialized
INFO - 2021-09-09 13:45:25 --> Helper loaded: url_helper
INFO - 2021-09-09 13:45:25 --> Helper loaded: file_helper
INFO - 2021-09-09 13:45:25 --> Helper loaded: form_helper
INFO - 2021-09-09 13:45:25 --> Helper loaded: security_helper
INFO - 2021-09-09 13:45:25 --> Helper loaded: directory_helper
INFO - 2021-09-09 13:45:25 --> Helper loaded: general_helper
INFO - 2021-09-09 13:45:25 --> Database Driver Class Initialized
INFO - 2021-09-09 13:45:25 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 13:45:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 13:45:25 --> Pagination Class Initialized
INFO - 2021-09-09 13:45:25 --> XML-RPC Class Initialized
INFO - 2021-09-09 13:45:25 --> Form Validation Class Initialized
INFO - 2021-09-09 13:45:25 --> Upload Class Initialized
INFO - 2021-09-09 13:45:25 --> MY_Model class loaded
INFO - 2021-09-09 13:45:25 --> Model "Application_model" initialized
INFO - 2021-09-09 13:45:25 --> Controller Class Initialized
DEBUG - 2021-09-09 13:45:25 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-09 13:45:25 --> Helper loaded: inflector_helper
INFO - 2021-09-09 13:45:25 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-09 13:45:25 --> Config Class Initialized
INFO - 2021-09-09 13:45:25 --> Hooks Class Initialized
DEBUG - 2021-09-09 13:45:25 --> UTF-8 Support Enabled
INFO - 2021-09-09 13:45:25 --> Utf8 Class Initialized
INFO - 2021-09-09 13:45:25 --> URI Class Initialized
INFO - 2021-09-09 13:45:25 --> Router Class Initialized
INFO - 2021-09-09 13:45:25 --> Output Class Initialized
INFO - 2021-09-09 13:45:25 --> Security Class Initialized
DEBUG - 2021-09-09 13:45:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 13:45:25 --> CSRF cookie sent
INFO - 2021-09-09 13:45:25 --> Input Class Initialized
INFO - 2021-09-09 13:45:25 --> Language Class Initialized
INFO - 2021-09-09 13:45:25 --> Loader Class Initialized
INFO - 2021-09-09 13:45:25 --> Helper loaded: url_helper
INFO - 2021-09-09 13:45:25 --> Helper loaded: file_helper
INFO - 2021-09-09 13:45:25 --> Helper loaded: form_helper
INFO - 2021-09-09 13:45:25 --> Helper loaded: security_helper
INFO - 2021-09-09 13:45:25 --> Helper loaded: directory_helper
INFO - 2021-09-09 13:45:25 --> Helper loaded: general_helper
INFO - 2021-09-09 13:45:25 --> Database Driver Class Initialized
INFO - 2021-09-09 13:45:25 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 13:45:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 13:45:25 --> Pagination Class Initialized
INFO - 2021-09-09 13:45:25 --> XML-RPC Class Initialized
INFO - 2021-09-09 13:45:25 --> Form Validation Class Initialized
INFO - 2021-09-09 13:45:25 --> Upload Class Initialized
INFO - 2021-09-09 13:45:25 --> MY_Model class loaded
INFO - 2021-09-09 13:45:25 --> Model "Application_model" initialized
INFO - 2021-09-09 13:45:25 --> Controller Class Initialized
DEBUG - 2021-09-09 13:45:25 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-09 13:45:25 --> Helper loaded: inflector_helper
INFO - 2021-09-09 13:45:25 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-09 13:45:25 --> Database Driver Class Initialized
ERROR - 2021-09-09 13:45:25 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 13:45:25 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 13:45:25 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-09 13:45:25 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-09 13:45:25 --> Model "Authentication_model" initialized
INFO - 2021-09-09 13:45:25 --> Model "Student_model" initialized
INFO - 2021-09-09 13:45:25 --> Final output sent to browser
DEBUG - 2021-09-09 13:45:25 --> Total execution time: 0.1542
INFO - 2021-09-09 13:46:37 --> Config Class Initialized
INFO - 2021-09-09 13:46:37 --> Hooks Class Initialized
DEBUG - 2021-09-09 13:46:37 --> UTF-8 Support Enabled
INFO - 2021-09-09 13:46:37 --> Utf8 Class Initialized
INFO - 2021-09-09 13:46:37 --> URI Class Initialized
INFO - 2021-09-09 13:46:37 --> Router Class Initialized
INFO - 2021-09-09 13:46:37 --> Output Class Initialized
INFO - 2021-09-09 13:46:37 --> Security Class Initialized
DEBUG - 2021-09-09 13:46:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 13:46:37 --> CSRF cookie sent
INFO - 2021-09-09 13:46:37 --> Input Class Initialized
INFO - 2021-09-09 13:46:37 --> Language Class Initialized
INFO - 2021-09-09 13:46:38 --> Loader Class Initialized
INFO - 2021-09-09 13:46:38 --> Helper loaded: url_helper
INFO - 2021-09-09 13:46:38 --> Helper loaded: file_helper
INFO - 2021-09-09 13:46:38 --> Helper loaded: form_helper
INFO - 2021-09-09 13:46:38 --> Helper loaded: security_helper
INFO - 2021-09-09 13:46:38 --> Helper loaded: directory_helper
INFO - 2021-09-09 13:46:38 --> Helper loaded: general_helper
INFO - 2021-09-09 13:46:38 --> Database Driver Class Initialized
INFO - 2021-09-09 13:46:38 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 13:46:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 13:46:38 --> Pagination Class Initialized
INFO - 2021-09-09 13:46:38 --> XML-RPC Class Initialized
INFO - 2021-09-09 13:46:38 --> Form Validation Class Initialized
INFO - 2021-09-09 13:46:38 --> Upload Class Initialized
INFO - 2021-09-09 13:46:38 --> MY_Model class loaded
INFO - 2021-09-09 13:46:38 --> Model "Application_model" initialized
INFO - 2021-09-09 13:46:38 --> Controller Class Initialized
DEBUG - 2021-09-09 13:46:38 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-09 13:46:38 --> Helper loaded: inflector_helper
INFO - 2021-09-09 13:46:38 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-09 13:46:38 --> Config Class Initialized
INFO - 2021-09-09 13:46:38 --> Hooks Class Initialized
DEBUG - 2021-09-09 13:46:38 --> UTF-8 Support Enabled
INFO - 2021-09-09 13:46:38 --> Utf8 Class Initialized
INFO - 2021-09-09 13:46:38 --> URI Class Initialized
INFO - 2021-09-09 13:46:38 --> Router Class Initialized
INFO - 2021-09-09 13:46:38 --> Output Class Initialized
INFO - 2021-09-09 13:46:38 --> Security Class Initialized
DEBUG - 2021-09-09 13:46:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 13:46:38 --> CSRF cookie sent
INFO - 2021-09-09 13:46:38 --> Input Class Initialized
INFO - 2021-09-09 13:46:38 --> Language Class Initialized
INFO - 2021-09-09 13:46:38 --> Loader Class Initialized
INFO - 2021-09-09 13:46:38 --> Helper loaded: url_helper
INFO - 2021-09-09 13:46:38 --> Helper loaded: file_helper
INFO - 2021-09-09 13:46:38 --> Helper loaded: form_helper
INFO - 2021-09-09 13:46:38 --> Helper loaded: security_helper
INFO - 2021-09-09 13:46:38 --> Helper loaded: directory_helper
INFO - 2021-09-09 13:46:38 --> Helper loaded: general_helper
INFO - 2021-09-09 13:46:38 --> Database Driver Class Initialized
INFO - 2021-09-09 13:46:38 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 13:46:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 13:46:38 --> Pagination Class Initialized
INFO - 2021-09-09 13:46:38 --> XML-RPC Class Initialized
INFO - 2021-09-09 13:46:38 --> Form Validation Class Initialized
INFO - 2021-09-09 13:46:38 --> Upload Class Initialized
INFO - 2021-09-09 13:46:38 --> MY_Model class loaded
INFO - 2021-09-09 13:46:38 --> Model "Application_model" initialized
INFO - 2021-09-09 13:46:38 --> Controller Class Initialized
DEBUG - 2021-09-09 13:46:38 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-09 13:46:38 --> Helper loaded: inflector_helper
INFO - 2021-09-09 13:46:38 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-09 13:46:38 --> Database Driver Class Initialized
ERROR - 2021-09-09 13:46:38 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 13:46:38 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 13:46:38 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-09 13:46:38 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-09 13:46:38 --> Model "Authentication_model" initialized
INFO - 2021-09-09 13:46:38 --> Model "Student_model" initialized
INFO - 2021-09-09 13:46:38 --> Final output sent to browser
DEBUG - 2021-09-09 13:46:38 --> Total execution time: 0.1974
INFO - 2021-09-09 13:46:52 --> Config Class Initialized
INFO - 2021-09-09 13:46:52 --> Hooks Class Initialized
DEBUG - 2021-09-09 13:46:52 --> UTF-8 Support Enabled
INFO - 2021-09-09 13:46:52 --> Utf8 Class Initialized
INFO - 2021-09-09 13:46:52 --> URI Class Initialized
INFO - 2021-09-09 13:46:52 --> Router Class Initialized
INFO - 2021-09-09 13:46:52 --> Output Class Initialized
INFO - 2021-09-09 13:46:52 --> Security Class Initialized
DEBUG - 2021-09-09 13:46:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 13:46:52 --> CSRF cookie sent
INFO - 2021-09-09 13:46:52 --> Input Class Initialized
INFO - 2021-09-09 13:46:52 --> Language Class Initialized
INFO - 2021-09-09 13:46:52 --> Loader Class Initialized
INFO - 2021-09-09 13:46:52 --> Helper loaded: url_helper
INFO - 2021-09-09 13:46:52 --> Helper loaded: file_helper
INFO - 2021-09-09 13:46:52 --> Helper loaded: form_helper
INFO - 2021-09-09 13:46:52 --> Helper loaded: security_helper
INFO - 2021-09-09 13:46:52 --> Helper loaded: directory_helper
INFO - 2021-09-09 13:46:52 --> Helper loaded: general_helper
INFO - 2021-09-09 13:46:52 --> Database Driver Class Initialized
INFO - 2021-09-09 13:46:53 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 13:46:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 13:46:53 --> Pagination Class Initialized
INFO - 2021-09-09 13:46:53 --> XML-RPC Class Initialized
INFO - 2021-09-09 13:46:53 --> Form Validation Class Initialized
INFO - 2021-09-09 13:46:53 --> Upload Class Initialized
INFO - 2021-09-09 13:46:53 --> MY_Model class loaded
INFO - 2021-09-09 13:46:53 --> Model "Application_model" initialized
INFO - 2021-09-09 13:46:53 --> Controller Class Initialized
DEBUG - 2021-09-09 13:46:53 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-09 13:46:53 --> Helper loaded: inflector_helper
INFO - 2021-09-09 13:46:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-09 13:46:53 --> Config Class Initialized
INFO - 2021-09-09 13:46:53 --> Hooks Class Initialized
DEBUG - 2021-09-09 13:46:53 --> UTF-8 Support Enabled
INFO - 2021-09-09 13:46:53 --> Utf8 Class Initialized
INFO - 2021-09-09 13:46:53 --> URI Class Initialized
INFO - 2021-09-09 13:46:53 --> Router Class Initialized
INFO - 2021-09-09 13:46:53 --> Output Class Initialized
INFO - 2021-09-09 13:46:53 --> Security Class Initialized
DEBUG - 2021-09-09 13:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 13:46:53 --> CSRF cookie sent
INFO - 2021-09-09 13:46:53 --> Input Class Initialized
INFO - 2021-09-09 13:46:53 --> Language Class Initialized
INFO - 2021-09-09 13:46:53 --> Loader Class Initialized
INFO - 2021-09-09 13:46:53 --> Helper loaded: url_helper
INFO - 2021-09-09 13:46:53 --> Helper loaded: file_helper
INFO - 2021-09-09 13:46:53 --> Helper loaded: form_helper
INFO - 2021-09-09 13:46:53 --> Helper loaded: security_helper
INFO - 2021-09-09 13:46:53 --> Helper loaded: directory_helper
INFO - 2021-09-09 13:46:53 --> Helper loaded: general_helper
INFO - 2021-09-09 13:46:53 --> Database Driver Class Initialized
INFO - 2021-09-09 13:46:53 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 13:46:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 13:46:53 --> Pagination Class Initialized
INFO - 2021-09-09 13:46:53 --> XML-RPC Class Initialized
INFO - 2021-09-09 13:46:53 --> Form Validation Class Initialized
INFO - 2021-09-09 13:46:53 --> Upload Class Initialized
INFO - 2021-09-09 13:46:53 --> MY_Model class loaded
INFO - 2021-09-09 13:46:53 --> Model "Application_model" initialized
INFO - 2021-09-09 13:46:53 --> Controller Class Initialized
DEBUG - 2021-09-09 13:46:53 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-09 13:46:53 --> Helper loaded: inflector_helper
INFO - 2021-09-09 13:46:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-09 13:46:53 --> Database Driver Class Initialized
ERROR - 2021-09-09 13:46:53 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 13:46:53 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 13:46:53 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-09 13:46:53 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-09 13:46:53 --> Model "Authentication_model" initialized
INFO - 2021-09-09 13:46:53 --> Model "Student_model" initialized
INFO - 2021-09-09 13:46:53 --> Final output sent to browser
DEBUG - 2021-09-09 13:46:53 --> Total execution time: 0.2336
INFO - 2021-09-09 13:47:21 --> Config Class Initialized
INFO - 2021-09-09 13:47:21 --> Hooks Class Initialized
DEBUG - 2021-09-09 13:47:21 --> UTF-8 Support Enabled
INFO - 2021-09-09 13:47:21 --> Utf8 Class Initialized
INFO - 2021-09-09 13:47:21 --> URI Class Initialized
INFO - 2021-09-09 13:47:21 --> Router Class Initialized
INFO - 2021-09-09 13:47:21 --> Output Class Initialized
INFO - 2021-09-09 13:47:21 --> Security Class Initialized
DEBUG - 2021-09-09 13:47:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 13:47:22 --> CSRF cookie sent
INFO - 2021-09-09 13:47:22 --> Input Class Initialized
INFO - 2021-09-09 13:47:22 --> Language Class Initialized
INFO - 2021-09-09 13:47:22 --> Loader Class Initialized
INFO - 2021-09-09 13:47:22 --> Helper loaded: url_helper
INFO - 2021-09-09 13:47:22 --> Helper loaded: file_helper
INFO - 2021-09-09 13:47:22 --> Helper loaded: form_helper
INFO - 2021-09-09 13:47:22 --> Helper loaded: security_helper
INFO - 2021-09-09 13:47:22 --> Helper loaded: directory_helper
INFO - 2021-09-09 13:47:22 --> Helper loaded: general_helper
INFO - 2021-09-09 13:47:22 --> Database Driver Class Initialized
INFO - 2021-09-09 13:47:22 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 13:47:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 13:47:22 --> Pagination Class Initialized
INFO - 2021-09-09 13:47:22 --> XML-RPC Class Initialized
INFO - 2021-09-09 13:47:22 --> Form Validation Class Initialized
INFO - 2021-09-09 13:47:22 --> Upload Class Initialized
INFO - 2021-09-09 13:47:22 --> MY_Model class loaded
INFO - 2021-09-09 13:47:22 --> Model "Application_model" initialized
INFO - 2021-09-09 13:47:22 --> Controller Class Initialized
DEBUG - 2021-09-09 13:47:22 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-09 13:47:23 --> Helper loaded: inflector_helper
INFO - 2021-09-09 13:47:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-09 13:47:23 --> Config Class Initialized
INFO - 2021-09-09 13:47:23 --> Hooks Class Initialized
DEBUG - 2021-09-09 13:47:23 --> UTF-8 Support Enabled
INFO - 2021-09-09 13:47:23 --> Utf8 Class Initialized
INFO - 2021-09-09 13:47:23 --> URI Class Initialized
INFO - 2021-09-09 13:47:23 --> Router Class Initialized
INFO - 2021-09-09 13:47:23 --> Output Class Initialized
INFO - 2021-09-09 13:47:23 --> Security Class Initialized
DEBUG - 2021-09-09 13:47:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 13:47:23 --> CSRF cookie sent
INFO - 2021-09-09 13:47:23 --> Input Class Initialized
INFO - 2021-09-09 13:47:23 --> Language Class Initialized
INFO - 2021-09-09 13:47:23 --> Loader Class Initialized
INFO - 2021-09-09 13:47:23 --> Helper loaded: url_helper
INFO - 2021-09-09 13:47:23 --> Helper loaded: file_helper
INFO - 2021-09-09 13:47:23 --> Helper loaded: form_helper
INFO - 2021-09-09 13:47:23 --> Helper loaded: security_helper
INFO - 2021-09-09 13:47:23 --> Helper loaded: directory_helper
INFO - 2021-09-09 13:47:23 --> Helper loaded: general_helper
INFO - 2021-09-09 13:47:23 --> Database Driver Class Initialized
INFO - 2021-09-09 13:47:23 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 13:47:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 13:47:23 --> Pagination Class Initialized
INFO - 2021-09-09 13:47:23 --> XML-RPC Class Initialized
INFO - 2021-09-09 13:47:23 --> Form Validation Class Initialized
INFO - 2021-09-09 13:47:23 --> Upload Class Initialized
INFO - 2021-09-09 13:47:23 --> MY_Model class loaded
INFO - 2021-09-09 13:47:23 --> Model "Application_model" initialized
INFO - 2021-09-09 13:47:23 --> Controller Class Initialized
DEBUG - 2021-09-09 13:47:23 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-09 13:47:23 --> Helper loaded: inflector_helper
INFO - 2021-09-09 13:47:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-09 13:47:23 --> Database Driver Class Initialized
ERROR - 2021-09-09 13:47:23 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 13:47:23 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 13:47:23 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-09 13:47:23 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-09 13:47:23 --> Model "Authentication_model" initialized
INFO - 2021-09-09 13:47:23 --> Model "Student_model" initialized
INFO - 2021-09-09 13:47:23 --> Final output sent to browser
DEBUG - 2021-09-09 13:47:23 --> Total execution time: 0.2758
INFO - 2021-09-09 13:50:08 --> Config Class Initialized
INFO - 2021-09-09 13:50:08 --> Hooks Class Initialized
DEBUG - 2021-09-09 13:50:08 --> UTF-8 Support Enabled
INFO - 2021-09-09 13:50:08 --> Utf8 Class Initialized
INFO - 2021-09-09 13:50:08 --> URI Class Initialized
INFO - 2021-09-09 13:50:09 --> Router Class Initialized
INFO - 2021-09-09 13:50:09 --> Output Class Initialized
INFO - 2021-09-09 13:50:09 --> Security Class Initialized
DEBUG - 2021-09-09 13:50:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 13:50:10 --> CSRF cookie sent
INFO - 2021-09-09 13:50:10 --> Input Class Initialized
INFO - 2021-09-09 13:50:10 --> Language Class Initialized
INFO - 2021-09-09 13:50:10 --> Loader Class Initialized
INFO - 2021-09-09 13:50:11 --> Helper loaded: url_helper
INFO - 2021-09-09 13:50:11 --> Helper loaded: file_helper
INFO - 2021-09-09 13:50:11 --> Helper loaded: form_helper
INFO - 2021-09-09 13:50:11 --> Helper loaded: security_helper
INFO - 2021-09-09 13:50:11 --> Helper loaded: directory_helper
INFO - 2021-09-09 13:50:11 --> Helper loaded: general_helper
INFO - 2021-09-09 13:50:11 --> Database Driver Class Initialized
INFO - 2021-09-09 13:50:11 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 13:50:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 13:50:11 --> Pagination Class Initialized
INFO - 2021-09-09 13:50:12 --> XML-RPC Class Initialized
INFO - 2021-09-09 13:50:12 --> Form Validation Class Initialized
INFO - 2021-09-09 13:50:12 --> Upload Class Initialized
INFO - 2021-09-09 13:50:12 --> MY_Model class loaded
INFO - 2021-09-09 13:50:12 --> Model "Application_model" initialized
INFO - 2021-09-09 13:50:12 --> Controller Class Initialized
DEBUG - 2021-09-09 13:50:12 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-09 13:50:12 --> Helper loaded: inflector_helper
INFO - 2021-09-09 13:50:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-09 13:50:14 --> Config Class Initialized
INFO - 2021-09-09 13:50:14 --> Hooks Class Initialized
DEBUG - 2021-09-09 13:50:14 --> UTF-8 Support Enabled
INFO - 2021-09-09 13:50:14 --> Utf8 Class Initialized
INFO - 2021-09-09 13:50:14 --> URI Class Initialized
INFO - 2021-09-09 13:50:14 --> Router Class Initialized
INFO - 2021-09-09 13:50:14 --> Output Class Initialized
INFO - 2021-09-09 13:50:14 --> Security Class Initialized
DEBUG - 2021-09-09 13:50:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 13:50:14 --> Input Class Initialized
INFO - 2021-09-09 13:50:14 --> Language Class Initialized
INFO - 2021-09-09 13:50:14 --> Loader Class Initialized
INFO - 2021-09-09 13:50:14 --> Helper loaded: url_helper
INFO - 2021-09-09 13:50:14 --> Helper loaded: file_helper
INFO - 2021-09-09 13:50:14 --> Helper loaded: form_helper
INFO - 2021-09-09 13:50:14 --> Helper loaded: security_helper
INFO - 2021-09-09 13:50:14 --> Helper loaded: directory_helper
INFO - 2021-09-09 13:50:14 --> Helper loaded: general_helper
INFO - 2021-09-09 13:50:14 --> Database Driver Class Initialized
INFO - 2021-09-09 13:50:14 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 13:50:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 13:50:14 --> Pagination Class Initialized
INFO - 2021-09-09 13:50:15 --> XML-RPC Class Initialized
INFO - 2021-09-09 13:50:15 --> Form Validation Class Initialized
INFO - 2021-09-09 13:50:15 --> Upload Class Initialized
INFO - 2021-09-09 13:50:15 --> MY_Model class loaded
INFO - 2021-09-09 13:50:15 --> Model "Application_model" initialized
INFO - 2021-09-09 13:50:15 --> Controller Class Initialized
DEBUG - 2021-09-09 13:50:15 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-09 13:50:16 --> Helper loaded: inflector_helper
INFO - 2021-09-09 13:50:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-09 13:50:16 --> Database Driver Class Initialized
ERROR - 2021-09-09 13:50:16 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 13:50:16 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 13:50:16 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-09 13:50:16 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-09 13:50:16 --> Model "Authentication_model" initialized
INFO - 2021-09-09 13:50:16 --> Model "Branch_model" initialized
INFO - 2021-09-09 13:50:19 --> Final output sent to browser
DEBUG - 2021-09-09 13:50:19 --> Total execution time: 4.8756
INFO - 2021-09-09 13:55:37 --> Config Class Initialized
INFO - 2021-09-09 13:55:37 --> Hooks Class Initialized
DEBUG - 2021-09-09 13:55:38 --> UTF-8 Support Enabled
INFO - 2021-09-09 13:55:38 --> Utf8 Class Initialized
INFO - 2021-09-09 13:55:38 --> URI Class Initialized
INFO - 2021-09-09 13:55:38 --> Router Class Initialized
INFO - 2021-09-09 13:55:38 --> Output Class Initialized
INFO - 2021-09-09 13:55:38 --> Security Class Initialized
DEBUG - 2021-09-09 13:55:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 13:55:38 --> CSRF cookie sent
INFO - 2021-09-09 13:55:38 --> Input Class Initialized
INFO - 2021-09-09 13:55:38 --> Language Class Initialized
INFO - 2021-09-09 13:55:39 --> Loader Class Initialized
INFO - 2021-09-09 13:55:39 --> Helper loaded: url_helper
INFO - 2021-09-09 13:55:39 --> Helper loaded: file_helper
INFO - 2021-09-09 13:55:39 --> Helper loaded: form_helper
INFO - 2021-09-09 13:55:39 --> Helper loaded: security_helper
INFO - 2021-09-09 13:55:39 --> Helper loaded: directory_helper
INFO - 2021-09-09 13:55:40 --> Helper loaded: general_helper
INFO - 2021-09-09 13:55:41 --> Database Driver Class Initialized
INFO - 2021-09-09 13:55:43 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 13:55:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 13:55:43 --> Pagination Class Initialized
INFO - 2021-09-09 13:55:43 --> XML-RPC Class Initialized
INFO - 2021-09-09 13:55:44 --> Form Validation Class Initialized
INFO - 2021-09-09 13:55:44 --> Upload Class Initialized
INFO - 2021-09-09 13:55:44 --> MY_Model class loaded
INFO - 2021-09-09 13:55:44 --> Model "Application_model" initialized
INFO - 2021-09-09 13:55:44 --> Controller Class Initialized
DEBUG - 2021-09-09 13:55:44 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-09 13:55:44 --> Helper loaded: inflector_helper
INFO - 2021-09-09 13:55:44 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-09 13:55:45 --> Config Class Initialized
INFO - 2021-09-09 13:55:45 --> Hooks Class Initialized
DEBUG - 2021-09-09 13:55:45 --> UTF-8 Support Enabled
INFO - 2021-09-09 13:55:45 --> Utf8 Class Initialized
INFO - 2021-09-09 13:55:45 --> URI Class Initialized
INFO - 2021-09-09 13:55:45 --> Router Class Initialized
INFO - 2021-09-09 13:55:45 --> Output Class Initialized
INFO - 2021-09-09 13:55:45 --> Security Class Initialized
DEBUG - 2021-09-09 13:55:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 13:55:45 --> CSRF cookie sent
INFO - 2021-09-09 13:55:45 --> Input Class Initialized
INFO - 2021-09-09 13:55:45 --> Language Class Initialized
INFO - 2021-09-09 13:55:45 --> Loader Class Initialized
INFO - 2021-09-09 13:55:45 --> Helper loaded: url_helper
INFO - 2021-09-09 13:55:45 --> Helper loaded: file_helper
INFO - 2021-09-09 13:55:45 --> Helper loaded: form_helper
INFO - 2021-09-09 13:55:45 --> Helper loaded: security_helper
INFO - 2021-09-09 13:55:45 --> Helper loaded: directory_helper
INFO - 2021-09-09 13:55:45 --> Helper loaded: general_helper
INFO - 2021-09-09 13:55:45 --> Database Driver Class Initialized
INFO - 2021-09-09 13:55:46 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 13:55:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 13:55:46 --> Pagination Class Initialized
INFO - 2021-09-09 13:55:46 --> XML-RPC Class Initialized
INFO - 2021-09-09 13:55:46 --> Form Validation Class Initialized
INFO - 2021-09-09 13:55:46 --> Upload Class Initialized
INFO - 2021-09-09 13:55:46 --> MY_Model class loaded
INFO - 2021-09-09 13:55:46 --> Model "Application_model" initialized
INFO - 2021-09-09 13:55:46 --> Controller Class Initialized
DEBUG - 2021-09-09 13:55:46 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-09 13:55:46 --> Helper loaded: inflector_helper
INFO - 2021-09-09 13:55:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-09 13:55:46 --> Database Driver Class Initialized
ERROR - 2021-09-09 13:55:46 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 13:55:46 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 13:55:46 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-09 13:55:46 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-09 13:55:46 --> Model "Authentication_model" initialized
INFO - 2021-09-09 13:55:46 --> Model "Student_model" initialized
INFO - 2021-09-09 13:55:47 --> Final output sent to browser
DEBUG - 2021-09-09 13:55:47 --> Total execution time: 1.1027
INFO - 2021-09-09 13:56:01 --> Config Class Initialized
INFO - 2021-09-09 13:56:01 --> Hooks Class Initialized
DEBUG - 2021-09-09 13:56:01 --> UTF-8 Support Enabled
INFO - 2021-09-09 13:56:01 --> Utf8 Class Initialized
INFO - 2021-09-09 13:56:01 --> URI Class Initialized
INFO - 2021-09-09 13:56:01 --> Router Class Initialized
INFO - 2021-09-09 13:56:01 --> Output Class Initialized
INFO - 2021-09-09 13:56:01 --> Security Class Initialized
DEBUG - 2021-09-09 13:56:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 13:56:01 --> CSRF cookie sent
INFO - 2021-09-09 13:56:01 --> Input Class Initialized
INFO - 2021-09-09 13:56:01 --> Language Class Initialized
INFO - 2021-09-09 13:56:01 --> Loader Class Initialized
INFO - 2021-09-09 13:56:01 --> Helper loaded: url_helper
INFO - 2021-09-09 13:56:01 --> Helper loaded: file_helper
INFO - 2021-09-09 13:56:01 --> Helper loaded: form_helper
INFO - 2021-09-09 13:56:01 --> Helper loaded: security_helper
INFO - 2021-09-09 13:56:01 --> Helper loaded: directory_helper
INFO - 2021-09-09 13:56:01 --> Helper loaded: general_helper
INFO - 2021-09-09 13:56:01 --> Database Driver Class Initialized
INFO - 2021-09-09 13:56:01 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 13:56:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 13:56:01 --> Pagination Class Initialized
INFO - 2021-09-09 13:56:01 --> XML-RPC Class Initialized
INFO - 2021-09-09 13:56:01 --> Form Validation Class Initialized
INFO - 2021-09-09 13:56:01 --> Upload Class Initialized
INFO - 2021-09-09 13:56:01 --> MY_Model class loaded
INFO - 2021-09-09 13:56:01 --> Model "Application_model" initialized
INFO - 2021-09-09 13:56:01 --> Controller Class Initialized
DEBUG - 2021-09-09 13:56:01 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-09 13:56:01 --> Helper loaded: inflector_helper
INFO - 2021-09-09 13:56:01 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-09 13:56:01 --> Config Class Initialized
INFO - 2021-09-09 13:56:01 --> Hooks Class Initialized
DEBUG - 2021-09-09 13:56:01 --> UTF-8 Support Enabled
INFO - 2021-09-09 13:56:01 --> Utf8 Class Initialized
INFO - 2021-09-09 13:56:01 --> URI Class Initialized
INFO - 2021-09-09 13:56:01 --> Router Class Initialized
INFO - 2021-09-09 13:56:01 --> Output Class Initialized
INFO - 2021-09-09 13:56:01 --> Security Class Initialized
DEBUG - 2021-09-09 13:56:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 13:56:01 --> CSRF cookie sent
INFO - 2021-09-09 13:56:01 --> Input Class Initialized
INFO - 2021-09-09 13:56:01 --> Language Class Initialized
INFO - 2021-09-09 13:56:01 --> Loader Class Initialized
INFO - 2021-09-09 13:56:01 --> Helper loaded: url_helper
INFO - 2021-09-09 13:56:01 --> Helper loaded: file_helper
INFO - 2021-09-09 13:56:01 --> Helper loaded: form_helper
INFO - 2021-09-09 13:56:01 --> Helper loaded: security_helper
INFO - 2021-09-09 13:56:01 --> Helper loaded: directory_helper
INFO - 2021-09-09 13:56:01 --> Helper loaded: general_helper
INFO - 2021-09-09 13:56:01 --> Database Driver Class Initialized
INFO - 2021-09-09 13:56:01 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 13:56:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 13:56:01 --> Pagination Class Initialized
INFO - 2021-09-09 13:56:01 --> XML-RPC Class Initialized
INFO - 2021-09-09 13:56:01 --> Form Validation Class Initialized
INFO - 2021-09-09 13:56:01 --> Upload Class Initialized
INFO - 2021-09-09 13:56:01 --> MY_Model class loaded
INFO - 2021-09-09 13:56:01 --> Model "Application_model" initialized
INFO - 2021-09-09 13:56:01 --> Controller Class Initialized
DEBUG - 2021-09-09 13:56:01 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-09 13:56:01 --> Helper loaded: inflector_helper
INFO - 2021-09-09 13:56:01 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-09 13:56:01 --> Database Driver Class Initialized
ERROR - 2021-09-09 13:56:01 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 13:56:01 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 13:56:01 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-09 13:56:01 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-09 13:56:01 --> Model "Authentication_model" initialized
INFO - 2021-09-09 13:56:01 --> Model "Student_model" initialized
INFO - 2021-09-09 13:56:01 --> Final output sent to browser
DEBUG - 2021-09-09 13:56:01 --> Total execution time: 0.3187
INFO - 2021-09-09 13:56:42 --> Config Class Initialized
INFO - 2021-09-09 13:56:42 --> Hooks Class Initialized
DEBUG - 2021-09-09 13:56:42 --> UTF-8 Support Enabled
INFO - 2021-09-09 13:56:42 --> Utf8 Class Initialized
INFO - 2021-09-09 13:56:42 --> URI Class Initialized
INFO - 2021-09-09 13:56:42 --> Router Class Initialized
INFO - 2021-09-09 13:56:42 --> Output Class Initialized
INFO - 2021-09-09 13:56:42 --> Security Class Initialized
DEBUG - 2021-09-09 13:56:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 13:56:42 --> CSRF cookie sent
INFO - 2021-09-09 13:56:42 --> Input Class Initialized
INFO - 2021-09-09 13:56:42 --> Language Class Initialized
INFO - 2021-09-09 13:56:42 --> Loader Class Initialized
INFO - 2021-09-09 13:56:42 --> Helper loaded: url_helper
INFO - 2021-09-09 13:56:42 --> Helper loaded: file_helper
INFO - 2021-09-09 13:56:42 --> Helper loaded: form_helper
INFO - 2021-09-09 13:56:42 --> Helper loaded: security_helper
INFO - 2021-09-09 13:56:42 --> Helper loaded: directory_helper
INFO - 2021-09-09 13:56:42 --> Helper loaded: general_helper
INFO - 2021-09-09 13:56:42 --> Database Driver Class Initialized
INFO - 2021-09-09 13:56:43 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 13:56:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 13:56:43 --> Pagination Class Initialized
INFO - 2021-09-09 13:56:43 --> XML-RPC Class Initialized
INFO - 2021-09-09 13:56:43 --> Form Validation Class Initialized
INFO - 2021-09-09 13:56:43 --> Upload Class Initialized
INFO - 2021-09-09 13:56:43 --> MY_Model class loaded
INFO - 2021-09-09 13:56:43 --> Model "Application_model" initialized
INFO - 2021-09-09 13:56:43 --> Controller Class Initialized
DEBUG - 2021-09-09 13:56:43 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-09 13:56:43 --> Helper loaded: inflector_helper
INFO - 2021-09-09 13:56:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-09 13:56:44 --> Config Class Initialized
INFO - 2021-09-09 13:56:44 --> Hooks Class Initialized
DEBUG - 2021-09-09 13:56:44 --> UTF-8 Support Enabled
INFO - 2021-09-09 13:56:44 --> Utf8 Class Initialized
INFO - 2021-09-09 13:56:44 --> URI Class Initialized
INFO - 2021-09-09 13:56:44 --> Router Class Initialized
INFO - 2021-09-09 13:56:44 --> Output Class Initialized
INFO - 2021-09-09 13:56:44 --> Security Class Initialized
DEBUG - 2021-09-09 13:56:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 13:56:44 --> CSRF cookie sent
INFO - 2021-09-09 13:56:44 --> Input Class Initialized
INFO - 2021-09-09 13:56:44 --> Language Class Initialized
INFO - 2021-09-09 13:56:44 --> Loader Class Initialized
INFO - 2021-09-09 13:56:44 --> Helper loaded: url_helper
INFO - 2021-09-09 13:56:44 --> Helper loaded: file_helper
INFO - 2021-09-09 13:56:44 --> Helper loaded: form_helper
INFO - 2021-09-09 13:56:44 --> Helper loaded: security_helper
INFO - 2021-09-09 13:56:44 --> Helper loaded: directory_helper
INFO - 2021-09-09 13:56:44 --> Helper loaded: general_helper
INFO - 2021-09-09 13:56:44 --> Database Driver Class Initialized
INFO - 2021-09-09 13:56:44 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 13:56:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 13:56:44 --> Pagination Class Initialized
INFO - 2021-09-09 13:56:44 --> XML-RPC Class Initialized
INFO - 2021-09-09 13:56:44 --> Form Validation Class Initialized
INFO - 2021-09-09 13:56:44 --> Upload Class Initialized
INFO - 2021-09-09 13:56:44 --> MY_Model class loaded
INFO - 2021-09-09 13:56:44 --> Model "Application_model" initialized
INFO - 2021-09-09 13:56:44 --> Controller Class Initialized
DEBUG - 2021-09-09 13:56:44 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-09 13:56:44 --> Helper loaded: inflector_helper
INFO - 2021-09-09 13:56:44 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-09 13:56:44 --> Database Driver Class Initialized
ERROR - 2021-09-09 13:56:44 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 13:56:44 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 13:56:44 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-09 13:56:44 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-09 13:56:44 --> Model "Authentication_model" initialized
INFO - 2021-09-09 13:56:44 --> Final output sent to browser
DEBUG - 2021-09-09 13:56:44 --> Total execution time: 0.3507
INFO - 2021-09-09 13:59:23 --> Config Class Initialized
INFO - 2021-09-09 13:59:23 --> Hooks Class Initialized
DEBUG - 2021-09-09 13:59:23 --> UTF-8 Support Enabled
INFO - 2021-09-09 13:59:23 --> Utf8 Class Initialized
INFO - 2021-09-09 13:59:23 --> URI Class Initialized
INFO - 2021-09-09 13:59:23 --> Router Class Initialized
INFO - 2021-09-09 13:59:24 --> Output Class Initialized
INFO - 2021-09-09 13:59:24 --> Security Class Initialized
DEBUG - 2021-09-09 13:59:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 13:59:24 --> CSRF cookie sent
INFO - 2021-09-09 13:59:24 --> Input Class Initialized
INFO - 2021-09-09 13:59:25 --> Language Class Initialized
INFO - 2021-09-09 13:59:25 --> Loader Class Initialized
INFO - 2021-09-09 13:59:25 --> Helper loaded: url_helper
INFO - 2021-09-09 13:59:25 --> Helper loaded: file_helper
INFO - 2021-09-09 13:59:26 --> Helper loaded: form_helper
INFO - 2021-09-09 13:59:26 --> Helper loaded: security_helper
INFO - 2021-09-09 13:59:26 --> Helper loaded: directory_helper
INFO - 2021-09-09 13:59:26 --> Helper loaded: general_helper
INFO - 2021-09-09 13:59:26 --> Database Driver Class Initialized
INFO - 2021-09-09 13:59:27 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 13:59:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 13:59:27 --> Pagination Class Initialized
INFO - 2021-09-09 13:59:27 --> XML-RPC Class Initialized
INFO - 2021-09-09 13:59:27 --> Form Validation Class Initialized
INFO - 2021-09-09 13:59:27 --> Upload Class Initialized
INFO - 2021-09-09 13:59:27 --> MY_Model class loaded
INFO - 2021-09-09 13:59:27 --> Model "Application_model" initialized
INFO - 2021-09-09 13:59:27 --> Controller Class Initialized
DEBUG - 2021-09-09 13:59:27 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-09 13:59:28 --> Helper loaded: inflector_helper
INFO - 2021-09-09 13:59:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-09 13:59:28 --> Config Class Initialized
INFO - 2021-09-09 13:59:28 --> Hooks Class Initialized
DEBUG - 2021-09-09 13:59:28 --> UTF-8 Support Enabled
INFO - 2021-09-09 13:59:28 --> Utf8 Class Initialized
INFO - 2021-09-09 13:59:28 --> URI Class Initialized
INFO - 2021-09-09 13:59:28 --> Router Class Initialized
INFO - 2021-09-09 13:59:28 --> Output Class Initialized
INFO - 2021-09-09 13:59:28 --> Security Class Initialized
DEBUG - 2021-09-09 13:59:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-09 13:59:28 --> CSRF cookie sent
INFO - 2021-09-09 13:59:28 --> Input Class Initialized
INFO - 2021-09-09 13:59:28 --> Language Class Initialized
INFO - 2021-09-09 13:59:28 --> Loader Class Initialized
INFO - 2021-09-09 13:59:28 --> Helper loaded: url_helper
INFO - 2021-09-09 13:59:28 --> Helper loaded: file_helper
INFO - 2021-09-09 13:59:28 --> Helper loaded: form_helper
INFO - 2021-09-09 13:59:28 --> Helper loaded: security_helper
INFO - 2021-09-09 13:59:28 --> Helper loaded: directory_helper
INFO - 2021-09-09 13:59:28 --> Helper loaded: general_helper
INFO - 2021-09-09 13:59:28 --> Database Driver Class Initialized
INFO - 2021-09-09 13:59:28 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-09 13:59:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-09 13:59:28 --> Pagination Class Initialized
INFO - 2021-09-09 13:59:28 --> XML-RPC Class Initialized
INFO - 2021-09-09 13:59:28 --> Form Validation Class Initialized
INFO - 2021-09-09 13:59:28 --> Upload Class Initialized
INFO - 2021-09-09 13:59:28 --> MY_Model class loaded
INFO - 2021-09-09 13:59:28 --> Model "Application_model" initialized
INFO - 2021-09-09 13:59:28 --> Controller Class Initialized
DEBUG - 2021-09-09 13:59:28 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-09 13:59:28 --> Helper loaded: inflector_helper
INFO - 2021-09-09 13:59:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-09 13:59:28 --> Database Driver Class Initialized
ERROR - 2021-09-09 13:59:28 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 13:59:28 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-09 13:59:28 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-09 13:59:28 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-09 13:59:28 --> Model "Authentication_model" initialized
INFO - 2021-09-09 13:59:28 --> Model "Student_model" initialized
INFO - 2021-09-09 13:59:28 --> Final output sent to browser
DEBUG - 2021-09-09 13:59:28 --> Total execution time: 0.3935
