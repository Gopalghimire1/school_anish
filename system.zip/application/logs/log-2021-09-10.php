<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-09-10 06:14:19 --> Config Class Initialized
INFO - 2021-09-10 06:14:19 --> Hooks Class Initialized
DEBUG - 2021-09-10 06:14:19 --> UTF-8 Support Enabled
INFO - 2021-09-10 06:14:19 --> Utf8 Class Initialized
INFO - 2021-09-10 06:14:20 --> URI Class Initialized
INFO - 2021-09-10 06:14:20 --> Router Class Initialized
INFO - 2021-09-10 06:14:20 --> Output Class Initialized
INFO - 2021-09-10 06:14:20 --> Security Class Initialized
DEBUG - 2021-09-10 06:14:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-10 06:14:20 --> CSRF cookie sent
INFO - 2021-09-10 06:14:20 --> Input Class Initialized
INFO - 2021-09-10 06:14:21 --> Language Class Initialized
INFO - 2021-09-10 06:14:21 --> Loader Class Initialized
INFO - 2021-09-10 06:14:21 --> Helper loaded: url_helper
INFO - 2021-09-10 06:14:21 --> Helper loaded: file_helper
INFO - 2021-09-10 06:14:21 --> Helper loaded: form_helper
INFO - 2021-09-10 06:14:21 --> Helper loaded: security_helper
INFO - 2021-09-10 06:14:21 --> Helper loaded: directory_helper
INFO - 2021-09-10 06:14:21 --> Helper loaded: general_helper
INFO - 2021-09-10 06:14:21 --> Database Driver Class Initialized
INFO - 2021-09-10 06:14:24 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-10 06:14:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-10 06:14:24 --> Pagination Class Initialized
INFO - 2021-09-10 06:14:24 --> XML-RPC Class Initialized
INFO - 2021-09-10 06:14:24 --> Form Validation Class Initialized
INFO - 2021-09-10 06:14:24 --> Upload Class Initialized
INFO - 2021-09-10 06:14:24 --> MY_Model class loaded
INFO - 2021-09-10 06:14:24 --> Model "Application_model" initialized
INFO - 2021-09-10 06:14:24 --> Controller Class Initialized
DEBUG - 2021-09-10 06:14:24 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school_anish\application\config/rest.php
INFO - 2021-09-10 06:14:24 --> Helper loaded: inflector_helper
INFO - 2021-09-10 06:14:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-10 06:14:25 --> Config Class Initialized
INFO - 2021-09-10 06:14:25 --> Hooks Class Initialized
DEBUG - 2021-09-10 06:14:25 --> UTF-8 Support Enabled
INFO - 2021-09-10 06:14:25 --> Utf8 Class Initialized
INFO - 2021-09-10 06:14:25 --> URI Class Initialized
INFO - 2021-09-10 06:14:25 --> Router Class Initialized
INFO - 2021-09-10 06:14:25 --> Output Class Initialized
INFO - 2021-09-10 06:14:25 --> Security Class Initialized
DEBUG - 2021-09-10 06:14:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-10 06:14:25 --> CSRF cookie sent
INFO - 2021-09-10 06:14:25 --> Input Class Initialized
INFO - 2021-09-10 06:14:25 --> Language Class Initialized
INFO - 2021-09-10 06:14:25 --> Loader Class Initialized
INFO - 2021-09-10 06:14:25 --> Helper loaded: url_helper
INFO - 2021-09-10 06:14:25 --> Helper loaded: file_helper
INFO - 2021-09-10 06:14:25 --> Helper loaded: form_helper
INFO - 2021-09-10 06:14:25 --> Helper loaded: security_helper
INFO - 2021-09-10 06:14:25 --> Helper loaded: directory_helper
INFO - 2021-09-10 06:14:25 --> Helper loaded: general_helper
INFO - 2021-09-10 06:14:25 --> Database Driver Class Initialized
INFO - 2021-09-10 06:14:25 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-10 06:14:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-10 06:14:25 --> Pagination Class Initialized
INFO - 2021-09-10 06:14:25 --> XML-RPC Class Initialized
INFO - 2021-09-10 06:14:25 --> Form Validation Class Initialized
INFO - 2021-09-10 06:14:25 --> Upload Class Initialized
INFO - 2021-09-10 06:14:25 --> MY_Model class loaded
INFO - 2021-09-10 06:14:25 --> Model "Application_model" initialized
INFO - 2021-09-10 06:14:25 --> Controller Class Initialized
DEBUG - 2021-09-10 06:14:25 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school_anish\application\config/rest.php
INFO - 2021-09-10 06:14:25 --> Helper loaded: inflector_helper
INFO - 2021-09-10 06:14:25 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-10 06:14:25 --> Database Driver Class Initialized
ERROR - 2021-09-10 06:14:25 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school_anish\application\libraries\REST_Controller.php 575
ERROR - 2021-09-10 06:14:25 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school_anish\application\libraries\REST_Controller.php 575
ERROR - 2021-09-10 06:14:25 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school_anish\application\libraries\REST_Controller.php 576
ERROR - 2021-09-10 06:14:25 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school_anish\application\libraries\REST_Controller.php 576
INFO - 2021-09-10 06:14:25 --> Model "Authentication_model" initialized
INFO - 2021-09-10 06:14:25 --> Model "Student_model" initialized
INFO - 2021-09-10 06:14:25 --> Final output sent to browser
DEBUG - 2021-09-10 06:14:25 --> Total execution time: 0.5924
INFO - 2021-09-10 06:16:09 --> Config Class Initialized
INFO - 2021-09-10 06:16:09 --> Hooks Class Initialized
DEBUG - 2021-09-10 06:16:09 --> UTF-8 Support Enabled
INFO - 2021-09-10 06:16:09 --> Utf8 Class Initialized
INFO - 2021-09-10 06:16:09 --> URI Class Initialized
INFO - 2021-09-10 06:16:09 --> Router Class Initialized
INFO - 2021-09-10 06:16:09 --> Output Class Initialized
INFO - 2021-09-10 06:16:09 --> Security Class Initialized
DEBUG - 2021-09-10 06:16:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-10 06:16:09 --> CSRF cookie sent
INFO - 2021-09-10 06:16:09 --> Input Class Initialized
INFO - 2021-09-10 06:16:09 --> Language Class Initialized
INFO - 2021-09-10 06:16:09 --> Loader Class Initialized
INFO - 2021-09-10 06:16:09 --> Helper loaded: url_helper
INFO - 2021-09-10 06:16:09 --> Helper loaded: file_helper
INFO - 2021-09-10 06:16:09 --> Helper loaded: form_helper
INFO - 2021-09-10 06:16:09 --> Helper loaded: security_helper
INFO - 2021-09-10 06:16:09 --> Helper loaded: directory_helper
INFO - 2021-09-10 06:16:09 --> Helper loaded: general_helper
INFO - 2021-09-10 06:16:09 --> Database Driver Class Initialized
INFO - 2021-09-10 06:16:09 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-10 06:16:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-10 06:16:09 --> Pagination Class Initialized
INFO - 2021-09-10 06:16:09 --> XML-RPC Class Initialized
INFO - 2021-09-10 06:16:09 --> Form Validation Class Initialized
INFO - 2021-09-10 06:16:09 --> Upload Class Initialized
INFO - 2021-09-10 06:16:09 --> MY_Model class loaded
INFO - 2021-09-10 06:16:09 --> Model "Application_model" initialized
INFO - 2021-09-10 06:16:09 --> Controller Class Initialized
DEBUG - 2021-09-10 06:16:09 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school_anish\application\config/rest.php
INFO - 2021-09-10 06:16:09 --> Helper loaded: inflector_helper
INFO - 2021-09-10 06:16:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-10 06:16:09 --> Config Class Initialized
INFO - 2021-09-10 06:16:09 --> Hooks Class Initialized
DEBUG - 2021-09-10 06:16:09 --> UTF-8 Support Enabled
INFO - 2021-09-10 06:16:09 --> Utf8 Class Initialized
INFO - 2021-09-10 06:16:09 --> URI Class Initialized
INFO - 2021-09-10 06:16:09 --> Router Class Initialized
INFO - 2021-09-10 06:16:09 --> Output Class Initialized
INFO - 2021-09-10 06:16:09 --> Security Class Initialized
DEBUG - 2021-09-10 06:16:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-10 06:16:09 --> CSRF cookie sent
INFO - 2021-09-10 06:16:09 --> Input Class Initialized
INFO - 2021-09-10 06:16:09 --> Language Class Initialized
INFO - 2021-09-10 06:16:09 --> Loader Class Initialized
INFO - 2021-09-10 06:16:09 --> Helper loaded: url_helper
INFO - 2021-09-10 06:16:09 --> Helper loaded: file_helper
INFO - 2021-09-10 06:16:09 --> Helper loaded: form_helper
INFO - 2021-09-10 06:16:09 --> Helper loaded: security_helper
INFO - 2021-09-10 06:16:09 --> Helper loaded: directory_helper
INFO - 2021-09-10 06:16:09 --> Helper loaded: general_helper
INFO - 2021-09-10 06:16:09 --> Database Driver Class Initialized
INFO - 2021-09-10 06:16:09 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-10 06:16:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-10 06:16:09 --> Pagination Class Initialized
INFO - 2021-09-10 06:16:09 --> XML-RPC Class Initialized
INFO - 2021-09-10 06:16:09 --> Form Validation Class Initialized
INFO - 2021-09-10 06:16:09 --> Upload Class Initialized
INFO - 2021-09-10 06:16:09 --> MY_Model class loaded
INFO - 2021-09-10 06:16:09 --> Model "Application_model" initialized
INFO - 2021-09-10 06:16:09 --> Controller Class Initialized
DEBUG - 2021-09-10 06:16:09 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school_anish\application\config/rest.php
INFO - 2021-09-10 06:16:09 --> Helper loaded: inflector_helper
INFO - 2021-09-10 06:16:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-10 06:16:09 --> Database Driver Class Initialized
ERROR - 2021-09-10 06:16:09 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school_anish\application\libraries\REST_Controller.php 575
ERROR - 2021-09-10 06:16:09 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school_anish\application\libraries\REST_Controller.php 575
ERROR - 2021-09-10 06:16:09 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school_anish\application\libraries\REST_Controller.php 576
ERROR - 2021-09-10 06:16:09 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school_anish\application\libraries\REST_Controller.php 576
INFO - 2021-09-10 06:16:09 --> Model "Authentication_model" initialized
INFO - 2021-09-10 06:16:09 --> Model "Student_model" initialized
INFO - 2021-09-10 06:16:09 --> Final output sent to browser
DEBUG - 2021-09-10 06:16:09 --> Total execution time: 0.1069
INFO - 2021-09-10 06:16:29 --> Config Class Initialized
INFO - 2021-09-10 06:16:29 --> Hooks Class Initialized
DEBUG - 2021-09-10 06:16:29 --> UTF-8 Support Enabled
INFO - 2021-09-10 06:16:29 --> Utf8 Class Initialized
INFO - 2021-09-10 06:16:29 --> URI Class Initialized
INFO - 2021-09-10 06:16:29 --> Router Class Initialized
INFO - 2021-09-10 06:16:29 --> Output Class Initialized
INFO - 2021-09-10 06:16:29 --> Security Class Initialized
DEBUG - 2021-09-10 06:16:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-10 06:16:29 --> CSRF cookie sent
INFO - 2021-09-10 06:16:29 --> Input Class Initialized
INFO - 2021-09-10 06:16:29 --> Language Class Initialized
INFO - 2021-09-10 06:16:29 --> Loader Class Initialized
INFO - 2021-09-10 06:16:29 --> Helper loaded: url_helper
INFO - 2021-09-10 06:16:29 --> Helper loaded: file_helper
INFO - 2021-09-10 06:16:29 --> Helper loaded: form_helper
INFO - 2021-09-10 06:16:29 --> Helper loaded: security_helper
INFO - 2021-09-10 06:16:29 --> Helper loaded: directory_helper
INFO - 2021-09-10 06:16:29 --> Helper loaded: general_helper
INFO - 2021-09-10 06:16:29 --> Database Driver Class Initialized
INFO - 2021-09-10 06:16:29 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-10 06:16:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-10 06:16:29 --> Pagination Class Initialized
INFO - 2021-09-10 06:16:29 --> XML-RPC Class Initialized
INFO - 2021-09-10 06:16:29 --> Form Validation Class Initialized
INFO - 2021-09-10 06:16:29 --> Upload Class Initialized
INFO - 2021-09-10 06:16:29 --> MY_Model class loaded
INFO - 2021-09-10 06:16:29 --> Model "Application_model" initialized
INFO - 2021-09-10 06:16:29 --> Controller Class Initialized
DEBUG - 2021-09-10 06:16:29 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school_anish\application\config/rest.php
INFO - 2021-09-10 06:16:29 --> Helper loaded: inflector_helper
INFO - 2021-09-10 06:16:29 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-10 06:16:29 --> Config Class Initialized
INFO - 2021-09-10 06:16:29 --> Hooks Class Initialized
DEBUG - 2021-09-10 06:16:29 --> UTF-8 Support Enabled
INFO - 2021-09-10 06:16:29 --> Utf8 Class Initialized
INFO - 2021-09-10 06:16:29 --> URI Class Initialized
INFO - 2021-09-10 06:16:29 --> Router Class Initialized
INFO - 2021-09-10 06:16:29 --> Output Class Initialized
INFO - 2021-09-10 06:16:29 --> Security Class Initialized
DEBUG - 2021-09-10 06:16:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-10 06:16:29 --> CSRF cookie sent
INFO - 2021-09-10 06:16:29 --> Input Class Initialized
INFO - 2021-09-10 06:16:29 --> Language Class Initialized
INFO - 2021-09-10 06:16:29 --> Loader Class Initialized
INFO - 2021-09-10 06:16:29 --> Helper loaded: url_helper
INFO - 2021-09-10 06:16:29 --> Helper loaded: file_helper
INFO - 2021-09-10 06:16:29 --> Helper loaded: form_helper
INFO - 2021-09-10 06:16:29 --> Helper loaded: security_helper
INFO - 2021-09-10 06:16:29 --> Helper loaded: directory_helper
INFO - 2021-09-10 06:16:29 --> Helper loaded: general_helper
INFO - 2021-09-10 06:16:29 --> Database Driver Class Initialized
INFO - 2021-09-10 06:16:29 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-10 06:16:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-10 06:16:29 --> Pagination Class Initialized
INFO - 2021-09-10 06:16:29 --> XML-RPC Class Initialized
INFO - 2021-09-10 06:16:29 --> Form Validation Class Initialized
INFO - 2021-09-10 06:16:29 --> Upload Class Initialized
INFO - 2021-09-10 06:16:29 --> MY_Model class loaded
INFO - 2021-09-10 06:16:29 --> Model "Application_model" initialized
INFO - 2021-09-10 06:16:29 --> Controller Class Initialized
DEBUG - 2021-09-10 06:16:29 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school_anish\application\config/rest.php
INFO - 2021-09-10 06:16:29 --> Helper loaded: inflector_helper
INFO - 2021-09-10 06:16:29 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-10 06:16:29 --> Database Driver Class Initialized
ERROR - 2021-09-10 06:16:29 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school_anish\application\libraries\REST_Controller.php 575
ERROR - 2021-09-10 06:16:29 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school_anish\application\libraries\REST_Controller.php 575
ERROR - 2021-09-10 06:16:29 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school_anish\application\libraries\REST_Controller.php 576
ERROR - 2021-09-10 06:16:29 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school_anish\application\libraries\REST_Controller.php 576
INFO - 2021-09-10 06:16:29 --> Model "Authentication_model" initialized
INFO - 2021-09-10 06:16:29 --> Model "Student_model" initialized
INFO - 2021-09-10 06:16:29 --> Final output sent to browser
DEBUG - 2021-09-10 06:16:29 --> Total execution time: 0.1269
INFO - 2021-09-10 06:17:02 --> Config Class Initialized
INFO - 2021-09-10 06:17:02 --> Hooks Class Initialized
DEBUG - 2021-09-10 06:17:02 --> UTF-8 Support Enabled
INFO - 2021-09-10 06:17:02 --> Utf8 Class Initialized
INFO - 2021-09-10 06:17:02 --> URI Class Initialized
INFO - 2021-09-10 06:17:02 --> Router Class Initialized
INFO - 2021-09-10 06:17:02 --> Output Class Initialized
INFO - 2021-09-10 06:17:02 --> Security Class Initialized
DEBUG - 2021-09-10 06:17:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-10 06:17:02 --> CSRF cookie sent
INFO - 2021-09-10 06:17:02 --> Input Class Initialized
INFO - 2021-09-10 06:17:02 --> Language Class Initialized
INFO - 2021-09-10 06:17:02 --> Loader Class Initialized
INFO - 2021-09-10 06:17:02 --> Helper loaded: url_helper
INFO - 2021-09-10 06:17:02 --> Helper loaded: file_helper
INFO - 2021-09-10 06:17:02 --> Helper loaded: form_helper
INFO - 2021-09-10 06:17:02 --> Helper loaded: security_helper
INFO - 2021-09-10 06:17:02 --> Helper loaded: directory_helper
INFO - 2021-09-10 06:17:02 --> Helper loaded: general_helper
INFO - 2021-09-10 06:17:02 --> Database Driver Class Initialized
INFO - 2021-09-10 06:17:02 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-10 06:17:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-10 06:17:02 --> Pagination Class Initialized
INFO - 2021-09-10 06:17:02 --> XML-RPC Class Initialized
INFO - 2021-09-10 06:17:02 --> Form Validation Class Initialized
INFO - 2021-09-10 06:17:02 --> Upload Class Initialized
INFO - 2021-09-10 06:17:02 --> MY_Model class loaded
INFO - 2021-09-10 06:17:02 --> Model "Application_model" initialized
INFO - 2021-09-10 06:17:02 --> Controller Class Initialized
DEBUG - 2021-09-10 06:17:02 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school_anish\application\config/rest.php
INFO - 2021-09-10 06:17:02 --> Helper loaded: inflector_helper
INFO - 2021-09-10 06:17:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-10 06:17:02 --> Config Class Initialized
INFO - 2021-09-10 06:17:02 --> Hooks Class Initialized
DEBUG - 2021-09-10 06:17:02 --> UTF-8 Support Enabled
INFO - 2021-09-10 06:17:02 --> Utf8 Class Initialized
INFO - 2021-09-10 06:17:02 --> URI Class Initialized
INFO - 2021-09-10 06:17:02 --> Router Class Initialized
INFO - 2021-09-10 06:17:02 --> Output Class Initialized
INFO - 2021-09-10 06:17:02 --> Security Class Initialized
DEBUG - 2021-09-10 06:17:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-10 06:17:02 --> CSRF cookie sent
INFO - 2021-09-10 06:17:02 --> Input Class Initialized
INFO - 2021-09-10 06:17:02 --> Language Class Initialized
INFO - 2021-09-10 06:17:02 --> Loader Class Initialized
INFO - 2021-09-10 06:17:02 --> Helper loaded: url_helper
INFO - 2021-09-10 06:17:02 --> Helper loaded: file_helper
INFO - 2021-09-10 06:17:02 --> Helper loaded: form_helper
INFO - 2021-09-10 06:17:02 --> Helper loaded: security_helper
INFO - 2021-09-10 06:17:02 --> Helper loaded: directory_helper
INFO - 2021-09-10 06:17:02 --> Helper loaded: general_helper
INFO - 2021-09-10 06:17:02 --> Database Driver Class Initialized
INFO - 2021-09-10 06:17:02 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-10 06:17:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-10 06:17:02 --> Pagination Class Initialized
INFO - 2021-09-10 06:17:02 --> XML-RPC Class Initialized
INFO - 2021-09-10 06:17:02 --> Form Validation Class Initialized
INFO - 2021-09-10 06:17:02 --> Upload Class Initialized
INFO - 2021-09-10 06:17:02 --> MY_Model class loaded
INFO - 2021-09-10 06:17:02 --> Model "Application_model" initialized
INFO - 2021-09-10 06:17:02 --> Controller Class Initialized
DEBUG - 2021-09-10 06:17:02 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school_anish\application\config/rest.php
INFO - 2021-09-10 06:17:02 --> Helper loaded: inflector_helper
INFO - 2021-09-10 06:17:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-10 06:17:02 --> Database Driver Class Initialized
ERROR - 2021-09-10 06:17:02 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school_anish\application\libraries\REST_Controller.php 575
ERROR - 2021-09-10 06:17:02 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school_anish\application\libraries\REST_Controller.php 575
ERROR - 2021-09-10 06:17:02 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school_anish\application\libraries\REST_Controller.php 576
ERROR - 2021-09-10 06:17:02 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school_anish\application\libraries\REST_Controller.php 576
INFO - 2021-09-10 06:17:02 --> Model "Authentication_model" initialized
INFO - 2021-09-10 06:17:02 --> Model "Student_model" initialized
INFO - 2021-09-10 06:17:02 --> Final output sent to browser
DEBUG - 2021-09-10 06:17:02 --> Total execution time: 0.1652
INFO - 2021-09-10 06:17:30 --> Config Class Initialized
INFO - 2021-09-10 06:17:30 --> Hooks Class Initialized
DEBUG - 2021-09-10 06:17:30 --> UTF-8 Support Enabled
INFO - 2021-09-10 06:17:30 --> Utf8 Class Initialized
INFO - 2021-09-10 06:17:30 --> URI Class Initialized
INFO - 2021-09-10 06:17:30 --> Router Class Initialized
INFO - 2021-09-10 06:17:30 --> Output Class Initialized
INFO - 2021-09-10 06:17:30 --> Security Class Initialized
DEBUG - 2021-09-10 06:17:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-10 06:17:30 --> CSRF cookie sent
INFO - 2021-09-10 06:17:30 --> Input Class Initialized
INFO - 2021-09-10 06:17:30 --> Language Class Initialized
INFO - 2021-09-10 06:17:30 --> Loader Class Initialized
INFO - 2021-09-10 06:17:30 --> Helper loaded: url_helper
INFO - 2021-09-10 06:17:30 --> Helper loaded: file_helper
INFO - 2021-09-10 06:17:30 --> Helper loaded: form_helper
INFO - 2021-09-10 06:17:30 --> Helper loaded: security_helper
INFO - 2021-09-10 06:17:30 --> Helper loaded: directory_helper
INFO - 2021-09-10 06:17:30 --> Helper loaded: general_helper
INFO - 2021-09-10 06:17:30 --> Database Driver Class Initialized
INFO - 2021-09-10 06:17:30 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-10 06:17:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-10 06:17:30 --> Pagination Class Initialized
INFO - 2021-09-10 06:17:30 --> XML-RPC Class Initialized
INFO - 2021-09-10 06:17:30 --> Form Validation Class Initialized
INFO - 2021-09-10 06:17:30 --> Upload Class Initialized
INFO - 2021-09-10 06:17:30 --> MY_Model class loaded
INFO - 2021-09-10 06:17:30 --> Model "Application_model" initialized
INFO - 2021-09-10 06:17:30 --> Controller Class Initialized
DEBUG - 2021-09-10 06:17:30 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school_anish\application\config/rest.php
INFO - 2021-09-10 06:17:30 --> Helper loaded: inflector_helper
INFO - 2021-09-10 06:17:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-10 06:17:30 --> Config Class Initialized
INFO - 2021-09-10 06:17:30 --> Hooks Class Initialized
DEBUG - 2021-09-10 06:17:30 --> UTF-8 Support Enabled
INFO - 2021-09-10 06:17:30 --> Utf8 Class Initialized
INFO - 2021-09-10 06:17:30 --> URI Class Initialized
INFO - 2021-09-10 06:17:30 --> Router Class Initialized
INFO - 2021-09-10 06:17:30 --> Output Class Initialized
INFO - 2021-09-10 06:17:30 --> Security Class Initialized
DEBUG - 2021-09-10 06:17:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-10 06:17:30 --> CSRF cookie sent
INFO - 2021-09-10 06:17:30 --> Input Class Initialized
INFO - 2021-09-10 06:17:30 --> Language Class Initialized
INFO - 2021-09-10 06:17:30 --> Loader Class Initialized
INFO - 2021-09-10 06:17:30 --> Helper loaded: url_helper
INFO - 2021-09-10 06:17:30 --> Helper loaded: file_helper
INFO - 2021-09-10 06:17:30 --> Helper loaded: form_helper
INFO - 2021-09-10 06:17:30 --> Helper loaded: security_helper
INFO - 2021-09-10 06:17:30 --> Helper loaded: directory_helper
INFO - 2021-09-10 06:17:30 --> Helper loaded: general_helper
INFO - 2021-09-10 06:17:30 --> Database Driver Class Initialized
INFO - 2021-09-10 06:17:30 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-10 06:17:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-10 06:17:30 --> Pagination Class Initialized
INFO - 2021-09-10 06:17:30 --> XML-RPC Class Initialized
INFO - 2021-09-10 06:17:30 --> Form Validation Class Initialized
INFO - 2021-09-10 06:17:30 --> Upload Class Initialized
INFO - 2021-09-10 06:17:30 --> MY_Model class loaded
INFO - 2021-09-10 06:17:30 --> Model "Application_model" initialized
INFO - 2021-09-10 06:17:30 --> Controller Class Initialized
DEBUG - 2021-09-10 06:17:30 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school_anish\application\config/rest.php
INFO - 2021-09-10 06:17:30 --> Helper loaded: inflector_helper
INFO - 2021-09-10 06:17:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-10 06:17:30 --> Database Driver Class Initialized
ERROR - 2021-09-10 06:17:30 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school_anish\application\libraries\REST_Controller.php 575
ERROR - 2021-09-10 06:17:30 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school_anish\application\libraries\REST_Controller.php 575
ERROR - 2021-09-10 06:17:30 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school_anish\application\libraries\REST_Controller.php 576
ERROR - 2021-09-10 06:17:30 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school_anish\application\libraries\REST_Controller.php 576
INFO - 2021-09-10 06:17:30 --> Model "Authentication_model" initialized
INFO - 2021-09-10 06:17:30 --> Model "Student_model" initialized
INFO - 2021-09-10 06:17:30 --> Final output sent to browser
DEBUG - 2021-09-10 06:17:30 --> Total execution time: 0.1400
INFO - 2021-09-10 07:13:19 --> Config Class Initialized
INFO - 2021-09-10 07:13:19 --> Hooks Class Initialized
DEBUG - 2021-09-10 07:13:20 --> UTF-8 Support Enabled
INFO - 2021-09-10 07:13:20 --> Utf8 Class Initialized
INFO - 2021-09-10 07:13:23 --> URI Class Initialized
DEBUG - 2021-09-10 07:13:23 --> No URI present. Default controller set.
INFO - 2021-09-10 07:13:23 --> Router Class Initialized
INFO - 2021-09-10 07:13:23 --> Output Class Initialized
INFO - 2021-09-10 07:13:24 --> Security Class Initialized
DEBUG - 2021-09-10 07:13:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-10 07:13:25 --> CSRF cookie sent
INFO - 2021-09-10 07:13:25 --> Input Class Initialized
INFO - 2021-09-10 07:13:25 --> Language Class Initialized
INFO - 2021-09-10 07:13:26 --> Loader Class Initialized
INFO - 2021-09-10 07:13:26 --> Helper loaded: url_helper
INFO - 2021-09-10 07:13:26 --> Helper loaded: file_helper
INFO - 2021-09-10 07:13:26 --> Helper loaded: form_helper
INFO - 2021-09-10 07:13:26 --> Helper loaded: security_helper
INFO - 2021-09-10 07:13:26 --> Helper loaded: directory_helper
INFO - 2021-09-10 07:13:26 --> Helper loaded: general_helper
INFO - 2021-09-10 07:13:27 --> Database Driver Class Initialized
INFO - 2021-09-10 07:13:39 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-10 07:13:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-10 07:13:39 --> Pagination Class Initialized
INFO - 2021-09-10 07:13:39 --> XML-RPC Class Initialized
INFO - 2021-09-10 07:13:39 --> Form Validation Class Initialized
INFO - 2021-09-10 07:13:39 --> Upload Class Initialized
INFO - 2021-09-10 07:13:39 --> MY_Model class loaded
INFO - 2021-09-10 07:13:39 --> Model "Application_model" initialized
INFO - 2021-09-10 07:13:39 --> Controller Class Initialized
INFO - 2021-09-10 10:58:44 --> Model "Home_model" initialized
INFO - 2021-09-10 07:13:50 --> Config Class Initialized
INFO - 2021-09-10 07:13:50 --> Hooks Class Initialized
DEBUG - 2021-09-10 07:13:50 --> UTF-8 Support Enabled
INFO - 2021-09-10 07:13:50 --> Utf8 Class Initialized
INFO - 2021-09-10 07:13:50 --> URI Class Initialized
INFO - 2021-09-10 07:13:50 --> Router Class Initialized
INFO - 2021-09-10 07:13:50 --> Output Class Initialized
INFO - 2021-09-10 07:13:50 --> Security Class Initialized
DEBUG - 2021-09-10 07:13:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-10 07:13:50 --> CSRF cookie sent
INFO - 2021-09-10 07:13:50 --> Input Class Initialized
INFO - 2021-09-10 07:13:50 --> Language Class Initialized
INFO - 2021-09-10 07:13:50 --> Loader Class Initialized
INFO - 2021-09-10 07:13:50 --> Helper loaded: url_helper
INFO - 2021-09-10 07:13:50 --> Helper loaded: file_helper
INFO - 2021-09-10 07:13:50 --> Helper loaded: form_helper
INFO - 2021-09-10 07:13:50 --> Helper loaded: security_helper
INFO - 2021-09-10 07:13:50 --> Helper loaded: directory_helper
INFO - 2021-09-10 07:13:50 --> Helper loaded: general_helper
INFO - 2021-09-10 07:13:50 --> Database Driver Class Initialized
INFO - 2021-09-10 07:13:50 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-10 07:13:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-10 07:13:50 --> Pagination Class Initialized
INFO - 2021-09-10 07:13:50 --> XML-RPC Class Initialized
INFO - 2021-09-10 07:13:50 --> Form Validation Class Initialized
INFO - 2021-09-10 07:13:50 --> Upload Class Initialized
INFO - 2021-09-10 07:13:50 --> MY_Model class loaded
INFO - 2021-09-10 07:13:50 --> Model "Application_model" initialized
INFO - 2021-09-10 07:13:50 --> Controller Class Initialized
INFO - 2021-09-10 10:58:50 --> Model "Authentication_model" initialized
INFO - 2021-09-10 10:58:55 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school_anish\application\views\authentication/login.php
INFO - 2021-09-10 10:58:55 --> Final output sent to browser
DEBUG - 2021-09-10 10:58:55 --> Total execution time: 5.1552
INFO - 2021-09-10 09:51:59 --> Config Class Initialized
INFO - 2021-09-10 09:51:59 --> Hooks Class Initialized
DEBUG - 2021-09-10 09:51:59 --> UTF-8 Support Enabled
INFO - 2021-09-10 09:51:59 --> Utf8 Class Initialized
INFO - 2021-09-10 09:52:00 --> URI Class Initialized
INFO - 2021-09-10 09:52:00 --> Router Class Initialized
INFO - 2021-09-10 09:52:01 --> Output Class Initialized
INFO - 2021-09-10 09:52:01 --> Security Class Initialized
DEBUG - 2021-09-10 09:52:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-10 09:52:01 --> CSRF cookie sent
INFO - 2021-09-10 09:52:01 --> Input Class Initialized
INFO - 2021-09-10 09:52:01 --> Language Class Initialized
INFO - 2021-09-10 09:52:02 --> Loader Class Initialized
INFO - 2021-09-10 09:52:02 --> Helper loaded: url_helper
INFO - 2021-09-10 09:52:02 --> Helper loaded: file_helper
INFO - 2021-09-10 09:52:02 --> Helper loaded: form_helper
INFO - 2021-09-10 09:52:02 --> Helper loaded: security_helper
INFO - 2021-09-10 09:52:02 --> Helper loaded: directory_helper
INFO - 2021-09-10 09:52:02 --> Helper loaded: general_helper
INFO - 2021-09-10 09:52:03 --> Database Driver Class Initialized
INFO - 2021-09-10 09:52:05 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-10 09:52:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-10 09:52:05 --> Pagination Class Initialized
INFO - 2021-09-10 09:52:05 --> XML-RPC Class Initialized
INFO - 2021-09-10 09:52:05 --> Form Validation Class Initialized
INFO - 2021-09-10 09:52:06 --> Upload Class Initialized
INFO - 2021-09-10 09:52:06 --> MY_Model class loaded
INFO - 2021-09-10 09:52:06 --> Model "Application_model" initialized
INFO - 2021-09-10 09:52:06 --> Controller Class Initialized
INFO - 2021-09-10 13:37:06 --> Model "Authentication_model" initialized
INFO - 2021-09-10 13:37:07 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school_anish\application\views\authentication/login.php
INFO - 2021-09-10 13:37:07 --> Final output sent to browser
DEBUG - 2021-09-10 13:37:07 --> Total execution time: 9.3457
