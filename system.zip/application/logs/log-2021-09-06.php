<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-09-06 08:30:28 --> Config Class Initialized
INFO - 2021-09-06 08:30:28 --> Hooks Class Initialized
DEBUG - 2021-09-06 08:30:28 --> UTF-8 Support Enabled
INFO - 2021-09-06 08:30:28 --> Utf8 Class Initialized
INFO - 2021-09-06 08:30:28 --> URI Class Initialized
DEBUG - 2021-09-06 08:30:28 --> No URI present. Default controller set.
INFO - 2021-09-06 08:30:28 --> Router Class Initialized
INFO - 2021-09-06 08:30:28 --> Output Class Initialized
INFO - 2021-09-06 08:30:28 --> Security Class Initialized
DEBUG - 2021-09-06 08:30:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-06 08:30:29 --> CSRF cookie sent
INFO - 2021-09-06 08:30:29 --> Input Class Initialized
INFO - 2021-09-06 08:30:29 --> Language Class Initialized
INFO - 2021-09-06 08:30:29 --> Loader Class Initialized
INFO - 2021-09-06 08:30:29 --> Helper loaded: url_helper
INFO - 2021-09-06 08:30:29 --> Helper loaded: file_helper
INFO - 2021-09-06 08:30:29 --> Helper loaded: form_helper
INFO - 2021-09-06 08:30:29 --> Helper loaded: security_helper
INFO - 2021-09-06 08:30:29 --> Helper loaded: directory_helper
INFO - 2021-09-06 08:30:29 --> Helper loaded: general_helper
INFO - 2021-09-06 08:30:29 --> Database Driver Class Initialized
INFO - 2021-09-06 08:30:32 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-06 08:30:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-06 08:30:32 --> Pagination Class Initialized
INFO - 2021-09-06 08:30:33 --> XML-RPC Class Initialized
INFO - 2021-09-06 08:30:33 --> Form Validation Class Initialized
INFO - 2021-09-06 08:30:33 --> Upload Class Initialized
INFO - 2021-09-06 08:30:33 --> MY_Model class loaded
INFO - 2021-09-06 08:30:33 --> Model "Application_model" initialized
INFO - 2021-09-06 08:30:33 --> Controller Class Initialized
INFO - 2021-09-06 12:15:33 --> Model "Home_model" initialized
INFO - 2021-09-06 08:30:34 --> Config Class Initialized
INFO - 2021-09-06 08:30:34 --> Hooks Class Initialized
DEBUG - 2021-09-06 08:30:34 --> UTF-8 Support Enabled
INFO - 2021-09-06 08:30:34 --> Utf8 Class Initialized
INFO - 2021-09-06 08:30:34 --> URI Class Initialized
INFO - 2021-09-06 08:30:34 --> Router Class Initialized
INFO - 2021-09-06 08:30:34 --> Output Class Initialized
INFO - 2021-09-06 08:30:34 --> Security Class Initialized
DEBUG - 2021-09-06 08:30:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-06 08:30:34 --> CSRF cookie sent
INFO - 2021-09-06 08:30:34 --> Input Class Initialized
INFO - 2021-09-06 08:30:34 --> Language Class Initialized
INFO - 2021-09-06 08:30:34 --> Loader Class Initialized
INFO - 2021-09-06 08:30:34 --> Helper loaded: url_helper
INFO - 2021-09-06 08:30:34 --> Helper loaded: file_helper
INFO - 2021-09-06 08:30:34 --> Helper loaded: form_helper
INFO - 2021-09-06 08:30:34 --> Helper loaded: security_helper
INFO - 2021-09-06 08:30:34 --> Helper loaded: directory_helper
INFO - 2021-09-06 08:30:34 --> Helper loaded: general_helper
INFO - 2021-09-06 08:30:34 --> Database Driver Class Initialized
INFO - 2021-09-06 08:30:34 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-06 08:30:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-06 08:30:34 --> Pagination Class Initialized
INFO - 2021-09-06 08:30:34 --> XML-RPC Class Initialized
INFO - 2021-09-06 08:30:34 --> Form Validation Class Initialized
INFO - 2021-09-06 08:30:34 --> Upload Class Initialized
INFO - 2021-09-06 08:30:34 --> MY_Model class loaded
INFO - 2021-09-06 08:30:34 --> Model "Application_model" initialized
INFO - 2021-09-06 08:30:34 --> Controller Class Initialized
INFO - 2021-09-06 12:15:34 --> Model "Authentication_model" initialized
INFO - 2021-09-06 12:15:34 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\authentication/login.php
INFO - 2021-09-06 12:15:34 --> Final output sent to browser
DEBUG - 2021-09-06 12:15:34 --> Total execution time: 0.2583
INFO - 2021-09-06 09:03:35 --> Config Class Initialized
INFO - 2021-09-06 09:03:35 --> Hooks Class Initialized
DEBUG - 2021-09-06 09:03:35 --> UTF-8 Support Enabled
INFO - 2021-09-06 09:03:35 --> Utf8 Class Initialized
INFO - 2021-09-06 09:03:35 --> URI Class Initialized
INFO - 2021-09-06 09:03:35 --> Router Class Initialized
INFO - 2021-09-06 09:03:35 --> Output Class Initialized
INFO - 2021-09-06 09:03:35 --> Security Class Initialized
DEBUG - 2021-09-06 09:03:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-06 09:03:36 --> CSRF cookie sent
INFO - 2021-09-06 09:03:36 --> Input Class Initialized
INFO - 2021-09-06 09:03:36 --> Language Class Initialized
INFO - 2021-09-06 09:03:36 --> Loader Class Initialized
INFO - 2021-09-06 09:03:36 --> Helper loaded: url_helper
INFO - 2021-09-06 09:03:36 --> Helper loaded: file_helper
INFO - 2021-09-06 09:03:36 --> Helper loaded: form_helper
INFO - 2021-09-06 09:03:36 --> Helper loaded: security_helper
INFO - 2021-09-06 09:03:36 --> Helper loaded: directory_helper
INFO - 2021-09-06 09:03:36 --> Helper loaded: general_helper
INFO - 2021-09-06 09:03:37 --> Database Driver Class Initialized
INFO - 2021-09-06 09:03:42 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-06 09:03:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-06 09:03:43 --> Pagination Class Initialized
INFO - 2021-09-06 09:03:43 --> XML-RPC Class Initialized
INFO - 2021-09-06 09:03:44 --> Form Validation Class Initialized
INFO - 2021-09-06 09:03:44 --> Upload Class Initialized
INFO - 2021-09-06 09:03:45 --> MY_Model class loaded
INFO - 2021-09-06 09:03:45 --> Model "Application_model" initialized
INFO - 2021-09-06 09:03:45 --> Controller Class Initialized
INFO - 2021-09-06 12:48:46 --> Model "Authentication_model" initialized
INFO - 2021-09-06 12:48:46 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\authentication/login.php
INFO - 2021-09-06 12:48:46 --> Final output sent to browser
DEBUG - 2021-09-06 12:48:46 --> Total execution time: 11.2521
INFO - 2021-09-06 09:06:39 --> Config Class Initialized
INFO - 2021-09-06 09:06:39 --> Hooks Class Initialized
DEBUG - 2021-09-06 09:06:39 --> UTF-8 Support Enabled
INFO - 2021-09-06 09:06:39 --> Utf8 Class Initialized
INFO - 2021-09-06 09:06:39 --> URI Class Initialized
INFO - 2021-09-06 09:06:39 --> Router Class Initialized
INFO - 2021-09-06 09:06:39 --> Output Class Initialized
INFO - 2021-09-06 09:06:39 --> Security Class Initialized
DEBUG - 2021-09-06 09:06:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-06 09:06:39 --> Input Class Initialized
INFO - 2021-09-06 09:06:39 --> Language Class Initialized
ERROR - 2021-09-06 09:06:39 --> Severity: error --> Exception: Class 'Api' not found C:\Users\Gopal Ghimire\Desktop\New folder\school\application\controllers\api\Student.php 9
INFO - 2021-09-06 09:06:55 --> Config Class Initialized
INFO - 2021-09-06 09:06:55 --> Hooks Class Initialized
DEBUG - 2021-09-06 09:06:55 --> UTF-8 Support Enabled
INFO - 2021-09-06 09:06:55 --> Utf8 Class Initialized
INFO - 2021-09-06 09:06:55 --> URI Class Initialized
INFO - 2021-09-06 09:06:55 --> Router Class Initialized
INFO - 2021-09-06 09:06:55 --> Output Class Initialized
INFO - 2021-09-06 09:06:55 --> Security Class Initialized
DEBUG - 2021-09-06 09:06:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-06 09:06:55 --> Input Class Initialized
INFO - 2021-09-06 09:06:55 --> Language Class Initialized
ERROR - 2021-09-06 09:06:55 --> Severity: error --> Exception: Class 'Api' not found C:\Users\Gopal Ghimire\Desktop\New folder\school\application\controllers\api\Student.php 9
INFO - 2021-09-06 09:13:22 --> Config Class Initialized
INFO - 2021-09-06 09:13:22 --> Hooks Class Initialized
DEBUG - 2021-09-06 09:13:22 --> UTF-8 Support Enabled
INFO - 2021-09-06 09:13:22 --> Utf8 Class Initialized
INFO - 2021-09-06 09:13:22 --> URI Class Initialized
INFO - 2021-09-06 09:13:22 --> Router Class Initialized
INFO - 2021-09-06 09:13:22 --> Output Class Initialized
INFO - 2021-09-06 09:13:22 --> Security Class Initialized
DEBUG - 2021-09-06 09:13:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-06 09:13:22 --> Input Class Initialized
INFO - 2021-09-06 09:13:22 --> Language Class Initialized
ERROR - 2021-09-06 09:13:22 --> Severity: error --> Exception: Class 'Api' not found C:\Users\Gopal Ghimire\Desktop\New folder\school\application\controllers\api\Student.php 8
INFO - 2021-09-06 09:13:36 --> Config Class Initialized
INFO - 2021-09-06 09:13:36 --> Hooks Class Initialized
DEBUG - 2021-09-06 09:13:36 --> UTF-8 Support Enabled
INFO - 2021-09-06 09:13:36 --> Utf8 Class Initialized
INFO - 2021-09-06 09:13:36 --> URI Class Initialized
INFO - 2021-09-06 09:13:36 --> Router Class Initialized
INFO - 2021-09-06 09:13:36 --> Output Class Initialized
INFO - 2021-09-06 09:13:36 --> Security Class Initialized
DEBUG - 2021-09-06 09:13:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-06 09:13:36 --> Input Class Initialized
INFO - 2021-09-06 09:13:36 --> Language Class Initialized
ERROR - 2021-09-06 09:13:36 --> Severity: error --> Exception: Class 'Api' not found C:\Users\Gopal Ghimire\Desktop\New folder\school\application\controllers\api\Student.php 8
INFO - 2021-09-06 09:19:58 --> Config Class Initialized
INFO - 2021-09-06 09:19:58 --> Hooks Class Initialized
DEBUG - 2021-09-06 09:19:59 --> UTF-8 Support Enabled
INFO - 2021-09-06 09:19:59 --> Utf8 Class Initialized
INFO - 2021-09-06 09:19:59 --> URI Class Initialized
INFO - 2021-09-06 09:19:59 --> Router Class Initialized
INFO - 2021-09-06 09:19:59 --> Output Class Initialized
INFO - 2021-09-06 09:19:59 --> Security Class Initialized
DEBUG - 2021-09-06 09:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-06 09:19:59 --> Input Class Initialized
INFO - 2021-09-06 09:19:59 --> Language Class Initialized
ERROR - 2021-09-06 09:19:59 --> Severity: error --> Exception: Class 'Api' not found C:\Users\Gopal Ghimire\Desktop\New folder\school\application\controllers\api\Student.php 8
INFO - 2021-09-06 09:20:07 --> Config Class Initialized
INFO - 2021-09-06 09:20:07 --> Hooks Class Initialized
DEBUG - 2021-09-06 09:20:07 --> UTF-8 Support Enabled
INFO - 2021-09-06 09:20:07 --> Utf8 Class Initialized
INFO - 2021-09-06 09:20:07 --> URI Class Initialized
INFO - 2021-09-06 09:20:07 --> Router Class Initialized
INFO - 2021-09-06 09:20:07 --> Output Class Initialized
INFO - 2021-09-06 09:20:07 --> Security Class Initialized
DEBUG - 2021-09-06 09:20:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-06 09:20:07 --> CSRF cookie sent
INFO - 2021-09-06 09:20:07 --> Input Class Initialized
INFO - 2021-09-06 09:20:07 --> Language Class Initialized
INFO - 2021-09-06 09:20:07 --> Loader Class Initialized
INFO - 2021-09-06 09:20:07 --> Helper loaded: url_helper
INFO - 2021-09-06 09:20:08 --> Helper loaded: file_helper
INFO - 2021-09-06 09:20:08 --> Helper loaded: form_helper
INFO - 2021-09-06 09:20:08 --> Helper loaded: security_helper
INFO - 2021-09-06 09:20:08 --> Helper loaded: directory_helper
INFO - 2021-09-06 09:20:08 --> Helper loaded: general_helper
INFO - 2021-09-06 09:20:08 --> Database Driver Class Initialized
INFO - 2021-09-06 09:20:08 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-06 09:20:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-06 09:20:08 --> Pagination Class Initialized
INFO - 2021-09-06 09:20:08 --> XML-RPC Class Initialized
INFO - 2021-09-06 09:20:08 --> Form Validation Class Initialized
INFO - 2021-09-06 09:20:08 --> Upload Class Initialized
INFO - 2021-09-06 09:20:08 --> MY_Model class loaded
INFO - 2021-09-06 09:20:08 --> Model "Application_model" initialized
INFO - 2021-09-06 09:20:08 --> Controller Class Initialized
INFO - 2021-09-06 13:05:08 --> Model "Authentication_model" initialized
INFO - 2021-09-06 13:05:09 --> File loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\views\authentication/login.php
INFO - 2021-09-06 13:05:09 --> Final output sent to browser
DEBUG - 2021-09-06 13:05:09 --> Total execution time: 1.1924
INFO - 2021-09-06 09:20:14 --> Config Class Initialized
INFO - 2021-09-06 09:20:14 --> Hooks Class Initialized
DEBUG - 2021-09-06 09:20:14 --> UTF-8 Support Enabled
INFO - 2021-09-06 09:20:14 --> Utf8 Class Initialized
INFO - 2021-09-06 09:20:14 --> URI Class Initialized
INFO - 2021-09-06 09:20:14 --> Router Class Initialized
INFO - 2021-09-06 09:20:14 --> Output Class Initialized
INFO - 2021-09-06 09:20:14 --> Security Class Initialized
DEBUG - 2021-09-06 09:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-06 09:20:14 --> Input Class Initialized
INFO - 2021-09-06 09:20:14 --> Language Class Initialized
ERROR - 2021-09-06 09:20:14 --> Severity: error --> Exception: Class 'Api' not found C:\Users\Gopal Ghimire\Desktop\New folder\school\application\controllers\api\Student.php 8
INFO - 2021-09-06 09:21:01 --> Config Class Initialized
INFO - 2021-09-06 09:21:01 --> Hooks Class Initialized
DEBUG - 2021-09-06 09:21:01 --> UTF-8 Support Enabled
INFO - 2021-09-06 09:21:01 --> Utf8 Class Initialized
INFO - 2021-09-06 09:21:01 --> URI Class Initialized
INFO - 2021-09-06 09:21:01 --> Router Class Initialized
INFO - 2021-09-06 09:21:01 --> Output Class Initialized
INFO - 2021-09-06 09:21:01 --> Security Class Initialized
DEBUG - 2021-09-06 09:21:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-06 09:21:01 --> Input Class Initialized
INFO - 2021-09-06 09:21:01 --> Language Class Initialized
ERROR - 2021-09-06 09:21:01 --> Severity: error --> Exception: Class 'Api' not found C:\Users\Gopal Ghimire\Desktop\New folder\school\application\controllers\api\Student.php 8
INFO - 2021-09-06 09:21:29 --> Config Class Initialized
INFO - 2021-09-06 09:21:29 --> Hooks Class Initialized
DEBUG - 2021-09-06 09:21:29 --> UTF-8 Support Enabled
INFO - 2021-09-06 09:21:29 --> Utf8 Class Initialized
INFO - 2021-09-06 09:21:29 --> URI Class Initialized
INFO - 2021-09-06 09:21:29 --> Router Class Initialized
INFO - 2021-09-06 09:21:29 --> Output Class Initialized
INFO - 2021-09-06 09:21:29 --> Security Class Initialized
DEBUG - 2021-09-06 09:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-06 09:21:29 --> CSRF cookie sent
INFO - 2021-09-06 09:21:29 --> Input Class Initialized
INFO - 2021-09-06 09:21:29 --> Language Class Initialized
ERROR - 2021-09-06 09:21:29 --> Severity: error --> Exception: Class 'Api' not found C:\Users\Gopal Ghimire\Desktop\New folder\school\application\controllers\api\Student.php 8
INFO - 2021-09-06 09:22:31 --> Config Class Initialized
INFO - 2021-09-06 09:22:31 --> Hooks Class Initialized
DEBUG - 2021-09-06 09:22:31 --> UTF-8 Support Enabled
INFO - 2021-09-06 09:22:31 --> Utf8 Class Initialized
INFO - 2021-09-06 09:22:31 --> URI Class Initialized
INFO - 2021-09-06 09:22:31 --> Router Class Initialized
INFO - 2021-09-06 09:22:31 --> Output Class Initialized
INFO - 2021-09-06 09:22:31 --> Security Class Initialized
DEBUG - 2021-09-06 09:22:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-06 09:22:31 --> Input Class Initialized
INFO - 2021-09-06 09:22:31 --> Language Class Initialized
INFO - 2021-09-06 09:22:31 --> Loader Class Initialized
INFO - 2021-09-06 09:22:31 --> Helper loaded: url_helper
INFO - 2021-09-06 09:22:31 --> Helper loaded: file_helper
INFO - 2021-09-06 09:22:31 --> Helper loaded: form_helper
INFO - 2021-09-06 09:22:31 --> Helper loaded: security_helper
INFO - 2021-09-06 09:22:31 --> Helper loaded: directory_helper
INFO - 2021-09-06 09:22:31 --> Helper loaded: general_helper
INFO - 2021-09-06 09:22:31 --> Database Driver Class Initialized
INFO - 2021-09-06 09:22:31 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-06 09:22:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-06 09:22:31 --> Pagination Class Initialized
INFO - 2021-09-06 09:22:31 --> XML-RPC Class Initialized
INFO - 2021-09-06 09:22:31 --> Form Validation Class Initialized
INFO - 2021-09-06 09:22:31 --> Upload Class Initialized
INFO - 2021-09-06 09:22:31 --> MY_Model class loaded
INFO - 2021-09-06 09:22:31 --> Model "Application_model" initialized
INFO - 2021-09-06 09:22:31 --> Controller Class Initialized
DEBUG - 2021-09-06 09:22:31 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-06 09:22:31 --> Helper loaded: inflector_helper
INFO - 2021-09-06 09:22:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-06 09:22:31 --> Database Driver Class Initialized
ERROR - 2021-09-06 09:22:31 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 09:22:31 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 09:22:31 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-06 09:22:31 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-06 09:22:31 --> Model "Student_model" initialized
INFO - 2021-09-06 09:22:31 --> Final output sent to browser
DEBUG - 2021-09-06 09:22:31 --> Total execution time: 0.4324
INFO - 2021-09-06 09:23:00 --> Config Class Initialized
INFO - 2021-09-06 09:23:00 --> Hooks Class Initialized
DEBUG - 2021-09-06 09:23:00 --> UTF-8 Support Enabled
INFO - 2021-09-06 09:23:00 --> Utf8 Class Initialized
INFO - 2021-09-06 09:23:00 --> URI Class Initialized
INFO - 2021-09-06 09:23:00 --> Router Class Initialized
INFO - 2021-09-06 09:23:00 --> Output Class Initialized
INFO - 2021-09-06 09:23:00 --> Security Class Initialized
DEBUG - 2021-09-06 09:23:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-06 09:23:00 --> Input Class Initialized
INFO - 2021-09-06 09:23:00 --> Language Class Initialized
INFO - 2021-09-06 09:23:00 --> Loader Class Initialized
INFO - 2021-09-06 09:23:00 --> Helper loaded: url_helper
INFO - 2021-09-06 09:23:00 --> Helper loaded: file_helper
INFO - 2021-09-06 09:23:00 --> Helper loaded: form_helper
INFO - 2021-09-06 09:23:00 --> Helper loaded: security_helper
INFO - 2021-09-06 09:23:00 --> Helper loaded: directory_helper
INFO - 2021-09-06 09:23:00 --> Helper loaded: general_helper
INFO - 2021-09-06 09:23:00 --> Database Driver Class Initialized
INFO - 2021-09-06 09:23:00 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-06 09:23:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-06 09:23:00 --> Pagination Class Initialized
INFO - 2021-09-06 09:23:00 --> XML-RPC Class Initialized
INFO - 2021-09-06 09:23:00 --> Form Validation Class Initialized
INFO - 2021-09-06 09:23:00 --> Upload Class Initialized
INFO - 2021-09-06 09:23:00 --> MY_Model class loaded
INFO - 2021-09-06 09:23:00 --> Model "Application_model" initialized
INFO - 2021-09-06 09:23:00 --> Controller Class Initialized
DEBUG - 2021-09-06 09:23:00 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-06 09:23:00 --> Helper loaded: inflector_helper
INFO - 2021-09-06 09:23:00 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-06 09:23:00 --> Database Driver Class Initialized
ERROR - 2021-09-06 09:23:00 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 09:23:00 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 09:23:00 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-06 09:23:00 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-06 09:23:00 --> Model "Student_model" initialized
INFO - 2021-09-06 09:23:00 --> Final output sent to browser
DEBUG - 2021-09-06 09:23:00 --> Total execution time: 0.1236
INFO - 2021-09-06 09:23:15 --> Config Class Initialized
INFO - 2021-09-06 09:23:15 --> Hooks Class Initialized
DEBUG - 2021-09-06 09:23:15 --> UTF-8 Support Enabled
INFO - 2021-09-06 09:23:15 --> Utf8 Class Initialized
INFO - 2021-09-06 09:23:15 --> URI Class Initialized
INFO - 2021-09-06 09:23:15 --> Router Class Initialized
INFO - 2021-09-06 09:23:15 --> Output Class Initialized
INFO - 2021-09-06 09:23:15 --> Security Class Initialized
DEBUG - 2021-09-06 09:23:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-06 09:23:15 --> Input Class Initialized
INFO - 2021-09-06 09:23:15 --> Language Class Initialized
INFO - 2021-09-06 09:23:15 --> Loader Class Initialized
INFO - 2021-09-06 09:23:15 --> Helper loaded: url_helper
INFO - 2021-09-06 09:23:15 --> Helper loaded: file_helper
INFO - 2021-09-06 09:23:15 --> Helper loaded: form_helper
INFO - 2021-09-06 09:23:15 --> Helper loaded: security_helper
INFO - 2021-09-06 09:23:15 --> Helper loaded: directory_helper
INFO - 2021-09-06 09:23:15 --> Helper loaded: general_helper
INFO - 2021-09-06 09:23:15 --> Database Driver Class Initialized
INFO - 2021-09-06 09:23:15 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-06 09:23:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-06 09:23:15 --> Pagination Class Initialized
INFO - 2021-09-06 09:23:15 --> XML-RPC Class Initialized
INFO - 2021-09-06 09:23:15 --> Form Validation Class Initialized
INFO - 2021-09-06 09:23:15 --> Upload Class Initialized
INFO - 2021-09-06 09:23:15 --> MY_Model class loaded
INFO - 2021-09-06 09:23:15 --> Model "Application_model" initialized
INFO - 2021-09-06 09:23:15 --> Controller Class Initialized
DEBUG - 2021-09-06 09:23:15 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-06 09:23:15 --> Helper loaded: inflector_helper
INFO - 2021-09-06 09:23:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-06 09:23:15 --> Database Driver Class Initialized
ERROR - 2021-09-06 09:23:15 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 09:23:15 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 09:23:15 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-06 09:23:15 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-06 09:23:15 --> Model "Student_model" initialized
INFO - 2021-09-06 09:23:16 --> Final output sent to browser
DEBUG - 2021-09-06 09:23:16 --> Total execution time: 0.4507
INFO - 2021-09-06 09:26:33 --> Config Class Initialized
INFO - 2021-09-06 09:26:33 --> Hooks Class Initialized
DEBUG - 2021-09-06 09:26:33 --> UTF-8 Support Enabled
INFO - 2021-09-06 09:26:33 --> Utf8 Class Initialized
INFO - 2021-09-06 09:26:33 --> URI Class Initialized
INFO - 2021-09-06 09:26:33 --> Router Class Initialized
INFO - 2021-09-06 09:26:33 --> Output Class Initialized
INFO - 2021-09-06 09:26:33 --> Security Class Initialized
DEBUG - 2021-09-06 09:26:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-06 09:26:33 --> Input Class Initialized
INFO - 2021-09-06 09:26:33 --> Language Class Initialized
INFO - 2021-09-06 09:26:33 --> Loader Class Initialized
INFO - 2021-09-06 09:26:33 --> Helper loaded: url_helper
INFO - 2021-09-06 09:26:33 --> Helper loaded: file_helper
INFO - 2021-09-06 09:26:33 --> Helper loaded: form_helper
INFO - 2021-09-06 09:26:33 --> Helper loaded: security_helper
INFO - 2021-09-06 09:26:33 --> Helper loaded: directory_helper
INFO - 2021-09-06 09:26:33 --> Helper loaded: general_helper
INFO - 2021-09-06 09:26:33 --> Database Driver Class Initialized
INFO - 2021-09-06 09:26:33 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-06 09:26:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-06 09:26:33 --> Pagination Class Initialized
INFO - 2021-09-06 09:26:33 --> XML-RPC Class Initialized
INFO - 2021-09-06 09:26:33 --> Form Validation Class Initialized
INFO - 2021-09-06 09:26:33 --> Upload Class Initialized
INFO - 2021-09-06 09:26:33 --> MY_Model class loaded
INFO - 2021-09-06 09:26:33 --> Model "Application_model" initialized
INFO - 2021-09-06 09:26:33 --> Controller Class Initialized
DEBUG - 2021-09-06 09:26:33 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-06 09:26:33 --> Helper loaded: inflector_helper
INFO - 2021-09-06 09:26:33 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-06 09:26:33 --> Database Driver Class Initialized
ERROR - 2021-09-06 09:26:33 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 09:26:33 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 09:26:33 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-06 09:26:33 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-06 09:26:33 --> Model "Student_model" initialized
INFO - 2021-09-06 09:26:33 --> Final output sent to browser
DEBUG - 2021-09-06 09:26:33 --> Total execution time: 0.1744
INFO - 2021-09-06 09:27:00 --> Config Class Initialized
INFO - 2021-09-06 09:27:00 --> Hooks Class Initialized
DEBUG - 2021-09-06 09:27:00 --> UTF-8 Support Enabled
INFO - 2021-09-06 09:27:00 --> Utf8 Class Initialized
INFO - 2021-09-06 09:27:00 --> URI Class Initialized
INFO - 2021-09-06 09:27:00 --> Router Class Initialized
INFO - 2021-09-06 09:27:00 --> Output Class Initialized
INFO - 2021-09-06 09:27:00 --> Security Class Initialized
DEBUG - 2021-09-06 09:27:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-06 09:27:00 --> CSRF cookie sent
INFO - 2021-09-06 09:27:00 --> Input Class Initialized
INFO - 2021-09-06 09:27:00 --> Language Class Initialized
INFO - 2021-09-06 09:27:01 --> Loader Class Initialized
INFO - 2021-09-06 09:27:01 --> Helper loaded: url_helper
INFO - 2021-09-06 09:27:01 --> Helper loaded: file_helper
INFO - 2021-09-06 09:27:01 --> Helper loaded: form_helper
INFO - 2021-09-06 09:27:01 --> Helper loaded: security_helper
INFO - 2021-09-06 09:27:01 --> Helper loaded: directory_helper
INFO - 2021-09-06 09:27:01 --> Helper loaded: general_helper
INFO - 2021-09-06 09:27:01 --> Database Driver Class Initialized
INFO - 2021-09-06 09:27:01 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-06 09:27:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-06 09:27:01 --> Pagination Class Initialized
INFO - 2021-09-06 09:27:01 --> XML-RPC Class Initialized
INFO - 2021-09-06 09:27:01 --> Form Validation Class Initialized
INFO - 2021-09-06 09:27:01 --> Upload Class Initialized
INFO - 2021-09-06 09:27:01 --> MY_Model class loaded
INFO - 2021-09-06 09:27:01 --> Model "Application_model" initialized
INFO - 2021-09-06 09:27:01 --> Controller Class Initialized
DEBUG - 2021-09-06 09:27:01 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-06 09:27:01 --> Helper loaded: inflector_helper
INFO - 2021-09-06 09:27:01 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-06 09:27:01 --> Database Driver Class Initialized
ERROR - 2021-09-06 09:27:01 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 09:27:01 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 09:27:01 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-06 09:27:01 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-06 09:27:01 --> Model "Branch_model" initialized
ERROR - 2021-09-06 09:27:01 --> Severity: Warning --> call_user_func_array() expects parameter 1 to be a valid callback, class 'Branch' does not have a method 'index_get' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 742
INFO - 2021-09-06 09:27:01 --> Final output sent to browser
DEBUG - 2021-09-06 09:27:01 --> Total execution time: 0.2120
INFO - 2021-09-06 09:27:13 --> Config Class Initialized
INFO - 2021-09-06 09:27:13 --> Hooks Class Initialized
DEBUG - 2021-09-06 09:27:13 --> UTF-8 Support Enabled
INFO - 2021-09-06 09:27:13 --> Utf8 Class Initialized
INFO - 2021-09-06 09:27:13 --> URI Class Initialized
INFO - 2021-09-06 09:27:13 --> Router Class Initialized
INFO - 2021-09-06 09:27:13 --> Output Class Initialized
INFO - 2021-09-06 09:27:13 --> Security Class Initialized
DEBUG - 2021-09-06 09:27:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-06 09:27:13 --> CSRF cookie sent
INFO - 2021-09-06 09:27:13 --> Input Class Initialized
INFO - 2021-09-06 09:27:13 --> Language Class Initialized
INFO - 2021-09-06 09:27:13 --> Loader Class Initialized
INFO - 2021-09-06 09:27:13 --> Helper loaded: url_helper
INFO - 2021-09-06 09:27:13 --> Helper loaded: file_helper
INFO - 2021-09-06 09:27:13 --> Helper loaded: form_helper
INFO - 2021-09-06 09:27:13 --> Helper loaded: security_helper
INFO - 2021-09-06 09:27:13 --> Helper loaded: directory_helper
INFO - 2021-09-06 09:27:13 --> Helper loaded: general_helper
INFO - 2021-09-06 09:27:13 --> Database Driver Class Initialized
INFO - 2021-09-06 09:27:13 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-06 09:27:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-06 09:27:13 --> Pagination Class Initialized
INFO - 2021-09-06 09:27:13 --> XML-RPC Class Initialized
INFO - 2021-09-06 09:27:13 --> Form Validation Class Initialized
INFO - 2021-09-06 09:27:13 --> Upload Class Initialized
INFO - 2021-09-06 09:27:13 --> MY_Model class loaded
INFO - 2021-09-06 09:27:13 --> Model "Application_model" initialized
INFO - 2021-09-06 09:27:13 --> Controller Class Initialized
DEBUG - 2021-09-06 09:27:13 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-06 09:27:13 --> Helper loaded: inflector_helper
INFO - 2021-09-06 09:27:13 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-06 09:27:13 --> Database Driver Class Initialized
ERROR - 2021-09-06 09:27:13 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 09:27:13 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 09:27:13 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-06 09:27:13 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-06 09:27:13 --> Model "Branch_model" initialized
ERROR - 2021-09-06 09:27:13 --> Severity: error --> Exception: Too few arguments to function MY_Model::get(), 0 passed in C:\Users\Gopal Ghimire\Desktop\New folder\school\application\controllers\api\Branch.php on line 15 and at least 1 expected C:\Users\Gopal Ghimire\Desktop\New folder\school\application\core\MY_Model.php 40
INFO - 2021-09-06 09:58:01 --> Config Class Initialized
INFO - 2021-09-06 09:58:01 --> Hooks Class Initialized
DEBUG - 2021-09-06 09:58:01 --> UTF-8 Support Enabled
INFO - 2021-09-06 09:58:01 --> Utf8 Class Initialized
INFO - 2021-09-06 09:58:01 --> URI Class Initialized
INFO - 2021-09-06 09:58:01 --> Router Class Initialized
INFO - 2021-09-06 09:58:01 --> Output Class Initialized
INFO - 2021-09-06 09:58:01 --> Security Class Initialized
DEBUG - 2021-09-06 09:58:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-06 09:58:01 --> CSRF cookie sent
INFO - 2021-09-06 09:58:01 --> Input Class Initialized
INFO - 2021-09-06 09:58:01 --> Language Class Initialized
INFO - 2021-09-06 09:58:02 --> Loader Class Initialized
INFO - 2021-09-06 09:58:02 --> Helper loaded: url_helper
INFO - 2021-09-06 09:58:02 --> Helper loaded: file_helper
INFO - 2021-09-06 09:58:02 --> Helper loaded: form_helper
INFO - 2021-09-06 09:58:02 --> Helper loaded: security_helper
INFO - 2021-09-06 09:58:02 --> Helper loaded: directory_helper
INFO - 2021-09-06 09:58:02 --> Helper loaded: general_helper
INFO - 2021-09-06 09:58:02 --> Database Driver Class Initialized
INFO - 2021-09-06 09:58:02 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-06 09:58:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-06 09:58:02 --> Pagination Class Initialized
INFO - 2021-09-06 09:58:03 --> XML-RPC Class Initialized
INFO - 2021-09-06 09:58:03 --> Form Validation Class Initialized
INFO - 2021-09-06 09:58:03 --> Upload Class Initialized
INFO - 2021-09-06 09:58:03 --> MY_Model class loaded
INFO - 2021-09-06 09:58:03 --> Model "Application_model" initialized
INFO - 2021-09-06 09:58:03 --> Controller Class Initialized
DEBUG - 2021-09-06 09:58:03 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-06 09:58:03 --> Helper loaded: inflector_helper
INFO - 2021-09-06 09:58:03 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-06 09:58:03 --> Database Driver Class Initialized
ERROR - 2021-09-06 09:58:03 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 09:58:03 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 09:58:03 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-06 09:58:03 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-06 09:58:03 --> Model "Branch_model" initialized
ERROR - 2021-09-06 09:58:03 --> Severity: error --> Exception: Too few arguments to function MY_Model::get(), 0 passed in C:\Users\Gopal Ghimire\Desktop\New folder\school\application\controllers\api\Branch.php on line 15 and at least 1 expected C:\Users\Gopal Ghimire\Desktop\New folder\school\application\core\MY_Model.php 40
INFO - 2021-09-06 09:59:02 --> Config Class Initialized
INFO - 2021-09-06 09:59:02 --> Hooks Class Initialized
DEBUG - 2021-09-06 09:59:02 --> UTF-8 Support Enabled
INFO - 2021-09-06 09:59:02 --> Utf8 Class Initialized
INFO - 2021-09-06 09:59:02 --> URI Class Initialized
INFO - 2021-09-06 09:59:02 --> Router Class Initialized
INFO - 2021-09-06 09:59:02 --> Output Class Initialized
INFO - 2021-09-06 09:59:02 --> Security Class Initialized
DEBUG - 2021-09-06 09:59:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-06 09:59:02 --> CSRF cookie sent
INFO - 2021-09-06 09:59:02 --> Input Class Initialized
INFO - 2021-09-06 09:59:02 --> Language Class Initialized
INFO - 2021-09-06 09:59:02 --> Loader Class Initialized
INFO - 2021-09-06 09:59:03 --> Helper loaded: url_helper
INFO - 2021-09-06 09:59:03 --> Helper loaded: file_helper
INFO - 2021-09-06 09:59:03 --> Helper loaded: form_helper
INFO - 2021-09-06 09:59:03 --> Helper loaded: security_helper
INFO - 2021-09-06 09:59:03 --> Helper loaded: directory_helper
INFO - 2021-09-06 09:59:03 --> Helper loaded: general_helper
INFO - 2021-09-06 09:59:03 --> Database Driver Class Initialized
INFO - 2021-09-06 09:59:03 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-06 09:59:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-06 09:59:03 --> Pagination Class Initialized
INFO - 2021-09-06 09:59:03 --> XML-RPC Class Initialized
INFO - 2021-09-06 09:59:03 --> Form Validation Class Initialized
INFO - 2021-09-06 09:59:03 --> Upload Class Initialized
INFO - 2021-09-06 09:59:04 --> MY_Model class loaded
INFO - 2021-09-06 09:59:04 --> Model "Application_model" initialized
INFO - 2021-09-06 09:59:04 --> Controller Class Initialized
DEBUG - 2021-09-06 09:59:04 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-06 09:59:04 --> Helper loaded: inflector_helper
INFO - 2021-09-06 09:59:04 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-06 09:59:04 --> Database Driver Class Initialized
ERROR - 2021-09-06 09:59:04 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 09:59:04 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 09:59:04 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-06 09:59:04 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-06 09:59:04 --> Model "Branch_model" initialized
INFO - 2021-09-06 09:59:04 --> Final output sent to browser
DEBUG - 2021-09-06 09:59:04 --> Total execution time: 2.6763
INFO - 2021-09-06 10:00:29 --> Config Class Initialized
INFO - 2021-09-06 10:00:29 --> Hooks Class Initialized
DEBUG - 2021-09-06 10:00:29 --> UTF-8 Support Enabled
INFO - 2021-09-06 10:00:29 --> Utf8 Class Initialized
INFO - 2021-09-06 10:00:29 --> URI Class Initialized
INFO - 2021-09-06 10:00:30 --> Router Class Initialized
INFO - 2021-09-06 10:00:30 --> Output Class Initialized
INFO - 2021-09-06 10:00:30 --> Security Class Initialized
DEBUG - 2021-09-06 10:00:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-06 10:00:30 --> CSRF cookie sent
INFO - 2021-09-06 10:00:30 --> Input Class Initialized
INFO - 2021-09-06 10:00:30 --> Language Class Initialized
INFO - 2021-09-06 10:00:30 --> Loader Class Initialized
INFO - 2021-09-06 10:00:30 --> Helper loaded: url_helper
INFO - 2021-09-06 10:00:30 --> Helper loaded: file_helper
INFO - 2021-09-06 10:00:30 --> Helper loaded: form_helper
INFO - 2021-09-06 10:00:30 --> Helper loaded: security_helper
INFO - 2021-09-06 10:00:30 --> Helper loaded: directory_helper
INFO - 2021-09-06 10:00:30 --> Helper loaded: general_helper
INFO - 2021-09-06 10:00:30 --> Database Driver Class Initialized
INFO - 2021-09-06 10:00:30 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-06 10:00:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-06 10:00:30 --> Pagination Class Initialized
INFO - 2021-09-06 10:00:30 --> XML-RPC Class Initialized
INFO - 2021-09-06 10:00:30 --> Form Validation Class Initialized
INFO - 2021-09-06 10:00:30 --> Upload Class Initialized
INFO - 2021-09-06 10:00:30 --> MY_Model class loaded
INFO - 2021-09-06 10:00:30 --> Model "Application_model" initialized
INFO - 2021-09-06 10:00:30 --> Controller Class Initialized
DEBUG - 2021-09-06 10:00:30 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-06 10:00:30 --> Helper loaded: inflector_helper
INFO - 2021-09-06 10:00:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-06 10:00:30 --> Database Driver Class Initialized
ERROR - 2021-09-06 10:00:30 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 10:00:30 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 10:00:30 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-06 10:00:30 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-06 10:00:30 --> Model "Branch_model" initialized
INFO - 2021-09-06 10:00:30 --> Final output sent to browser
DEBUG - 2021-09-06 10:00:30 --> Total execution time: 1.2780
INFO - 2021-09-06 10:00:47 --> Config Class Initialized
INFO - 2021-09-06 10:00:47 --> Hooks Class Initialized
DEBUG - 2021-09-06 10:00:47 --> UTF-8 Support Enabled
INFO - 2021-09-06 10:00:47 --> Utf8 Class Initialized
INFO - 2021-09-06 10:00:47 --> URI Class Initialized
INFO - 2021-09-06 10:00:47 --> Router Class Initialized
INFO - 2021-09-06 10:00:47 --> Output Class Initialized
INFO - 2021-09-06 10:00:47 --> Security Class Initialized
DEBUG - 2021-09-06 10:00:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-06 10:00:47 --> CSRF cookie sent
INFO - 2021-09-06 10:00:47 --> Input Class Initialized
INFO - 2021-09-06 10:00:47 --> Language Class Initialized
INFO - 2021-09-06 10:00:47 --> Loader Class Initialized
INFO - 2021-09-06 10:00:47 --> Helper loaded: url_helper
INFO - 2021-09-06 10:00:47 --> Helper loaded: file_helper
INFO - 2021-09-06 10:00:47 --> Helper loaded: form_helper
INFO - 2021-09-06 10:00:47 --> Helper loaded: security_helper
INFO - 2021-09-06 10:00:47 --> Helper loaded: directory_helper
INFO - 2021-09-06 10:00:47 --> Helper loaded: general_helper
INFO - 2021-09-06 10:00:47 --> Database Driver Class Initialized
INFO - 2021-09-06 10:00:47 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-06 10:00:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-06 10:00:47 --> Pagination Class Initialized
INFO - 2021-09-06 10:00:47 --> XML-RPC Class Initialized
INFO - 2021-09-06 10:00:47 --> Form Validation Class Initialized
INFO - 2021-09-06 10:00:47 --> Upload Class Initialized
INFO - 2021-09-06 10:00:47 --> MY_Model class loaded
INFO - 2021-09-06 10:00:47 --> Model "Application_model" initialized
INFO - 2021-09-06 10:00:47 --> Controller Class Initialized
DEBUG - 2021-09-06 10:00:47 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-06 10:00:47 --> Helper loaded: inflector_helper
INFO - 2021-09-06 10:00:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-06 10:00:47 --> Database Driver Class Initialized
ERROR - 2021-09-06 10:00:47 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 10:00:47 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 10:00:47 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-06 10:00:47 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-06 10:00:47 --> Model "Branch_model" initialized
ERROR - 2021-09-06 10:00:47 --> Severity: error --> Exception: Too few arguments to function MY_Model::get(), 0 passed in C:\Users\Gopal Ghimire\Desktop\New folder\school\application\controllers\api\Branch.php on line 15 and at least 1 expected C:\Users\Gopal Ghimire\Desktop\New folder\school\application\core\MY_Model.php 40
INFO - 2021-09-06 10:03:36 --> Config Class Initialized
INFO - 2021-09-06 10:03:36 --> Hooks Class Initialized
DEBUG - 2021-09-06 10:03:36 --> UTF-8 Support Enabled
INFO - 2021-09-06 10:03:36 --> Utf8 Class Initialized
INFO - 2021-09-06 10:03:36 --> URI Class Initialized
INFO - 2021-09-06 10:03:36 --> Router Class Initialized
INFO - 2021-09-06 10:03:36 --> Output Class Initialized
INFO - 2021-09-06 10:03:36 --> Security Class Initialized
DEBUG - 2021-09-06 10:03:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-06 10:03:36 --> CSRF cookie sent
INFO - 2021-09-06 10:03:36 --> Input Class Initialized
INFO - 2021-09-06 10:03:36 --> Language Class Initialized
INFO - 2021-09-06 10:03:36 --> Loader Class Initialized
INFO - 2021-09-06 10:03:36 --> Helper loaded: url_helper
INFO - 2021-09-06 10:03:36 --> Helper loaded: file_helper
INFO - 2021-09-06 10:03:36 --> Helper loaded: form_helper
INFO - 2021-09-06 10:03:36 --> Helper loaded: security_helper
INFO - 2021-09-06 10:03:36 --> Helper loaded: directory_helper
INFO - 2021-09-06 10:03:36 --> Helper loaded: general_helper
INFO - 2021-09-06 10:03:36 --> Database Driver Class Initialized
INFO - 2021-09-06 10:03:36 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-06 10:03:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-06 10:03:36 --> Pagination Class Initialized
INFO - 2021-09-06 10:03:36 --> XML-RPC Class Initialized
INFO - 2021-09-06 10:03:36 --> Form Validation Class Initialized
INFO - 2021-09-06 10:03:36 --> Upload Class Initialized
INFO - 2021-09-06 10:03:36 --> MY_Model class loaded
INFO - 2021-09-06 10:03:36 --> Model "Application_model" initialized
INFO - 2021-09-06 10:03:36 --> Controller Class Initialized
DEBUG - 2021-09-06 10:03:36 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-06 10:03:36 --> Helper loaded: inflector_helper
INFO - 2021-09-06 10:03:36 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-06 10:03:36 --> Database Driver Class Initialized
ERROR - 2021-09-06 10:03:36 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 10:03:36 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 10:03:36 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-06 10:03:36 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-06 10:03:36 --> Model "Branch_model" initialized
INFO - 2021-09-06 10:03:37 --> Final output sent to browser
DEBUG - 2021-09-06 10:03:37 --> Total execution time: 0.4705
INFO - 2021-09-06 10:04:01 --> Config Class Initialized
INFO - 2021-09-06 10:04:01 --> Hooks Class Initialized
DEBUG - 2021-09-06 10:04:01 --> UTF-8 Support Enabled
INFO - 2021-09-06 10:04:01 --> Utf8 Class Initialized
INFO - 2021-09-06 10:04:01 --> URI Class Initialized
INFO - 2021-09-06 10:04:01 --> Router Class Initialized
INFO - 2021-09-06 10:04:01 --> Output Class Initialized
INFO - 2021-09-06 10:04:01 --> Security Class Initialized
DEBUG - 2021-09-06 10:04:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-06 10:04:01 --> CSRF cookie sent
INFO - 2021-09-06 10:04:01 --> Input Class Initialized
INFO - 2021-09-06 10:04:01 --> Language Class Initialized
INFO - 2021-09-06 10:04:01 --> Loader Class Initialized
INFO - 2021-09-06 10:04:01 --> Helper loaded: url_helper
INFO - 2021-09-06 10:04:01 --> Helper loaded: file_helper
INFO - 2021-09-06 10:04:01 --> Helper loaded: form_helper
INFO - 2021-09-06 10:04:01 --> Helper loaded: security_helper
INFO - 2021-09-06 10:04:01 --> Helper loaded: directory_helper
INFO - 2021-09-06 10:04:01 --> Helper loaded: general_helper
INFO - 2021-09-06 10:04:01 --> Database Driver Class Initialized
INFO - 2021-09-06 10:04:01 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-06 10:04:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-06 10:04:01 --> Pagination Class Initialized
INFO - 2021-09-06 10:04:01 --> XML-RPC Class Initialized
INFO - 2021-09-06 10:04:01 --> Form Validation Class Initialized
INFO - 2021-09-06 10:04:01 --> Upload Class Initialized
INFO - 2021-09-06 10:04:01 --> MY_Model class loaded
INFO - 2021-09-06 10:04:01 --> Model "Application_model" initialized
INFO - 2021-09-06 10:04:01 --> Controller Class Initialized
DEBUG - 2021-09-06 10:04:01 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-06 10:04:01 --> Helper loaded: inflector_helper
INFO - 2021-09-06 10:04:01 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-06 10:04:01 --> Database Driver Class Initialized
ERROR - 2021-09-06 10:04:01 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 10:04:01 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 10:04:01 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-06 10:04:01 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-06 10:04:01 --> Model "Branch_model" initialized
INFO - 2021-09-06 10:04:01 --> Final output sent to browser
DEBUG - 2021-09-06 10:04:01 --> Total execution time: 0.1571
INFO - 2021-09-06 10:05:07 --> Config Class Initialized
INFO - 2021-09-06 10:05:07 --> Hooks Class Initialized
DEBUG - 2021-09-06 10:05:07 --> UTF-8 Support Enabled
INFO - 2021-09-06 10:05:07 --> Utf8 Class Initialized
INFO - 2021-09-06 10:05:07 --> URI Class Initialized
INFO - 2021-09-06 10:05:07 --> Router Class Initialized
INFO - 2021-09-06 10:05:07 --> Output Class Initialized
INFO - 2021-09-06 10:05:07 --> Security Class Initialized
DEBUG - 2021-09-06 10:05:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-06 10:05:07 --> CSRF cookie sent
INFO - 2021-09-06 10:05:07 --> Input Class Initialized
INFO - 2021-09-06 10:05:07 --> Language Class Initialized
INFO - 2021-09-06 10:05:07 --> Loader Class Initialized
INFO - 2021-09-06 10:05:07 --> Helper loaded: url_helper
INFO - 2021-09-06 10:05:07 --> Helper loaded: file_helper
INFO - 2021-09-06 10:05:07 --> Helper loaded: form_helper
INFO - 2021-09-06 10:05:07 --> Helper loaded: security_helper
INFO - 2021-09-06 10:05:07 --> Helper loaded: directory_helper
INFO - 2021-09-06 10:05:07 --> Helper loaded: general_helper
INFO - 2021-09-06 10:05:07 --> Database Driver Class Initialized
INFO - 2021-09-06 10:05:07 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-06 10:05:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-06 10:05:07 --> Pagination Class Initialized
INFO - 2021-09-06 10:05:07 --> XML-RPC Class Initialized
INFO - 2021-09-06 10:05:07 --> Form Validation Class Initialized
INFO - 2021-09-06 10:05:07 --> Upload Class Initialized
INFO - 2021-09-06 10:05:07 --> MY_Model class loaded
INFO - 2021-09-06 10:05:07 --> Model "Application_model" initialized
INFO - 2021-09-06 10:05:07 --> Controller Class Initialized
DEBUG - 2021-09-06 10:05:07 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-06 10:05:07 --> Helper loaded: inflector_helper
INFO - 2021-09-06 10:05:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-06 10:05:07 --> Database Driver Class Initialized
ERROR - 2021-09-06 10:05:07 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 10:05:07 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 10:05:07 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-06 10:05:07 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-06 10:05:07 --> Model "Branch_model" initialized
INFO - 2021-09-06 10:05:07 --> Final output sent to browser
DEBUG - 2021-09-06 10:05:07 --> Total execution time: 0.1388
INFO - 2021-09-06 10:05:35 --> Config Class Initialized
INFO - 2021-09-06 10:05:35 --> Hooks Class Initialized
DEBUG - 2021-09-06 10:05:35 --> UTF-8 Support Enabled
INFO - 2021-09-06 10:05:35 --> Utf8 Class Initialized
INFO - 2021-09-06 10:05:35 --> URI Class Initialized
INFO - 2021-09-06 10:05:35 --> Router Class Initialized
INFO - 2021-09-06 10:05:35 --> Output Class Initialized
INFO - 2021-09-06 10:05:35 --> Security Class Initialized
DEBUG - 2021-09-06 10:05:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-06 10:05:35 --> CSRF cookie sent
INFO - 2021-09-06 10:05:35 --> Input Class Initialized
INFO - 2021-09-06 10:05:35 --> Language Class Initialized
INFO - 2021-09-06 10:05:35 --> Loader Class Initialized
INFO - 2021-09-06 10:05:35 --> Helper loaded: url_helper
INFO - 2021-09-06 10:05:35 --> Helper loaded: file_helper
INFO - 2021-09-06 10:05:35 --> Helper loaded: form_helper
INFO - 2021-09-06 10:05:35 --> Helper loaded: security_helper
INFO - 2021-09-06 10:05:35 --> Helper loaded: directory_helper
INFO - 2021-09-06 10:05:35 --> Helper loaded: general_helper
INFO - 2021-09-06 10:05:35 --> Database Driver Class Initialized
INFO - 2021-09-06 10:05:35 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-06 10:05:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-06 10:05:35 --> Pagination Class Initialized
INFO - 2021-09-06 10:05:35 --> XML-RPC Class Initialized
INFO - 2021-09-06 10:05:35 --> Form Validation Class Initialized
INFO - 2021-09-06 10:05:35 --> Upload Class Initialized
INFO - 2021-09-06 10:05:35 --> MY_Model class loaded
INFO - 2021-09-06 10:05:35 --> Model "Application_model" initialized
INFO - 2021-09-06 10:05:35 --> Controller Class Initialized
DEBUG - 2021-09-06 10:05:35 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-06 10:05:35 --> Helper loaded: inflector_helper
INFO - 2021-09-06 10:05:35 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-06 10:05:35 --> Database Driver Class Initialized
ERROR - 2021-09-06 10:05:35 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 10:05:35 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 10:05:35 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-06 10:05:35 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-06 10:05:35 --> Model "Branch_model" initialized
INFO - 2021-09-06 10:05:35 --> Final output sent to browser
DEBUG - 2021-09-06 10:05:35 --> Total execution time: 0.1886
INFO - 2021-09-06 10:06:20 --> Config Class Initialized
INFO - 2021-09-06 10:06:20 --> Hooks Class Initialized
DEBUG - 2021-09-06 10:06:20 --> UTF-8 Support Enabled
INFO - 2021-09-06 10:06:20 --> Utf8 Class Initialized
INFO - 2021-09-06 10:06:20 --> URI Class Initialized
INFO - 2021-09-06 10:06:20 --> Router Class Initialized
INFO - 2021-09-06 10:06:20 --> Output Class Initialized
INFO - 2021-09-06 10:06:20 --> Security Class Initialized
DEBUG - 2021-09-06 10:06:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-06 10:06:20 --> CSRF cookie sent
INFO - 2021-09-06 10:06:20 --> Input Class Initialized
INFO - 2021-09-06 10:06:20 --> Language Class Initialized
INFO - 2021-09-06 10:06:21 --> Loader Class Initialized
INFO - 2021-09-06 10:06:21 --> Helper loaded: url_helper
INFO - 2021-09-06 10:06:21 --> Helper loaded: file_helper
INFO - 2021-09-06 10:06:21 --> Helper loaded: form_helper
INFO - 2021-09-06 10:06:21 --> Helper loaded: security_helper
INFO - 2021-09-06 10:06:21 --> Helper loaded: directory_helper
INFO - 2021-09-06 10:06:21 --> Helper loaded: general_helper
INFO - 2021-09-06 10:06:21 --> Database Driver Class Initialized
INFO - 2021-09-06 10:06:21 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-06 10:06:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-06 10:06:21 --> Pagination Class Initialized
INFO - 2021-09-06 10:06:21 --> XML-RPC Class Initialized
INFO - 2021-09-06 10:06:21 --> Form Validation Class Initialized
INFO - 2021-09-06 10:06:21 --> Upload Class Initialized
INFO - 2021-09-06 10:06:21 --> MY_Model class loaded
INFO - 2021-09-06 10:06:21 --> Model "Application_model" initialized
INFO - 2021-09-06 10:06:21 --> Controller Class Initialized
DEBUG - 2021-09-06 10:06:21 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-06 10:06:21 --> Helper loaded: inflector_helper
INFO - 2021-09-06 10:06:21 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-06 10:06:21 --> Database Driver Class Initialized
ERROR - 2021-09-06 10:06:21 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 10:06:21 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 10:06:21 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-06 10:06:21 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-06 10:06:21 --> Model "Branch_model" initialized
INFO - 2021-09-06 10:06:21 --> Final output sent to browser
DEBUG - 2021-09-06 10:06:21 --> Total execution time: 0.1096
INFO - 2021-09-06 10:06:51 --> Config Class Initialized
INFO - 2021-09-06 10:06:51 --> Hooks Class Initialized
DEBUG - 2021-09-06 10:06:51 --> UTF-8 Support Enabled
INFO - 2021-09-06 10:06:51 --> Utf8 Class Initialized
INFO - 2021-09-06 10:06:51 --> URI Class Initialized
INFO - 2021-09-06 10:06:51 --> Router Class Initialized
INFO - 2021-09-06 10:06:51 --> Output Class Initialized
INFO - 2021-09-06 10:06:51 --> Security Class Initialized
DEBUG - 2021-09-06 10:06:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-06 10:06:51 --> CSRF cookie sent
INFO - 2021-09-06 10:06:51 --> Input Class Initialized
INFO - 2021-09-06 10:06:51 --> Language Class Initialized
INFO - 2021-09-06 10:06:51 --> Loader Class Initialized
INFO - 2021-09-06 10:06:51 --> Helper loaded: url_helper
INFO - 2021-09-06 10:06:51 --> Helper loaded: file_helper
INFO - 2021-09-06 10:06:51 --> Helper loaded: form_helper
INFO - 2021-09-06 10:06:51 --> Helper loaded: security_helper
INFO - 2021-09-06 10:06:51 --> Helper loaded: directory_helper
INFO - 2021-09-06 10:06:51 --> Helper loaded: general_helper
INFO - 2021-09-06 10:06:51 --> Database Driver Class Initialized
INFO - 2021-09-06 10:06:51 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-06 10:06:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-06 10:06:51 --> Pagination Class Initialized
INFO - 2021-09-06 10:06:51 --> XML-RPC Class Initialized
INFO - 2021-09-06 10:06:51 --> Form Validation Class Initialized
INFO - 2021-09-06 10:06:51 --> Upload Class Initialized
INFO - 2021-09-06 10:06:51 --> MY_Model class loaded
INFO - 2021-09-06 10:06:51 --> Model "Application_model" initialized
INFO - 2021-09-06 10:06:51 --> Controller Class Initialized
DEBUG - 2021-09-06 10:06:51 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-06 10:06:51 --> Helper loaded: inflector_helper
INFO - 2021-09-06 10:06:51 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-06 10:06:51 --> Database Driver Class Initialized
ERROR - 2021-09-06 10:06:51 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 10:06:51 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 10:06:51 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-06 10:06:51 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-06 10:06:51 --> Model "Branch_model" initialized
INFO - 2021-09-06 10:06:51 --> Final output sent to browser
DEBUG - 2021-09-06 10:06:51 --> Total execution time: 0.2519
INFO - 2021-09-06 10:07:05 --> Config Class Initialized
INFO - 2021-09-06 10:07:05 --> Hooks Class Initialized
DEBUG - 2021-09-06 10:07:05 --> UTF-8 Support Enabled
INFO - 2021-09-06 10:07:05 --> Utf8 Class Initialized
INFO - 2021-09-06 10:07:05 --> URI Class Initialized
INFO - 2021-09-06 10:07:05 --> Router Class Initialized
INFO - 2021-09-06 10:07:05 --> Output Class Initialized
INFO - 2021-09-06 10:07:05 --> Security Class Initialized
DEBUG - 2021-09-06 10:07:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-06 10:07:05 --> CSRF cookie sent
INFO - 2021-09-06 10:07:05 --> Input Class Initialized
INFO - 2021-09-06 10:07:05 --> Language Class Initialized
INFO - 2021-09-06 10:07:05 --> Loader Class Initialized
INFO - 2021-09-06 10:07:05 --> Helper loaded: url_helper
INFO - 2021-09-06 10:07:05 --> Helper loaded: file_helper
INFO - 2021-09-06 10:07:05 --> Helper loaded: form_helper
INFO - 2021-09-06 10:07:05 --> Helper loaded: security_helper
INFO - 2021-09-06 10:07:05 --> Helper loaded: directory_helper
INFO - 2021-09-06 10:07:05 --> Helper loaded: general_helper
INFO - 2021-09-06 10:07:05 --> Database Driver Class Initialized
INFO - 2021-09-06 10:07:05 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-06 10:07:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-06 10:07:05 --> Pagination Class Initialized
INFO - 2021-09-06 10:07:05 --> XML-RPC Class Initialized
INFO - 2021-09-06 10:07:05 --> Form Validation Class Initialized
INFO - 2021-09-06 10:07:05 --> Upload Class Initialized
INFO - 2021-09-06 10:07:05 --> MY_Model class loaded
INFO - 2021-09-06 10:07:05 --> Model "Application_model" initialized
INFO - 2021-09-06 10:07:05 --> Controller Class Initialized
DEBUG - 2021-09-06 10:07:05 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-06 10:07:05 --> Helper loaded: inflector_helper
INFO - 2021-09-06 10:07:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-06 10:07:05 --> Database Driver Class Initialized
ERROR - 2021-09-06 10:07:05 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 10:07:05 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 10:07:05 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-06 10:07:05 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-06 10:07:05 --> Model "Branch_model" initialized
INFO - 2021-09-06 10:07:05 --> Final output sent to browser
DEBUG - 2021-09-06 10:07:05 --> Total execution time: 0.1105
INFO - 2021-09-06 10:07:22 --> Config Class Initialized
INFO - 2021-09-06 10:07:22 --> Hooks Class Initialized
DEBUG - 2021-09-06 10:07:22 --> UTF-8 Support Enabled
INFO - 2021-09-06 10:07:22 --> Utf8 Class Initialized
INFO - 2021-09-06 10:07:22 --> URI Class Initialized
INFO - 2021-09-06 10:07:22 --> Router Class Initialized
INFO - 2021-09-06 10:07:22 --> Output Class Initialized
INFO - 2021-09-06 10:07:22 --> Security Class Initialized
DEBUG - 2021-09-06 10:07:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-06 10:07:22 --> CSRF cookie sent
INFO - 2021-09-06 10:07:22 --> Input Class Initialized
INFO - 2021-09-06 10:07:22 --> Language Class Initialized
INFO - 2021-09-06 10:07:22 --> Loader Class Initialized
INFO - 2021-09-06 10:07:22 --> Helper loaded: url_helper
INFO - 2021-09-06 10:07:22 --> Helper loaded: file_helper
INFO - 2021-09-06 10:07:22 --> Helper loaded: form_helper
INFO - 2021-09-06 10:07:22 --> Helper loaded: security_helper
INFO - 2021-09-06 10:07:22 --> Helper loaded: directory_helper
INFO - 2021-09-06 10:07:22 --> Helper loaded: general_helper
INFO - 2021-09-06 10:07:22 --> Database Driver Class Initialized
INFO - 2021-09-06 10:07:22 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-06 10:07:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-06 10:07:22 --> Pagination Class Initialized
INFO - 2021-09-06 10:07:22 --> XML-RPC Class Initialized
INFO - 2021-09-06 10:07:22 --> Form Validation Class Initialized
INFO - 2021-09-06 10:07:22 --> Upload Class Initialized
INFO - 2021-09-06 10:07:22 --> MY_Model class loaded
INFO - 2021-09-06 10:07:22 --> Model "Application_model" initialized
INFO - 2021-09-06 10:07:22 --> Controller Class Initialized
DEBUG - 2021-09-06 10:07:22 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-06 10:07:22 --> Helper loaded: inflector_helper
INFO - 2021-09-06 10:07:22 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-06 10:07:22 --> Database Driver Class Initialized
ERROR - 2021-09-06 10:07:22 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 10:07:22 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 10:07:22 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-06 10:07:22 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-06 10:07:22 --> Model "Branch_model" initialized
INFO - 2021-09-06 10:07:22 --> Final output sent to browser
DEBUG - 2021-09-06 10:07:22 --> Total execution time: 0.1337
INFO - 2021-09-06 10:08:22 --> Config Class Initialized
INFO - 2021-09-06 10:08:22 --> Hooks Class Initialized
DEBUG - 2021-09-06 10:08:22 --> UTF-8 Support Enabled
INFO - 2021-09-06 10:08:22 --> Utf8 Class Initialized
INFO - 2021-09-06 10:08:22 --> URI Class Initialized
INFO - 2021-09-06 10:08:22 --> Router Class Initialized
INFO - 2021-09-06 10:08:22 --> Output Class Initialized
INFO - 2021-09-06 10:08:22 --> Security Class Initialized
DEBUG - 2021-09-06 10:08:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-06 10:08:22 --> CSRF cookie sent
INFO - 2021-09-06 10:08:22 --> Input Class Initialized
INFO - 2021-09-06 10:08:22 --> Language Class Initialized
INFO - 2021-09-06 10:08:22 --> Loader Class Initialized
INFO - 2021-09-06 10:08:22 --> Helper loaded: url_helper
INFO - 2021-09-06 10:08:22 --> Helper loaded: file_helper
INFO - 2021-09-06 10:08:22 --> Helper loaded: form_helper
INFO - 2021-09-06 10:08:22 --> Helper loaded: security_helper
INFO - 2021-09-06 10:08:22 --> Helper loaded: directory_helper
INFO - 2021-09-06 10:08:22 --> Helper loaded: general_helper
INFO - 2021-09-06 10:08:22 --> Database Driver Class Initialized
INFO - 2021-09-06 10:08:22 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-06 10:08:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-06 10:08:22 --> Pagination Class Initialized
INFO - 2021-09-06 10:08:22 --> XML-RPC Class Initialized
INFO - 2021-09-06 10:08:22 --> Form Validation Class Initialized
INFO - 2021-09-06 10:08:22 --> Upload Class Initialized
INFO - 2021-09-06 10:08:22 --> MY_Model class loaded
INFO - 2021-09-06 10:08:22 --> Model "Application_model" initialized
INFO - 2021-09-06 10:08:22 --> Controller Class Initialized
DEBUG - 2021-09-06 10:08:22 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-06 10:08:22 --> Helper loaded: inflector_helper
INFO - 2021-09-06 10:08:22 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-06 10:08:22 --> Database Driver Class Initialized
ERROR - 2021-09-06 10:08:22 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 10:08:22 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 10:08:22 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-06 10:08:22 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-06 10:08:22 --> Model "Branch_model" initialized
INFO - 2021-09-06 10:08:22 --> Final output sent to browser
DEBUG - 2021-09-06 10:08:22 --> Total execution time: 0.1345
INFO - 2021-09-06 10:08:50 --> Config Class Initialized
INFO - 2021-09-06 10:08:50 --> Hooks Class Initialized
DEBUG - 2021-09-06 10:08:50 --> UTF-8 Support Enabled
INFO - 2021-09-06 10:08:50 --> Utf8 Class Initialized
INFO - 2021-09-06 10:08:50 --> URI Class Initialized
INFO - 2021-09-06 10:08:50 --> Router Class Initialized
INFO - 2021-09-06 10:08:50 --> Output Class Initialized
INFO - 2021-09-06 10:08:50 --> Security Class Initialized
DEBUG - 2021-09-06 10:08:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-06 10:08:50 --> CSRF cookie sent
INFO - 2021-09-06 10:08:50 --> Input Class Initialized
INFO - 2021-09-06 10:08:50 --> Language Class Initialized
INFO - 2021-09-06 10:08:50 --> Loader Class Initialized
INFO - 2021-09-06 10:08:50 --> Helper loaded: url_helper
INFO - 2021-09-06 10:08:50 --> Helper loaded: file_helper
INFO - 2021-09-06 10:08:50 --> Helper loaded: form_helper
INFO - 2021-09-06 10:08:50 --> Helper loaded: security_helper
INFO - 2021-09-06 10:08:50 --> Helper loaded: directory_helper
INFO - 2021-09-06 10:08:50 --> Helper loaded: general_helper
INFO - 2021-09-06 10:08:50 --> Database Driver Class Initialized
INFO - 2021-09-06 10:08:50 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-06 10:08:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-06 10:08:50 --> Pagination Class Initialized
INFO - 2021-09-06 10:08:50 --> XML-RPC Class Initialized
INFO - 2021-09-06 10:08:50 --> Form Validation Class Initialized
INFO - 2021-09-06 10:08:50 --> Upload Class Initialized
INFO - 2021-09-06 10:08:50 --> MY_Model class loaded
INFO - 2021-09-06 10:08:50 --> Model "Application_model" initialized
INFO - 2021-09-06 10:08:50 --> Controller Class Initialized
DEBUG - 2021-09-06 10:08:50 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-06 10:08:50 --> Helper loaded: inflector_helper
INFO - 2021-09-06 10:08:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-06 10:08:50 --> Database Driver Class Initialized
ERROR - 2021-09-06 10:08:50 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 10:08:50 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 10:08:50 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-06 10:08:50 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-06 10:08:50 --> Model "Branch_model" initialized
INFO - 2021-09-06 10:08:50 --> Final output sent to browser
DEBUG - 2021-09-06 10:08:50 --> Total execution time: 0.2415
INFO - 2021-09-06 10:09:04 --> Config Class Initialized
INFO - 2021-09-06 10:09:04 --> Hooks Class Initialized
DEBUG - 2021-09-06 10:09:04 --> UTF-8 Support Enabled
INFO - 2021-09-06 10:09:04 --> Utf8 Class Initialized
INFO - 2021-09-06 10:09:04 --> URI Class Initialized
INFO - 2021-09-06 10:09:04 --> Router Class Initialized
INFO - 2021-09-06 10:09:04 --> Output Class Initialized
INFO - 2021-09-06 10:09:04 --> Security Class Initialized
DEBUG - 2021-09-06 10:09:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-06 10:09:04 --> CSRF cookie sent
INFO - 2021-09-06 10:09:04 --> Input Class Initialized
INFO - 2021-09-06 10:09:04 --> Language Class Initialized
INFO - 2021-09-06 10:09:04 --> Loader Class Initialized
INFO - 2021-09-06 10:09:04 --> Helper loaded: url_helper
INFO - 2021-09-06 10:09:04 --> Helper loaded: file_helper
INFO - 2021-09-06 10:09:04 --> Helper loaded: form_helper
INFO - 2021-09-06 10:09:04 --> Helper loaded: security_helper
INFO - 2021-09-06 10:09:04 --> Helper loaded: directory_helper
INFO - 2021-09-06 10:09:04 --> Helper loaded: general_helper
INFO - 2021-09-06 10:09:04 --> Database Driver Class Initialized
INFO - 2021-09-06 10:09:04 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-06 10:09:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-06 10:09:04 --> Pagination Class Initialized
INFO - 2021-09-06 10:09:04 --> XML-RPC Class Initialized
INFO - 2021-09-06 10:09:04 --> Form Validation Class Initialized
INFO - 2021-09-06 10:09:04 --> Upload Class Initialized
INFO - 2021-09-06 10:09:04 --> MY_Model class loaded
INFO - 2021-09-06 10:09:04 --> Model "Application_model" initialized
INFO - 2021-09-06 10:09:04 --> Controller Class Initialized
DEBUG - 2021-09-06 10:09:04 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-06 10:09:04 --> Helper loaded: inflector_helper
INFO - 2021-09-06 10:09:04 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-06 10:09:04 --> Database Driver Class Initialized
ERROR - 2021-09-06 10:09:04 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 10:09:04 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 10:09:04 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-06 10:09:04 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-06 10:09:04 --> Model "Branch_model" initialized
INFO - 2021-09-06 10:09:04 --> Final output sent to browser
DEBUG - 2021-09-06 10:09:04 --> Total execution time: 0.1179
INFO - 2021-09-06 10:16:11 --> Config Class Initialized
INFO - 2021-09-06 10:16:11 --> Hooks Class Initialized
DEBUG - 2021-09-06 10:16:11 --> UTF-8 Support Enabled
INFO - 2021-09-06 10:16:11 --> Utf8 Class Initialized
INFO - 2021-09-06 10:16:11 --> URI Class Initialized
INFO - 2021-09-06 10:16:11 --> Router Class Initialized
INFO - 2021-09-06 10:16:11 --> Output Class Initialized
INFO - 2021-09-06 10:16:11 --> Security Class Initialized
DEBUG - 2021-09-06 10:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-06 10:16:11 --> CSRF cookie sent
INFO - 2021-09-06 10:16:11 --> Input Class Initialized
INFO - 2021-09-06 10:16:11 --> Language Class Initialized
INFO - 2021-09-06 10:16:12 --> Loader Class Initialized
INFO - 2021-09-06 10:16:12 --> Helper loaded: url_helper
INFO - 2021-09-06 10:16:12 --> Helper loaded: file_helper
INFO - 2021-09-06 10:16:12 --> Helper loaded: form_helper
INFO - 2021-09-06 10:16:12 --> Helper loaded: security_helper
INFO - 2021-09-06 10:16:12 --> Helper loaded: directory_helper
INFO - 2021-09-06 10:16:12 --> Helper loaded: general_helper
INFO - 2021-09-06 10:16:12 --> Database Driver Class Initialized
INFO - 2021-09-06 10:16:12 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-06 10:16:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-06 10:16:12 --> Pagination Class Initialized
INFO - 2021-09-06 10:16:12 --> XML-RPC Class Initialized
INFO - 2021-09-06 10:16:12 --> Form Validation Class Initialized
INFO - 2021-09-06 10:16:12 --> Upload Class Initialized
INFO - 2021-09-06 10:16:12 --> MY_Model class loaded
INFO - 2021-09-06 10:16:12 --> Model "Application_model" initialized
INFO - 2021-09-06 10:16:12 --> Controller Class Initialized
DEBUG - 2021-09-06 10:16:12 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-06 10:16:12 --> Helper loaded: inflector_helper
INFO - 2021-09-06 10:16:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-06 10:16:12 --> Database Driver Class Initialized
ERROR - 2021-09-06 10:16:12 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 10:16:12 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 10:16:12 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-06 10:16:12 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-06 10:16:12 --> Model "Branch_model" initialized
ERROR - 2021-09-06 10:16:13 --> Query error: Table 'anish.classs' doesn't exist - Invalid query: SELECT *
FROM `classs`
ERROR - 2021-09-06 10:16:13 --> Severity: error --> Exception: Call to a member function where() on bool C:\Users\Gopal Ghimire\Desktop\New folder\school\application\controllers\api\Branch.php 18
INFO - 2021-09-06 10:16:40 --> Config Class Initialized
INFO - 2021-09-06 10:16:40 --> Hooks Class Initialized
DEBUG - 2021-09-06 10:16:40 --> UTF-8 Support Enabled
INFO - 2021-09-06 10:16:40 --> Utf8 Class Initialized
INFO - 2021-09-06 10:16:40 --> URI Class Initialized
INFO - 2021-09-06 10:16:40 --> Router Class Initialized
INFO - 2021-09-06 10:16:40 --> Output Class Initialized
INFO - 2021-09-06 10:16:40 --> Security Class Initialized
DEBUG - 2021-09-06 10:16:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-06 10:16:40 --> CSRF cookie sent
INFO - 2021-09-06 10:16:40 --> Input Class Initialized
INFO - 2021-09-06 10:16:40 --> Language Class Initialized
INFO - 2021-09-06 10:16:40 --> Loader Class Initialized
INFO - 2021-09-06 10:16:40 --> Helper loaded: url_helper
INFO - 2021-09-06 10:16:40 --> Helper loaded: file_helper
INFO - 2021-09-06 10:16:40 --> Helper loaded: form_helper
INFO - 2021-09-06 10:16:40 --> Helper loaded: security_helper
INFO - 2021-09-06 10:16:40 --> Helper loaded: directory_helper
INFO - 2021-09-06 10:16:40 --> Helper loaded: general_helper
INFO - 2021-09-06 10:16:40 --> Database Driver Class Initialized
INFO - 2021-09-06 10:16:41 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-06 10:16:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-06 10:16:41 --> Pagination Class Initialized
INFO - 2021-09-06 10:16:41 --> XML-RPC Class Initialized
INFO - 2021-09-06 10:16:41 --> Form Validation Class Initialized
INFO - 2021-09-06 10:16:41 --> Upload Class Initialized
INFO - 2021-09-06 10:16:41 --> MY_Model class loaded
INFO - 2021-09-06 10:16:41 --> Model "Application_model" initialized
INFO - 2021-09-06 10:16:41 --> Controller Class Initialized
DEBUG - 2021-09-06 10:16:41 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-06 10:16:41 --> Helper loaded: inflector_helper
INFO - 2021-09-06 10:16:41 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-06 10:16:41 --> Database Driver Class Initialized
ERROR - 2021-09-06 10:16:41 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 10:16:41 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 10:16:41 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-06 10:16:41 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-06 10:16:41 --> Model "Branch_model" initialized
ERROR - 2021-09-06 10:16:41 --> Query error: Table 'anish.classs' doesn't exist - Invalid query: SELECT *
FROM `classs`
ERROR - 2021-09-06 10:16:41 --> Severity: error --> Exception: Call to a member function where() on bool C:\Users\Gopal Ghimire\Desktop\New folder\school\application\controllers\api\Branch.php 18
INFO - 2021-09-06 10:34:18 --> Config Class Initialized
INFO - 2021-09-06 10:34:18 --> Hooks Class Initialized
DEBUG - 2021-09-06 10:34:18 --> UTF-8 Support Enabled
INFO - 2021-09-06 10:34:18 --> Utf8 Class Initialized
INFO - 2021-09-06 10:34:18 --> URI Class Initialized
INFO - 2021-09-06 10:34:18 --> Router Class Initialized
INFO - 2021-09-06 10:34:18 --> Output Class Initialized
INFO - 2021-09-06 10:34:18 --> Security Class Initialized
DEBUG - 2021-09-06 10:34:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-06 10:34:18 --> CSRF cookie sent
INFO - 2021-09-06 10:34:18 --> Input Class Initialized
INFO - 2021-09-06 10:34:19 --> Language Class Initialized
INFO - 2021-09-06 10:34:19 --> Loader Class Initialized
INFO - 2021-09-06 10:34:19 --> Helper loaded: url_helper
INFO - 2021-09-06 10:34:19 --> Helper loaded: file_helper
INFO - 2021-09-06 10:34:19 --> Helper loaded: form_helper
INFO - 2021-09-06 10:34:19 --> Helper loaded: security_helper
INFO - 2021-09-06 10:34:19 --> Helper loaded: directory_helper
INFO - 2021-09-06 10:34:19 --> Helper loaded: general_helper
INFO - 2021-09-06 10:34:19 --> Database Driver Class Initialized
INFO - 2021-09-06 10:34:19 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-06 10:34:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-06 10:34:19 --> Pagination Class Initialized
INFO - 2021-09-06 10:34:20 --> XML-RPC Class Initialized
INFO - 2021-09-06 10:34:20 --> Form Validation Class Initialized
INFO - 2021-09-06 10:34:20 --> Upload Class Initialized
INFO - 2021-09-06 10:34:20 --> MY_Model class loaded
INFO - 2021-09-06 10:34:20 --> Model "Application_model" initialized
INFO - 2021-09-06 10:34:20 --> Controller Class Initialized
DEBUG - 2021-09-06 10:34:20 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-06 10:34:20 --> Helper loaded: inflector_helper
INFO - 2021-09-06 10:34:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-06 10:34:20 --> Database Driver Class Initialized
ERROR - 2021-09-06 10:34:20 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 10:34:20 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 10:34:20 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-06 10:34:20 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-06 10:34:20 --> Model "Branch_model" initialized
ERROR - 2021-09-06 10:34:20 --> Query error: Table 'anish.classs' doesn't exist - Invalid query: SELECT *
FROM `classs`
ERROR - 2021-09-06 10:34:20 --> Severity: error --> Exception: Call to a member function where() on bool C:\Users\Gopal Ghimire\Desktop\New folder\school\application\controllers\api\Branch.php 19
INFO - 2021-09-06 10:34:39 --> Config Class Initialized
INFO - 2021-09-06 10:34:39 --> Hooks Class Initialized
DEBUG - 2021-09-06 10:34:39 --> UTF-8 Support Enabled
INFO - 2021-09-06 10:34:39 --> Utf8 Class Initialized
INFO - 2021-09-06 10:34:39 --> URI Class Initialized
INFO - 2021-09-06 10:34:39 --> Router Class Initialized
INFO - 2021-09-06 10:34:39 --> Output Class Initialized
INFO - 2021-09-06 10:34:39 --> Security Class Initialized
DEBUG - 2021-09-06 10:34:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-06 10:34:39 --> CSRF cookie sent
INFO - 2021-09-06 10:34:39 --> Input Class Initialized
INFO - 2021-09-06 10:34:39 --> Language Class Initialized
INFO - 2021-09-06 10:34:39 --> Loader Class Initialized
INFO - 2021-09-06 10:34:39 --> Helper loaded: url_helper
INFO - 2021-09-06 10:34:39 --> Helper loaded: file_helper
INFO - 2021-09-06 10:34:39 --> Helper loaded: form_helper
INFO - 2021-09-06 10:34:39 --> Helper loaded: security_helper
INFO - 2021-09-06 10:34:39 --> Helper loaded: directory_helper
INFO - 2021-09-06 10:34:39 --> Helper loaded: general_helper
INFO - 2021-09-06 10:34:39 --> Database Driver Class Initialized
INFO - 2021-09-06 10:34:39 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-06 10:34:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-06 10:34:39 --> Pagination Class Initialized
INFO - 2021-09-06 10:34:39 --> XML-RPC Class Initialized
INFO - 2021-09-06 10:34:39 --> Form Validation Class Initialized
INFO - 2021-09-06 10:34:39 --> Upload Class Initialized
INFO - 2021-09-06 10:34:39 --> MY_Model class loaded
INFO - 2021-09-06 10:34:39 --> Model "Application_model" initialized
INFO - 2021-09-06 10:34:39 --> Controller Class Initialized
DEBUG - 2021-09-06 10:34:39 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-06 10:34:39 --> Helper loaded: inflector_helper
INFO - 2021-09-06 10:34:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-06 10:34:39 --> Database Driver Class Initialized
ERROR - 2021-09-06 10:34:39 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 10:34:39 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 10:34:39 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-06 10:34:39 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-06 10:34:39 --> Model "Branch_model" initialized
ERROR - 2021-09-06 10:34:39 --> Severity: error --> Exception: Too few arguments to function MY_Model::get(), 0 passed in C:\Users\Gopal Ghimire\Desktop\New folder\school\application\controllers\api\Branch.php on line 22 and at least 1 expected C:\Users\Gopal Ghimire\Desktop\New folder\school\application\core\MY_Model.php 40
INFO - 2021-09-06 10:35:06 --> Config Class Initialized
INFO - 2021-09-06 10:35:06 --> Hooks Class Initialized
DEBUG - 2021-09-06 10:35:06 --> UTF-8 Support Enabled
INFO - 2021-09-06 10:35:06 --> Utf8 Class Initialized
INFO - 2021-09-06 10:35:06 --> URI Class Initialized
INFO - 2021-09-06 10:35:06 --> Router Class Initialized
INFO - 2021-09-06 10:35:06 --> Output Class Initialized
INFO - 2021-09-06 10:35:06 --> Security Class Initialized
DEBUG - 2021-09-06 10:35:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-06 10:35:06 --> CSRF cookie sent
INFO - 2021-09-06 10:35:06 --> Input Class Initialized
INFO - 2021-09-06 10:35:06 --> Language Class Initialized
INFO - 2021-09-06 10:35:06 --> Loader Class Initialized
INFO - 2021-09-06 10:35:06 --> Helper loaded: url_helper
INFO - 2021-09-06 10:35:06 --> Helper loaded: file_helper
INFO - 2021-09-06 10:35:06 --> Helper loaded: form_helper
INFO - 2021-09-06 10:35:06 --> Helper loaded: security_helper
INFO - 2021-09-06 10:35:06 --> Helper loaded: directory_helper
INFO - 2021-09-06 10:35:06 --> Helper loaded: general_helper
INFO - 2021-09-06 10:35:06 --> Database Driver Class Initialized
INFO - 2021-09-06 10:35:06 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-06 10:35:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-06 10:35:06 --> Pagination Class Initialized
INFO - 2021-09-06 10:35:06 --> XML-RPC Class Initialized
INFO - 2021-09-06 10:35:06 --> Form Validation Class Initialized
INFO - 2021-09-06 10:35:06 --> Upload Class Initialized
INFO - 2021-09-06 10:35:06 --> MY_Model class loaded
INFO - 2021-09-06 10:35:06 --> Model "Application_model" initialized
INFO - 2021-09-06 10:35:06 --> Controller Class Initialized
DEBUG - 2021-09-06 10:35:06 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-06 10:35:06 --> Helper loaded: inflector_helper
INFO - 2021-09-06 10:35:06 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-06 10:35:06 --> Database Driver Class Initialized
ERROR - 2021-09-06 10:35:06 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 10:35:06 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 10:35:06 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-06 10:35:06 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-06 10:35:06 --> Model "Branch_model" initialized
ERROR - 2021-09-06 10:35:06 --> Severity: error --> Exception: Too few arguments to function MY_Model::get(), 0 passed in C:\Users\Gopal Ghimire\Desktop\New folder\school\application\controllers\api\Branch.php on line 22 and at least 1 expected C:\Users\Gopal Ghimire\Desktop\New folder\school\application\core\MY_Model.php 40
INFO - 2021-09-06 10:35:52 --> Config Class Initialized
INFO - 2021-09-06 10:35:52 --> Hooks Class Initialized
DEBUG - 2021-09-06 10:35:52 --> UTF-8 Support Enabled
INFO - 2021-09-06 10:35:52 --> Utf8 Class Initialized
INFO - 2021-09-06 10:35:52 --> URI Class Initialized
INFO - 2021-09-06 10:35:52 --> Router Class Initialized
INFO - 2021-09-06 10:35:52 --> Output Class Initialized
INFO - 2021-09-06 10:35:52 --> Security Class Initialized
DEBUG - 2021-09-06 10:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-06 10:35:52 --> CSRF cookie sent
INFO - 2021-09-06 10:35:52 --> Input Class Initialized
INFO - 2021-09-06 10:35:52 --> Language Class Initialized
INFO - 2021-09-06 10:35:52 --> Loader Class Initialized
INFO - 2021-09-06 10:35:52 --> Helper loaded: url_helper
INFO - 2021-09-06 10:35:52 --> Helper loaded: file_helper
INFO - 2021-09-06 10:35:52 --> Helper loaded: form_helper
INFO - 2021-09-06 10:35:52 --> Helper loaded: security_helper
INFO - 2021-09-06 10:35:52 --> Helper loaded: directory_helper
INFO - 2021-09-06 10:35:52 --> Helper loaded: general_helper
INFO - 2021-09-06 10:35:52 --> Database Driver Class Initialized
INFO - 2021-09-06 10:35:52 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-06 10:35:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-06 10:35:52 --> Pagination Class Initialized
INFO - 2021-09-06 10:35:52 --> XML-RPC Class Initialized
INFO - 2021-09-06 10:35:52 --> Form Validation Class Initialized
INFO - 2021-09-06 10:35:52 --> Upload Class Initialized
INFO - 2021-09-06 10:35:52 --> MY_Model class loaded
INFO - 2021-09-06 10:35:52 --> Model "Application_model" initialized
INFO - 2021-09-06 10:35:52 --> Controller Class Initialized
DEBUG - 2021-09-06 10:35:52 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-06 10:35:52 --> Helper loaded: inflector_helper
INFO - 2021-09-06 10:35:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-06 10:35:52 --> Database Driver Class Initialized
ERROR - 2021-09-06 10:35:52 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 10:35:52 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 10:35:52 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-06 10:35:52 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-06 10:35:52 --> Model "Branch_model" initialized
INFO - 2021-09-06 10:35:52 --> Final output sent to browser
DEBUG - 2021-09-06 10:35:52 --> Total execution time: 0.1252
INFO - 2021-09-06 10:37:08 --> Config Class Initialized
INFO - 2021-09-06 10:37:08 --> Hooks Class Initialized
DEBUG - 2021-09-06 10:37:08 --> UTF-8 Support Enabled
INFO - 2021-09-06 10:37:08 --> Utf8 Class Initialized
INFO - 2021-09-06 10:37:08 --> URI Class Initialized
INFO - 2021-09-06 10:37:08 --> Router Class Initialized
INFO - 2021-09-06 10:37:08 --> Output Class Initialized
INFO - 2021-09-06 10:37:08 --> Security Class Initialized
DEBUG - 2021-09-06 10:37:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-06 10:37:08 --> CSRF cookie sent
INFO - 2021-09-06 10:37:08 --> Input Class Initialized
INFO - 2021-09-06 10:37:08 --> Language Class Initialized
INFO - 2021-09-06 10:37:08 --> Loader Class Initialized
INFO - 2021-09-06 10:37:08 --> Helper loaded: url_helper
INFO - 2021-09-06 10:37:08 --> Helper loaded: file_helper
INFO - 2021-09-06 10:37:08 --> Helper loaded: form_helper
INFO - 2021-09-06 10:37:08 --> Helper loaded: security_helper
INFO - 2021-09-06 10:37:08 --> Helper loaded: directory_helper
INFO - 2021-09-06 10:37:08 --> Helper loaded: general_helper
INFO - 2021-09-06 10:37:08 --> Database Driver Class Initialized
INFO - 2021-09-06 10:37:08 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-06 10:37:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-06 10:37:08 --> Pagination Class Initialized
INFO - 2021-09-06 10:37:08 --> XML-RPC Class Initialized
INFO - 2021-09-06 10:37:08 --> Form Validation Class Initialized
INFO - 2021-09-06 10:37:08 --> Upload Class Initialized
INFO - 2021-09-06 10:37:08 --> MY_Model class loaded
INFO - 2021-09-06 10:37:08 --> Model "Application_model" initialized
INFO - 2021-09-06 10:37:08 --> Controller Class Initialized
DEBUG - 2021-09-06 10:37:08 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-06 10:37:08 --> Helper loaded: inflector_helper
INFO - 2021-09-06 10:37:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-06 10:37:08 --> Database Driver Class Initialized
ERROR - 2021-09-06 10:37:08 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 10:37:08 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 10:37:08 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-06 10:37:08 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-06 10:37:08 --> Model "Branch_model" initialized
INFO - 2021-09-06 10:37:08 --> Final output sent to browser
DEBUG - 2021-09-06 10:37:08 --> Total execution time: 0.1263
INFO - 2021-09-06 10:38:27 --> Config Class Initialized
INFO - 2021-09-06 10:38:27 --> Hooks Class Initialized
DEBUG - 2021-09-06 10:38:27 --> UTF-8 Support Enabled
INFO - 2021-09-06 10:38:27 --> Utf8 Class Initialized
INFO - 2021-09-06 10:38:27 --> URI Class Initialized
INFO - 2021-09-06 10:38:27 --> Router Class Initialized
INFO - 2021-09-06 10:38:27 --> Output Class Initialized
INFO - 2021-09-06 10:38:27 --> Security Class Initialized
DEBUG - 2021-09-06 10:38:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-06 10:38:27 --> CSRF cookie sent
INFO - 2021-09-06 10:38:27 --> Input Class Initialized
INFO - 2021-09-06 10:38:27 --> Language Class Initialized
INFO - 2021-09-06 10:38:27 --> Loader Class Initialized
INFO - 2021-09-06 10:38:27 --> Helper loaded: url_helper
INFO - 2021-09-06 10:38:27 --> Helper loaded: file_helper
INFO - 2021-09-06 10:38:27 --> Helper loaded: form_helper
INFO - 2021-09-06 10:38:27 --> Helper loaded: security_helper
INFO - 2021-09-06 10:38:27 --> Helper loaded: directory_helper
INFO - 2021-09-06 10:38:27 --> Helper loaded: general_helper
INFO - 2021-09-06 10:38:27 --> Database Driver Class Initialized
INFO - 2021-09-06 10:38:27 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-06 10:38:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-06 10:38:27 --> Pagination Class Initialized
INFO - 2021-09-06 10:38:27 --> XML-RPC Class Initialized
INFO - 2021-09-06 10:38:27 --> Form Validation Class Initialized
INFO - 2021-09-06 10:38:27 --> Upload Class Initialized
INFO - 2021-09-06 10:38:27 --> MY_Model class loaded
INFO - 2021-09-06 10:38:27 --> Model "Application_model" initialized
INFO - 2021-09-06 10:38:27 --> Controller Class Initialized
DEBUG - 2021-09-06 10:38:27 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-06 10:38:27 --> Helper loaded: inflector_helper
INFO - 2021-09-06 10:38:27 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-06 10:38:27 --> Database Driver Class Initialized
ERROR - 2021-09-06 10:38:27 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 10:38:27 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 10:38:27 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-06 10:38:27 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-06 10:38:27 --> Model "Branch_model" initialized
ERROR - 2021-09-06 10:38:27 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_result::where() C:\Users\Gopal Ghimire\Desktop\New folder\school\application\controllers\api\Branch.php 19
INFO - 2021-09-06 10:38:54 --> Config Class Initialized
INFO - 2021-09-06 10:38:54 --> Hooks Class Initialized
DEBUG - 2021-09-06 10:38:54 --> UTF-8 Support Enabled
INFO - 2021-09-06 10:38:54 --> Utf8 Class Initialized
INFO - 2021-09-06 10:38:54 --> URI Class Initialized
INFO - 2021-09-06 10:38:54 --> Router Class Initialized
INFO - 2021-09-06 10:38:54 --> Output Class Initialized
INFO - 2021-09-06 10:38:54 --> Security Class Initialized
DEBUG - 2021-09-06 10:38:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-06 10:38:54 --> CSRF cookie sent
INFO - 2021-09-06 10:38:54 --> Input Class Initialized
INFO - 2021-09-06 10:38:54 --> Language Class Initialized
INFO - 2021-09-06 10:38:54 --> Loader Class Initialized
INFO - 2021-09-06 10:38:54 --> Helper loaded: url_helper
INFO - 2021-09-06 10:38:54 --> Helper loaded: file_helper
INFO - 2021-09-06 10:38:54 --> Helper loaded: form_helper
INFO - 2021-09-06 10:38:54 --> Helper loaded: security_helper
INFO - 2021-09-06 10:38:54 --> Helper loaded: directory_helper
INFO - 2021-09-06 10:38:54 --> Helper loaded: general_helper
INFO - 2021-09-06 10:38:54 --> Database Driver Class Initialized
INFO - 2021-09-06 10:38:54 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-06 10:38:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-06 10:38:54 --> Pagination Class Initialized
INFO - 2021-09-06 10:38:54 --> XML-RPC Class Initialized
INFO - 2021-09-06 10:38:54 --> Form Validation Class Initialized
INFO - 2021-09-06 10:38:54 --> Upload Class Initialized
INFO - 2021-09-06 10:38:54 --> MY_Model class loaded
INFO - 2021-09-06 10:38:54 --> Model "Application_model" initialized
INFO - 2021-09-06 10:38:54 --> Controller Class Initialized
DEBUG - 2021-09-06 10:38:54 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-06 10:38:54 --> Helper loaded: inflector_helper
INFO - 2021-09-06 10:38:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-06 10:38:54 --> Database Driver Class Initialized
ERROR - 2021-09-06 10:38:54 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 10:38:54 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 10:38:54 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-06 10:38:54 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-06 10:38:54 --> Model "Branch_model" initialized
ERROR - 2021-09-06 10:38:54 --> Severity: Warning --> Illegal string offset 'class' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\controllers\api\Branch.php 23
INFO - 2021-09-06 10:38:54 --> Final output sent to browser
DEBUG - 2021-09-06 10:38:54 --> Total execution time: 0.1337
INFO - 2021-09-06 10:39:42 --> Config Class Initialized
INFO - 2021-09-06 10:39:42 --> Hooks Class Initialized
DEBUG - 2021-09-06 10:39:42 --> UTF-8 Support Enabled
INFO - 2021-09-06 10:39:42 --> Utf8 Class Initialized
INFO - 2021-09-06 10:39:42 --> URI Class Initialized
INFO - 2021-09-06 10:39:42 --> Router Class Initialized
INFO - 2021-09-06 10:39:42 --> Output Class Initialized
INFO - 2021-09-06 10:39:42 --> Security Class Initialized
DEBUG - 2021-09-06 10:39:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-06 10:39:42 --> CSRF cookie sent
INFO - 2021-09-06 10:39:42 --> Input Class Initialized
INFO - 2021-09-06 10:39:42 --> Language Class Initialized
INFO - 2021-09-06 10:39:42 --> Loader Class Initialized
INFO - 2021-09-06 10:39:42 --> Helper loaded: url_helper
INFO - 2021-09-06 10:39:42 --> Helper loaded: file_helper
INFO - 2021-09-06 10:39:42 --> Helper loaded: form_helper
INFO - 2021-09-06 10:39:42 --> Helper loaded: security_helper
INFO - 2021-09-06 10:39:42 --> Helper loaded: directory_helper
INFO - 2021-09-06 10:39:42 --> Helper loaded: general_helper
INFO - 2021-09-06 10:39:42 --> Database Driver Class Initialized
INFO - 2021-09-06 10:39:43 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-06 10:39:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-06 10:39:43 --> Pagination Class Initialized
INFO - 2021-09-06 10:39:43 --> XML-RPC Class Initialized
INFO - 2021-09-06 10:39:43 --> Form Validation Class Initialized
INFO - 2021-09-06 10:39:43 --> Upload Class Initialized
INFO - 2021-09-06 10:39:43 --> MY_Model class loaded
INFO - 2021-09-06 10:39:43 --> Model "Application_model" initialized
INFO - 2021-09-06 10:39:43 --> Controller Class Initialized
DEBUG - 2021-09-06 10:39:43 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-06 10:39:43 --> Helper loaded: inflector_helper
INFO - 2021-09-06 10:39:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-06 10:39:43 --> Database Driver Class Initialized
ERROR - 2021-09-06 10:39:43 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 10:39:43 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 10:39:43 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-06 10:39:43 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-06 10:39:43 --> Model "Branch_model" initialized
ERROR - 2021-09-06 10:39:43 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_result::where() C:\Users\Gopal Ghimire\Desktop\New folder\school\application\controllers\api\Branch.php 19
INFO - 2021-09-06 10:40:26 --> Config Class Initialized
INFO - 2021-09-06 10:40:26 --> Hooks Class Initialized
DEBUG - 2021-09-06 10:40:26 --> UTF-8 Support Enabled
INFO - 2021-09-06 10:40:26 --> Utf8 Class Initialized
INFO - 2021-09-06 10:40:26 --> URI Class Initialized
INFO - 2021-09-06 10:40:26 --> Router Class Initialized
INFO - 2021-09-06 10:40:26 --> Output Class Initialized
INFO - 2021-09-06 10:40:26 --> Security Class Initialized
DEBUG - 2021-09-06 10:40:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-06 10:40:26 --> CSRF cookie sent
INFO - 2021-09-06 10:40:26 --> Input Class Initialized
INFO - 2021-09-06 10:40:26 --> Language Class Initialized
INFO - 2021-09-06 10:40:26 --> Loader Class Initialized
INFO - 2021-09-06 10:40:26 --> Helper loaded: url_helper
INFO - 2021-09-06 10:40:26 --> Helper loaded: file_helper
INFO - 2021-09-06 10:40:26 --> Helper loaded: form_helper
INFO - 2021-09-06 10:40:26 --> Helper loaded: security_helper
INFO - 2021-09-06 10:40:26 --> Helper loaded: directory_helper
INFO - 2021-09-06 10:40:26 --> Helper loaded: general_helper
INFO - 2021-09-06 10:40:26 --> Database Driver Class Initialized
INFO - 2021-09-06 10:40:26 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-06 10:40:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-06 10:40:26 --> Pagination Class Initialized
INFO - 2021-09-06 10:40:26 --> XML-RPC Class Initialized
INFO - 2021-09-06 10:40:26 --> Form Validation Class Initialized
INFO - 2021-09-06 10:40:26 --> Upload Class Initialized
INFO - 2021-09-06 10:40:27 --> MY_Model class loaded
INFO - 2021-09-06 10:40:27 --> Model "Application_model" initialized
INFO - 2021-09-06 10:40:27 --> Controller Class Initialized
DEBUG - 2021-09-06 10:40:27 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-06 10:40:27 --> Helper loaded: inflector_helper
INFO - 2021-09-06 10:40:27 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-06 10:40:27 --> Database Driver Class Initialized
ERROR - 2021-09-06 10:40:27 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 10:40:27 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 10:40:27 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-06 10:40:27 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-06 10:40:27 --> Model "Branch_model" initialized
INFO - 2021-09-06 10:41:01 --> Config Class Initialized
INFO - 2021-09-06 10:41:01 --> Hooks Class Initialized
DEBUG - 2021-09-06 10:41:01 --> UTF-8 Support Enabled
INFO - 2021-09-06 10:41:01 --> Utf8 Class Initialized
INFO - 2021-09-06 10:41:01 --> URI Class Initialized
INFO - 2021-09-06 10:41:01 --> Router Class Initialized
INFO - 2021-09-06 10:41:01 --> Output Class Initialized
INFO - 2021-09-06 10:41:01 --> Security Class Initialized
DEBUG - 2021-09-06 10:41:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-06 10:41:01 --> CSRF cookie sent
INFO - 2021-09-06 10:41:01 --> Input Class Initialized
INFO - 2021-09-06 10:41:01 --> Language Class Initialized
INFO - 2021-09-06 10:41:01 --> Loader Class Initialized
INFO - 2021-09-06 10:41:01 --> Helper loaded: url_helper
INFO - 2021-09-06 10:41:01 --> Helper loaded: file_helper
INFO - 2021-09-06 10:41:01 --> Helper loaded: form_helper
INFO - 2021-09-06 10:41:01 --> Helper loaded: security_helper
INFO - 2021-09-06 10:41:01 --> Helper loaded: directory_helper
INFO - 2021-09-06 10:41:01 --> Helper loaded: general_helper
INFO - 2021-09-06 10:41:01 --> Database Driver Class Initialized
INFO - 2021-09-06 10:41:01 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-06 10:41:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-06 10:41:01 --> Pagination Class Initialized
INFO - 2021-09-06 10:41:01 --> XML-RPC Class Initialized
INFO - 2021-09-06 10:41:01 --> Form Validation Class Initialized
INFO - 2021-09-06 10:41:01 --> Upload Class Initialized
INFO - 2021-09-06 10:41:01 --> MY_Model class loaded
INFO - 2021-09-06 10:41:01 --> Model "Application_model" initialized
INFO - 2021-09-06 10:41:01 --> Controller Class Initialized
DEBUG - 2021-09-06 10:41:01 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-06 10:41:01 --> Helper loaded: inflector_helper
INFO - 2021-09-06 10:41:01 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-06 10:41:01 --> Database Driver Class Initialized
ERROR - 2021-09-06 10:41:01 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 10:41:01 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 10:41:01 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-06 10:41:01 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-06 10:41:01 --> Model "Branch_model" initialized
INFO - 2021-09-06 10:41:24 --> Config Class Initialized
INFO - 2021-09-06 10:41:24 --> Hooks Class Initialized
DEBUG - 2021-09-06 10:41:24 --> UTF-8 Support Enabled
INFO - 2021-09-06 10:41:24 --> Utf8 Class Initialized
INFO - 2021-09-06 10:41:24 --> URI Class Initialized
INFO - 2021-09-06 10:41:24 --> Router Class Initialized
INFO - 2021-09-06 10:41:24 --> Output Class Initialized
INFO - 2021-09-06 10:41:24 --> Security Class Initialized
DEBUG - 2021-09-06 10:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-06 10:41:24 --> CSRF cookie sent
INFO - 2021-09-06 10:41:24 --> Input Class Initialized
INFO - 2021-09-06 10:41:24 --> Language Class Initialized
INFO - 2021-09-06 10:41:24 --> Loader Class Initialized
INFO - 2021-09-06 10:41:24 --> Helper loaded: url_helper
INFO - 2021-09-06 10:41:24 --> Helper loaded: file_helper
INFO - 2021-09-06 10:41:24 --> Helper loaded: form_helper
INFO - 2021-09-06 10:41:24 --> Helper loaded: security_helper
INFO - 2021-09-06 10:41:24 --> Helper loaded: directory_helper
INFO - 2021-09-06 10:41:24 --> Helper loaded: general_helper
INFO - 2021-09-06 10:41:24 --> Database Driver Class Initialized
INFO - 2021-09-06 10:41:24 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-06 10:41:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-06 10:41:24 --> Pagination Class Initialized
INFO - 2021-09-06 10:41:24 --> XML-RPC Class Initialized
INFO - 2021-09-06 10:41:24 --> Form Validation Class Initialized
INFO - 2021-09-06 10:41:24 --> Upload Class Initialized
INFO - 2021-09-06 10:41:24 --> MY_Model class loaded
INFO - 2021-09-06 10:41:24 --> Model "Application_model" initialized
INFO - 2021-09-06 10:41:24 --> Controller Class Initialized
DEBUG - 2021-09-06 10:41:24 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-06 10:41:24 --> Helper loaded: inflector_helper
INFO - 2021-09-06 10:41:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-06 10:41:24 --> Database Driver Class Initialized
ERROR - 2021-09-06 10:41:24 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 10:41:24 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 10:41:24 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-06 10:41:24 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-06 10:41:24 --> Model "Branch_model" initialized
INFO - 2021-09-06 10:41:24 --> Final output sent to browser
DEBUG - 2021-09-06 10:41:24 --> Total execution time: 0.1112
INFO - 2021-09-06 10:42:19 --> Config Class Initialized
INFO - 2021-09-06 10:42:19 --> Hooks Class Initialized
DEBUG - 2021-09-06 10:42:19 --> UTF-8 Support Enabled
INFO - 2021-09-06 10:42:19 --> Utf8 Class Initialized
INFO - 2021-09-06 10:42:19 --> URI Class Initialized
INFO - 2021-09-06 10:42:19 --> Router Class Initialized
INFO - 2021-09-06 10:42:19 --> Output Class Initialized
INFO - 2021-09-06 10:42:20 --> Security Class Initialized
DEBUG - 2021-09-06 10:42:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-06 10:42:20 --> CSRF cookie sent
INFO - 2021-09-06 10:42:20 --> Input Class Initialized
INFO - 2021-09-06 10:42:20 --> Language Class Initialized
INFO - 2021-09-06 10:42:20 --> Loader Class Initialized
INFO - 2021-09-06 10:42:20 --> Helper loaded: url_helper
INFO - 2021-09-06 10:42:20 --> Helper loaded: file_helper
INFO - 2021-09-06 10:42:20 --> Helper loaded: form_helper
INFO - 2021-09-06 10:42:20 --> Helper loaded: security_helper
INFO - 2021-09-06 10:42:20 --> Helper loaded: directory_helper
INFO - 2021-09-06 10:42:20 --> Helper loaded: general_helper
INFO - 2021-09-06 10:42:20 --> Database Driver Class Initialized
INFO - 2021-09-06 10:42:20 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-06 10:42:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-06 10:42:20 --> Pagination Class Initialized
INFO - 2021-09-06 10:42:20 --> XML-RPC Class Initialized
INFO - 2021-09-06 10:42:20 --> Form Validation Class Initialized
INFO - 2021-09-06 10:42:20 --> Upload Class Initialized
INFO - 2021-09-06 10:42:20 --> MY_Model class loaded
INFO - 2021-09-06 10:42:20 --> Model "Application_model" initialized
INFO - 2021-09-06 10:42:20 --> Controller Class Initialized
DEBUG - 2021-09-06 10:42:20 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-06 10:42:20 --> Helper loaded: inflector_helper
INFO - 2021-09-06 10:42:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-06 10:42:20 --> Database Driver Class Initialized
ERROR - 2021-09-06 10:42:20 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 10:42:20 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 10:42:20 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-06 10:42:20 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-06 10:42:20 --> Model "Branch_model" initialized
INFO - 2021-09-06 10:42:20 --> Final output sent to browser
DEBUG - 2021-09-06 10:42:20 --> Total execution time: 0.1156
INFO - 2021-09-06 10:42:47 --> Config Class Initialized
INFO - 2021-09-06 10:42:47 --> Hooks Class Initialized
DEBUG - 2021-09-06 10:42:47 --> UTF-8 Support Enabled
INFO - 2021-09-06 10:42:47 --> Utf8 Class Initialized
INFO - 2021-09-06 10:42:47 --> URI Class Initialized
INFO - 2021-09-06 10:42:47 --> Router Class Initialized
INFO - 2021-09-06 10:42:47 --> Output Class Initialized
INFO - 2021-09-06 10:42:47 --> Security Class Initialized
DEBUG - 2021-09-06 10:42:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-06 10:42:47 --> CSRF cookie sent
INFO - 2021-09-06 10:42:47 --> Input Class Initialized
INFO - 2021-09-06 10:42:47 --> Language Class Initialized
INFO - 2021-09-06 10:42:47 --> Loader Class Initialized
INFO - 2021-09-06 10:42:47 --> Helper loaded: url_helper
INFO - 2021-09-06 10:42:47 --> Helper loaded: file_helper
INFO - 2021-09-06 10:42:47 --> Helper loaded: form_helper
INFO - 2021-09-06 10:42:47 --> Helper loaded: security_helper
INFO - 2021-09-06 10:42:47 --> Helper loaded: directory_helper
INFO - 2021-09-06 10:42:47 --> Helper loaded: general_helper
INFO - 2021-09-06 10:42:47 --> Database Driver Class Initialized
INFO - 2021-09-06 10:42:48 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-06 10:42:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-06 10:42:48 --> Pagination Class Initialized
INFO - 2021-09-06 10:42:48 --> XML-RPC Class Initialized
INFO - 2021-09-06 10:42:48 --> Form Validation Class Initialized
INFO - 2021-09-06 10:42:48 --> Upload Class Initialized
INFO - 2021-09-06 10:42:48 --> MY_Model class loaded
INFO - 2021-09-06 10:42:48 --> Model "Application_model" initialized
INFO - 2021-09-06 10:42:48 --> Controller Class Initialized
DEBUG - 2021-09-06 10:42:48 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-06 10:42:48 --> Helper loaded: inflector_helper
INFO - 2021-09-06 10:42:48 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-06 10:42:48 --> Database Driver Class Initialized
ERROR - 2021-09-06 10:42:48 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 10:42:48 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 10:42:48 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-06 10:42:48 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-06 10:42:48 --> Model "Branch_model" initialized
INFO - 2021-09-06 10:42:48 --> Final output sent to browser
DEBUG - 2021-09-06 10:42:48 --> Total execution time: 0.7061
INFO - 2021-09-06 10:43:09 --> Config Class Initialized
INFO - 2021-09-06 10:43:09 --> Hooks Class Initialized
DEBUG - 2021-09-06 10:43:09 --> UTF-8 Support Enabled
INFO - 2021-09-06 10:43:09 --> Utf8 Class Initialized
INFO - 2021-09-06 10:43:09 --> URI Class Initialized
INFO - 2021-09-06 10:43:09 --> Router Class Initialized
INFO - 2021-09-06 10:43:09 --> Output Class Initialized
INFO - 2021-09-06 10:43:09 --> Security Class Initialized
DEBUG - 2021-09-06 10:43:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-06 10:43:09 --> CSRF cookie sent
INFO - 2021-09-06 10:43:09 --> Input Class Initialized
INFO - 2021-09-06 10:43:09 --> Language Class Initialized
INFO - 2021-09-06 10:43:09 --> Loader Class Initialized
INFO - 2021-09-06 10:43:09 --> Helper loaded: url_helper
INFO - 2021-09-06 10:43:09 --> Helper loaded: file_helper
INFO - 2021-09-06 10:43:09 --> Helper loaded: form_helper
INFO - 2021-09-06 10:43:09 --> Helper loaded: security_helper
INFO - 2021-09-06 10:43:09 --> Helper loaded: directory_helper
INFO - 2021-09-06 10:43:09 --> Helper loaded: general_helper
INFO - 2021-09-06 10:43:09 --> Database Driver Class Initialized
INFO - 2021-09-06 10:43:09 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-06 10:43:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-06 10:43:09 --> Pagination Class Initialized
INFO - 2021-09-06 10:43:09 --> XML-RPC Class Initialized
INFO - 2021-09-06 10:43:09 --> Form Validation Class Initialized
INFO - 2021-09-06 10:43:09 --> Upload Class Initialized
INFO - 2021-09-06 10:43:09 --> MY_Model class loaded
INFO - 2021-09-06 10:43:09 --> Model "Application_model" initialized
INFO - 2021-09-06 10:43:09 --> Controller Class Initialized
DEBUG - 2021-09-06 10:43:09 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-06 10:43:09 --> Helper loaded: inflector_helper
INFO - 2021-09-06 10:43:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-06 10:43:09 --> Database Driver Class Initialized
ERROR - 2021-09-06 10:43:09 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 10:43:09 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 10:43:09 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-06 10:43:09 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-06 10:43:09 --> Model "Branch_model" initialized
INFO - 2021-09-06 10:43:09 --> Final output sent to browser
DEBUG - 2021-09-06 10:43:09 --> Total execution time: 0.1539
INFO - 2021-09-06 10:44:53 --> Config Class Initialized
INFO - 2021-09-06 10:44:53 --> Hooks Class Initialized
DEBUG - 2021-09-06 10:44:53 --> UTF-8 Support Enabled
INFO - 2021-09-06 10:44:53 --> Utf8 Class Initialized
INFO - 2021-09-06 10:44:53 --> URI Class Initialized
INFO - 2021-09-06 10:44:53 --> Router Class Initialized
INFO - 2021-09-06 10:44:53 --> Output Class Initialized
INFO - 2021-09-06 10:44:53 --> Security Class Initialized
DEBUG - 2021-09-06 10:44:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-06 10:44:53 --> CSRF cookie sent
INFO - 2021-09-06 10:44:53 --> Input Class Initialized
INFO - 2021-09-06 10:44:53 --> Language Class Initialized
INFO - 2021-09-06 10:44:53 --> Loader Class Initialized
INFO - 2021-09-06 10:44:53 --> Helper loaded: url_helper
INFO - 2021-09-06 10:44:53 --> Helper loaded: file_helper
INFO - 2021-09-06 10:44:53 --> Helper loaded: form_helper
INFO - 2021-09-06 10:44:53 --> Helper loaded: security_helper
INFO - 2021-09-06 10:44:53 --> Helper loaded: directory_helper
INFO - 2021-09-06 10:44:53 --> Helper loaded: general_helper
INFO - 2021-09-06 10:44:53 --> Database Driver Class Initialized
INFO - 2021-09-06 10:44:53 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-06 10:44:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-06 10:44:53 --> Pagination Class Initialized
INFO - 2021-09-06 10:44:53 --> XML-RPC Class Initialized
INFO - 2021-09-06 10:44:53 --> Form Validation Class Initialized
INFO - 2021-09-06 10:44:53 --> Upload Class Initialized
INFO - 2021-09-06 10:44:53 --> MY_Model class loaded
INFO - 2021-09-06 10:44:53 --> Model "Application_model" initialized
INFO - 2021-09-06 10:44:53 --> Controller Class Initialized
DEBUG - 2021-09-06 10:44:53 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-06 10:44:53 --> Helper loaded: inflector_helper
INFO - 2021-09-06 10:44:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-06 10:44:53 --> Database Driver Class Initialized
ERROR - 2021-09-06 10:44:53 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 10:44:53 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 10:44:53 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-06 10:44:53 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-06 10:44:53 --> Model "Branch_model" initialized
ERROR - 2021-09-06 10:44:53 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_result::where() C:\Users\Gopal Ghimire\Desktop\New folder\school\application\controllers\api\Branch.php 18
INFO - 2021-09-06 10:45:17 --> Config Class Initialized
INFO - 2021-09-06 10:45:17 --> Hooks Class Initialized
DEBUG - 2021-09-06 10:45:17 --> UTF-8 Support Enabled
INFO - 2021-09-06 10:45:17 --> Utf8 Class Initialized
INFO - 2021-09-06 10:45:17 --> URI Class Initialized
INFO - 2021-09-06 10:45:17 --> Router Class Initialized
INFO - 2021-09-06 10:45:17 --> Output Class Initialized
INFO - 2021-09-06 10:45:17 --> Security Class Initialized
DEBUG - 2021-09-06 10:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-06 10:45:17 --> CSRF cookie sent
INFO - 2021-09-06 10:45:17 --> Input Class Initialized
INFO - 2021-09-06 10:45:17 --> Language Class Initialized
INFO - 2021-09-06 10:45:17 --> Loader Class Initialized
INFO - 2021-09-06 10:45:17 --> Helper loaded: url_helper
INFO - 2021-09-06 10:45:17 --> Helper loaded: file_helper
INFO - 2021-09-06 10:45:17 --> Helper loaded: form_helper
INFO - 2021-09-06 10:45:17 --> Helper loaded: security_helper
INFO - 2021-09-06 10:45:17 --> Helper loaded: directory_helper
INFO - 2021-09-06 10:45:17 --> Helper loaded: general_helper
INFO - 2021-09-06 10:45:17 --> Database Driver Class Initialized
INFO - 2021-09-06 10:45:17 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-06 10:45:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-06 10:45:17 --> Pagination Class Initialized
INFO - 2021-09-06 10:45:17 --> XML-RPC Class Initialized
INFO - 2021-09-06 10:45:17 --> Form Validation Class Initialized
INFO - 2021-09-06 10:45:17 --> Upload Class Initialized
INFO - 2021-09-06 10:45:17 --> MY_Model class loaded
INFO - 2021-09-06 10:45:17 --> Model "Application_model" initialized
INFO - 2021-09-06 10:45:17 --> Controller Class Initialized
DEBUG - 2021-09-06 10:45:17 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-06 10:45:17 --> Helper loaded: inflector_helper
INFO - 2021-09-06 10:45:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-06 10:45:17 --> Database Driver Class Initialized
ERROR - 2021-09-06 10:45:17 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 10:45:17 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 10:45:17 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-06 10:45:17 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-06 10:45:17 --> Model "Branch_model" initialized
INFO - 2021-09-06 10:45:17 --> Final output sent to browser
DEBUG - 2021-09-06 10:45:17 --> Total execution time: 0.1803
INFO - 2021-09-06 11:00:50 --> Config Class Initialized
INFO - 2021-09-06 11:00:50 --> Hooks Class Initialized
DEBUG - 2021-09-06 11:00:50 --> UTF-8 Support Enabled
INFO - 2021-09-06 11:00:50 --> Utf8 Class Initialized
INFO - 2021-09-06 11:00:50 --> URI Class Initialized
INFO - 2021-09-06 11:00:50 --> Router Class Initialized
INFO - 2021-09-06 11:00:50 --> Output Class Initialized
INFO - 2021-09-06 11:00:50 --> Security Class Initialized
DEBUG - 2021-09-06 11:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-06 11:00:50 --> CSRF cookie sent
INFO - 2021-09-06 11:00:50 --> Input Class Initialized
INFO - 2021-09-06 11:00:50 --> Language Class Initialized
INFO - 2021-09-06 11:00:51 --> Loader Class Initialized
INFO - 2021-09-06 11:00:51 --> Helper loaded: url_helper
INFO - 2021-09-06 11:00:51 --> Helper loaded: file_helper
INFO - 2021-09-06 11:00:51 --> Helper loaded: form_helper
INFO - 2021-09-06 11:00:51 --> Helper loaded: security_helper
INFO - 2021-09-06 11:00:51 --> Helper loaded: directory_helper
INFO - 2021-09-06 11:00:51 --> Helper loaded: general_helper
INFO - 2021-09-06 11:00:51 --> Database Driver Class Initialized
INFO - 2021-09-06 11:00:51 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-06 11:00:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-06 11:00:52 --> Pagination Class Initialized
INFO - 2021-09-06 11:00:52 --> XML-RPC Class Initialized
INFO - 2021-09-06 11:00:52 --> Form Validation Class Initialized
INFO - 2021-09-06 11:00:52 --> Upload Class Initialized
INFO - 2021-09-06 11:00:52 --> MY_Model class loaded
INFO - 2021-09-06 11:00:52 --> Model "Application_model" initialized
INFO - 2021-09-06 11:00:52 --> Controller Class Initialized
DEBUG - 2021-09-06 11:00:52 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-06 11:00:52 --> Helper loaded: inflector_helper
INFO - 2021-09-06 11:00:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-06 11:00:52 --> Database Driver Class Initialized
ERROR - 2021-09-06 11:00:52 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 11:00:52 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 11:00:52 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-06 11:00:52 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-06 11:00:52 --> Model "Branch_model" initialized
INFO - 2021-09-06 11:00:52 --> Final output sent to browser
DEBUG - 2021-09-06 11:00:52 --> Total execution time: 2.3209
INFO - 2021-09-06 11:08:56 --> Config Class Initialized
INFO - 2021-09-06 11:08:57 --> Hooks Class Initialized
DEBUG - 2021-09-06 11:08:57 --> UTF-8 Support Enabled
INFO - 2021-09-06 11:08:57 --> Utf8 Class Initialized
INFO - 2021-09-06 11:08:57 --> URI Class Initialized
INFO - 2021-09-06 11:08:57 --> Router Class Initialized
INFO - 2021-09-06 11:08:57 --> Output Class Initialized
INFO - 2021-09-06 11:08:57 --> Security Class Initialized
DEBUG - 2021-09-06 11:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-06 11:08:57 --> CSRF cookie sent
INFO - 2021-09-06 11:08:57 --> Input Class Initialized
INFO - 2021-09-06 11:08:57 --> Language Class Initialized
INFO - 2021-09-06 11:08:58 --> Loader Class Initialized
INFO - 2021-09-06 11:08:58 --> Helper loaded: url_helper
INFO - 2021-09-06 11:08:58 --> Helper loaded: file_helper
INFO - 2021-09-06 11:08:59 --> Helper loaded: form_helper
INFO - 2021-09-06 11:08:59 --> Helper loaded: security_helper
INFO - 2021-09-06 11:09:00 --> Helper loaded: directory_helper
INFO - 2021-09-06 11:09:01 --> Helper loaded: general_helper
INFO - 2021-09-06 11:09:03 --> Database Driver Class Initialized
INFO - 2021-09-06 11:09:05 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-06 11:09:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-06 11:09:05 --> Pagination Class Initialized
INFO - 2021-09-06 11:09:05 --> XML-RPC Class Initialized
INFO - 2021-09-06 11:09:05 --> Form Validation Class Initialized
INFO - 2021-09-06 11:09:05 --> Upload Class Initialized
INFO - 2021-09-06 11:09:06 --> MY_Model class loaded
INFO - 2021-09-06 11:09:06 --> Model "Application_model" initialized
INFO - 2021-09-06 11:09:06 --> Controller Class Initialized
DEBUG - 2021-09-06 11:09:06 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-06 11:09:06 --> Helper loaded: inflector_helper
INFO - 2021-09-06 11:09:06 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-06 11:09:06 --> Database Driver Class Initialized
ERROR - 2021-09-06 11:09:07 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 11:09:07 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 11:09:07 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-06 11:09:07 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-06 11:09:07 --> Model "Branch_model" initialized
INFO - 2021-09-06 11:09:07 --> Final output sent to browser
DEBUG - 2021-09-06 11:09:07 --> Total execution time: 10.8322
INFO - 2021-09-06 11:10:51 --> Config Class Initialized
INFO - 2021-09-06 11:10:51 --> Hooks Class Initialized
DEBUG - 2021-09-06 11:10:51 --> UTF-8 Support Enabled
INFO - 2021-09-06 11:10:51 --> Utf8 Class Initialized
INFO - 2021-09-06 11:10:51 --> URI Class Initialized
INFO - 2021-09-06 11:10:51 --> Router Class Initialized
INFO - 2021-09-06 11:10:51 --> Output Class Initialized
INFO - 2021-09-06 11:10:51 --> Security Class Initialized
DEBUG - 2021-09-06 11:10:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-06 11:10:51 --> CSRF cookie sent
INFO - 2021-09-06 11:10:51 --> Input Class Initialized
INFO - 2021-09-06 11:10:51 --> Language Class Initialized
INFO - 2021-09-06 11:10:51 --> Loader Class Initialized
INFO - 2021-09-06 11:10:51 --> Helper loaded: url_helper
INFO - 2021-09-06 11:10:51 --> Helper loaded: file_helper
INFO - 2021-09-06 11:10:51 --> Helper loaded: form_helper
INFO - 2021-09-06 11:10:51 --> Helper loaded: security_helper
INFO - 2021-09-06 11:10:51 --> Helper loaded: directory_helper
INFO - 2021-09-06 11:10:51 --> Helper loaded: general_helper
INFO - 2021-09-06 11:10:51 --> Database Driver Class Initialized
INFO - 2021-09-06 11:10:52 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-06 11:10:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-06 11:10:52 --> Pagination Class Initialized
INFO - 2021-09-06 11:10:52 --> XML-RPC Class Initialized
INFO - 2021-09-06 11:10:52 --> Form Validation Class Initialized
INFO - 2021-09-06 11:10:52 --> Upload Class Initialized
INFO - 2021-09-06 11:10:52 --> MY_Model class loaded
INFO - 2021-09-06 11:10:52 --> Model "Application_model" initialized
INFO - 2021-09-06 11:10:52 --> Controller Class Initialized
DEBUG - 2021-09-06 11:10:52 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-06 11:10:52 --> Helper loaded: inflector_helper
INFO - 2021-09-06 11:10:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-06 11:10:52 --> Database Driver Class Initialized
ERROR - 2021-09-06 11:10:52 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 11:10:52 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 11:10:52 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-06 11:10:52 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-06 11:10:52 --> Model "Branch_model" initialized
ERROR - 2021-09-06 11:10:54 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_result::having() C:\Users\Gopal Ghimire\Desktop\New folder\school\application\controllers\api\Branch.php 19
INFO - 2021-09-06 11:21:41 --> Config Class Initialized
INFO - 2021-09-06 11:21:41 --> Hooks Class Initialized
DEBUG - 2021-09-06 11:21:41 --> UTF-8 Support Enabled
INFO - 2021-09-06 11:21:41 --> Utf8 Class Initialized
INFO - 2021-09-06 11:21:41 --> URI Class Initialized
INFO - 2021-09-06 11:21:41 --> Router Class Initialized
INFO - 2021-09-06 11:21:41 --> Output Class Initialized
INFO - 2021-09-06 11:21:41 --> Security Class Initialized
DEBUG - 2021-09-06 11:21:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-06 11:21:41 --> CSRF cookie sent
INFO - 2021-09-06 11:21:41 --> Input Class Initialized
INFO - 2021-09-06 11:21:41 --> Language Class Initialized
INFO - 2021-09-06 11:21:42 --> Loader Class Initialized
INFO - 2021-09-06 11:21:43 --> Helper loaded: url_helper
INFO - 2021-09-06 11:21:43 --> Helper loaded: file_helper
INFO - 2021-09-06 11:21:43 --> Helper loaded: form_helper
INFO - 2021-09-06 11:21:43 --> Helper loaded: security_helper
INFO - 2021-09-06 11:21:43 --> Helper loaded: directory_helper
INFO - 2021-09-06 11:21:43 --> Helper loaded: general_helper
INFO - 2021-09-06 11:21:43 --> Database Driver Class Initialized
INFO - 2021-09-06 11:21:45 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-06 11:21:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-06 11:21:45 --> Pagination Class Initialized
INFO - 2021-09-06 11:21:46 --> XML-RPC Class Initialized
INFO - 2021-09-06 11:21:46 --> Form Validation Class Initialized
INFO - 2021-09-06 11:21:46 --> Upload Class Initialized
INFO - 2021-09-06 11:21:46 --> MY_Model class loaded
INFO - 2021-09-06 11:21:46 --> Model "Application_model" initialized
INFO - 2021-09-06 11:21:46 --> Controller Class Initialized
DEBUG - 2021-09-06 11:21:46 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-06 11:21:46 --> Helper loaded: inflector_helper
INFO - 2021-09-06 11:21:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-06 11:21:46 --> Database Driver Class Initialized
ERROR - 2021-09-06 11:21:46 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 11:21:46 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 11:21:46 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-06 11:21:46 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-06 11:21:46 --> Model "Branch_model" initialized
ERROR - 2021-09-06 11:21:47 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '.`id`)' at line 3 - Invalid query: SELECT *
FROM `branch`
JOIN `class` USING (`branch`.`id`)
ERROR - 2021-09-06 11:21:47 --> Severity: error --> Exception: Call to a member function result() on bool C:\Users\Gopal Ghimire\Desktop\New folder\school\application\controllers\api\Branch.php 25
INFO - 2021-09-06 11:22:43 --> Config Class Initialized
INFO - 2021-09-06 11:22:43 --> Hooks Class Initialized
DEBUG - 2021-09-06 11:22:43 --> UTF-8 Support Enabled
INFO - 2021-09-06 11:22:43 --> Utf8 Class Initialized
INFO - 2021-09-06 11:22:43 --> URI Class Initialized
INFO - 2021-09-06 11:22:43 --> Router Class Initialized
INFO - 2021-09-06 11:22:44 --> Output Class Initialized
INFO - 2021-09-06 11:22:44 --> Security Class Initialized
DEBUG - 2021-09-06 11:22:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-06 11:22:44 --> CSRF cookie sent
INFO - 2021-09-06 11:22:44 --> Input Class Initialized
INFO - 2021-09-06 11:22:44 --> Language Class Initialized
INFO - 2021-09-06 11:22:44 --> Loader Class Initialized
INFO - 2021-09-06 11:22:44 --> Helper loaded: url_helper
INFO - 2021-09-06 11:22:44 --> Helper loaded: file_helper
INFO - 2021-09-06 11:22:44 --> Helper loaded: form_helper
INFO - 2021-09-06 11:22:44 --> Helper loaded: security_helper
INFO - 2021-09-06 11:22:44 --> Helper loaded: directory_helper
INFO - 2021-09-06 11:22:44 --> Helper loaded: general_helper
INFO - 2021-09-06 11:22:44 --> Database Driver Class Initialized
INFO - 2021-09-06 11:22:44 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-06 11:22:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-06 11:22:44 --> Pagination Class Initialized
INFO - 2021-09-06 11:22:44 --> XML-RPC Class Initialized
INFO - 2021-09-06 11:22:44 --> Form Validation Class Initialized
INFO - 2021-09-06 11:22:44 --> Upload Class Initialized
INFO - 2021-09-06 11:22:44 --> MY_Model class loaded
INFO - 2021-09-06 11:22:44 --> Model "Application_model" initialized
INFO - 2021-09-06 11:22:44 --> Controller Class Initialized
DEBUG - 2021-09-06 11:22:44 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-06 11:22:44 --> Helper loaded: inflector_helper
INFO - 2021-09-06 11:22:44 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-06 11:22:44 --> Database Driver Class Initialized
ERROR - 2021-09-06 11:22:44 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 11:22:44 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 11:22:44 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-06 11:22:44 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-06 11:22:44 --> Model "Branch_model" initialized
INFO - 2021-09-06 11:22:45 --> Final output sent to browser
DEBUG - 2021-09-06 11:22:45 --> Total execution time: 1.4227
INFO - 2021-09-06 11:27:52 --> Config Class Initialized
INFO - 2021-09-06 11:27:52 --> Hooks Class Initialized
DEBUG - 2021-09-06 11:27:52 --> UTF-8 Support Enabled
INFO - 2021-09-06 11:27:52 --> Utf8 Class Initialized
INFO - 2021-09-06 11:27:52 --> URI Class Initialized
INFO - 2021-09-06 11:27:52 --> Router Class Initialized
INFO - 2021-09-06 11:27:52 --> Output Class Initialized
INFO - 2021-09-06 11:27:52 --> Security Class Initialized
DEBUG - 2021-09-06 11:27:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-06 11:27:52 --> CSRF cookie sent
INFO - 2021-09-06 11:27:52 --> Input Class Initialized
INFO - 2021-09-06 11:27:52 --> Language Class Initialized
INFO - 2021-09-06 11:27:52 --> Loader Class Initialized
INFO - 2021-09-06 11:27:52 --> Helper loaded: url_helper
INFO - 2021-09-06 11:27:52 --> Helper loaded: file_helper
INFO - 2021-09-06 11:27:52 --> Helper loaded: form_helper
INFO - 2021-09-06 11:27:52 --> Helper loaded: security_helper
INFO - 2021-09-06 11:27:52 --> Helper loaded: directory_helper
INFO - 2021-09-06 11:27:52 --> Helper loaded: general_helper
INFO - 2021-09-06 11:27:52 --> Database Driver Class Initialized
INFO - 2021-09-06 11:27:54 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-06 11:27:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-06 11:27:54 --> Pagination Class Initialized
INFO - 2021-09-06 11:27:54 --> XML-RPC Class Initialized
INFO - 2021-09-06 11:27:54 --> Form Validation Class Initialized
INFO - 2021-09-06 11:27:54 --> Upload Class Initialized
INFO - 2021-09-06 11:27:54 --> MY_Model class loaded
INFO - 2021-09-06 11:27:54 --> Model "Application_model" initialized
INFO - 2021-09-06 11:27:54 --> Controller Class Initialized
DEBUG - 2021-09-06 11:27:54 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-06 11:27:54 --> Helper loaded: inflector_helper
INFO - 2021-09-06 11:27:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-06 11:27:54 --> Database Driver Class Initialized
ERROR - 2021-09-06 11:27:55 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 11:27:55 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 11:27:55 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-06 11:27:55 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-06 11:27:55 --> Model "Branch_model" initialized
ERROR - 2021-09-06 11:27:56 --> Query error: Table 'anish.classs' doesn't exist - Invalid query: SELECT *
FROM `classs`
WHERE `branch_id` = '1'
ERROR - 2021-09-06 11:27:56 --> Severity: error --> Exception: Call to a member function result() on bool C:\Users\Gopal Ghimire\Desktop\New folder\school\application\controllers\api\Branch.php 20
INFO - 2021-09-06 11:28:44 --> Config Class Initialized
INFO - 2021-09-06 11:28:44 --> Hooks Class Initialized
DEBUG - 2021-09-06 11:28:44 --> UTF-8 Support Enabled
INFO - 2021-09-06 11:28:44 --> Utf8 Class Initialized
INFO - 2021-09-06 11:28:44 --> URI Class Initialized
INFO - 2021-09-06 11:28:44 --> Router Class Initialized
INFO - 2021-09-06 11:28:44 --> Output Class Initialized
INFO - 2021-09-06 11:28:44 --> Security Class Initialized
DEBUG - 2021-09-06 11:28:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-06 11:28:44 --> CSRF cookie sent
INFO - 2021-09-06 11:28:44 --> Input Class Initialized
INFO - 2021-09-06 11:28:44 --> Language Class Initialized
INFO - 2021-09-06 11:28:44 --> Loader Class Initialized
INFO - 2021-09-06 11:28:44 --> Helper loaded: url_helper
INFO - 2021-09-06 11:28:44 --> Helper loaded: file_helper
INFO - 2021-09-06 11:28:44 --> Helper loaded: form_helper
INFO - 2021-09-06 11:28:44 --> Helper loaded: security_helper
INFO - 2021-09-06 11:28:44 --> Helper loaded: directory_helper
INFO - 2021-09-06 11:28:44 --> Helper loaded: general_helper
INFO - 2021-09-06 11:28:44 --> Database Driver Class Initialized
INFO - 2021-09-06 11:28:44 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-06 11:28:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-06 11:28:44 --> Pagination Class Initialized
INFO - 2021-09-06 11:28:44 --> XML-RPC Class Initialized
INFO - 2021-09-06 11:28:44 --> Form Validation Class Initialized
INFO - 2021-09-06 11:28:44 --> Upload Class Initialized
INFO - 2021-09-06 11:28:44 --> MY_Model class loaded
INFO - 2021-09-06 11:28:44 --> Model "Application_model" initialized
INFO - 2021-09-06 11:28:44 --> Controller Class Initialized
DEBUG - 2021-09-06 11:28:44 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-06 11:28:44 --> Helper loaded: inflector_helper
INFO - 2021-09-06 11:28:44 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-06 11:28:44 --> Database Driver Class Initialized
ERROR - 2021-09-06 11:28:44 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 11:28:44 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 11:28:44 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-06 11:28:44 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-06 11:28:44 --> Model "Branch_model" initialized
ERROR - 2021-09-06 11:28:44 --> Query error: Table 'anish.classs' doesn't exist - Invalid query: SELECT *
FROM `classs`
WHERE `branch_id` = '1'
ERROR - 2021-09-06 11:28:44 --> Severity: error --> Exception: Call to a member function result() on bool C:\Users\Gopal Ghimire\Desktop\New folder\school\application\controllers\api\Branch.php 20
INFO - 2021-09-06 11:29:02 --> Config Class Initialized
INFO - 2021-09-06 11:29:02 --> Hooks Class Initialized
DEBUG - 2021-09-06 11:29:02 --> UTF-8 Support Enabled
INFO - 2021-09-06 11:29:02 --> Utf8 Class Initialized
INFO - 2021-09-06 11:29:02 --> URI Class Initialized
INFO - 2021-09-06 11:29:02 --> Router Class Initialized
INFO - 2021-09-06 11:29:02 --> Output Class Initialized
INFO - 2021-09-06 11:29:02 --> Security Class Initialized
DEBUG - 2021-09-06 11:29:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-06 11:29:02 --> CSRF cookie sent
INFO - 2021-09-06 11:29:02 --> Input Class Initialized
INFO - 2021-09-06 11:29:02 --> Language Class Initialized
INFO - 2021-09-06 11:29:02 --> Loader Class Initialized
INFO - 2021-09-06 11:29:02 --> Helper loaded: url_helper
INFO - 2021-09-06 11:29:02 --> Helper loaded: file_helper
INFO - 2021-09-06 11:29:02 --> Helper loaded: form_helper
INFO - 2021-09-06 11:29:02 --> Helper loaded: security_helper
INFO - 2021-09-06 11:29:02 --> Helper loaded: directory_helper
INFO - 2021-09-06 11:29:02 --> Helper loaded: general_helper
INFO - 2021-09-06 11:29:02 --> Database Driver Class Initialized
INFO - 2021-09-06 11:29:02 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-06 11:29:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-06 11:29:02 --> Pagination Class Initialized
INFO - 2021-09-06 11:29:02 --> XML-RPC Class Initialized
INFO - 2021-09-06 11:29:02 --> Form Validation Class Initialized
INFO - 2021-09-06 11:29:02 --> Upload Class Initialized
INFO - 2021-09-06 11:29:02 --> MY_Model class loaded
INFO - 2021-09-06 11:29:02 --> Model "Application_model" initialized
INFO - 2021-09-06 11:29:02 --> Controller Class Initialized
DEBUG - 2021-09-06 11:29:02 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-06 11:29:02 --> Helper loaded: inflector_helper
INFO - 2021-09-06 11:29:03 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-06 11:29:03 --> Database Driver Class Initialized
ERROR - 2021-09-06 11:29:03 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 11:29:03 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 11:29:03 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-06 11:29:03 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-06 11:29:03 --> Model "Branch_model" initialized
INFO - 2021-09-06 11:29:03 --> Final output sent to browser
DEBUG - 2021-09-06 11:29:03 --> Total execution time: 0.1394
INFO - 2021-09-06 11:29:21 --> Config Class Initialized
INFO - 2021-09-06 11:29:21 --> Hooks Class Initialized
DEBUG - 2021-09-06 11:29:21 --> UTF-8 Support Enabled
INFO - 2021-09-06 11:29:21 --> Utf8 Class Initialized
INFO - 2021-09-06 11:29:21 --> URI Class Initialized
INFO - 2021-09-06 11:29:21 --> Router Class Initialized
INFO - 2021-09-06 11:29:21 --> Output Class Initialized
INFO - 2021-09-06 11:29:21 --> Security Class Initialized
DEBUG - 2021-09-06 11:29:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-06 11:29:21 --> CSRF cookie sent
INFO - 2021-09-06 11:29:21 --> Input Class Initialized
INFO - 2021-09-06 11:29:21 --> Language Class Initialized
INFO - 2021-09-06 11:29:21 --> Loader Class Initialized
INFO - 2021-09-06 11:29:21 --> Helper loaded: url_helper
INFO - 2021-09-06 11:29:21 --> Helper loaded: file_helper
INFO - 2021-09-06 11:29:21 --> Helper loaded: form_helper
INFO - 2021-09-06 11:29:21 --> Helper loaded: security_helper
INFO - 2021-09-06 11:29:21 --> Helper loaded: directory_helper
INFO - 2021-09-06 11:29:21 --> Helper loaded: general_helper
INFO - 2021-09-06 11:29:21 --> Database Driver Class Initialized
INFO - 2021-09-06 11:29:21 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-06 11:29:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-06 11:29:21 --> Pagination Class Initialized
INFO - 2021-09-06 11:29:21 --> XML-RPC Class Initialized
INFO - 2021-09-06 11:29:21 --> Form Validation Class Initialized
INFO - 2021-09-06 11:29:21 --> Upload Class Initialized
INFO - 2021-09-06 11:29:21 --> MY_Model class loaded
INFO - 2021-09-06 11:29:22 --> Model "Application_model" initialized
INFO - 2021-09-06 11:29:22 --> Controller Class Initialized
DEBUG - 2021-09-06 11:29:22 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-06 11:29:22 --> Helper loaded: inflector_helper
INFO - 2021-09-06 11:29:22 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-06 11:29:22 --> Database Driver Class Initialized
ERROR - 2021-09-06 11:29:22 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 11:29:22 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 11:29:22 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-06 11:29:22 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-06 11:29:22 --> Model "Branch_model" initialized
INFO - 2021-09-06 11:29:22 --> Final output sent to browser
DEBUG - 2021-09-06 11:29:22 --> Total execution time: 0.5230
INFO - 2021-09-06 11:31:10 --> Config Class Initialized
INFO - 2021-09-06 11:31:10 --> Hooks Class Initialized
DEBUG - 2021-09-06 11:31:10 --> UTF-8 Support Enabled
INFO - 2021-09-06 11:31:10 --> Utf8 Class Initialized
INFO - 2021-09-06 11:31:10 --> URI Class Initialized
INFO - 2021-09-06 11:31:10 --> Router Class Initialized
INFO - 2021-09-06 11:31:10 --> Output Class Initialized
INFO - 2021-09-06 11:31:10 --> Security Class Initialized
DEBUG - 2021-09-06 11:31:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-06 11:31:10 --> CSRF cookie sent
INFO - 2021-09-06 11:31:10 --> Input Class Initialized
INFO - 2021-09-06 11:31:10 --> Language Class Initialized
INFO - 2021-09-06 11:31:10 --> Loader Class Initialized
INFO - 2021-09-06 11:31:10 --> Helper loaded: url_helper
INFO - 2021-09-06 11:31:10 --> Helper loaded: file_helper
INFO - 2021-09-06 11:31:10 --> Helper loaded: form_helper
INFO - 2021-09-06 11:31:10 --> Helper loaded: security_helper
INFO - 2021-09-06 11:31:10 --> Helper loaded: directory_helper
INFO - 2021-09-06 11:31:10 --> Helper loaded: general_helper
INFO - 2021-09-06 11:31:10 --> Database Driver Class Initialized
INFO - 2021-09-06 11:31:10 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-06 11:31:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-06 11:31:10 --> Pagination Class Initialized
INFO - 2021-09-06 11:31:10 --> XML-RPC Class Initialized
INFO - 2021-09-06 11:31:10 --> Form Validation Class Initialized
INFO - 2021-09-06 11:31:10 --> Upload Class Initialized
INFO - 2021-09-06 11:31:10 --> MY_Model class loaded
INFO - 2021-09-06 11:31:10 --> Model "Application_model" initialized
INFO - 2021-09-06 11:31:10 --> Controller Class Initialized
DEBUG - 2021-09-06 11:31:10 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-06 11:31:10 --> Helper loaded: inflector_helper
INFO - 2021-09-06 11:31:10 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-06 11:31:10 --> Database Driver Class Initialized
ERROR - 2021-09-06 11:31:10 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 11:31:10 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 11:31:10 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-06 11:31:10 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-06 11:31:10 --> Model "Branch_model" initialized
INFO - 2021-09-06 11:31:10 --> Final output sent to browser
DEBUG - 2021-09-06 11:31:10 --> Total execution time: 0.1567
INFO - 2021-09-06 11:31:53 --> Config Class Initialized
INFO - 2021-09-06 11:31:53 --> Hooks Class Initialized
DEBUG - 2021-09-06 11:31:53 --> UTF-8 Support Enabled
INFO - 2021-09-06 11:31:53 --> Utf8 Class Initialized
INFO - 2021-09-06 11:31:53 --> URI Class Initialized
INFO - 2021-09-06 11:31:53 --> Router Class Initialized
INFO - 2021-09-06 11:31:53 --> Output Class Initialized
INFO - 2021-09-06 11:31:53 --> Security Class Initialized
DEBUG - 2021-09-06 11:31:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-06 11:31:53 --> CSRF cookie sent
INFO - 2021-09-06 11:31:53 --> Input Class Initialized
INFO - 2021-09-06 11:31:53 --> Language Class Initialized
INFO - 2021-09-06 11:31:53 --> Loader Class Initialized
INFO - 2021-09-06 11:31:53 --> Helper loaded: url_helper
INFO - 2021-09-06 11:31:53 --> Helper loaded: file_helper
INFO - 2021-09-06 11:31:53 --> Helper loaded: form_helper
INFO - 2021-09-06 11:31:53 --> Helper loaded: security_helper
INFO - 2021-09-06 11:31:53 --> Helper loaded: directory_helper
INFO - 2021-09-06 11:31:53 --> Helper loaded: general_helper
INFO - 2021-09-06 11:31:53 --> Database Driver Class Initialized
INFO - 2021-09-06 11:31:53 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-06 11:31:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-06 11:31:53 --> Pagination Class Initialized
INFO - 2021-09-06 11:31:53 --> XML-RPC Class Initialized
INFO - 2021-09-06 11:31:54 --> Form Validation Class Initialized
INFO - 2021-09-06 11:31:54 --> Upload Class Initialized
INFO - 2021-09-06 11:31:54 --> MY_Model class loaded
INFO - 2021-09-06 11:31:54 --> Model "Application_model" initialized
INFO - 2021-09-06 11:31:54 --> Controller Class Initialized
DEBUG - 2021-09-06 11:31:54 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-06 11:31:54 --> Helper loaded: inflector_helper
INFO - 2021-09-06 11:31:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-06 11:31:54 --> Database Driver Class Initialized
ERROR - 2021-09-06 11:31:54 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 11:31:54 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 11:31:54 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-06 11:31:54 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-06 11:31:54 --> Model "Branch_model" initialized
INFO - 2021-09-06 11:32:40 --> Config Class Initialized
INFO - 2021-09-06 11:32:40 --> Hooks Class Initialized
DEBUG - 2021-09-06 11:32:40 --> UTF-8 Support Enabled
INFO - 2021-09-06 11:32:40 --> Utf8 Class Initialized
INFO - 2021-09-06 11:32:40 --> URI Class Initialized
INFO - 2021-09-06 11:32:40 --> Router Class Initialized
INFO - 2021-09-06 11:32:40 --> Output Class Initialized
INFO - 2021-09-06 11:32:40 --> Security Class Initialized
DEBUG - 2021-09-06 11:32:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-06 11:32:40 --> CSRF cookie sent
INFO - 2021-09-06 11:32:40 --> Input Class Initialized
INFO - 2021-09-06 11:32:40 --> Language Class Initialized
INFO - 2021-09-06 11:32:40 --> Loader Class Initialized
INFO - 2021-09-06 11:32:40 --> Helper loaded: url_helper
INFO - 2021-09-06 11:32:40 --> Helper loaded: file_helper
INFO - 2021-09-06 11:32:40 --> Helper loaded: form_helper
INFO - 2021-09-06 11:32:40 --> Helper loaded: security_helper
INFO - 2021-09-06 11:32:40 --> Helper loaded: directory_helper
INFO - 2021-09-06 11:32:40 --> Helper loaded: general_helper
INFO - 2021-09-06 11:32:40 --> Database Driver Class Initialized
INFO - 2021-09-06 11:32:40 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-06 11:32:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-06 11:32:40 --> Pagination Class Initialized
INFO - 2021-09-06 11:32:40 --> XML-RPC Class Initialized
INFO - 2021-09-06 11:32:40 --> Form Validation Class Initialized
INFO - 2021-09-06 11:32:40 --> Upload Class Initialized
INFO - 2021-09-06 11:32:40 --> MY_Model class loaded
INFO - 2021-09-06 11:32:40 --> Model "Application_model" initialized
INFO - 2021-09-06 11:32:40 --> Controller Class Initialized
DEBUG - 2021-09-06 11:32:40 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-06 11:32:40 --> Helper loaded: inflector_helper
INFO - 2021-09-06 11:32:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-06 11:32:40 --> Database Driver Class Initialized
ERROR - 2021-09-06 11:32:40 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 11:32:40 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 11:32:40 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-06 11:32:40 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-06 11:32:40 --> Model "Branch_model" initialized
INFO - 2021-09-06 11:32:40 --> Final output sent to browser
DEBUG - 2021-09-06 11:32:40 --> Total execution time: 0.3263
INFO - 2021-09-06 11:34:20 --> Config Class Initialized
INFO - 2021-09-06 11:34:20 --> Hooks Class Initialized
DEBUG - 2021-09-06 11:34:20 --> UTF-8 Support Enabled
INFO - 2021-09-06 11:34:20 --> Utf8 Class Initialized
INFO - 2021-09-06 11:34:20 --> URI Class Initialized
INFO - 2021-09-06 11:34:20 --> Router Class Initialized
INFO - 2021-09-06 11:34:20 --> Output Class Initialized
INFO - 2021-09-06 11:34:20 --> Security Class Initialized
DEBUG - 2021-09-06 11:34:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-06 11:34:20 --> CSRF cookie sent
INFO - 2021-09-06 11:34:20 --> Input Class Initialized
INFO - 2021-09-06 11:34:20 --> Language Class Initialized
INFO - 2021-09-06 11:34:20 --> Loader Class Initialized
INFO - 2021-09-06 11:34:20 --> Helper loaded: url_helper
INFO - 2021-09-06 11:34:20 --> Helper loaded: file_helper
INFO - 2021-09-06 11:34:20 --> Helper loaded: form_helper
INFO - 2021-09-06 11:34:20 --> Helper loaded: security_helper
INFO - 2021-09-06 11:34:20 --> Helper loaded: directory_helper
INFO - 2021-09-06 11:34:20 --> Helper loaded: general_helper
INFO - 2021-09-06 11:34:20 --> Database Driver Class Initialized
INFO - 2021-09-06 11:34:20 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-06 11:34:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-06 11:34:20 --> Pagination Class Initialized
INFO - 2021-09-06 11:34:20 --> XML-RPC Class Initialized
INFO - 2021-09-06 11:34:20 --> Form Validation Class Initialized
INFO - 2021-09-06 11:34:20 --> Upload Class Initialized
INFO - 2021-09-06 11:34:20 --> MY_Model class loaded
INFO - 2021-09-06 11:34:20 --> Model "Application_model" initialized
INFO - 2021-09-06 11:34:20 --> Controller Class Initialized
DEBUG - 2021-09-06 11:34:20 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-06 11:34:20 --> Helper loaded: inflector_helper
INFO - 2021-09-06 11:34:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-06 11:34:20 --> Database Driver Class Initialized
ERROR - 2021-09-06 11:34:20 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 11:34:20 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 11:34:20 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-06 11:34:20 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-06 11:34:20 --> Model "Branch_model" initialized
INFO - 2021-09-06 11:34:20 --> Final output sent to browser
DEBUG - 2021-09-06 11:34:20 --> Total execution time: 0.7546
INFO - 2021-09-06 11:36:59 --> Config Class Initialized
INFO - 2021-09-06 11:36:59 --> Hooks Class Initialized
DEBUG - 2021-09-06 11:36:59 --> UTF-8 Support Enabled
INFO - 2021-09-06 11:36:59 --> Utf8 Class Initialized
INFO - 2021-09-06 11:36:59 --> URI Class Initialized
INFO - 2021-09-06 11:36:59 --> Router Class Initialized
INFO - 2021-09-06 11:36:59 --> Output Class Initialized
INFO - 2021-09-06 11:36:59 --> Security Class Initialized
DEBUG - 2021-09-06 11:36:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-06 11:36:59 --> CSRF cookie sent
INFO - 2021-09-06 11:36:59 --> Input Class Initialized
INFO - 2021-09-06 11:36:59 --> Language Class Initialized
INFO - 2021-09-06 11:36:59 --> Loader Class Initialized
INFO - 2021-09-06 11:36:59 --> Helper loaded: url_helper
INFO - 2021-09-06 11:36:59 --> Helper loaded: file_helper
INFO - 2021-09-06 11:36:59 --> Helper loaded: form_helper
INFO - 2021-09-06 11:36:59 --> Helper loaded: security_helper
INFO - 2021-09-06 11:36:59 --> Helper loaded: directory_helper
INFO - 2021-09-06 11:36:59 --> Helper loaded: general_helper
INFO - 2021-09-06 11:36:59 --> Database Driver Class Initialized
INFO - 2021-09-06 11:36:59 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-06 11:36:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-06 11:36:59 --> Pagination Class Initialized
INFO - 2021-09-06 11:36:59 --> XML-RPC Class Initialized
INFO - 2021-09-06 11:36:59 --> Form Validation Class Initialized
INFO - 2021-09-06 11:36:59 --> Upload Class Initialized
INFO - 2021-09-06 11:36:59 --> MY_Model class loaded
INFO - 2021-09-06 11:36:59 --> Model "Application_model" initialized
INFO - 2021-09-06 11:36:59 --> Controller Class Initialized
DEBUG - 2021-09-06 11:36:59 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-06 11:36:59 --> Helper loaded: inflector_helper
INFO - 2021-09-06 11:36:59 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-06 11:36:59 --> Database Driver Class Initialized
ERROR - 2021-09-06 11:36:59 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 11:36:59 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 11:36:59 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-06 11:36:59 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-06 11:36:59 --> Model "Branch_model" initialized
INFO - 2021-09-06 11:36:59 --> Final output sent to browser
DEBUG - 2021-09-06 11:36:59 --> Total execution time: 0.1471
INFO - 2021-09-06 11:39:34 --> Config Class Initialized
INFO - 2021-09-06 11:39:34 --> Hooks Class Initialized
DEBUG - 2021-09-06 11:39:34 --> UTF-8 Support Enabled
INFO - 2021-09-06 11:39:34 --> Utf8 Class Initialized
INFO - 2021-09-06 11:39:34 --> URI Class Initialized
INFO - 2021-09-06 11:39:34 --> Router Class Initialized
INFO - 2021-09-06 11:39:34 --> Output Class Initialized
INFO - 2021-09-06 11:39:34 --> Security Class Initialized
DEBUG - 2021-09-06 11:39:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-06 11:39:34 --> CSRF cookie sent
INFO - 2021-09-06 11:39:34 --> Input Class Initialized
INFO - 2021-09-06 11:39:34 --> Language Class Initialized
INFO - 2021-09-06 11:39:34 --> Loader Class Initialized
INFO - 2021-09-06 11:39:34 --> Helper loaded: url_helper
INFO - 2021-09-06 11:39:34 --> Helper loaded: file_helper
INFO - 2021-09-06 11:39:34 --> Helper loaded: form_helper
INFO - 2021-09-06 11:39:34 --> Helper loaded: security_helper
INFO - 2021-09-06 11:39:34 --> Helper loaded: directory_helper
INFO - 2021-09-06 11:39:34 --> Helper loaded: general_helper
INFO - 2021-09-06 11:39:34 --> Database Driver Class Initialized
INFO - 2021-09-06 11:39:35 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-06 11:39:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-06 11:39:35 --> Pagination Class Initialized
INFO - 2021-09-06 11:39:35 --> XML-RPC Class Initialized
INFO - 2021-09-06 11:39:35 --> Form Validation Class Initialized
INFO - 2021-09-06 11:39:35 --> Upload Class Initialized
INFO - 2021-09-06 11:39:35 --> MY_Model class loaded
INFO - 2021-09-06 11:39:35 --> Model "Application_model" initialized
INFO - 2021-09-06 11:39:35 --> Controller Class Initialized
DEBUG - 2021-09-06 11:39:35 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-06 11:39:35 --> Helper loaded: inflector_helper
INFO - 2021-09-06 11:39:35 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-06 11:39:35 --> Database Driver Class Initialized
ERROR - 2021-09-06 11:39:35 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 11:39:35 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 11:39:35 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-06 11:39:35 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-06 11:39:35 --> Model "Branch_model" initialized
INFO - 2021-09-06 11:39:35 --> Final output sent to browser
DEBUG - 2021-09-06 11:39:35 --> Total execution time: 0.3150
INFO - 2021-09-06 11:39:59 --> Config Class Initialized
INFO - 2021-09-06 11:39:59 --> Hooks Class Initialized
DEBUG - 2021-09-06 11:39:59 --> UTF-8 Support Enabled
INFO - 2021-09-06 11:39:59 --> Utf8 Class Initialized
INFO - 2021-09-06 11:39:59 --> URI Class Initialized
INFO - 2021-09-06 11:39:59 --> Router Class Initialized
INFO - 2021-09-06 11:39:59 --> Output Class Initialized
INFO - 2021-09-06 11:39:59 --> Security Class Initialized
DEBUG - 2021-09-06 11:39:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-06 11:39:59 --> CSRF cookie sent
INFO - 2021-09-06 11:39:59 --> Input Class Initialized
INFO - 2021-09-06 11:39:59 --> Language Class Initialized
INFO - 2021-09-06 11:39:59 --> Loader Class Initialized
INFO - 2021-09-06 11:39:59 --> Helper loaded: url_helper
INFO - 2021-09-06 11:39:59 --> Helper loaded: file_helper
INFO - 2021-09-06 11:39:59 --> Helper loaded: form_helper
INFO - 2021-09-06 11:39:59 --> Helper loaded: security_helper
INFO - 2021-09-06 11:39:59 --> Helper loaded: directory_helper
INFO - 2021-09-06 11:39:59 --> Helper loaded: general_helper
INFO - 2021-09-06 11:39:59 --> Database Driver Class Initialized
INFO - 2021-09-06 11:39:59 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-06 11:39:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-06 11:39:59 --> Pagination Class Initialized
INFO - 2021-09-06 11:39:59 --> XML-RPC Class Initialized
INFO - 2021-09-06 11:39:59 --> Form Validation Class Initialized
INFO - 2021-09-06 11:39:59 --> Upload Class Initialized
INFO - 2021-09-06 11:39:59 --> MY_Model class loaded
INFO - 2021-09-06 11:39:59 --> Model "Application_model" initialized
INFO - 2021-09-06 11:39:59 --> Controller Class Initialized
DEBUG - 2021-09-06 11:39:59 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-06 11:39:59 --> Helper loaded: inflector_helper
INFO - 2021-09-06 11:39:59 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-06 11:39:59 --> Database Driver Class Initialized
ERROR - 2021-09-06 11:39:59 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 11:39:59 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 11:39:59 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-06 11:39:59 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-06 11:39:59 --> Model "Branch_model" initialized
INFO - 2021-09-06 11:39:59 --> Final output sent to browser
DEBUG - 2021-09-06 11:39:59 --> Total execution time: 0.1363
INFO - 2021-09-06 11:41:29 --> Config Class Initialized
INFO - 2021-09-06 11:41:29 --> Hooks Class Initialized
DEBUG - 2021-09-06 11:41:29 --> UTF-8 Support Enabled
INFO - 2021-09-06 11:41:29 --> Utf8 Class Initialized
INFO - 2021-09-06 11:41:29 --> URI Class Initialized
INFO - 2021-09-06 11:41:29 --> Router Class Initialized
INFO - 2021-09-06 11:41:29 --> Output Class Initialized
INFO - 2021-09-06 11:41:29 --> Security Class Initialized
DEBUG - 2021-09-06 11:41:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-06 11:41:29 --> CSRF cookie sent
INFO - 2021-09-06 11:41:29 --> Input Class Initialized
INFO - 2021-09-06 11:41:29 --> Language Class Initialized
INFO - 2021-09-06 11:41:29 --> Loader Class Initialized
INFO - 2021-09-06 11:41:29 --> Helper loaded: url_helper
INFO - 2021-09-06 11:41:29 --> Helper loaded: file_helper
INFO - 2021-09-06 11:41:29 --> Helper loaded: form_helper
INFO - 2021-09-06 11:41:29 --> Helper loaded: security_helper
INFO - 2021-09-06 11:41:29 --> Helper loaded: directory_helper
INFO - 2021-09-06 11:41:29 --> Helper loaded: general_helper
INFO - 2021-09-06 11:41:29 --> Database Driver Class Initialized
INFO - 2021-09-06 11:41:29 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-06 11:41:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-06 11:41:29 --> Pagination Class Initialized
INFO - 2021-09-06 11:41:29 --> XML-RPC Class Initialized
INFO - 2021-09-06 11:41:29 --> Form Validation Class Initialized
INFO - 2021-09-06 11:41:29 --> Upload Class Initialized
INFO - 2021-09-06 11:41:29 --> MY_Model class loaded
INFO - 2021-09-06 11:41:29 --> Model "Application_model" initialized
INFO - 2021-09-06 11:41:29 --> Controller Class Initialized
DEBUG - 2021-09-06 11:41:29 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-06 11:41:29 --> Helper loaded: inflector_helper
INFO - 2021-09-06 11:41:29 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-06 11:41:29 --> Database Driver Class Initialized
ERROR - 2021-09-06 11:41:29 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 11:41:29 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 11:41:29 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-06 11:41:29 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-06 11:41:29 --> Model "Branch_model" initialized
INFO - 2021-09-06 11:41:29 --> Final output sent to browser
DEBUG - 2021-09-06 11:41:29 --> Total execution time: 0.1588
INFO - 2021-09-06 11:45:50 --> Config Class Initialized
INFO - 2021-09-06 11:45:50 --> Hooks Class Initialized
DEBUG - 2021-09-06 11:45:50 --> UTF-8 Support Enabled
INFO - 2021-09-06 11:45:50 --> Utf8 Class Initialized
INFO - 2021-09-06 11:45:50 --> URI Class Initialized
INFO - 2021-09-06 11:45:50 --> Router Class Initialized
INFO - 2021-09-06 11:45:50 --> Output Class Initialized
INFO - 2021-09-06 11:45:50 --> Security Class Initialized
DEBUG - 2021-09-06 11:45:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-06 11:45:50 --> CSRF cookie sent
INFO - 2021-09-06 11:45:50 --> Input Class Initialized
INFO - 2021-09-06 11:45:50 --> Language Class Initialized
INFO - 2021-09-06 11:45:50 --> Loader Class Initialized
INFO - 2021-09-06 11:45:50 --> Helper loaded: url_helper
INFO - 2021-09-06 11:45:50 --> Helper loaded: file_helper
INFO - 2021-09-06 11:45:50 --> Helper loaded: form_helper
INFO - 2021-09-06 11:45:50 --> Helper loaded: security_helper
INFO - 2021-09-06 11:45:50 --> Helper loaded: directory_helper
INFO - 2021-09-06 11:45:50 --> Helper loaded: general_helper
INFO - 2021-09-06 11:45:51 --> Database Driver Class Initialized
INFO - 2021-09-06 11:45:51 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-06 11:45:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-06 11:45:51 --> Pagination Class Initialized
INFO - 2021-09-06 11:45:51 --> XML-RPC Class Initialized
INFO - 2021-09-06 11:45:51 --> Form Validation Class Initialized
INFO - 2021-09-06 11:45:51 --> Upload Class Initialized
INFO - 2021-09-06 11:45:51 --> MY_Model class loaded
INFO - 2021-09-06 11:45:51 --> Model "Application_model" initialized
INFO - 2021-09-06 11:45:51 --> Controller Class Initialized
DEBUG - 2021-09-06 11:45:51 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-06 11:45:51 --> Helper loaded: inflector_helper
INFO - 2021-09-06 11:45:51 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-06 11:45:51 --> Database Driver Class Initialized
ERROR - 2021-09-06 11:45:51 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 11:45:51 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 11:45:51 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-06 11:45:51 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-06 11:45:51 --> Model "Branch_model" initialized
ERROR - 2021-09-06 11:45:51 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\Users\Gopal Ghimire\Desktop\New folder\school\application\controllers\api\Branch.php 21
INFO - 2021-09-06 11:46:55 --> Config Class Initialized
INFO - 2021-09-06 11:46:55 --> Hooks Class Initialized
DEBUG - 2021-09-06 11:46:55 --> UTF-8 Support Enabled
INFO - 2021-09-06 11:46:55 --> Utf8 Class Initialized
INFO - 2021-09-06 11:46:55 --> URI Class Initialized
INFO - 2021-09-06 11:46:55 --> Router Class Initialized
INFO - 2021-09-06 11:46:55 --> Output Class Initialized
INFO - 2021-09-06 11:46:55 --> Security Class Initialized
DEBUG - 2021-09-06 11:46:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-06 11:46:55 --> CSRF cookie sent
INFO - 2021-09-06 11:46:55 --> Input Class Initialized
INFO - 2021-09-06 11:46:55 --> Language Class Initialized
INFO - 2021-09-06 11:46:55 --> Loader Class Initialized
INFO - 2021-09-06 11:46:55 --> Helper loaded: url_helper
INFO - 2021-09-06 11:46:55 --> Helper loaded: file_helper
INFO - 2021-09-06 11:46:55 --> Helper loaded: form_helper
INFO - 2021-09-06 11:46:55 --> Helper loaded: security_helper
INFO - 2021-09-06 11:46:55 --> Helper loaded: directory_helper
INFO - 2021-09-06 11:46:55 --> Helper loaded: general_helper
INFO - 2021-09-06 11:46:55 --> Database Driver Class Initialized
INFO - 2021-09-06 11:46:55 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-06 11:46:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-06 11:46:55 --> Pagination Class Initialized
INFO - 2021-09-06 11:46:55 --> XML-RPC Class Initialized
INFO - 2021-09-06 11:46:55 --> Form Validation Class Initialized
INFO - 2021-09-06 11:46:55 --> Upload Class Initialized
INFO - 2021-09-06 11:46:55 --> MY_Model class loaded
INFO - 2021-09-06 11:46:55 --> Model "Application_model" initialized
INFO - 2021-09-06 11:46:55 --> Controller Class Initialized
DEBUG - 2021-09-06 11:46:55 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-06 11:46:55 --> Helper loaded: inflector_helper
INFO - 2021-09-06 11:46:55 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-06 11:46:55 --> Database Driver Class Initialized
ERROR - 2021-09-06 11:46:55 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 11:46:55 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 11:46:55 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-06 11:46:55 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-06 11:46:55 --> Model "Branch_model" initialized
INFO - 2021-09-06 11:46:55 --> Final output sent to browser
DEBUG - 2021-09-06 11:46:55 --> Total execution time: 0.1104
INFO - 2021-09-06 11:58:38 --> Config Class Initialized
INFO - 2021-09-06 11:58:38 --> Hooks Class Initialized
DEBUG - 2021-09-06 11:58:38 --> UTF-8 Support Enabled
INFO - 2021-09-06 11:58:38 --> Utf8 Class Initialized
INFO - 2021-09-06 11:58:39 --> URI Class Initialized
INFO - 2021-09-06 11:58:39 --> Router Class Initialized
INFO - 2021-09-06 11:58:39 --> Output Class Initialized
INFO - 2021-09-06 11:58:39 --> Security Class Initialized
DEBUG - 2021-09-06 11:58:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-06 11:58:39 --> CSRF cookie sent
INFO - 2021-09-06 11:58:39 --> Input Class Initialized
INFO - 2021-09-06 11:58:39 --> Language Class Initialized
INFO - 2021-09-06 11:58:40 --> Loader Class Initialized
INFO - 2021-09-06 11:58:40 --> Helper loaded: url_helper
INFO - 2021-09-06 11:58:40 --> Helper loaded: file_helper
INFO - 2021-09-06 11:58:40 --> Helper loaded: form_helper
INFO - 2021-09-06 11:58:40 --> Helper loaded: security_helper
INFO - 2021-09-06 11:58:41 --> Helper loaded: directory_helper
INFO - 2021-09-06 11:58:41 --> Helper loaded: general_helper
INFO - 2021-09-06 11:58:41 --> Database Driver Class Initialized
INFO - 2021-09-06 11:58:43 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-06 11:58:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-06 11:58:43 --> Pagination Class Initialized
INFO - 2021-09-06 11:58:43 --> XML-RPC Class Initialized
INFO - 2021-09-06 11:58:43 --> Form Validation Class Initialized
INFO - 2021-09-06 11:58:43 --> Upload Class Initialized
INFO - 2021-09-06 11:58:43 --> MY_Model class loaded
INFO - 2021-09-06 11:58:43 --> Model "Application_model" initialized
INFO - 2021-09-06 11:58:43 --> Controller Class Initialized
DEBUG - 2021-09-06 11:58:43 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-06 11:58:44 --> Helper loaded: inflector_helper
INFO - 2021-09-06 11:58:44 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-06 11:58:44 --> Database Driver Class Initialized
ERROR - 2021-09-06 11:58:44 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 11:58:44 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 11:58:44 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-06 11:58:44 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-06 11:58:44 --> Model "Branch_model" initialized
INFO - 2021-09-06 11:58:44 --> Final output sent to browser
DEBUG - 2021-09-06 11:58:44 --> Total execution time: 5.9044
INFO - 2021-09-06 11:59:48 --> Config Class Initialized
INFO - 2021-09-06 11:59:48 --> Hooks Class Initialized
DEBUG - 2021-09-06 11:59:48 --> UTF-8 Support Enabled
INFO - 2021-09-06 11:59:48 --> Utf8 Class Initialized
INFO - 2021-09-06 11:59:48 --> URI Class Initialized
INFO - 2021-09-06 11:59:48 --> Router Class Initialized
INFO - 2021-09-06 11:59:48 --> Output Class Initialized
INFO - 2021-09-06 11:59:48 --> Security Class Initialized
DEBUG - 2021-09-06 11:59:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-06 11:59:48 --> CSRF cookie sent
INFO - 2021-09-06 11:59:48 --> Input Class Initialized
INFO - 2021-09-06 11:59:48 --> Language Class Initialized
INFO - 2021-09-06 11:59:48 --> Loader Class Initialized
INFO - 2021-09-06 11:59:48 --> Helper loaded: url_helper
INFO - 2021-09-06 11:59:48 --> Helper loaded: file_helper
INFO - 2021-09-06 11:59:48 --> Helper loaded: form_helper
INFO - 2021-09-06 11:59:48 --> Helper loaded: security_helper
INFO - 2021-09-06 11:59:48 --> Helper loaded: directory_helper
INFO - 2021-09-06 11:59:48 --> Helper loaded: general_helper
INFO - 2021-09-06 11:59:48 --> Database Driver Class Initialized
INFO - 2021-09-06 11:59:48 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-06 11:59:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-06 11:59:48 --> Pagination Class Initialized
INFO - 2021-09-06 11:59:48 --> XML-RPC Class Initialized
INFO - 2021-09-06 11:59:48 --> Form Validation Class Initialized
INFO - 2021-09-06 11:59:48 --> Upload Class Initialized
INFO - 2021-09-06 11:59:48 --> MY_Model class loaded
INFO - 2021-09-06 11:59:48 --> Model "Application_model" initialized
INFO - 2021-09-06 11:59:48 --> Controller Class Initialized
DEBUG - 2021-09-06 11:59:48 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-06 11:59:48 --> Helper loaded: inflector_helper
INFO - 2021-09-06 11:59:48 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-06 11:59:48 --> Database Driver Class Initialized
ERROR - 2021-09-06 11:59:48 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 11:59:48 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 11:59:48 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-06 11:59:48 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-06 11:59:48 --> Model "Branch_model" initialized
INFO - 2021-09-06 11:59:48 --> Final output sent to browser
DEBUG - 2021-09-06 11:59:48 --> Total execution time: 0.3104
INFO - 2021-09-06 12:20:50 --> Config Class Initialized
INFO - 2021-09-06 12:20:51 --> Hooks Class Initialized
DEBUG - 2021-09-06 12:20:51 --> UTF-8 Support Enabled
INFO - 2021-09-06 12:20:51 --> Utf8 Class Initialized
INFO - 2021-09-06 12:20:51 --> URI Class Initialized
INFO - 2021-09-06 12:20:51 --> Router Class Initialized
INFO - 2021-09-06 12:20:51 --> Output Class Initialized
INFO - 2021-09-06 12:20:51 --> Security Class Initialized
DEBUG - 2021-09-06 12:20:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-06 12:20:51 --> CSRF cookie sent
INFO - 2021-09-06 12:20:51 --> Input Class Initialized
INFO - 2021-09-06 12:20:51 --> Language Class Initialized
INFO - 2021-09-06 12:20:51 --> Loader Class Initialized
INFO - 2021-09-06 12:20:51 --> Helper loaded: url_helper
INFO - 2021-09-06 12:20:51 --> Helper loaded: file_helper
INFO - 2021-09-06 12:20:51 --> Helper loaded: form_helper
INFO - 2021-09-06 12:20:51 --> Helper loaded: security_helper
INFO - 2021-09-06 12:20:51 --> Helper loaded: directory_helper
INFO - 2021-09-06 12:20:52 --> Helper loaded: general_helper
INFO - 2021-09-06 12:20:52 --> Database Driver Class Initialized
INFO - 2021-09-06 12:20:52 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-06 12:20:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-06 12:20:52 --> Pagination Class Initialized
INFO - 2021-09-06 12:20:52 --> XML-RPC Class Initialized
INFO - 2021-09-06 12:20:52 --> Form Validation Class Initialized
INFO - 2021-09-06 12:20:52 --> Upload Class Initialized
INFO - 2021-09-06 12:20:53 --> MY_Model class loaded
INFO - 2021-09-06 12:20:53 --> Model "Application_model" initialized
INFO - 2021-09-06 12:20:53 --> Controller Class Initialized
DEBUG - 2021-09-06 12:20:53 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-06 12:20:53 --> Helper loaded: inflector_helper
INFO - 2021-09-06 12:20:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-06 12:20:53 --> Database Driver Class Initialized
ERROR - 2021-09-06 12:20:53 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 12:20:53 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 12:20:53 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-06 12:20:53 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-06 12:20:53 --> Model "Branch_model" initialized
INFO - 2021-09-06 12:20:53 --> Final output sent to browser
DEBUG - 2021-09-06 12:20:53 --> Total execution time: 2.3653
INFO - 2021-09-06 12:21:37 --> Config Class Initialized
INFO - 2021-09-06 12:21:37 --> Hooks Class Initialized
DEBUG - 2021-09-06 12:21:37 --> UTF-8 Support Enabled
INFO - 2021-09-06 12:21:37 --> Utf8 Class Initialized
INFO - 2021-09-06 12:21:37 --> URI Class Initialized
INFO - 2021-09-06 12:21:37 --> Router Class Initialized
INFO - 2021-09-06 12:21:37 --> Output Class Initialized
INFO - 2021-09-06 12:21:37 --> Security Class Initialized
DEBUG - 2021-09-06 12:21:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-06 12:21:37 --> CSRF cookie sent
INFO - 2021-09-06 12:21:37 --> Input Class Initialized
INFO - 2021-09-06 12:21:37 --> Language Class Initialized
INFO - 2021-09-06 12:21:37 --> Loader Class Initialized
INFO - 2021-09-06 12:21:37 --> Helper loaded: url_helper
INFO - 2021-09-06 12:21:37 --> Helper loaded: file_helper
INFO - 2021-09-06 12:21:37 --> Helper loaded: form_helper
INFO - 2021-09-06 12:21:37 --> Helper loaded: security_helper
INFO - 2021-09-06 12:21:37 --> Helper loaded: directory_helper
INFO - 2021-09-06 12:21:37 --> Helper loaded: general_helper
INFO - 2021-09-06 12:21:37 --> Database Driver Class Initialized
INFO - 2021-09-06 12:21:37 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-06 12:21:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-06 12:21:37 --> Pagination Class Initialized
INFO - 2021-09-06 12:21:37 --> XML-RPC Class Initialized
INFO - 2021-09-06 12:21:37 --> Form Validation Class Initialized
INFO - 2021-09-06 12:21:37 --> Upload Class Initialized
INFO - 2021-09-06 12:21:37 --> MY_Model class loaded
INFO - 2021-09-06 12:21:37 --> Model "Application_model" initialized
INFO - 2021-09-06 12:21:37 --> Controller Class Initialized
DEBUG - 2021-09-06 12:21:37 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-06 12:21:37 --> Helper loaded: inflector_helper
INFO - 2021-09-06 12:21:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-06 12:21:37 --> Database Driver Class Initialized
ERROR - 2021-09-06 12:21:37 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 12:21:37 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 12:21:37 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-06 12:21:37 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-06 12:21:37 --> Model "Branch_model" initialized
INFO - 2021-09-06 12:21:37 --> Final output sent to browser
DEBUG - 2021-09-06 12:21:37 --> Total execution time: 0.2346
INFO - 2021-09-06 12:22:48 --> Config Class Initialized
INFO - 2021-09-06 12:22:48 --> Hooks Class Initialized
DEBUG - 2021-09-06 12:22:48 --> UTF-8 Support Enabled
INFO - 2021-09-06 12:22:48 --> Utf8 Class Initialized
INFO - 2021-09-06 12:22:48 --> URI Class Initialized
INFO - 2021-09-06 12:22:48 --> Router Class Initialized
INFO - 2021-09-06 12:22:48 --> Output Class Initialized
INFO - 2021-09-06 12:22:48 --> Security Class Initialized
DEBUG - 2021-09-06 12:22:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-06 12:22:48 --> CSRF cookie sent
INFO - 2021-09-06 12:22:48 --> Input Class Initialized
INFO - 2021-09-06 12:22:48 --> Language Class Initialized
INFO - 2021-09-06 12:22:48 --> Loader Class Initialized
INFO - 2021-09-06 12:22:48 --> Helper loaded: url_helper
INFO - 2021-09-06 12:22:48 --> Helper loaded: file_helper
INFO - 2021-09-06 12:22:48 --> Helper loaded: form_helper
INFO - 2021-09-06 12:22:48 --> Helper loaded: security_helper
INFO - 2021-09-06 12:22:48 --> Helper loaded: directory_helper
INFO - 2021-09-06 12:22:48 --> Helper loaded: general_helper
INFO - 2021-09-06 12:22:48 --> Database Driver Class Initialized
INFO - 2021-09-06 12:22:48 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-06 12:22:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-06 12:22:48 --> Pagination Class Initialized
INFO - 2021-09-06 12:22:48 --> XML-RPC Class Initialized
INFO - 2021-09-06 12:22:48 --> Form Validation Class Initialized
INFO - 2021-09-06 12:22:48 --> Upload Class Initialized
INFO - 2021-09-06 12:22:48 --> MY_Model class loaded
INFO - 2021-09-06 12:22:48 --> Model "Application_model" initialized
INFO - 2021-09-06 12:22:48 --> Controller Class Initialized
DEBUG - 2021-09-06 12:22:48 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-06 12:22:48 --> Helper loaded: inflector_helper
INFO - 2021-09-06 12:22:48 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-06 12:22:48 --> Database Driver Class Initialized
ERROR - 2021-09-06 12:22:48 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 12:22:48 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 12:22:48 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-06 12:22:48 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-06 12:22:48 --> Model "Branch_model" initialized
INFO - 2021-09-06 12:22:48 --> Final output sent to browser
DEBUG - 2021-09-06 12:22:48 --> Total execution time: 0.1790
INFO - 2021-09-06 12:28:57 --> Config Class Initialized
INFO - 2021-09-06 12:28:57 --> Hooks Class Initialized
DEBUG - 2021-09-06 12:28:57 --> UTF-8 Support Enabled
INFO - 2021-09-06 12:28:57 --> Utf8 Class Initialized
INFO - 2021-09-06 12:28:57 --> URI Class Initialized
INFO - 2021-09-06 12:28:57 --> Router Class Initialized
INFO - 2021-09-06 12:28:57 --> Output Class Initialized
INFO - 2021-09-06 12:28:57 --> Security Class Initialized
DEBUG - 2021-09-06 12:28:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-06 12:28:57 --> CSRF cookie sent
INFO - 2021-09-06 12:28:57 --> Input Class Initialized
INFO - 2021-09-06 12:28:57 --> Language Class Initialized
INFO - 2021-09-06 12:28:57 --> Loader Class Initialized
INFO - 2021-09-06 12:28:57 --> Helper loaded: url_helper
INFO - 2021-09-06 12:28:57 --> Helper loaded: file_helper
INFO - 2021-09-06 12:28:57 --> Helper loaded: form_helper
INFO - 2021-09-06 12:28:57 --> Helper loaded: security_helper
INFO - 2021-09-06 12:28:57 --> Helper loaded: directory_helper
INFO - 2021-09-06 12:28:57 --> Helper loaded: general_helper
INFO - 2021-09-06 12:28:57 --> Database Driver Class Initialized
INFO - 2021-09-06 12:28:58 --> Session: Class initialized using 'database' driver.
INFO - 2021-09-06 12:28:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2021-09-06 12:28:58 --> Pagination Class Initialized
INFO - 2021-09-06 12:28:58 --> XML-RPC Class Initialized
INFO - 2021-09-06 12:28:58 --> Form Validation Class Initialized
INFO - 2021-09-06 12:28:58 --> Upload Class Initialized
INFO - 2021-09-06 12:28:58 --> MY_Model class loaded
INFO - 2021-09-06 12:28:58 --> Model "Application_model" initialized
INFO - 2021-09-06 12:28:58 --> Controller Class Initialized
DEBUG - 2021-09-06 12:28:58 --> Config file loaded: C:\Users\Gopal Ghimire\Desktop\New folder\school\application\config/rest.php
INFO - 2021-09-06 12:28:58 --> Helper loaded: inflector_helper
INFO - 2021-09-06 12:28:58 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2021-09-06 12:28:58 --> Database Driver Class Initialized
ERROR - 2021-09-06 12:28:59 --> Severity: Warning --> Illegal string offset 'cookie_secure' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 12:28:59 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 575
ERROR - 2021-09-06 12:28:59 --> Severity: Warning --> Illegal string offset 'csrf_protection' C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
ERROR - 2021-09-06 12:28:59 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\Users\Gopal Ghimire\Desktop\New folder\school\application\libraries\REST_Controller.php 576
INFO - 2021-09-06 12:28:59 --> Model "Branch_model" initialized
INFO - 2021-09-06 12:29:00 --> Final output sent to browser
DEBUG - 2021-09-06 12:29:00 --> Total execution time: 3.1331
